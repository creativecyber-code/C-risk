
/* eslint-disable no-restricted-globals */
const CACHE_NAME = 'creative-cyber-v1';
const URLS_TO_CACHE = [
  '/',
  '/index.html',
  '/manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(URLS_TO_CACHE))
  );
});

self.addEventListener('fetch', (event) => {
  // Network-first strategy for API calls (supabase)
  if (event.request.url.includes('supabase')) {
    event.respondWith(
      fetch(event.request).catch(() => {
        // Fallback or offline handling for API could go here
        return new Response(JSON.stringify({ error: 'Offline' }), { 
          headers: { 'Content-Type': 'application/json' } 
        });
      })
    );
    return;
  }

  // Stale-while-revalidate for static assets
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        const fetchPromise = fetch(event.request).then(
          (networkResponse) => {
            if (networkResponse && networkResponse.status === 200 && networkResponse.type === 'basic') {
              const responseToCache = networkResponse.clone();
              caches.open(CACHE_NAME).then((cache) => {
                cache.put(event.request, responseToCache);
              });
            }
            return networkResponse;
          }
        ).catch(() => {
             // If fetch fails, we might just return the cached response (already handled by the first return if it exists)
             // or return a fallback if no cache.
        });
        return response || fetchPromise;
      })
  );
});

self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
