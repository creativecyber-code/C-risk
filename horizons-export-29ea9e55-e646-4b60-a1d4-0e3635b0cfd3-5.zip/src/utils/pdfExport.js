
import jsPDF from 'jspdf';
import 'jspdf-autotable';

export const generateRemediationReport = (threats, filters = {}) => {
  const doc = new jsPDF();
  const date = new Date().toLocaleDateString();

  // Header
  doc.setFontSize(20);
  doc.setTextColor(40, 40, 40);
  doc.text('Remediation Plan Report', 14, 22);
  
  doc.setFontSize(11);
  doc.setTextColor(100, 100, 100);
  doc.text(`Generated on: ${date}`, 14, 30);
  doc.text(`Total Threats: ${threats.length}`, 14, 36);

  // Filter Summary if any
  let yPos = 45;
  if (Object.keys(filters).length > 0) {
    doc.setFontSize(10);
    doc.text('Applied Filters:', 14, yPos);
    yPos += 6;
    Object.entries(filters).forEach(([key, value]) => {
      if (value && value !== 'all') {
        doc.text(`- ${key.charAt(0).toUpperCase() + key.slice(1)}: ${value}`, 20, yPos);
        yPos += 5;
      }
    });
    yPos += 5;
  }

  // Table Data Preparation
  const tableColumn = ["Threat", "Severity", "Model", "STRIDE", "Status", "Owner", "Ext. Refs"];
  const tableRows = [];

  threats.forEach(threat => {
    const threatData = [
      threat.title || 'Untitled Threat',
      threat.risk_score ? Math.round(threat.risk_score) : 'N/A',
      threat.model_name || 'Unknown Model',
      threat.category || 'Uncategorized',
      threat.status || 'Open',
      threat.assigned_to_name || 'Unassigned',
      threat.external_refs ? Object.keys(threat.external_refs).join(', ') : '-'
    ];
    tableRows.push(threatData);
  });

  // Generate Table
  doc.autoTable({
    head: [tableColumn],
    body: tableRows,
    startY: yPos,
    theme: 'grid',
    headStyles: { fillColor: [79, 70, 229] }, // brand-600ish
    styles: { fontSize: 8, cellPadding: 3 },
    columnStyles: {
      0: { cellWidth: 50 }, // Threat
      2: { cellWidth: 30 }, // Model
      6: { cellWidth: 25 }  // Refs
    }
  });

  // Footer
  const pageCount = doc.internal.getNumberOfPages();
  for(let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.text('CreativeCyber Remediation Plan', 14, doc.internal.pageSize.height - 10);
    doc.text(`Page ${i} of ${pageCount}`, doc.internal.pageSize.width - 25, doc.internal.pageSize.height - 10);
  }

  // Save
  doc.save(`remediation_plan_${new Date().toISOString().split('T')[0]}.pdf`);
};
