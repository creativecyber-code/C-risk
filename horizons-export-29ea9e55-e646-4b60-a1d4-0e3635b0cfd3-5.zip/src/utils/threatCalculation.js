
import { BANKING_THREAT_LIBRARY } from '@/data/bankingThreatLibrary';

// Helper to check line intersection
export const getIntersection = (p1, p2, p3, p4) => {
  const d1 = (p2.x - p1.x) * (p4.y - p3.y) - (p2.y - p1.y) * (p4.x - p3.x);
  if (d1 === 0) return null;

  const u = ((p3.x - p1.x) * (p4.y - p3.y) - (p3.y - p1.y) * (p4.x - p3.x)) / d1;
  const v = ((p3.x - p1.x) * (p2.y - p1.y) - (p3.y - p1.y) * (p2.x - p1.x)) / d1;

  if (u >= 0 && u <= 1 && v >= 0 && v <= 1) {
    return {
      x: p1.x + u * (p2.x - p1.x),
      y: p1.y + u * (p2.y - p1.y)
    };
  }
  return null;
};

// Core logic to detect threats based on model geometry
export const calculateThreats = (elements, connections) => {
  const detectedThreats = [];
  const boundaries = elements.filter(el => el.type === 'boundary');
  
  connections.forEach(conn => {
    const fromEl = elements.find(el => el.id === conn.from);
    const toEl = elements.find(el => el.id === conn.to);
    if (!fromEl || !toEl) return;

    boundaries.forEach(boundary => {
      const boundaryWidth = 200; 
      const boundaryLeft = boundary.x - (boundaryWidth / 2);
      const boundaryRight = boundary.x + (boundaryWidth / 2);
      
      const intersection = getIntersection(
        { x: fromEl.x, y: fromEl.y },
        { x: toEl.x, y: toEl.y },
        { x: boundaryLeft, y: boundary.y },
        { x: boundaryRight, y: boundary.y }
      );

      if (intersection) {
        // Find relevant banking threats
        // In a real app, this logic would be more sophisticated based on element types
        // For this demo, we use a subset of the library for boundary violations
        const potentialRisks = BANKING_THREAT_LIBRARY.slice(0, 3); // Top 3 as examples

        detectedThreats.push({
          id: `threat-${conn.id}-${boundary.id}`,
          x: intersection.x,
          y: intersection.y,
          connectionId: conn.id,
          boundaryId: boundary.id,
          boundaryLabel: boundary.label || 'Trust Boundary',
          flowLabel: conn.label || 'Data Flow',
          risks: potentialRisks
        });
      }
    });
  });
  return detectedThreats;
};
