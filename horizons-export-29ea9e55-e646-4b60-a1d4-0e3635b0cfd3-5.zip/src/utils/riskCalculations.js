
// Utility functions for Risk Calculation (CVSS Style & FAIR)

export const RISK_LEVELS = {
  CRITICAL: { label: 'Critical', color: 'bg-red-500', text: 'text-red-600', min: 9.0 },
  HIGH: { label: 'High', color: 'bg-orange-500', text: 'text-orange-600', min: 7.0 },
  MEDIUM: { label: 'Medium', color: 'bg-yellow-500', text: 'text-yellow-600', min: 4.0 },
  LOW: { label: 'Low', color: 'bg-green-500', text: 'text-green-600', min: 0.0 }
};

export const getRiskLevel = (score) => {
  if (score >= RISK_LEVELS.CRITICAL.min) return RISK_LEVELS.CRITICAL;
  if (score >= RISK_LEVELS.HIGH.min) return RISK_LEVELS.HIGH;
  if (score >= RISK_LEVELS.MEDIUM.min) return RISK_LEVELS.MEDIUM;
  return RISK_LEVELS.LOW;
};

// FAIR Calculation Logic
export const calculateFAIR = (tef, vulnerabilityPercentage, lossMagnitude) => {
  // TEF: How many times per year the threat event occurs
  // Vulnerability: Probability (0-1) that the threat event results in a loss
  // Loss Magnitude: Financial loss per successful event
  
  const vulnProb = vulnerabilityPercentage / 100;
  const ale = tef * vulnProb * lossMagnitude;
  
  return parseFloat(ale.toFixed(2));
};

export const formatCurrency = (amount) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

export const calculateCVSS = (vectors) => {
  // Simplified CVSS-like calculation
  // Factors range 0-10
  const impactFactors = [
    vectors.confidentiality || 5,
    vectors.integrity || 5,
    vectors.availability || 5
  ];
  
  const likelihoodFactors = [
    vectors.skill || 5,
    vectors.motivation || 5,
    vectors.access || 5
  ];

  const impactScore = impactFactors.reduce((a, b) => a + b, 0) / 3;
  const likelihoodScore = likelihoodFactors.reduce((a, b) => a + b, 0) / 3;
  
  // Base Risk Score
  let riskScore = (impactScore * 0.6) + (likelihoodScore * 0.4);
  
  // Adjust for Exploitability if present (multiplier)
  if (vectors.exploitability) {
    riskScore = riskScore * (1 + (vectors.exploitability / 100)); // up to 10% boost
  }

  // Cap at 10
  riskScore = Math.min(10, Math.max(0, riskScore));

  return {
    impact: parseFloat(impactScore.toFixed(1)),
    likelihood: parseFloat(likelihoodScore.toFixed(1)),
    score: parseFloat(riskScore.toFixed(1))
  };
};

export const calculateOverallRisk = (assessments, businessContext = 1.0) => {
  if (!assessments || !assessments.length) return 0;
  
  // Weighted average where higher risks have more weight
  const totalWeight = assessments.reduce((acc, curr) => acc + (curr.risk_score || 0), 0);
  const averageRisk = totalWeight / assessments.length;
  
  // Business context multiplier (e.g. Critical Asset = 1.2x)
  let overall = averageRisk * businessContext;
  return Math.min(10, parseFloat(overall.toFixed(1)));
};
