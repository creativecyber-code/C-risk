
/**
 * AI/NLP Logic Engine for C-RISK
 * Simulates Context-Aware Analysis without external API dependencies.
 */

const KEYWORD_MAPPINGS = {
  biometric: {
    keywords: ['video', 'face', 'fingerprint', 'retina', 'biometric', 'kyc', 'onboard', 'aadhaar', 'uidai', 'selfie'],
    class: 'SPII (Biometric)',
    risk_score: 9.5,
    cia: { c: 'High', i: 'High', a: 'High' }
  },
  financial: {
    keywords: ['payment', 'upi', 'neft', 'rtgs', 'transaction', 'ledger', 'wallet', 'money', 'fund', 'credit card', 'debit', 'pan'],
    class: 'Financial (PCI/Non-PCI)',
    risk_score: 8.0,
    cia: { c: 'High', i: 'High', a: 'Medium' }
  },
  cloud: {
    keywords: ['aws', 'azure', 'gcp', 'cloud', 'hosting', 'saas', 'serverless', 'bucket', 's3', 'lambda'],
    class: 'Infrastructure',
    risk_score: 6.0,
    cia: { c: 'Medium', i: 'Medium', a: 'High' }
  },
  identity: {
    keywords: ['email', 'phone', 'mobile', 'address', 'dob', 'name', 'passport', 'voter'],
    class: 'PII (Identity)',
    risk_score: 7.0,
    cia: { c: 'High', i: 'Medium', a: 'Low' }
  },
  restricted_geo: {
    keywords: ['china', 'russia', 'cross-border', 'foreign', 'offshore', 'us-east', 'eu-west'],
    class: 'Cross-Border',
    risk_score: 8.5,
    cia: { c: 'High', i: 'High', a: 'High' }
  }
};

const REGULATIONS = [
  {
    id: 'RBI-PAY',
    name: 'RBI Master Direction on Digital Payment Security Controls',
    triggers: ['financial', 'upi', 'payment', 'wallet'],
    description: 'Mandatory for any application handling digital payments.'
  },
  {
    id: 'RBI-OUT',
    name: 'RBI Guidelines on Managing Risks in Outsourcing',
    triggers: ['cloud', 'saas', 'aws', 'azure', 'vendor'],
    description: 'Applicable when critical functions are outsourced to cloud/vendors.'
  },
  {
    id: 'UIDAI-ADV',
    name: 'UIDAI Aadhaar Data Vault (ADV) Circulars',
    triggers: ['aadhaar', 'biometric', 'uidai'],
    description: 'Strict isolation required for Aadhaar numbers and reference keys.'
  },
  {
    id: 'RBI-VCIP',
    name: 'RBI Master Direction on KYC (V-CIP)',
    triggers: ['video', 'kyc', 'face', 'onboard'],
    description: 'Video Customer Identification Process standards.'
  },
  {
    id: 'DPDP-2023',
    name: 'Digital Personal Data Protection Act 2023',
    triggers: ['biometric', 'identity', 'email', 'phone'],
    description: 'Consent management and notice requirements for PII.'
  }
];

export const aiLogic = {
  analyzeText(text) {
    if (!text) return { tags: [], classifications: [], score: 0, summary: '' };
    
    const lowerText = text.toLowerCase();
    const foundTags = new Set();
    const foundClasses = new Set();
    let maxRisk = 0;
    let cia = { c: 'Low', i: 'Low', a: 'Low' };

    // Scan Keywords
    Object.entries(KEYWORD_MAPPINGS).forEach(([key, rule]) => {
      const matches = rule.keywords.filter(k => lowerText.includes(k));
      if (matches.length > 0) {
        matches.forEach(m => foundTags.add(m));
        foundClasses.add(rule.class);
        if (rule.risk_score > maxRisk) {
          maxRisk = rule.risk_score;
          cia = rule.cia; // Take CIA of highest risk element
        }
      }
    });

    // Determine Confidence
    const confidence = Math.min(0.98, 0.5 + (foundTags.size * 0.1));

    return {
      keywords: Array.from(foundTags),
      classifications: Array.from(foundClasses),
      riskScore: maxRisk,
      ciaLevels: cia,
      confidence: confidence
    };
  },

  recommendRegulations(tags) {
    const relevantRegs = REGULATIONS.filter(reg => {
      return reg.triggers.some(trigger => tags.includes(trigger));
    });
    return relevantRegs;
  },

  detectVendorRisk(vendorName) {
    const EMPANELLED = ['microsoft', 'aws', 'google', 'oracle', 'tcs', 'infosys'];
    const HIGH_RISK = ['zoom', 'tiktok', 'wechat', 'kaspersky'];
    
    const lower = vendorName.toLowerCase();
    
    if (EMPANELLED.some(v => lower.includes(v))) {
      return { status: 'Empanelled', tier: 'Tier 1', action: 'Fast Track' };
    }
    if (HIGH_RISK.some(v => lower.includes(v))) {
      return { status: 'High Risk', tier: 'Restricted', action: 'Enhanced Due Diligence' };
    }
    return { status: 'Unknown', tier: 'Tier 3', action: 'Full Assessment' };
  }
};
