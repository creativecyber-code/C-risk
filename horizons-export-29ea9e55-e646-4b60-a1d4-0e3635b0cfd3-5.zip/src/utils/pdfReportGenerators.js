
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { LOGO_URL, COMPANY_NAME } from '@/lib/constants';

// Helper to load image as base64
const getDataUrl = (url) => {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'Anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = (e) => {
        console.warn("Failed to load image for PDF", e);
        resolve(null);
    };
    img.src = url;
  });
};

const setupDocHeader = async (doc, title, organizationName) => {
    const pageWidth = doc.internal.pageSize.width;
    const pageHeight = doc.internal.pageSize.height;
    const margin = 14;

    // Load Logo
    let logoData = null;
    try {
        logoData = await getDataUrl(LOGO_URL);
    } catch (e) {
        console.warn("Failed to load logo", e);
    }

    if (logoData) {
        doc.addImage(logoData, 'PNG', margin, 10, 40, 16);
    } else {
        doc.setFontSize(22);
        doc.setTextColor(30, 64, 175);
        doc.setFont(undefined, 'bold');
        doc.text(COMPANY_NAME, margin, 22);
    }

    doc.setFontSize(18);
    doc.setTextColor(15, 23, 42);
    doc.setFont(undefined, 'bold');
    doc.text(title, pageWidth - margin, 20, { align: 'right' });

    doc.setFontSize(10);
    doc.setFont(undefined, 'normal');
    doc.setTextColor(100, 116, 139);
    const dateStr = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    doc.text(`Generated for ${organizationName} • ${dateStr}`, pageWidth - margin, 26, { align: 'right' });

    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.5);
    doc.line(margin, 35, pageWidth - margin, 35);

    return { margin, startY: 45, pageWidth, pageHeight };
};

const addFooter = (doc, pageNumber, pageHeight, margin, pageWidth) => {
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, pageHeight - 15, pageWidth - margin, pageHeight - 15);
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text(`${COMPANY_NAME} Platform • Confidential`, margin, pageHeight - 10);
    doc.text(`Page ${pageNumber}`, pageWidth - margin, pageHeight - 10, { align: 'right' });
};

// --- SOC 2 Report Generator ---
export const generateSOC2Report = async (organizationName = "Acme Corp") => {
    const doc = new jsPDF();
    const { margin, startY, pageWidth, pageHeight } = await setupDocHeader(doc, "SOC 2 Type II Readiness Report", organizationName);
    let yPos = startY;

    // Executive Summary
    doc.setFontSize(14);
    doc.setTextColor(30, 41, 59);
    doc.setFont(undefined, 'bold');
    doc.text("1. Executive Summary", margin, yPos);
    yPos += 8;
    
    doc.setFontSize(10);
    doc.setFont(undefined, 'normal');
    doc.text("This report details the organization's readiness for SOC 2 Type II compliance, focusing on Security, Availability, and Confidentiality trust principles.", margin, yPos, { maxWidth: pageWidth - (margin * 2) });
    yPos += 15;

    // Status Overview
    const statusData = [
        ["Trust Principle", "Status", "Controls Met", "Gaps"],
        ["Security (Common Criteria)", "On Track", "85/92", "7"],
        ["Availability", "At Risk", "12/24", "12"],
        ["Confidentiality", "On Track", "18/20", "2"],
        ["Processing Integrity", "N/A", "-", "-"],
        ["Privacy", "N/A", "-", "-"]
    ];

    autoTable(doc, {
        startY: yPos,
        head: [statusData[0]],
        body: statusData.slice(1),
        theme: 'grid',
        headStyles: { fillColor: [30, 41, 59] },
    });
    
    yPos = doc.lastAutoTable.finalY + 15;

    // Detailed Gaps
    doc.setFontSize(14);
    doc.setFont(undefined, 'bold');
    doc.text("2. Critical Gap Analysis", margin, yPos);
    yPos += 8;

    const gapData = [
        ["CC6.1", "Logical Access", "MFA not enforced for all administrative accounts."],
        ["A1.2", "Env. Protection", "Disaster recovery plan not tested in last 12 months."],
        ["CC7.2", "Risk Assessment", "Vendor risk assessment process is manual and incomplete."]
    ];

    autoTable(doc, {
        startY: yPos,
        head: [["Ref", "Area", "Finding"]],
        body: gapData,
        theme: 'striped',
        headStyles: { fillColor: [185, 28, 28] }, // Red
    });

    addFooter(doc, 1, pageHeight, margin, pageWidth);
    doc.save(`SOC2_Report_${organizationName.replace(/\s+/g, '_')}.pdf`);
};

// --- GDPR Report Generator ---
export const generateGDPRReport = async (organizationName = "Acme Corp") => {
    const doc = new jsPDF();
    const { margin, startY, pageWidth, pageHeight } = await setupDocHeader(doc, "GDPR Compliance Report", organizationName);
    let yPos = startY;

    doc.setFontSize(14);
    doc.setTextColor(30, 41, 59);
    doc.setFont(undefined, 'bold');
    doc.text("1. Compliance Overview", margin, yPos);
    yPos += 10;

    const kpiData = [
        ["Overall Score", "Data Mapping", "Consent Mgmt", "Breach Response"],
        ["82%", "95%", "70%", "80%"]
    ];

    autoTable(doc, {
        startY: yPos,
        head: [kpiData[0]],
        body: kpiData.slice(1),
        theme: 'grid',
        headStyles: { fillColor: [37, 99, 235] },
    });
    yPos = doc.lastAutoTable.finalY + 15;

    doc.setFontSize(14);
    doc.setFont(undefined, 'bold');
    doc.text("2. Article-Level Compliance", margin, yPos);
    yPos += 8;

    const articles = [
        ["Art. 6", "Lawfulness of Processing", "Compliant", "All processing activities have defined legal basis."],
        ["Art. 15", "Right of Access", "Partial", "Automated export tools pending for archived data."],
        ["Art. 17", "Right to Erasure", "Compliant", "Deletion workflows tested and verified."],
        ["Art. 32", "Security of Processing", "Compliant", "Encryption at rest and in transit verified."]
    ];

    autoTable(doc, {
        startY: yPos,
        head: [["Article", "Title", "Status", "Notes"]],
        body: articles,
        theme: 'striped',
    });

    addFooter(doc, 1, pageHeight, margin, pageWidth);
    doc.save(`GDPR_Report_${organizationName.replace(/\s+/g, '_')}.pdf`);
};

// --- HIPAA Report Generator ---
export const generateHIPAAReport = async (organizationName = "Acme Corp") => {
    const doc = new jsPDF();
    const { margin, startY, pageWidth, pageHeight } = await setupDocHeader(doc, "HIPAA Security Rule Report", organizationName);
    let yPos = startY;

    doc.setFontSize(14);
    doc.setTextColor(30, 41, 59);
    doc.setFont(undefined, 'bold');
    doc.text("1. ePHI Environment Analysis", margin, yPos);
    yPos += 10;

    doc.setFontSize(10);
    doc.setFont(undefined, 'normal');
    doc.text("Assessment of safeguards for electronic Protected Health Information (ePHI).", margin, yPos);
    yPos += 10;

    const safeguards = [
        ["Administrative", "Risk Analysis (164.308(a)(1)(ii)(A))", "Compliant"],
        ["Administrative", "Workforce Security (164.308(a)(3))", "Review Needed"],
        ["Physical", "Facility Access (164.310(a)(1))", "Compliant"],
        ["Technical", "Access Control (164.312(a)(1))", "Compliant"],
        ["Technical", "Audit Controls (164.312(b))", "Action Required"]
    ];

    autoTable(doc, {
        startY: yPos,
        head: [["Category", "Safeguard Standard", "Status"]],
        body: safeguards,
        theme: 'grid',
        headStyles: { fillColor: [13, 148, 136] }, // Teal
    });
    
    yPos = doc.lastAutoTable.finalY + 15;
    
    doc.setFontSize(14);
    doc.setFont(undefined, 'bold');
    doc.text("2. Findings & Recommendations", margin, yPos);
    yPos += 8;

    const findings = [
        ["High", "Audit logs are not centrally collected for legacy databases containing ePHI."],
        ["Medium", "Termination procedures for remote employees need formal documentation."]
    ];

    autoTable(doc, {
        startY: yPos,
        head: [["Priority", "Finding"]],
        body: findings,
        theme: 'plain',
    });

    addFooter(doc, 1, pageHeight, margin, pageWidth);
    doc.save(`HIPAA_Report_${organizationName.replace(/\s+/g, '_')}.pdf`);
};

// --- PCI-DSS Report Generator ---
export const generatePCIDSSReport = async (organizationName = "Acme Corp") => {
    const doc = new jsPDF();
    const { margin, startY, pageWidth, pageHeight } = await setupDocHeader(doc, "PCI-DSS v4.0 Readiness Report", organizationName);
    let yPos = startY;

    doc.setFontSize(14);
    doc.setTextColor(30, 41, 59);
    doc.setFont(undefined, 'bold');
    doc.text("1. Cardholder Data Environment (CDE)", margin, yPos);
    yPos += 10;
    
    const requirements = [
        ["Req 1", "Install/maintain network security controls", "Compliant"],
        ["Req 3", "Protect stored account data", "Compliant"],
        ["Req 4", "Protect cardholder data with strong cryptography", "Compliant"],
        ["Req 8", "Identify users and authenticate access", "Partial Fail"],
        ["Req 11", "Test security of systems and networks", "Compliant"]
    ];

    autoTable(doc, {
        startY: yPos,
        head: [["Requirement", "Description", "Status"]],
        body: requirements,
        theme: 'grid',
        headStyles: { fillColor: [180, 83, 9] }, // Amber/Orange
    });

    yPos = doc.lastAutoTable.finalY + 15;

    doc.setFontSize(14);
    doc.setFont(undefined, 'bold');
    doc.text("2. Remediation Plan", margin, yPos);
    yPos += 8;
    
    const remediation = [
        ["Req 8.3.6", "Password complexity rules do not meet v4.0 standards (length < 12 chars).", "Update IAM policy."],
        ["Req 12.10", "Incident response plan needs annual tabletop exercise.", "Schedule drill for Q4."]
    ];

    autoTable(doc, {
        startY: yPos,
        head: [["Reference", "Gap", "Action Plan"]],
        body: remediation,
        theme: 'striped',
    });

    addFooter(doc, 1, pageHeight, margin, pageWidth);
    doc.save(`PCI_DSS_Report_${organizationName.replace(/\s+/g, '_')}.pdf`);
};
