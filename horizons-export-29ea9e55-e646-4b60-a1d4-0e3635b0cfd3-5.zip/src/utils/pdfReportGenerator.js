
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { LOGO_URL, COMPANY_NAME } from '@/lib/constants';

// Helper to load image as base64
const getDataUrl = (url) => {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'Anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = (e) => {
        console.warn("Failed to load image for PDF", e);
        resolve(null);
    };
    img.src = url;
  });
};

export const generateComprehensiveReport = async (data, organizationName = "Acme Corp") => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.width;
  const pageHeight = doc.internal.pageSize.height;
  const margin = 14;
  let yPos = 20;

  // --- Load Logos ---
  const logoUrl = LOGO_URL; 
  let logoData = null;
  try {
      logoData = await getDataUrl(logoUrl);
  } catch (e) {
      console.warn("Failed to load logo", e);
  }

  // --- Header Function ---
  const printHeader = (pageNumber) => {
    // Add Logo if available
    if (logoData) {
      // Dimensions: x, y, width, height
      // Adjusted aspect ratio for the specific Wix logo
      doc.addImage(logoData, 'PNG', margin, 10, 40, 16); 
    } else {
      // Fallback text logo if image fails
      doc.setFontSize(22);
      doc.setTextColor(30, 64, 175); // Blue
      doc.setFont(undefined, 'bold');
      doc.text(COMPANY_NAME, margin, 22);
    }
    
    // Title aligned right
    doc.setFontSize(18);
    doc.setTextColor(15, 23, 42); // slate-900
    doc.setFont(undefined, 'bold');
    doc.text("Risk Assessment Report", pageWidth - margin, 20, { align: 'right' });
    
    // Subtitle / Date
    doc.setFontSize(10);
    doc.setFont(undefined, 'normal');
    doc.setTextColor(100, 116, 139); // slate-500
    const dateStr = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    doc.text(`Generated for ${organizationName} • ${dateStr}`, pageWidth - margin, 26, { align: 'right' });
    
    // Divider
    doc.setDrawColor(226, 232, 240); // slate-200
    doc.setLineWidth(0.5);
    doc.line(margin, 35, pageWidth - margin, 35);
    
    // Reset Y
    return 45;
  };

  const printFooter = (pageNumber) => {
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, pageHeight - 15, pageWidth - margin, pageHeight - 15);
    
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184); // slate-400
    
    // Footer Logo/Text
    doc.text(`${COMPANY_NAME} Platform • Confidential`, margin, pageHeight - 10);
    doc.text(`Page ${pageNumber}`, pageWidth - margin, pageHeight - 10, { align: 'right' });
  };

  // --- Page 1: Executive Summary ---
  yPos = printHeader(1);
  
  doc.setFontSize(14);
  doc.setTextColor(30, 41, 59);
  doc.setFont(undefined, 'bold');
  doc.text("1. Executive Summary", margin, yPos);
  yPos += 10;

  // KPI Boxes (Simplified textual representation for PDF)
  // Adjusted: Removed Financial Exposure as requested
  const kpiY = yPos;
  const kpiWidth = (pageWidth - (margin * 2) - 10) / 3; // 3 KPIs instead of 4
  
  const drawKPI = (x, title, value, subtext, color = [30, 41, 59]) => {
    doc.setFillColor(248, 250, 252); // slate-50
    doc.setDrawColor(226, 232, 240); // slate-200
    doc.roundedRect(x, kpiY, kpiWidth, 30, 2, 2, 'FD');
    
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.setFont(undefined, 'normal');
    doc.text(title, x + 3, kpiY + 8);
    
    doc.setFontSize(12);
    doc.setTextColor(...color);
    doc.setFont(undefined, 'bold');
    doc.text(String(value), x + 3, kpiY + 18);
    
    doc.setFont(undefined, 'normal');
    doc.setFontSize(7);
    doc.setTextColor(148, 163, 184);
    doc.text(subtext, x + 3, kpiY + 25);
  };

  const summary = data?.summary || {};
  const businessImpact = data?.businessImpact || {};
  const threats = data?.threats || [];
  const complianceData = data?.complianceData || [];

  // KPI 1: Risk Score
  drawKPI(margin, "Risk Score", summary.riskScore || "0", "Scale 1-10", [234, 88, 12]);
  
  // KPI 2: Compliance
  drawKPI(margin + kpiWidth + 5, "Compliance", `${summary.complianceScore || 0}%`, "Avg Score", [37, 99, 235]);
  
  // KPI 3: Active Threats
  drawKPI(margin + (kpiWidth + 5) * 2, "Active Threats", String(summary.activeThreats || 0), "Critical Items", [220, 38, 38]);

  yPos += 40;

  // Business Impact Table
  doc.setFontSize(12);
  doc.setTextColor(30, 41, 59);
  doc.setFont(undefined, 'bold');
  doc.text("2. Business Impact Analysis", margin, yPos);
  yPos += 6;

  const impactData = [
    ["Compliance", businessImpact.compliance || "N/A"],
    ["Reputation", businessImpact.reputation || "N/A"],
    ["Operational", businessImpact.operational || "N/A"]
  ];

  autoTable(doc, {
    startY: yPos,
    head: [['Category', 'Potential Impact']],
    body: impactData,
    theme: 'grid',
    headStyles: { fillColor: [15, 23, 42] }, // slate-900
    styles: { fontSize: 9, cellPadding: 3 },
    columnStyles: { 0: { cellWidth: 40, fontStyle: 'bold' } }
  });

  yPos = doc.lastAutoTable.finalY + 15;

  printFooter(1);

  // --- Page 2: Risk Analysis ---
  doc.addPage();
  yPos = printHeader(2);
  
  doc.setFontSize(14);
  doc.setTextColor(30, 41, 59);
  doc.setFont(undefined, 'bold');
  doc.text("3. Detailed Threat Analysis", margin, yPos);
  yPos += 10;

  // Added ALE column to report
  const threatData = threats.map(t => [
    t.title,
    t.severity,
    t.likelihood,
    t.impact,
    t.ale ? `$${Number(t.ale).toLocaleString()}` : '$0', // Display ALE
    t.status
  ]);

  autoTable(doc, {
    startY: yPos,
    head: [['Threat', 'Severity', 'Like.', 'Imp.', 'Est. ALE', 'Status']],
    body: threatData,
    theme: 'striped',
    headStyles: { fillColor: [220, 38, 38] }, // red-600
    styles: { fontSize: 8 },
    columnStyles: { 
        0: { cellWidth: 50 },
        4: { cellWidth: 25, halign: 'right' }
    }
  });

  printFooter(2);

  // --- Page 3: Compliance & Mitigation ---
  doc.addPage();
  yPos = printHeader(3);
  
  // Compliance Section
  doc.setFontSize(14);
  doc.text("4. Compliance Status", margin, yPos);
  yPos += 10;

  const complianceRows = complianceData.map(c => [
    c.name,
    `${c.score}%`,
    c.status,
    c.gap
  ]);

  autoTable(doc, {
    startY: yPos,
    head: [['Framework', 'Score', 'Status', 'Critical Gap']],
    body: complianceRows,
    theme: 'grid',
    headStyles: { fillColor: [37, 99, 235] }, // blue-600
    styles: { fontSize: 9 }
  });

  printFooter(3);

  // Save the PDF
  doc.save(`Risk_Assessment_${organizationName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`);
};
