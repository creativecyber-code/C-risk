
export const demoCredentials = [
  {
    org: "HDFC Bank Ltd",
    industry: "Finance",
    users: [
      { role: "CISO / Admin", name: "Rajesh Kumar", email: "ciso@hdfc.com", password: "P@ssw0rd@123" },
      { role: "Compliance / Auditor", name: "Suresh Menon", email: "compliance@hdfc.com", password: "P@ssw0rd@123" },
      { role: "Product / Architect", name: "Priya Sharma", email: "product@hdfc.com", password: "P@ssw0rd@123" }
    ]
  },
  {
    org: "ICICI Bank Ltd",
    industry: "Finance",
    users: [
      { role: "CISO / Admin", name: "Vikram Singh", email: "ciso@icici.com", password: "P@ssw0rd@123" },
      { role: "Compliance / Auditor", name: "Anita Desai", email: "compliance@icici.com", password: "P@ssw0rd@123" },
      { role: "Product / Architect", name: "Rahul Verma", email: "product@icici.com", password: "P@ssw0rd@123" }
    ]
  },
  {
    org: "Axis Bank Ltd",
    industry: "Finance",
    users: [
      { role: "CISO / Admin", name: "Amit Patel", email: "ciso@axis.com", password: "P@ssw0rd@123" },
      { role: "Compliance / Auditor", name: "Meera Reddy", email: "compliance@axis.com", password: "P@ssw0rd@123" },
      { role: "Product / Architect", name: "Karan Johar", email: "product@axis.com", password: "P@ssw0rd@123" }
    ]
  }
];
