
export const COMPLIANCE_STANDARDS = {
  NIST_CSF: {
    name: "NIST CSF 2.0",
    controls: [
      { id: "GV.OC-01", name: "Organizational Context" },
      { id: "GV.RM-01", name: "Risk Management Strategy" },
      { id: "PR.AA-01", name: "Identity Management" },
      { id: "PR.AA-02", name: "Access Control" },
      { id: "PR.DS-01", name: "Data-at-Rest Protection" },
      { id: "PR.DS-02", name: "Data-in-Transit Protection" },
      { id: "DE.AE-01", name: "Anomalies Detection" },
      { id: "RS.MA-01", name: "Incident Mitigation" }
    ]
  },
  ISO_27001: {
    name: "ISO 27001:2022",
    controls: [
      { id: "A.5.1", name: "Policies for information security" },
      { id: "A.5.15", name: "Access control" },
      { id: "A.8.2", name: "Privileged access rights" },
      { id: "A.8.20", name: "Networks security" },
      { id: "A.8.24", name: "Use of cryptography" },
      { id: "A.8.26", name: "Application security requirements" }
    ]
  },
  PCI_DSS: {
    name: "PCI DSS v4.0",
    controls: [
      { id: "1.1.2", name: "Network Security Controls" },
      { id: "3.2.1", name: "SAD Storage" },
      { id: "8.2.1", name: "Strong Authentication" },
      { id: "10.2.1", name: "Audit Logs" },
      { id: "12.3.1", name: "Risk Analysis" }
    ]
  },
  RBI_CS: {
    name: "RBI Cyber Security Framework",
    controls: [
      { id: "RBI.AN-1", name: "Network Security" },
      { id: "RBI.ID-1", name: "User Access Control" },
      { id: "RBI.DA-1", name: "Data Leak Prevention" },
      { id: "RBI.AU-1", name: "Audit Trails" }
    ]
  }
};
