
// Comprehensive library of banking-specific threats, controls, and risks for the templates.
// This acts as a centralized repository for banking domain knowledge used in the templates.

export const BANKING_THREAT_LIBRARY = {
  digitalBanking: {
    threats: [
      {
        id: 'tb-db-001',
        title: 'Account Takeover (ATO) via Credential Stuffing',
        severity: 'Critical',
        description: 'Attackers use stolen credentials from other breaches to gain unauthorized access to customer accounts.',
        mitigation: 'Implement MFA, rate limiting, and behavioral biometrics.',
        category: 'Authentication'
      },
      {
        id: 'tb-db-002',
        title: 'Man-in-the-Middle (MitM) Attacks on Mobile App',
        severity: 'High',
        description: 'Interception of communication between the mobile app and backend servers, potentially stealing session tokens or sensitive data.',
        mitigation: 'Implement Certificate Pinning and strong TLS configuration.',
        category: 'Network Security'
      },
      {
        id: 'tb-db-003',
        title: 'UPI Payment Fraud via Social Engineering',
        severity: 'High',
        description: 'Users tricked into approving collect requests or scanning malicious QR codes.',
        mitigation: 'Implement transaction limits, biometric confirmation for high-value transactions, and user awareness prompts.',
        category: 'Fraud'
      }
    ],
    controls: [
      { id: 'cb-db-001', code: 'AUTH-MFA', name: 'Multi-Factor Authentication', description: 'Mandatory MFA for login and transaction signing.' },
      { id: 'cb-db-002', code: 'APP-PIN', name: 'Certificate Pinning', description: 'Pinning server certificates in mobile application to prevent MitM.' },
      { id: 'cb-db-003', code: 'TXN-MON', name: 'Real-time Transaction Monitoring', description: 'AI-driven analysis of transaction patterns to detect anomalies.' }
    ],
    mappings: {
      'RBI': ['Annex 1.2', 'Annex 2.1'],
      'PCI-DSS': ['Requirement 8.3'],
      'NIST': ['AC-2', 'IA-2']
    }
  },
  cbs: {
    threats: [
      {
        id: 'tb-cbs-001',
        title: 'Unauthorized Direct Database Access',
        severity: 'Critical',
        description: 'Insider or attacker bypassing application logic to query or modify the CBS database directly.',
        mitigation: 'Implement Database Activity Monitoring (DAM) and strict privileged access management (PAM).',
        category: 'Database Security'
      },
      {
        id: 'tb-cbs-002',
        title: 'Batch Job Manipulation',
        severity: 'High',
        description: 'Tampering with end-of-day batch processing files to alter interest calculations or balances.',
        mitigation: 'Implement file integrity monitoring (FIM) and digital signatures for batch files.',
        category: 'Integrity'
      }
    ],
    controls: [
      { id: 'cb-cbs-001', code: 'DB-PAM', name: 'Privileged Access Management', description: 'Strict control and monitoring of DBA access.' },
      { id: 'cb-cbs-002', code: 'FIM-BATCH', name: 'File Integrity Monitoring', description: 'Monitoring critical batch files for unauthorized changes.' }
    ]
  },
  openBanking: {
    threats: [
      {
        id: 'tb-api-001',
        title: 'Broken Object Level Authorization (BOLA)',
        severity: 'Critical',
        description: 'API endpoints allowing access to resources of other users by manipulating ID parameters.',
        mitigation: 'Implement strict ownership checks on every object access.',
        category: 'API Security'
      },
      {
        id: 'tb-api-002',
        title: 'OAuth Token Theft',
        severity: 'High',
        description: 'Stealing access tokens to impersonate users or third-party providers (TPPs).',
        mitigation: 'Use short-lived tokens, mutual TLS (mTLS) for TPPs, and token binding.',
        category: 'Authorization'
      }
    ],
    controls: [
      { id: 'cb-api-001', code: 'API-GW', name: 'API Gateway Security', description: 'Rate limiting, input validation, and JWT verification at the edge.' },
      { id: 'cb-api-002', code: 'MTLS-TPP', name: 'Mutual TLS for TPPs', description: 'Mandatory mTLS for all third-party provider connections.' }
    ]
  },
  payments: {
    threats: [
      {
        id: 'tb-pay-001',
        title: 'SWIFT/RTGS Message Tampering',
        severity: 'Critical',
        description: 'Modification of payment instruction messages in transit or at rest before processing.',
        mitigation: 'End-to-end message signing and integrity checks (HMAC).',
        category: 'Integrity'
      },
      {
        id: 'tb-pay-002',
        title: 'Double Spending Attack',
        severity: 'High',
        description: 'Exploiting race conditions to spend the same funds twice.',
        mitigation: 'Implement atomic transactions and idempotent processing.',
        category: 'Logic'
      }
    ],
    controls: [
      { id: 'cb-pay-001', code: 'MSG-SIGN', name: 'Message Signing', description: 'Digital signatures for all high-value payment instructions.' },
      { id: 'cb-pay-002', code: 'IDEM-KEY', name: 'Idempotency Keys', description: 'Use of unique keys to prevent duplicate transaction processing.' }
    ]
  },
  kyc: {
    threats: [
      {
        id: 'tb-kyc-001',
        title: 'Identity Document Forgery (Deepfakes)',
        severity: 'High',
        description: 'Using AI-generated images or videos to bypass video KYC verification.',
        mitigation: 'Implement liveness detection and cross-verification with government databases.',
        category: 'Fraud'
      },
      {
        id: 'tb-kyc-002',
        title: 'PII Data Leakage',
        severity: 'Critical',
        description: 'Exposure of sensitive customer documents (PAN, Aadhaar, Passport) during storage or transit.',
        mitigation: 'Encrypt data at rest and in transit; implement strict access controls.',
        category: 'Data Privacy'
      }
    ],
    controls: [
      { id: 'cb-kyc-001', code: 'LIVENESS', name: 'Liveness Detection', description: 'Active and passive liveness checks during video KYC.' },
      { id: 'cb-kyc-002', code: 'DATA-ENC', name: 'PII Encryption', description: 'AES-256 encryption for all stored identity documents.' }
    ]
  },
  thirdParty: {
    threats: [
      {
        id: 'tb-tp-001',
        title: 'Supply Chain Attack via SDK',
        severity: 'High',
        description: 'Malicious code injected via a compromised third-party SDK integrated into the banking app.',
        mitigation: 'Regular SDK audits, code scanning, and behavior monitoring.',
        category: 'Supply Chain'
      },
      {
        id: 'tb-tp-002',
        title: 'Insecure Vendor API',
        severity: 'Medium',
        description: 'Third-party vendor exposing sensitive bank data due to weak API security on their end.',
        mitigation: 'Vendor risk assessment and mandatory security compliance clauses.',
        category: 'Third Party'
      }
    ],
    controls: [
      { id: 'cb-tp-001', code: 'VEND-AUDIT', name: 'Vendor Security Audit', description: 'Regular security assessments of critical third-party vendors.' },
      { id: 'cb-tp-002', code: 'SDK-SCAN', name: 'Dependency Scanning', description: 'Automated scanning of all third-party libraries and SDKs.' }
    ]
  },
  ai: {
    threats: [
      {
        id: 'tb-ai-001',
        title: 'Model Inversion Attack',
        severity: 'High',
        description: 'Reconstructing sensitive training data (customer financial records) by querying the ML model.',
        mitigation: 'Differential privacy and limitation of model output precision.',
        category: 'AI Security'
      },
      {
        id: 'tb-ai-002',
        title: 'Algorithmic Bias in Lending',
        severity: 'High',
        description: 'AI model systematically discriminating against certain demographics in loan approval.',
        mitigation: 'Regular bias testing and fairness auditing of models.',
        category: 'Ethics/Compliance'
      }
    ],
    controls: [
      { id: 'cb-ai-001', code: 'DIFF-PRIV', name: 'Differential Privacy', description: 'Adding noise to training data to protect individual privacy.' },
      { id: 'cb-ai-002', code: 'XAI-AUDIT', name: 'Explainable AI Audit', description: 'Ensuring model decisions are interpretable and auditable.' }
    ]
  }
};
