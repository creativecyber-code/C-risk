
export const riskQuestionnaires = {
  Critical: {
    color: 'red',
    title: 'Critical Risk Assessment (Red Questionnaire)',
    description: 'Mandatory for Core Banking, Payments, and UIDAI integrations.',
    questions: [
      {
        id: 'CR-01',
        text: 'Does the solution ensure all data is stored exclusively within India (Data Localization)?',
        regulatory_driver: 'RBI Data Localization Directive 2018',
        type: 'boolean'
      },
      {
        id: 'CR-02',
        text: 'Is the system compliant with CERT-In Cyber Security directions and PCI-DSS v4.0?',
        regulatory_driver: 'RBI Master Direction on Outsourcing IT',
        type: 'boolean'
      },
      {
        id: 'CR-03',
        text: 'Does this application require direct write-access to the Core Banking System (CBS)?',
        regulatory_driver: 'NIST PR.AC',
        type: 'boolean'
      },
      {
        id: 'CR-04',
        text: 'Does the application process Aadhaar numbers? If yes, is it using Aadhaar Data Vault?',
        regulatory_driver: 'UIDAI Circulars',
        type: 'boolean'
      },
      {
        id: 'CR-05',
        text: 'Is Multi-Factor Authentication (2FA) enforced for all administrative and user access?',
        regulatory_driver: 'RBI Master Direction on Digital Payment Security 2021',
        type: 'boolean'
      }
    ]
  },
  High: {
    color: 'orange',
    title: 'High Risk Assessment (Orange Questionnaire)',
    description: 'Required for PII handling, Cloud Hosting, Mobile Apps, and Video KYC.',
    questions: [
      {
        id: 'HR-01',
        text: 'Does the application collect or process Personal Identifiable Information (PII) of customers?',
        regulatory_driver: 'DPDP Act 2023',
        type: 'boolean'
      },
      {
        id: 'HR-02',
        text: 'Is data encrypted both at rest (AES-256) and in transit (TLS 1.2+)?',
        regulatory_driver: 'RBI Cyber Security Framework',
        type: 'boolean'
      },
      {
        id: 'HR-03',
        text: 'Are comprehensive audit trails maintained for all user activities for at least 3 years?',
        regulatory_driver: 'NIST ID.RA',
        type: 'boolean'
      },
      {
        id: 'HR-04',
        text: 'Is the application hosted on a MeitY empanelled cloud service provider?',
        regulatory_driver: 'RBI Cloud Computing Guidelines',
        type: 'boolean'
      },
      {
        id: 'HR-05',
        text: 'Does the system support "Right to Erasure" (Data Deletion) upon customer request?',
        regulatory_driver: 'DPDP Act Right to Erasure',
        type: 'boolean'
      }
    ]
  },
  Medium: {
    color: 'yellow',
    title: 'Medium Risk Assessment (Yellow Questionnaire)',
    description: 'Standard assessment for Internal Workflows, Dashboards, and Hardware.',
    questions: [
      {
        id: 'MR-01',
        text: 'Is user authentication integrated with the corporate Active Directory (AD/SSO)?',
        regulatory_driver: 'Identity Management',
        type: 'boolean'
      },
      {
        id: 'MR-02',
        text: 'Is there a documented Business Continuity Plan (BCP) with <4 hours RTO for this application?',
        regulatory_driver: 'Business Continuity',
        type: 'boolean'
      },
      {
        id: 'MR-03',
        text: 'Are endpoints (if applicable) protected by corporate Antivirus/MDM solutions?',
        regulatory_driver: 'Endpoint Security',
        type: 'boolean'
      },
      {
        id: 'MR-04',
        text: 'Are automated email reports checked for sensitive data leakage (DLP)?',
        regulatory_driver: 'Data Leakage Prevention',
        type: 'boolean'
      }
    ]
  }
};
