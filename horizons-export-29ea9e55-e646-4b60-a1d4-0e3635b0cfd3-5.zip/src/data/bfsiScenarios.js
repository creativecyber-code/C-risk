
export const bfsiScenarios = [
  // --- Branch Operations (10) ---
  {
    id: "BO-001",
    category: "Branch Operations",
    title: "Single-View Dashboard",
    description: "Unified customer view for branch tellers to improve service efficiency.",
    compliance_tags: ["No Compliance Tag"],
    risk_level: "Medium",
    type: "Core",
    business_unit: "Branch Banking"
  },
  {
    id: "BO-002",
    category: "Branch Operations",
    title: "Passbook Printer",
    description: "Self-service kiosk software for passbook printing.",
    compliance_tags: ["No Compliance Tag"],
    risk_level: "Low",
    type: "Device",
    business_unit: "Operations"
  },
  {
    id: "BO-003",
    category: "Branch Operations",
    title: "CTS Scanners",
    description: "Cheque Truncation System scanning integration for faster clearing.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "Medium",
    type: "Device",
    business_unit: "Clearing"
  },
  {
    id: "BO-004",
    category: "Branch Operations",
    title: "Digital Token System",
    description: "Queue management system with mobile token generation.",
    compliance_tags: ["No Compliance Tag"],
    risk_level: "Low",
    type: "SaaS",
    business_unit: "Branch Banking"
  },
  {
    id: "BO-005",
    category: "Branch Operations",
    title: "Biometric Login",
    description: "Staff authentication using fingerprint scanners for core banking access.",
    compliance_tags: ["UIDAI Compliance", "RBI Mandate"],
    risk_level: "High",
    type: "Core",
    business_unit: "IT Security"
  },
  {
    id: "BO-006",
    category: "Branch Operations",
    title: "Locker Mgmt",
    description: "Digital locker allocation and rent recovery system.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "Medium",
    type: "Core",
    business_unit: "Operations"
  },
  {
    id: "BO-007",
    category: "Branch Operations",
    title: "Gold Scales",
    description: "IoT integration for gold loan appraisal scales.",
    compliance_tags: ["No Compliance Tag"],
    risk_level: "Low",
    type: "Device",
    business_unit: "Lending"
  },
  {
    id: "BO-008",
    category: "Branch Operations",
    title: "CCTV Cloud",
    description: "Cloud backup for branch surveillance footage.",
    compliance_tags: ["TPRM Required"],
    risk_level: "Medium",
    type: "SaaS",
    business_unit: "Security"
  },
  {
    id: "BO-009",
    category: "Branch Operations",
    title: "Visitor Mgmt",
    description: "Digital entry log for non-customer visitors.",
    compliance_tags: ["No Compliance Tag"],
    risk_level: "Low",
    type: "SaaS",
    business_unit: "Security"
  },
  {
    id: "BO-010",
    category: "Branch Operations",
    title: "Cash Van Tracking",
    description: "GPS tracking for CIT (Cash-in-Transit) vehicles.",
    compliance_tags: ["TPRM Required"],
    risk_level: "Medium",
    type: "SaaS",
    business_unit: "Operations"
  },

  // --- Assets/Lending (10) ---
  {
    id: "AL-001",
    category: "Assets/Lending",
    title: "LOS Retail",
    description: "Loan Origination System for retail products.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "High",
    type: "Core",
    business_unit: "Retail Assets"
  },
  {
    id: "AL-002",
    category: "Assets/Lending",
    title: "CIBIL Fetch",
    description: "Integration with Credit Information Companies for bureau scores.",
    compliance_tags: ["RBI Mandate", "TPRM Required"],
    risk_level: "Medium",
    type: "Integration",
    business_unit: "Credit Risk"
  },
  {
    id: "AL-003",
    category: "Assets/Lending",
    title: "Collection App",
    description: "Mobile app for field collection agents.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "Medium",
    type: "Digital",
    business_unit: "Collections"
  },
  {
    id: "AL-004",
    category: "Assets/Lending",
    title: "Gold LTV Calc",
    description: "Calculator for Gold Loan-to-Value ratios.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "Low",
    type: "Digital",
    business_unit: "Lending"
  },
  {
    id: "AL-005",
    category: "Assets/Lending",
    title: "E-Agreement (NeSL)",
    description: "Digital document execution with NeSL.",
    compliance_tags: ["RBI Mandate", "TPRM Required"],
    risk_level: "Medium",
    type: "Integration",
    business_unit: "Legal"
  },
  {
    id: "AL-006",
    category: "Assets/Lending",
    title: "NPA Auto-tagging",
    description: "System to automatically tag Non-Performing Assets.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "High",
    type: "Core",
    business_unit: "Credit Risk"
  },
  {
    id: "AL-007",
    category: "Assets/Lending",
    title: "Kissan Card",
    description: "KCC issuance and management system.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "Medium",
    type: "Core",
    business_unit: "Rural Banking"
  },
  {
    id: "AL-008",
    category: "Assets/Lending",
    title: "Vehicle Inspection",
    description: "App for pre-disbursement vehicle inspection.",
    compliance_tags: ["TPRM Required"],
    risk_level: "Medium",
    type: "Digital",
    business_unit: "Operations"
  },
  {
    id: "AL-009",
    category: "Assets/Lending",
    title: "E-NACH",
    description: "Electronic mandate management for recurring payments.",
    compliance_tags: ["NPCI Requirement"],
    risk_level: "Medium",
    type: "Integration",
    business_unit: "Payments"
  },
  {
    id: "AL-010",
    category: "Assets/Lending",
    title: "Legal Audit Workflow",
    description: "Workflow for vetting property documents.",
    compliance_tags: ["No Compliance Tag"],
    risk_level: "Low",
    type: "SaaS",
    business_unit: "Legal"
  },

  // --- Liabilities/Deposits (10) ---
  {
    id: "LD-001",
    category: "Liabilities/Deposits",
    title: "CKYC Upload",
    description: "Central KYC Registry bulk upload utility.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "Medium",
    type: "Core",
    business_unit: "Compliance"
  },
  {
    id: "LD-002",
    category: "Liabilities/Deposits",
    title: "Bulk Salary Accounts",
    description: "Corporate salary account opening workflow.",
    compliance_tags: ["No Compliance Tag"],
    risk_level: "Medium",
    type: "Core",
    business_unit: "Retail Liabilities"
  },
  {
    id: "LD-003",
    category: "Liabilities/Deposits",
    title: "Video KYC (V-CIP)",
    description: "Video-based Customer Identification Process.",
    compliance_tags: ["RBI Mandate", "UIDAI Compliance"],
    risk_level: "Critical",
    type: "Digital",
    business_unit: "Digital Banking"
  },
  {
    id: "LD-004",
    category: "Liabilities/Deposits",
    title: "Dormant Activation",
    description: "Workflow to activate dormant accounts securely.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "Medium",
    type: "Core",
    business_unit: "Operations"
  },
  {
    id: "LD-005",
    category: "Liabilities/Deposits",
    title: "TDS Portal",
    description: "Customer portal to download TDS certificates.",
    compliance_tags: ["No Compliance Tag"],
    risk_level: "Low",
    type: "Digital",
    business_unit: "Taxation"
  },
  {
    id: "LD-006",
    category: "Liabilities/Deposits",
    title: "Positive Pay",
    description: "Cheque fraud prevention mechanism for high value cheques.",
    compliance_tags: ["RBI Mandate", "NPCI Requirement"],
    risk_level: "High",
    type: "Digital",
    business_unit: "Clearing"
  },
  {
    id: "LD-007",
    category: "Liabilities/Deposits",
    title: "Doorstep Banking",
    description: "App for agents providing doorstep banking services.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "Medium",
    type: "Digital",
    business_unit: "Operations"
  },
  {
    id: "LD-008",
    category: "Liabilities/Deposits",
    title: "Nominee Update",
    description: "Self-service portal for nomination updates.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "Medium",
    type: "Digital",
    business_unit: "Operations"
  },
  {
    id: "LD-009",
    category: "Liabilities/Deposits",
    title: "FD Calc",
    description: "Fixed Deposit interest calculator.",
    compliance_tags: ["No Compliance Tag"],
    risk_level: "Low",
    type: "Digital",
    business_unit: "Retail Liabilities"
  },
  {
    id: "LD-010",
    category: "Liabilities/Deposits",
    title: "Form 15G/H",
    description: "Digital submission of tax exemption forms.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "Medium",
    type: "Digital",
    business_unit: "Taxation"
  },

  // --- Payments/High Risk (10) ---
  {
    id: "PH-001",
    category: "Payments/High Risk",
    title: "UPI Switch",
    description: "Core UPI transaction processing switch.",
    compliance_tags: ["NPCI Requirement", "RBI Mandate"],
    risk_level: "Critical",
    type: "Core",
    business_unit: "Payments"
  },
  {
    id: "PH-002",
    category: "Payments/High Risk",
    title: "IMPS Limit",
    description: "Dynamic limit management for IMPS transactions.",
    compliance_tags: ["NPCI Requirement"],
    risk_level: "High",
    type: "Core",
    business_unit: "Payments"
  },
  {
    id: "PH-003",
    category: "Payments/High Risk",
    title: "BBPS",
    description: "Bharat Bill Payment System integration.",
    compliance_tags: ["NPCI Requirement"],
    risk_level: "High",
    type: "Core",
    business_unit: "Payments"
  },
  {
    id: "PH-004",
    category: "Payments/High Risk",
    title: "RuPay Mgmt",
    description: "Lifecycle management for RuPay cards.",
    compliance_tags: ["NPCI Requirement", "RBI Mandate"],
    risk_level: "High",
    type: "Core",
    business_unit: "Cards"
  },
  {
    id: "PH-005",
    category: "Payments/High Risk",
    title: "AEPS Merchant",
    description: "Aadhaar Enabled Payment System for merchants.",
    compliance_tags: ["NPCI Requirement", "UIDAI Compliance"],
    risk_level: "Critical",
    type: "Digital",
    business_unit: "Financial Inclusion"
  },
  {
    id: "PH-006",
    category: "Payments/High Risk",
    title: "Fastag",
    description: "NETC Fastag issuance and toll processing.",
    compliance_tags: ["NPCI Requirement"],
    risk_level: "High",
    type: "Core",
    business_unit: "Payments"
  },
  {
    id: "PH-007",
    category: "Payments/High Risk",
    title: "NEFT Bulk",
    description: "Bulk upload utility for corporate NEFT payments.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "High",
    type: "Core",
    business_unit: "Wholesale Banking"
  },
  {
    id: "PH-008",
    category: "Payments/High Risk",
    title: "ATM Screens",
    description: "Management of ATM display content and flows.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "High",
    type: "Device",
    business_unit: "Channel Management"
  },
  {
    id: "PH-009",
    category: "Payments/High Risk",
    title: "Tokenization (CoF)",
    description: "Card-on-File tokenization solution.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "Critical",
    type: "Core",
    business_unit: "Cards"
  },
  {
    id: "PH-010",
    category: "Payments/High Risk",
    title: "Nodal Reconciliation",
    description: "Reconciliation system for Nodal accounts.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "High",
    type: "Core",
    business_unit: "Finance"
  },

  // --- Regulatory/Mandatory (10) ---
  {
    id: "RM-001",
    category: "Regulatory/Mandatory",
    title: "Aadhaar Vault",
    description: "Secure storage for Aadhaar numbers (Data Vault).",
    compliance_tags: ["UIDAI Compliance", "RBI Mandate"],
    risk_level: "Critical",
    type: "Core",
    business_unit: "IT Security"
  },
  {
    id: "RM-002",
    category: "Regulatory/Mandatory",
    title: "Masking Solution",
    description: "Data masking for PII in non-production environments.",
    compliance_tags: ["RBI Mandate", "DPDP Act"],
    risk_level: "High",
    type: "Core",
    business_unit: "IT Security"
  },
  {
    id: "RM-003",
    category: "Regulatory/Mandatory",
    title: "XBRL Reporting",
    description: "Reporting tool for RBI automated returns.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "High",
    type: "Core",
    business_unit: "Finance"
  },
  {
    id: "RM-004",
    category: "Regulatory/Mandatory",
    title: "UDGAM Portal",
    description: "Integration with RBI UDGAM portal for unclaimed deposits.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "High",
    type: "Integration",
    business_unit: "Operations"
  },
  {
    id: "RM-005",
    category: "Regulatory/Mandatory",
    title: "STR Reporting",
    description: "Suspicious Transaction Reporting to FIU-IND.",
    compliance_tags: ["RBI Mandate", "PMLA"],
    risk_level: "High",
    type: "Core",
    business_unit: "Compliance"
  },
  {
    id: "RM-006",
    category: "Regulatory/Mandatory",
    title: "Email Security",
    description: "DLP and anti-phishing solution for corporate email.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "High",
    type: "Core",
    business_unit: "IT Security"
  },
  {
    id: "RM-007",
    category: "Regulatory/Mandatory",
    title: "USB Blocking",
    description: "Endpoint security policy to block USB storage.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "High",
    type: "Core",
    business_unit: "IT Security"
  },
  {
    id: "RM-008",
    category: "Regulatory/Mandatory",
    title: "SSL Audit",
    description: "Automated tool to check SSL certificate validity.",
    compliance_tags: ["RBI Mandate"],
    risk_level: "Medium",
    type: "SaaS",
    business_unit: "IT Security"
  },
  {
    id: "RM-009",
    category: "Regulatory/Mandatory",
    title: "SMS Gateway",
    description: "Secure gateway for transactional SMS alerts.",
    compliance_tags: ["RBI Mandate", "TRAI"],
    risk_level: "High",
    type: "Integration",
    business_unit: "IT Infrastructure"
  },
  {
    id: "RM-010",
    category: "Regulatory/Mandatory",
    title: "SWIFT Upgrade",
    description: "Upgrading SWIFT infrastructure to ISO 20022.",
    compliance_tags: ["RBI Mandate", "SWIFT"],
    risk_level: "Critical",
    type: "Core",
    business_unit: "Treasury"
  }
];
