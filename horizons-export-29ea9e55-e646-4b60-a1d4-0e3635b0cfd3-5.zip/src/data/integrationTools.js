
export const INTEGRATION_TOOLS = [
  // SIEM
  {
    id: 'splunk',
    name: 'Splunk',
    category: 'SIEM',
    description: 'Enterprise SIEM for real-time security monitoring and log analysis.',
    logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=100&h=100',
    difficulty: 'Intermediate',
    setupFields: [
      { name: 'url', label: 'Splunk HEC URL', type: 'text', placeholder: 'https://splunk-instance:8088' },
      { name: 'apiKey', label: 'HEC Token', type: 'password' }
    ],
    supportedFeatures: ['Log Export', 'Alert Ingestion']
  },
  {
    id: 'elk',
    name: 'Elastic Stack (ELK)',
    category: 'SIEM',
    description: 'Open source search and analytics engine for security data.',
    logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=100&h=100',
    difficulty: 'Advanced',
    setupFields: [
      { name: 'url', label: 'Elasticsearch URL', type: 'text', placeholder: 'https://elasticsearch:9200' },
      { name: 'username', label: 'Username', type: 'text' },
      { name: 'password', label: 'Password', type: 'password' }
    ],
    supportedFeatures: ['Log Export', 'Dashboarding']
  },

  // Vulnerability Scanners
  {
    id: 'nessus',
    name: 'Nessus',
    category: 'Vulnerability',
    description: 'Vulnerability assessment solution for identifying network flaws.',
    logo: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=100&h=100',
    difficulty: 'Basic',
    setupFields: [
      { name: 'accessKey', label: 'Access Key', type: 'text' },
      { name: 'secretKey', label: 'Secret Key', type: 'password' }
    ],
    supportedFeatures: ['Import Vulnerabilities', 'Risk Scoring']
  },
  {
    id: 'qualys',
    name: 'Qualys',
    category: 'Vulnerability',
    description: 'Cloud-based security and compliance solutions.',
    logo: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=100&h=100',
    difficulty: 'Intermediate',
    setupFields: [
      { name: 'username', label: 'Username', type: 'text' },
      { name: 'password', label: 'Password', type: 'password' },
      { name: 'platform', label: 'Platform URL', type: 'text' }
    ],
    supportedFeatures: ['Asset Sync', 'Vuln Import']
  },

  // Ticketing
  {
    id: 'jira',
    name: 'Jira Software',
    category: 'Ticketing',
    description: 'Issue tracking and project management for software teams.',
    logo: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80&w=100&h=100',
    difficulty: 'Basic',
    setupFields: [
      { name: 'domain', label: 'Jira Domain', type: 'text', placeholder: 'your-company.atlassian.net' },
      { name: 'email', label: 'Email', type: 'text' },
      { name: 'apiToken', label: 'API Token', type: 'password' }
    ],
    supportedFeatures: ['Create Tickets', 'Sync Status', 'Two-way Sync']
  },
  {
    id: 'servicenow',
    name: 'ServiceNow',
    category: 'Ticketing',
    description: 'IT service management and digital workflow platform.',
    logo: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80&w=100&h=100',
    difficulty: 'Advanced',
    setupFields: [
      { name: 'instance', label: 'Instance URL', type: 'text' },
      { name: 'clientId', label: 'Client ID', type: 'text' },
      { name: 'clientSecret', label: 'Client Secret', type: 'password' }
    ],
    supportedFeatures: ['Incident Management', 'CMDB Sync']
  },

  // Cloud Security
  {
    id: 'aws-security',
    name: 'AWS Security Hub',
    category: 'Cloud Security',
    description: 'Comprehensive view of high-priority security alerts and posture.',
    logo: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=100&h=100',
    difficulty: 'Intermediate',
    setupFields: [
      { name: 'region', label: 'AWS Region', type: 'text' },
      { name: 'accessKeyId', label: 'Access Key ID', type: 'text' },
      { name: 'secretAccessKey', label: 'Secret Access Key', type: 'password' }
    ],
    supportedFeatures: ['Finding Import', 'Compliance Checks']
  },
  {
    id: 'azure-defender',
    name: 'Azure Defender',
    category: 'Cloud Security',
    description: 'Cloud workload protection for Azure resources.',
    logo: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=100&h=100',
    difficulty: 'Intermediate',
    setupFields: [
      { name: 'tenantId', label: 'Tenant ID', type: 'text' },
      { name: 'clientId', label: 'Client ID', type: 'text' },
      { name: 'clientSecret', label: 'Client Secret', type: 'password' }
    ],
    supportedFeatures: ['Security Recommendations', 'Alert Sync']
  },

  // API Security
  {
    id: 'postman',
    name: 'Postman',
    category: 'API Security',
    description: 'API platform for building and using APIs.',
    logo: 'https://images.unsplash.com/photo-1516259762381-22954d7d3ad2?auto=format&fit=crop&q=80&w=100&h=100',
    difficulty: 'Basic',
    setupFields: [
      { name: 'apiKey', label: 'Postman API Key', type: 'password' }
    ],
    supportedFeatures: ['Schema Import', 'Test Collection Sync']
  },
  {
    id: 'swagger',
    name: 'SwaggerHub',
    category: 'API Security',
    description: 'API design and documentation platform.',
    logo: 'https://images.unsplash.com/photo-1516259762381-22954d7d3ad2?auto=format&fit=crop&q=80&w=100&h=100',
    difficulty: 'Basic',
    setupFields: [
      { name: 'apiKey', label: 'API Key', type: 'password' }
    ],
    supportedFeatures: ['OpenAPI Import', 'Design Sync']
  },

  // SOAR
  {
    id: 'phantom',
    name: 'Splunk Phantom',
    category: 'SOAR',
    description: 'Security orchestration, automation, and response.',
    logo: 'https://images.unsplash.com/photo-1558494949-ef526b0042a0?auto=format&fit=crop&q=80&w=100&h=100',
    difficulty: 'Advanced',
    setupFields: [
      { name: 'url', label: 'Phantom URL', type: 'text' },
      { name: 'token', label: 'Auth Token', type: 'password' }
    ],
    supportedFeatures: ['Playbook Triggering', 'Action Execution']
  },

  // Compliance
  {
    id: 'rapid7',
    name: 'Rapid7 InsightVM',
    category: 'Compliance',
    description: 'Vulnerability management and compliance analytics.',
    logo: 'https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&q=80&w=100&h=100',
    difficulty: 'Intermediate',
    setupFields: [
      { name: 'region', label: 'Platform Region', type: 'text' },
      { name: 'apiKey', label: 'Platform API Key', type: 'password' }
    ],
    supportedFeatures: ['Compliance Scanning', 'Policy Sync']
  }
];

export const INTEGRATION_CATEGORIES = [
  'All', 
  'SIEM', 
  'Vulnerability', 
  'Ticketing', 
  'Cloud Security', 
  'API Security', 
  'SOAR', 
  'Compliance'
];
