
import { BANKING_THREAT_LIBRARY } from './bankingThreatLibrary';

// Helper to inject threats into description for display purposes (optional)
const appendThreatSummary = (baseDesc, category) => {
  const threats = BANKING_THREAT_LIBRARY[category]?.threats || [];
  const topThreats = threats.slice(0, 3).map(t => t.title).join(', ');
  return `${baseDesc} Includes pre-mapped controls for threats like: ${topThreats}.`;
};

export const SYSTEM_TEMPLATES = [
  // --- Existing General Templates ---
  {
    id: 'tpl-webapp-001',
    name: 'Standard Web Application',
    description: 'A typical 3-tier web application architecture featuring a frontend client, backend API server, and a relational database. Includes standard trust boundaries between public internet, DMZ, and internal network.',
    industry: 'SaaS',
    complexity: 'Basic',
    threatCount: 12,
    previewImage: 'https://images.unsplash.com/photo-1558494949-ef526b0042a0?auto=format&fit=crop&q=80&w=300&h=200',
    useCases: ['SaaS Platforms', 'Customer Portals', 'Internal Tools'],
    hotspots: ['API Authentication', 'SQL Injection Points', 'Cross-Site Scripting (XSS)'],
    elements: [
      { id: 'el-1', type: 'interactor', x: 100, y: 150, label: 'User Browser' },
      { id: 'el-2', type: 'process', x: 400, y: 150, label: 'Web Server / API' },
      { id: 'el-3', type: 'store', x: 700, y: 150, label: 'SQL Database' },
      { id: 'el-4', type: 'interactor', x: 400, y: 350, label: 'Admin User' },
      { id: 'b-1', type: 'boundary', x: 250, y: 150, label: 'Internet Boundary' }
    ],
    connections: [
      { id: 'c-1', from: 'el-1', to: 'el-2', label: 'HTTPS / JSON' },
      { id: 'c-2', from: 'el-2', to: 'el-3', label: 'TCP / SQL' },
      { id: 'c-3', from: 'el-2', to: 'el-1', label: 'Response' },
      { id: 'c-4', from: 'el-4', to: 'el-2', label: 'HTTPS / Admin' }
    ]
  },
  {
    id: 'tpl-micro-001',
    name: 'Microservices Architecture',
    description: 'Distributed system with multiple independent services communicating via an API Gateway. Includes service discovery and separate data stores for isolation.',
    industry: 'Tech',
    complexity: 'Advanced',
    threatCount: 24,
    previewImage: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=300&h=200',
    useCases: ['Enterprise Apps', 'Scalable Platforms', 'E-commerce'],
    hotspots: ['Inter-service Auth', 'API Gateway Bypass', 'Distributed Tracing'],
    elements: [
      { id: 'el-1', type: 'interactor', x: 50, y: 200, label: 'Client App' },
      { id: 'el-2', type: 'process', x: 250, y: 200, label: 'API Gateway' },
      { id: 'el-3', type: 'process', x: 500, y: 100, label: 'Auth Service' },
      { id: 'el-4', type: 'process', x: 500, y: 300, label: 'Order Service' },
      { id: 'el-5', type: 'store', x: 700, y: 100, label: 'User DB' },
      { id: 'el-6', type: 'store', x: 700, y: 300, label: 'Order DB' },
      { id: 'b-1', type: 'boundary', x: 150, y: 200, label: 'Public Boundary' },
      { id: 'b-2', type: 'boundary', x: 380, y: 200, label: 'Service Mesh' }
    ],
    connections: [
      { id: 'c-1', from: 'el-1', to: 'el-2', label: 'REST' },
      { id: 'c-2', from: 'el-2', to: 'el-3', label: 'gRPC' },
      { id: 'c-3', from: 'el-2', to: 'el-4', label: 'gRPC' },
      { id: 'c-4', from: 'el-3', to: 'el-5', label: 'SQL' },
      { id: 'c-5', from: 'el-4', to: 'el-6', label: 'NoSQL' }
    ]
  },

  // --- NEW Banking Templates ---

  // 1. Digital Banking Platforms
  {
    id: 'tpl-bank-digital-001',
    name: 'Digital Banking Platform',
    description: appendThreatSummary('Omnichannel banking architecture supporting Internet Banking, Mobile Apps, and UPI integration. Focuses on secure customer access and transaction handling.', 'digitalBanking'),
    industry: 'Finance',
    complexity: 'Advanced',
    threatCount: 35,
    previewImage: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=300&h=200',
    useCases: ['Retail Banking', 'Mobile Wallets', 'UPI Payments'],
    hotspots: ['MFA Bypass', 'Session Hijacking', 'API Security'],
    elements: [
      { id: 'el-1', type: 'interactor', x: 50, y: 150, label: 'Customer Mobile App' },
      { id: 'el-2', type: 'interactor', x: 50, y: 350, label: 'Web Browser' },
      { id: 'el-3', type: 'process', x: 250, y: 250, label: 'Omnichannel API Gateway' },
      { id: 'el-4', type: 'process', x: 450, y: 150, label: 'Auth & IAM Service' },
      { id: 'el-5', type: 'process', x: 450, y: 350, label: 'Transaction Engine' },
      { id: 'el-6', type: 'store', x: 650, y: 250, label: 'Customer DB (Encrypted)' },
      { id: 'el-7', type: 'process', x: 650, y: 350, label: 'Fraud Detection System' },
      { id: 'b-1', type: 'boundary', x: 150, y: 250, label: 'Internet Boundary' },
      { id: 'b-2', type: 'boundary', x: 350, y: 250, label: 'DMZ / Internal' }
    ],
    connections: [
      { id: 'c-1', from: 'el-1', to: 'el-3', label: 'HTTPS / TLS 1.3' },
      { id: 'c-2', from: 'el-2', to: 'el-3', label: 'HTTPS / TLS 1.3' },
      { id: 'c-3', from: 'el-3', to: 'el-4', label: 'OIDC / OAuth2' },
      { id: 'c-4', from: 'el-3', to: 'el-5', label: 'Process Txn' },
      { id: 'c-5', from: 'el-5', to: 'el-6', label: 'Read/Write Data' },
      { id: 'c-6', from: 'el-5', to: 'el-7', label: 'Async Analysis' }
    ],
    metadata: {
      frameworks: ['RBI Cyber Security Framework', 'PCI-DSS', 'NIST CSF'],
      controls: BANKING_THREAT_LIBRARY.digitalBanking.controls
    }
  },

  // 2. Core Banking System (CBS) Integrations
  {
    id: 'tpl-bank-cbs-001',
    name: 'Core Banking System (CBS)',
    description: appendThreatSummary('Heart of the banking infrastructure. High-security zone handling ledgers, accounts, and end-of-day processing. Includes middleware for channel integration.', 'cbs'),
    industry: 'Finance',
    complexity: 'Advanced',
    threatCount: 28,
    previewImage: 'https://images.unsplash.com/photo-1501167786227-4cba60f6d58f?auto=format&fit=crop&q=80&w=300&h=200',
    useCases: ['Account Management', 'General Ledger', 'Clearing & Settlement'],
    hotspots: ['Insider Threats', 'Database Injection', 'Batch File Integrity'],
    elements: [
      { id: 'el-1', type: 'process', x: 100, y: 250, label: 'Enterprise Service Bus (ESB)' },
      { id: 'el-2', type: 'process', x: 300, y: 250, label: 'CBS App Server' },
      { id: 'el-3', type: 'store', x: 500, y: 250, label: 'Core Database (Oracle/DB2)' },
      { id: 'el-4', type: 'process', x: 300, y: 100, label: 'EOD Batch Server' },
      { id: 'el-5', type: 'interactor', x: 500, y: 100, label: 'DB Administrator' },
      { id: 'b-1', type: 'boundary', x: 200, y: 250, label: 'High Security Zone' }
    ],
    connections: [
      { id: 'c-1', from: 'el-1', to: 'el-2', label: 'ISO 8583 / XML' },
      { id: 'c-2', from: 'el-2', to: 'el-3', label: 'SQL / Proprietary' },
      { id: 'c-3', from: 'el-4', to: 'el-3', label: 'Batch Updates' },
      { id: 'c-4', from: 'el-5', to: 'el-3', label: 'Maintenance (PAM)' }
    ],
    metadata: {
      frameworks: ['ISO 27001', 'RBI Cyber Security Framework'],
      controls: BANKING_THREAT_LIBRARY.cbs.controls
    }
  },

  // 3. APIs and Open Banking Interfaces
  {
    id: 'tpl-bank-api-001',
    name: 'Open Banking / PSD2 API',
    description: appendThreatSummary('Secure API infrastructure for exposing banking services to Third Party Providers (TPPs) in compliance with Open Banking/PSD2 standards.', 'openBanking'),
    industry: 'Finance',
    complexity: 'Intermediate',
    threatCount: 22,
    previewImage: 'https://images.unsplash.com/photo-1555421689-491a97ff2040?auto=format&fit=crop&q=80&w=300&h=200',
    useCases: ['FinTech Integration', 'Account Aggregation', 'Payment Initiation'],
    hotspots: ['Broken Object Level Auth', 'Token Theft', 'Rate Limiting'],
    elements: [
      { id: 'el-1', type: 'interactor', x: 50, y: 200, label: 'Third Party Provider (TPP)' },
      { id: 'el-2', type: 'process', x: 250, y: 200, label: 'Open Banking Gateway' },
      { id: 'el-3', type: 'process', x: 450, y: 100, label: 'Consent Management' },
      { id: 'el-4', type: 'process', x: 450, y: 300, label: 'Auth Server (OAuth2/OIDC)' },
      { id: 'el-5', type: 'process', x: 650, y: 200, label: 'Internal Microservices' },
      { id: 'b-1', type: 'boundary', x: 150, y: 200, label: 'mTLS Boundary' }
    ],
    connections: [
      { id: 'c-1', from: 'el-1', to: 'el-2', label: 'REST / mTLS' },
      { id: 'c-2', from: 'el-2', to: 'el-4', label: 'Validate Token' },
      { id: 'c-3', from: 'el-2', to: 'el-3', label: 'Check Consent' },
      { id: 'c-4', from: 'el-2', to: 'el-5', label: 'Proxy Request' }
    ],
    metadata: {
      frameworks: ['PSD2', 'FAPI', 'OWASP API Security'],
      controls: BANKING_THREAT_LIBRARY.openBanking.controls
    }
  },

  // 4. Payment Systems
  {
    id: 'tpl-bank-pay-001',
    name: 'Payment Switch (IMPS/NEFT/SWIFT)',
    description: appendThreatSummary('Critical infrastructure for processing real-time and bulk payments. Connects internal systems to external payment networks.', 'payments'),
    industry: 'Finance',
    complexity: 'Critical',
    threatCount: 30,
    previewImage: 'https://images.unsplash.com/photo-1556742049-0cfed4f7a07d?auto=format&fit=crop&q=80&w=300&h=200',
    useCases: ['Fund Transfers', 'Card Processing', 'Inter-bank Settlement'],
    hotspots: ['Message Tampering', 'Replay Attacks', 'Gateway Compromise'],
    elements: [
      { id: 'el-1', type: 'process', x: 100, y: 200, label: 'Channel Manager' },
      { id: 'el-2', type: 'process', x: 300, y: 200, label: 'Payment Switch / Hub' },
      { id: 'el-3', type: 'process', x: 500, y: 200, label: 'Network Interface (SWIFT/NPCI)' },
      { id: 'el-4', type: 'store', x: 300, y: 350, label: 'Transaction Store (Immutable)' },
      { id: 'el-5', type: 'store', x: 500, y: 100, label: 'HSM (Hardware Security Module)' },
      { id: 'b-1', type: 'boundary', x: 400, y: 200, label: 'External Network Boundary' }
    ],
    connections: [
      { id: 'c-1', from: 'el-1', to: 'el-2', label: 'Internal Msg' },
      { id: 'c-2', from: 'el-2', to: 'el-3', label: 'Payment Instruction' },
      { id: 'c-3', from: 'el-2', to: 'el-5', label: 'Sign / Encrypt' },
      { id: 'c-4', from: 'el-2', to: 'el-4', label: 'Audit Log' }
    ],
    metadata: {
      frameworks: ['PCI-DSS', 'SWIFT CSP', 'RBI PSS'],
      controls: BANKING_THREAT_LIBRARY.payments.controls
    }
  },

  // 5. Loan Origination & Onboarding
  {
    id: 'tpl-bank-lms-001',
    name: 'Loan Origination & KYC',
    description: appendThreatSummary('Workflow system for customer onboarding, document collection, and loan approval. Heavily focuses on PII protection and identity verification.', 'kyc'),
    industry: 'Finance',
    complexity: 'Intermediate',
    threatCount: 18,
    previewImage: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&q=80&w=300&h=200',
    useCases: ['Digital Lending', 'Account Opening', 'Video KYC'],
    hotspots: ['Identity Theft', 'Document Forgery', 'Insecure Storage'],
    elements: [
      { id: 'el-1', type: 'interactor', x: 50, y: 200, label: 'Applicant' },
      { id: 'el-2', type: 'process', x: 250, y: 200, label: 'Onboarding Portal' },
      { id: 'el-3', type: 'process', x: 450, y: 100, label: 'Video KYC Engine' },
      { id: 'el-4', type: 'process', x: 450, y: 300, label: 'Credit Bureau Interface' },
      { id: 'el-5', type: 'store', x: 650, y: 200, label: 'Document Vault (S3/Blob)' },
      { id: 'b-1', type: 'boundary', x: 150, y: 200, label: 'Public Boundary' }
    ],
    connections: [
      { id: 'c-1', from: 'el-1', to: 'el-2', label: 'Submit Data' },
      { id: 'c-2', from: 'el-2', to: 'el-3', label: 'Stream Video' },
      { id: 'c-3', from: 'el-2', to: 'el-4', label: 'Fetch Credit Score' },
      { id: 'c-4', from: 'el-2', to: 'el-5', label: 'Store Docs (Encrypted)' }
    ],
    metadata: {
      frameworks: ['GDPR', 'RBI KYC Guidelines', 'DPDP Act'],
      controls: BANKING_THREAT_LIBRARY.kyc.controls
    }
  },

  // 6. Third-party Integrations
  {
    id: 'tpl-bank-tpp-001',
    name: 'FinTech & Third-Party Integration',
    description: appendThreatSummary('Architecture for securely integrating with external FinTech partners, payment gateways, and loyalty programs.', 'thirdParty'),
    industry: 'Finance',
    complexity: 'Intermediate',
    threatCount: 20,
    previewImage: 'https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?auto=format&fit=crop&q=80&w=300&h=200',
    useCases: ['Co-branded Cards', 'Loyalty Programs', 'Embedded Finance'],
    hotspots: ['Supply Chain Attacks', 'Insecure Webhooks', 'Data Leakage'],
    elements: [
      { id: 'el-1', type: 'process', x: 100, y: 200, label: 'Bank Core' },
      { id: 'el-2', type: 'process', x: 300, y: 200, label: 'Partner API Gateway' },
      { id: 'el-3', type: 'process', x: 500, y: 200, label: 'FinTech Partner System' },
      { id: 'el-4', type: 'store', x: 300, y: 350, label: 'Shared Data Cache' },
      { id: 'b-1', type: 'boundary', x: 400, y: 200, label: 'Partner Trust Boundary' }
    ],
    connections: [
      { id: 'c-1', from: 'el-1', to: 'el-2', label: 'Internal Data' },
      { id: 'c-2', from: 'el-2', to: 'el-3', label: 'Webhook / API Call' },
      { id: 'c-3', from: 'el-3', to: 'el-2', label: 'Callback' }
    ],
    metadata: {
      frameworks: ['ISO 27001', 'Third Party Risk Management (TPRM)'],
      controls: BANKING_THREAT_LIBRARY.thirdParty.controls
    }
  },

  // 7. AI/ML Systems
  {
    id: 'tpl-bank-ai-001',
    name: 'Banking AI/ML Analytics',
    description: appendThreatSummary('Architecture for training and deploying ML models for credit scoring, fraud detection, and customer insights. Focuses on data privacy and model security.', 'ai'),
    industry: 'Finance',
    complexity: 'Advanced',
    threatCount: 15,
    previewImage: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=300&h=200',
    useCases: ['Credit Scoring', 'Fraud Detection', 'Chatbots'],
    hotspots: ['Model Inversion', 'Training Data Poisoning', 'Bias'],
    elements: [
      { id: 'el-1', type: 'store', x: 100, y: 150, label: 'Raw Data Lake' },
      { id: 'el-2', type: 'process', x: 300, y: 150, label: 'Data Anonymizer' },
      { id: 'el-3', type: 'process', x: 500, y: 150, label: 'Model Training (GPU)' },
      { id: 'el-4', type: 'process', x: 500, y: 350, label: 'Inference Engine' },
      { id: 'el-5', type: 'interactor', x: 300, y: 350, label: 'Banking App' },
      { id: 'b-1', type: 'boundary', x: 400, y: 150, label: 'Analytics Sandbox' }
    ],
    connections: [
      { id: 'c-1', from: 'el-1', to: 'el-2', label: 'Extract' },
      { id: 'c-2', from: 'el-2', to: 'el-3', label: 'Sanitized Data' },
      { id: 'c-3', from: 'el-3', to: 'el-4', label: 'Deploy Model' },
      { id: 'c-4', from: 'el-5', to: 'el-4', label: 'Prediction Request' }
    ],
    metadata: {
      frameworks: ['NIST AI RMF', 'GDPR', 'EU AI Act'],
      controls: BANKING_THREAT_LIBRARY.ai.controls
    }
  }
];
