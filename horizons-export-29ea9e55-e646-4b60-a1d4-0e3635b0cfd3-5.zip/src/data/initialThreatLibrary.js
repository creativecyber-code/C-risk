
export const SEED_PATTERNS = [
  {
    id: 'pat-001',
    title: 'SQL Injection (SQLi)',
    description: 'Attackers inject malicious SQL commands into input fields to manipulate the database query execution.',
    stride_category: 'Tampering',
    severity: 'Critical',
    likelihood: 'High',
    impact: 'High',
    industry: ['Finance', 'Retail', 'Healthcare', 'Tech'],
    affected_components: ['Database', 'Web Form', 'API Endpoint'],
    attack_vectors: ['Login Forms', 'Search Bars', 'URL Parameters'],
    mitigation_strategies: 'Use parameterized queries (Prepared Statements) for all database access. Employ ORMs that handle escaping automatically.',
    usage_count: 1240,
    rating_avg: 4.8,
    is_public: true,
    cvss_vector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H',
    cve_references: ['CVE-2017-5638', 'CVE-2019-10758']
  },
  {
    id: 'pat-002',
    title: 'Cross-Site Scripting (XSS)',
    description: 'Malicious scripts are injected into trusted websites and executed in the victim\'s browser.',
    stride_category: 'Tampering',
    severity: 'High',
    likelihood: 'High',
    impact: 'Medium',
    industry: ['All'],
    affected_components: ['Web UI', 'Browser'],
    attack_vectors: ['Comment sections', 'Profile inputs'],
    mitigation_strategies: 'Implement strict Content Security Policy (CSP). Sanitize all user inputs and escape outputs contextually.',
    usage_count: 980,
    rating_avg: 4.5,
    is_public: true,
    cvss_vector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N',
    cve_references: []
  },
  {
    id: 'pat-003',
    title: 'Insecure Direct Object References (IDOR)',
    description: 'Application provides direct access to objects based on user-supplied input without authorization checks.',
    stride_category: 'Elevation of Privilege',
    severity: 'High',
    likelihood: 'Medium',
    impact: 'High',
    industry: ['Finance', 'Healthcare'],
    affected_components: ['API', 'Database'],
    attack_vectors: ['URL ID Manipulation', 'API Resource IDs'],
    mitigation_strategies: 'Implement robust access control checks for every object access. Use indirect references (random UUIDs) instead of sequential IDs.',
    usage_count: 850,
    rating_avg: 4.7,
    is_public: true,
    cvss_vector: 'CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:N',
    cve_references: []
  },
  {
    id: 'pat-004',
    title: 'Broken Authentication',
    description: 'Weaknesses in session management or credential handling allow attackers to compromise passwords or session tokens.',
    stride_category: 'Spoofing',
    severity: 'Critical',
    likelihood: 'Medium',
    impact: 'Critical',
    industry: ['Finance', 'All'],
    affected_components: ['Identity Provider', 'Session Manager'],
    attack_vectors: ['Credential Stuffing', 'Session Hijacking'],
    mitigation_strategies: 'Implement Multi-Factor Authentication (MFA). Prohibit weak passwords. Rotate session IDs after login.',
    usage_count: 1500,
    rating_avg: 4.9,
    is_public: true,
    cvss_vector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H',
    cve_references: []
  }
];

export const SEED_KB_ARTICLES = [
  {
    id: 'kb-001',
    title: 'Understanding STRIDE',
    category: 'Methodology',
    summary: 'A deep dive into the STRIDE threat modeling methodology.',
    content: 'STRIDE is a model of threats developed by Praerit Garg and Loren Kohnfelder at Microsoft...',
    tags: ['STRIDE', 'Basics', 'Education'],
    views: 342
  },
  {
    id: 'kb-002',
    title: 'Implementing Zero Trust Architecture',
    category: 'Best Practices',
    summary: 'How to shift from perimeter-based security to Zero Trust.',
    content: 'Zero Trust assumes there is no implicit trust granted to assets or user accounts based solely on their physical or network location...',
    tags: ['Zero Trust', 'Architecture', 'Network'],
    views: 561
  }
];
