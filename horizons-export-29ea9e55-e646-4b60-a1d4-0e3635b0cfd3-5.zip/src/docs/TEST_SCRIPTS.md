
# QA Test Scripts: Enterprise Risk Management System (ERMS)

**Version:** 1.0  
**Last Updated:** 2025-12-30  
**Scope:** Comprehensive functional and integration testing for ERMS Dashboard, Intake, and Administration modules.

---

## 📋 Table of Contents

1. [Prerequisites & Environment Setup](#1-prerequisites--environment-setup)
2. [Module 1: Authentication & Access](#2-module-1-authentication--access)
3. [Module 2: Executive Dashboard (Real-time)](#3-module-2-executive-dashboard-real-time)
4. [Module 3: Business Initiation (Intake Workflow)](#4-module-3-business-initiation-intake-workflow)
5. [Module 4: User Management](#5-module-4-user-management)
6. [Module 5: Organization Management](#6-module-5-organization-management)
7. [Module 6: Email Configuration](#7-module-6-email-configuration)
8. [Module 7: Reliability & Error Handling](#8-module-7-reliability--error-handling)
9. [Integration Flows](#9-integration-flows)
10. [Troubleshooting Guide](#10-troubleshooting-guide)

---

## 1. Prerequisites & Environment Setup

**Pre-conditions:**
- Application is running (`npm run dev`).
- User has a valid account (or access to Sign Up).
- Network connection is active.
- Supabase project is connected.

**Test Data:**
- **Valid Admin User:** `admin@example.com` / `password` (if seeded)
- **Valid Standard User:** `user@example.com` / `password`
- **Invalid Credentials:** `fake@test.com` / `wrongpass`

---

## 2. Module 1: Authentication & Access

| ID | Test Case | Steps | Expected Result | Pass/Fail |
|----|-----------|-------|-----------------|-----------|
| **AUTH-01** | **Successful Login** | 1. Navigate to `/login`.<br>2. Enter valid email/password.<br>3. Click "Sign In". | User is redirected to `/dashboard`. "Successfully signed in" toast appears. | |
| **AUTH-02** | **Failed Login** | 1. Navigate to `/login`.<br>2. Enter invalid credentials.<br>3. Click "Sign In". | Error toast "Invalid login credentials" appears. URL remains `/login`. | |
| **AUTH-03** | **Protected Route Guard** | 1. Logout if logged in.<br>2. Manually type `/dashboard` in browser URL bar. | System redirects to `/login` automatically. | |
| **AUTH-04** | **Sign Up Flow** | 1. Go to `/signup`.<br>2. Enter Email/Password/Org Name.<br>3. Submit. | Account created. User redirected to dashboard. Welcome message appears. | |
| **AUTH-05** | **Logout** | 1. Click User Avatar (top-right).<br>2. Select "Log out". | User redirected to Landing Page (`/`). Session cleared. | |

---

## 3. Module 2: Executive Dashboard (Real-time)

**Focus:** Verifying the "Completed Intakes not reflecting" fix and Real-time Activity Feed.

| ID | Test Case | Steps | Expected Result | Pass/Fail |
|----|-----------|-------|-----------------|-----------|
| **DASH-01** | **Stats Loading** | 1. Login as Admin.<br>2. Load Dashboard. | "Total Applications", "Pending Approvals", and "Risk Score" cards show numbers (not `...` or `0` if data exists). | |
| **DASH-02** | **Pending Approval Logic** | 1. Note the current "Pending Approval" count.<br>2. Go to **Business Initiation**.<br>3. Create & Submit a new app.<br>4. Return to Dashboard. | "Pending Approval" count should **increment by 1**. (Drafts must NOT count). | |
| **DASH-03** | **Real-time Activity Feed** | 1. Open Dashboard in **Tab A**.<br>2. Open Initiation in **Tab B**.<br>3. In Tab B: Submit a new application.<br>4. View Tab A immediately. | "Recent Activity" list updates automatically *without refresh*. New app appears at top. | |
| **DASH-04** | **Chart Rendering** | 1. Verify "Risk Distribution" chart.<br>2. Verify "Application Velocity" chart. | Charts render bars/lines correctly. Tooltips appear on hover. | |
| **DASH-05** | **Empty State** | 1. Login as new user (no data). | Dashboard shows empty states/zeros gracefully. No JS errors in console. | |

---

## 4. Module 3: Business Initiation (Intake Workflow)

| ID | Test Case | Steps | Expected Result | Pass/Fail |
|----|-----------|-------|-----------------|-----------|
| **INT-01** | **Step 1 Validation** | 1. Open Initiation Wizard.<br>2. Leave "Name" empty.<br>3. Click "Next". | "Next" button disabled or validation error red text appears. | |
| **INT-02** | **SPI Warning Trigger** | 1. Step 1: Fill Name.<br>2. Step 2: Select "SPI (Sensitive)" checkbox.<br>3. Click Next. | **Warning Alert** appears: "DPIA Triggered: Sensitive data detected". | |
| **INT-03** | **Risk Calculation** | 1. Complete Step 1 & 2.<br>2. Observe "Risk Score" badge. | Badge shows calculated score (e.g., "High", "Medium") based on inputs. | |
| **INT-04** | **Successful Submission** | 1. Complete all steps.<br>2. Click "Register Application". | Loading spinner appears. Success toast "Application Registered". Redirects to App List. | |
| **INT-05** | **Status Transition** | 1. Check status of newly created app in list. | Status should be **"Under Review"** (not Draft). | |

---

## 5. Module 4: User Management

**Focus:** Testing the "Refresh" button fix and invite flows.

| ID | Test Case | Steps | Expected Result | Pass/Fail |
|----|-----------|-------|-----------------|-----------|
| **USER-01** | **Load Users** | 1. Navigate to `Dashboard > Users`. | User table loads. Spinner disappears. List is visible. | |
| **USER-02** | **Manual Refresh** | 1. Click the "Refresh" icon button.<br>2. Observe icon. | Icon spins for ~500ms-1s. Table reloads data. Spin stops. | |
| **USER-03** | **Invite User** | 1. Click "Add User".<br>2. Fill Email/Role.<br>3. Click "Send Invite". | Modal closes. Toast "Invitation Sent". User appears in table as "Invited". | |
| **USER-04** | **Resend Invite** | 1. Find user with "Invited" status.<br>2. Click `...` > "Resend Invite". | **Only** that row's action triggers. Success toast appears. Button resets state. | |
| **USER-05** | **Remove User** | 1. Click `...` > "Remove User". | User is removed from list immediately. Success toast appears. | |

---

## 6. Module 5: Organization Management

| ID | Test Case | Steps | Expected Result | Pass/Fail |
|----|-----------|-------|-----------------|-----------|
| **ORG-01** | **View Details** | 1. Go to `Dashboard > Organization`. | Org Name, ID, and Tier are displayed correctly. | |
| **ORG-02** | **Update Settings** | 1. Change "Industry" dropdown.<br>2. Click "Save Changes". | Success toast. Page reload retains new value. | |
| **ORG-03** | **Tab Navigation** | 1. Click "Security & SSO".<br>2. Click "DNS & Domains". | Content area updates immediately without full page reload. | |

---

## 7. Module 6: Email Configuration

**Focus:** Verifying timeout handling and connection testing.

| ID | Test Case | Steps | Expected Result | Pass/Fail |
|----|-----------|-------|-----------------|-----------|
| **EMAIL-01** | **Toggle Custom SMTP** | 1. Go to `Organization > Email Services`.<br>2. Toggle "Use Custom SMTP". | Form fields slide down/appear. | |
| **EMAIL-02** | **Test Connection (Fail)** | 1. Enter dummy SMTP host/port.<br>2. Click "Test Connection". | Button shows spinner. After delay, Error toast: "Connection Failed". | |
| **EMAIL-03** | **Test Connection (Success)** | 1. Enter valid SMTP creds (if available).<br>2. Click "Test Connection". | Success toast: "Connection Successful". | |
| **EMAIL-04** | **Reset Changes** | 1. Modify fields.<br>2. Click "Reset Changes". | Fields revert to original DB values. Spinner stops. | |

---

## 8. Module 7: Reliability & Error Handling

| ID | Test Case | Steps | Expected Result | Pass/Fail |
|----|-----------|-------|-----------------|-----------|
| **ERR-01** | **Network Offline** | 1. Open DevTools > Network > "Offline".<br>2. Try to navigate/save. | "Connection Lost" banner appears at bottom of screen. | |
| **ERR-02** | **Network Recovery** | 1. Switch Network back to "No Throttling". | Banner changes to "Back Online" (Green) then disappears. | |
| **ERR-03** | **API Timeout** | 1. Simulate slow network (Slow 3G).<br>2. Load huge data set (if applicable). | Loading skeletons show. App does not crash. | |
| **ERR-04** | **404 Handling** | 1. Navigate to `/dashboard/non-existent-page`. | Redirects to `/dashboard` OR shows "Page Not Found" component. | |

---

## 9. Integration Flows

**Scenario: Complete Lifecycle**
1.  **Admin** configures Email Settings (**EMAIL-03**).
2.  **User** logs in (**AUTH-01**).
3.  **User** starts Business Intake (**INT-01**).
4.  **User** submits High Risk app (**INT-02**, **INT-04**).
5.  **Admin** sees update on Dashboard Activity Feed (**DASH-03**).
6.  **Admin** sees "Pending Approvals" increment (**DASH-02**).

---

## 10. Troubleshooting Tips

### Dashboard Not Updating?
*   **Check Realtime:** Open browser console. Look for `WebSocket connection established`. If red errors appear, Supabase Realtime might be down or blocked by firewall.
*   **Check Subscription:** Ensure you are looking at the correct Organization ID. The dashboard subscribes to `exec-dashboard-{orgId}`.

### "User Fetch Failed" in User Management?
*   **Check RLS Policies:** Ensure the current user has `Admin` or `Site Owner` role in `user_profiles` table. Standard users may be blocked from viewing the full user list.
*   **Check Console:** Look for `403 Forbidden` errors.

### Email Test Connection Times Out?
*   **Port Blocking:** Many ISPs block port `25` or `587`. Ensure you are not testing from a restricted network.
*   **Credentials:** Double-check SMTP Username/Password. Gmail requires "App Passwords" if 2FA is on.

### Changes Not Saving?
*   **Check Internet:** Verify "Offline" banner is not visible.
*   **Validation:** Scroll up to see if any hidden fields have red validation errors.

---
*End of Test Scripts*
