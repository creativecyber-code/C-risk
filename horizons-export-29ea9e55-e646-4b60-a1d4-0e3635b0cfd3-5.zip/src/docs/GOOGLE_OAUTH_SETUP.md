
# Google OAuth Configuration Guide

## 1. Credentials Configured
The following credentials have been securely stored in your Supabase project environment variables:

- **Google Client ID**: `66216995306-5ekvq2bhnmbbfdgpfu7sh99pnbafkl4q.apps.googleusercontent.com`
- **Google Client Secret**: `[Stored Securely]`
- **Supabase Project ID**: `bugvpkividbccayimgje`

## 2. Required Manual Configuration (Supabase Dashboard)
While the frontend logic is implemented, you **MUST** configure the provider in the Supabase Dashboard to enable the functionality:

1.  Go to **Authentication** > **Providers** > **Google**.
2.  Paste the **Client ID** listed above.
3.  Paste the **Client Secret**: `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`
4.  Ensure **Enable Sign in with Google** is toggled ON.
5.  Click **Save**.

## 3. Required Manual Configuration (Google Cloud Console)
Ensure your Google Cloud Console project is configured correctly:

1.  Go to APIs & Services > Credentials.
2.  Edit the OAuth 2.0 Client ID used above.
3.  Under **Authorized redirect URIs**, ensure the following URL is present:
    `https://bugvpkividbccayimgje.supabase.co/auth/v1/callback`
4.  Click **Save**.

## 4. Verification Steps
Once configured, you can verify the integration:
1.  Navigate to `/login` in this application.
2.  Click "Continue with Google".
3.  You should be redirected to the Google Consent Screen.
4.  After creating an account, you will be redirected to `/dashboard`.
5.  Check your User Profile (`/dashboard/profile`) to see the connected Google Identity.

## Troubleshooting
- **Error: "Provider not enabled"**: You skipped Step 2 above.
- **Error: "redirect_uri_mismatch"**: You skipped Step 3 above or the URL has a typo.
- **Error: "Popup closed by user"**: User closed the window before finishing.
