
# Edge Function Deployment Guide

## Overview
This document outlines the deployment and configuration process for the C-RISK invitation system Edge Functions.

## 1. Prerequisites
- Supabase CLI installed
- Supabase project initialized
- Resend API Key (for email delivery)

## 2. Functions

### `send-invite`
- **Purpose**: Generates a secure token, stores invitation record, and sends email.
- **Trigger**: Called by Tenant Management UI.
- **Environment Variables**:
  - `RESEND_API_KEY`: API key from Resend.com.
  - `SUPABASE_URL`: Auto-injected.
  - `SUPABASE_SERVICE_ROLE_KEY`: Auto-injected.

### `accept-invite`
- **Purpose**: Validates token, creates/links Auth user, assigns Tenant Member role.
- **Trigger**: Called by Accept Invitation page.
- **Environment Variables**:
  - `SUPABASE_URL`: Auto-injected.
  - `SUPABASE_SERVICE_ROLE_KEY`: Auto-injected.

## 3. Deployment Steps

### Step 1: Configure Secrets
Run the following commands to set up production secrets:
