
# Tenant Onboarding & Admin Mapping Process

## 1. Process Overview
The onboarding of a new tenant in the C-RISK platform involves two distinct phases: **Resource Provisioning** (creating the tenant entity) and **Access Provisioning** (mapping the first admin).

## 2. Current Architecture

### 2.1 Database Schema
The relationship between Tenants and Admins is **Many-to-Many** (technically, though usually 1:N in practice) managed via the `tenant_members` join table.

