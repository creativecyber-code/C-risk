
# API & Data Integration Guide

## 1. Overview
The C-RISK platform primarily uses **Supabase** as a Backend-as-a-Service (BaaS). All "API calls" are actually direct database interactions via the `supabase-js` client, secured by RLS.

## 2. Core Services

### 2.1 Business Initiation Service (`src/services/businessInitService.js`)
Handles the CRUD operations for the risk lifecycle.

**Key Methods:**
- `createApplication(data, orgId)`: Creates the application and initializes empty assessment records.
- `updateAssessment(appId, scores)`: Calculates the risk score (Qualitative + FAIR ALE) and updates the database. Triggers status changes (e.g., to "Under Review").
- `getDashboardStats(orgId)`: Aggregates counts for the dashboard (High Risk, Pending, etc.).

### 2.2 C-RISK Service (`src/services/cRiskService.js`)
Handles specific domain logic for the banking sector.

**Key Methods:**
- `initializeGates(appId)`: Creates the default set of blocking gates (Contract, Architecture, AppSec) for a new app.
- `getRegulatoryMappings(classification)`: Returns a list of required controls based on data types (e.g., if PII -> return DPDP Act controls).

## 3. External Integrations (Simulated)

### 3.1 Document Parsing
**Component:** `DocumentParser.jsx`
- **Current State:** Simulation.
- **Future Integration:** Could connect to Azure AI Document Intelligence or AWS Textract to parse uploaded SOW/Architecture documents.

### 3.2 AI Classification
**Component:** `AIDataClassifier.jsx`
- **Current State:** Keyword matching (Deterministic).
- **Future Integration:** OpenAI API / Anthropic Claude API to analyze description text and suggest risk categories with higher accuracy.

## 4. Data Models (JSONB Structures)

### 4.1 Data Classification
Stored in `business_applications.data_classification` (JSONB):
