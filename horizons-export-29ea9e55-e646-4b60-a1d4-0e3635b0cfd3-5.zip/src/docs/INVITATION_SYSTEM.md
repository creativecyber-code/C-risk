
# Tenant Invitation System Documentation

## 1. Overview
The invitation system allows Platform Admins and Tenant Admins to onboard new users to specific organizations. It utilizes a secure token-based workflow handled via Supabase Edge Functions to ensure security and proper data consistency across Auth and Application tables.

## 2. Architecture

### Database Schema (`public.tenant_invitations`)
| Column | Type | Description |
|---|---|---|
| `id` | uuid | Primary Key |
| `tenant_id` | uuid | Foreign Key to Organizations |
| `email` | text | Recipient email |
| `role` | text | Role to be assigned (e.g., 'tenant_admin') |
| `token` | text | Unique 64-char secure token |
| `status` | text | 'pending', 'accepted', 'expired' |
| `expires_at` | timestamptz | Token expiration (default: 7 days) |

### Components

1.  **Frontend**:
    *   `TenantManagement.jsx`: Admin UI to issue invites.
    *   `AcceptInvitation.jsx`: Public landing page for the email link.
    *   `invitationService.js`: Client-side wrapper for API calls.

2.  **Backend (Supabase Edge Functions)**:
    *   `send-invite`: Generates token, stores in DB, sends email.
    *   `accept-invite`: Validates token, provisions user in `auth.users`, links to `tenant_members`.

## 3. Workflow

### A. Sending an Invitation
1.  Admin enters email and role.
2.  `send-invite` function is called.
3.  Function checks for existing pending invites.
4.  Function generates a crypto-random token.
5.  Record inserted into `tenant_invitations`.
6.  Email sent via SMTP/Provider containing link: `https://[domain]/accept-invitation?token=[token]`.

### B. Accepting an Invitation
1.  User clicks link.
2.  `AcceptInvitation.jsx` validates token against DB on mount.
3.  User enters full name and password.
4.  `accept-invite` function is called with token + password.
5.  Function:
    *   Verifies token expiry.
    *   Creates user in Supabase Auth (auto-confirmed).
    *   Inserts record into `tenant_members`.
    *   Updates invitation status to `accepted`.
6.  User is automatically logged in and redirected to dashboard.

## 4. Security
*   **Token Expiry**: Invites expire after 7 days.
*   **RLS**: Only Admins can see invites. Public can only query if they possess the exact token.
*   **Atomic Operations**: Acceptance logic runs in a transaction within the Edge Function to prevent orphaned records.

## 5. API Reference

### `POST /functions/v1/send-invite`
**Body:** `{ "email": "user@example.com", "role": "tenant_admin", "tenantId": "uuid" }`

### `POST /functions/v1/accept-invite`
**Body:** `{ "token": "xyz...", "password": "...", "fullName": "..." }`
