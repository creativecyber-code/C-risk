
# Database Schema Analysis: User Activity & Management

This document outlines the current database schema related to user tracking, activity logs, and platform staff management as of 2026-01-04.

## 1. User Management Tables

### `platform_staff`
Primary table for tracking users with platform-level access.
*   **`id`** (uuid): Primary Key.
*   **`user_id`** (uuid): Foreign Key to `auth.users`. Links the profile to the authentication record.
*   **`email`** (text): User's email address (synced).
*   **`role`** (text): The permission level (`super_admin`, `admin`, `viewer`).
*   **`created_at`** (timestamp): When the staff record was created.

### `platform_invites`
Tracks pending invitations for new staff members.
*   **`id`** (uuid): Primary Key.
*   **`code`** (text): Unique invite code used for signup validation.
*   **`email`** (text): The email address invited.
*   **`role`** (text): The role to be assigned upon signup.
*   **`invited_by`** (uuid): ID of the admin who created the invite.
*   **`status`** (text): State of invite (`pending`, `used`, `expired`).
*   **`expires_at`** (timestamp): Expiration deadline.
*   **`used_at`** (timestamp): When the invite was accepted.
*   **`used_by_user_id`** (uuid): Which user ID claimed this invite.

## 2. Activity & Audit Logs

### `audit_logs`
The central table for tracking critical actions and user activity within the system.
*   **`id`** (uuid): Primary Key.
*   **`actor_id`** (uuid): The ID of the user performing the action.
*   **`actor_realm`** (text): Context of the actor (e.g., 'platform' or 'tenant').
*   **`action`** (text): specific action code (e.g., `LOGIN`, `CREATE_USER`, `DELETE_INVITE`).
*   **`resource_table`** (text): The database table affected.
*   **`resource_id`** (uuid): The ID of the specific record affected.
*   **`old_values`** (jsonb): Snapshot of data before change (for updates/deletes).
*   **`new_values`** (jsonb): Snapshot of data after change.
*   **`ip_address`** (text): IP address of the user.
*   **`timestamp`** (timestamp): Exact time of the event.

### `system_logs`
Tracks system-level errors, warnings, and operational logs.
*   **`level`** (text): Severity (`info`, `warn`, `error`).
*   **`user_email`** (text): Email of user involved (if applicable).
*   **`action`** (text): System action.
*   **`details`** (jsonb): JSON payload with error stack or debug info.
*   **`ip_address`** (text): Source IP.

## 3. Login History & Active Status Logic

### Tracking Login History
Login history is tracked in two places:
1.  **`auth.users` (Internal Supabase Table)**: Contains the `last_sign_in_at` timestamp. This is the most reliable source for "last seen" status.
2.  **`audit_logs`**: If configured, login events can be inserted here with `action = 'LOGIN'` for a historical record of all logins (not just the last one).

### Distinguishing User Status
The application logic (specifically the `get_platform_staff_details` RPC function) uses the following logic to determine status:

1.  **Invited (Pending)**:
    *   Record exists in `platform_invites` with `status = 'pending'`.
    *   OR record exists in `auth.users` but `confirmed_at` is NULL.

2.  **Active**:
    *   Record exists in `platform_staff`.
    *   Linked `auth.users` record has a valid `confirmed_at` timestamp.
    *   `banned_until` is NULL or in the past.

3.  **Suspended**:
    *   `auth.users.banned_until` is set to a future date.

### Helper Functions
*   **`get_platform_staff_details()`**: A security-definer RPC function that joins `platform_staff` with `auth.users` to return:
    *   `full_name` (from metadata)
    *   `last_sign_in_at` (from auth.users)
    *   Calculated `status` field.
