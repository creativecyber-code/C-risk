
# User Roles & Permissions Matrix

## 1. Role Types

### 1.1 Platform Roles
Defined in `public.platform_staff`. These users manage the SaaS infrastructure.
- **Super Admin (`super_admin`):** Full access to all tenants, logs, and system configurations.
- **Platform Admin (`admin`):** Can manage support tickets and view tenant usage, but cannot access tenant risk data directly without impersonation (if enabled).

### 1.2 Tenant Roles
Defined in `public.tenant_members`. These are the actual users of the C-RISK modules.
- **Tenant Admin:** Can configure tenant settings, invite users, and see all initiatives.
- **Risk Officer:** Can approve/reject assessments, manage security gates, and configure risk parameters.
- **Business Owner:** Can create initiatives (Intake) and view their status. Cannot approve their own high-risk assessments.
- **Auditor:** Read-only access to all records and reports.

## 2. Access Control Logic

### 2.1 Route Protection
Handled by `src/components/ProtectedRoute.jsx`.
- Checks `allowedRole` prop against user's context.
- Redirects unauthorized users to `/login`.

### 2.2 Row Level Security (RLS)
Database-level enforcement using PostgreSQL policies.

**Example Policies:**
1.  **"Tenant: View Own Applications"**
    