
# C-RISK Platform Architectural Overview

## 1. Introduction
C-RISK is a specialized GRC (Governance, Risk, and Compliance) platform built for the BFSI sector. It enables organizations to manage the risk lifecycle of new business initiatives, ensuring compliance with regulators like RBI, SEBI, and UIDAI before systems go live.

## 2. High-Level Architecture
The system uses a **Multi-Tenant SaaS Architecture** deployed on a serverless infrastructure (Supabase/Vite).

### 2.1 Technology Stack
- **Frontend Framework:** React 18 with Vite
- **Styling:** TailwindCSS 3.3
- **Component Library:** Shadcn/UI (Radix UI)
- **Icons:** Lucide React
- **Visualization:** Recharts
- **State Management:** React Context + Hooks
- **Backend/DB:** Supabase (PostgreSQL 15)
- **Security:** RLS (Row Level Security)

### 2.2 Security Model
- **Authentication:** Supabase Auth handles identity.
- **Authorization:** 
  - **Platform Role:** Checked via `platform_staff` table.
  - **Tenant Role:** Checked via `tenant_members` table.
- **Data Isolation:** Enforced at the database level using RLS policies. A user from Tenant A cannot physically query data from Tenant B.

## 3. Module Breakdown

### 3.1 Platform Console (Super Admin)
**Path:** `/platform-console/*`
Designed for the SaaS provider to manage the system.
- **Tenant Management:** Provisioning new banking clients.
- **Content Push Engine:** Broadcasting new regulatory baselines to all tenants.
- **Global Logs:** System-wide health monitoring.

### 3.2 Tenant Dashboard (End User)
**Path:** `/app-dashboard/*`
The operational hub for Risk Officers and CISOs.

#### A. Business Initiation Module (C-RISK Core)
Located at `src/components/business/BusinessInitiation.jsx`. This is a wizard-style flow:
1.  **Intake:** Captures basic metadata. Features AI-driven keyword analysis to suggest risk categories.
2.  **Classification:** Data taxonomy selection (PII, SPI, Financial). Automated trigger logic determines if a DPIA (Data Protection Impact Assessment) is required.
3.  **Risk Assessment:** 
    - **Qualitative:** 5-dimension scoring (Confidentiality, Integrity, etc.).
    - **Quantitative:** FAIR model calculator for financial exposure (ALE).
4.  **Questionnaire:** Dynamic checklist based on calculated risk level.
5.  **Security Gates:** Phase-gate process (e.g., Architecture Review, TPRM) that blocks production deployment until satisfied.

#### B. Compliance Dashboard
Located at `src/components/business/InitiativeComplianceDashboard.jsx`.
- Provides aggregated views of risk posture.
- Filters by Regulation (RBI, NPCI, DPDP).
- Exports reports for external auditors.

## 4. Database Schema Relationships

### 4.1 Core Entities
- `organizations` (id, name)
    - 1:N -> `tenant_members` (users)
    - 1:N -> `business_applications` (projects)

- `business_applications` (id, org_id, name, risk_level)
    - 1:1 -> `inherent_risk_assessments` (scores)
    - 1:N -> `security_gates` (approvals)
    - 1:N -> `workflow_approvals` (audit trail)

## 5. Key Integrations & Services
- **`businessInitService.js`:** Orchestrates the complex logic of creating applications, calculating risk scores, and managing gate status.
- **`cRiskService.js`:** Specialized service for the C-RISK workflow, handling scenario mapping and regulatory lookups.
- **`SupabaseAuthContext.jsx`:** Provides the `useAuth` hook for session management.

## 6. Directory Structure
