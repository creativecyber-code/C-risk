
import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { invitationService } from '@/services/invitationService';

const AuthContext = createContext(undefined);

// Helper for exponential backoff
const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();
  
  // Auth State
  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // MFA State
  const [mfaRequired, setMfaRequired] = useState(false);
  const [mfaVerified, setMfaVerified] = useState(false);
  
  // Role & Tenant State
  const [userRole, setUserRole] = useState(null);
  const [userRoleDefinition, setUserRoleDefinition] = useState(null);
  const [tenant, setTenant] = useState(null);
  const [isPlatformStaff, setIsPlatformStaff] = useState(false);
  
  // Invitation State
  const [pendingInvites, setPendingInvites] = useState([]);
  
  // Error & Debugging State
  const [roleError, setRoleError] = useState(null);
  const [rawUser, setRawUser] = useState(null); // Store raw user for debugging
  
  // Ref to prevent duplicate checks
  const isCheckingRoleRef = useRef(false);

  // Helper to clear state
  const clearAuthState = () => {
    setUser(null);
    setSession(null);
    setUserRole(null);
    setIsPlatformStaff(false);
    setTenant(null);
    setUserRoleDefinition(null);
    setRoleError(null);
    setRawUser(null);
    setPendingInvites([]);
    setMfaRequired(false);
    setMfaVerified(false);
  };

  /**
   * Check MFA Status for current user/session
   */
  const checkMfaStatus = useCallback(async (currentSession) => {
    if (!currentSession?.user) {
      setMfaRequired(false);
      setMfaVerified(false);
      return;
    }

    try {
      // 1. Check Assurance Level
      const { data: aalData, error: aalError } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
      
      if (aalError) {
        console.warn('[AuthContext] Error checking AAL:', aalError);
        return;
      }

      // 2. Check Enrolled Factors
      const { data: factorsData, error: factorsError } = await supabase.auth.mfa.listFactors();
      
      if (factorsError) {
        console.warn('[AuthContext] Error listing factors:', factorsError);
        return;
      }

      const hasVerifiedFactors = factorsData?.totp?.length > 0;
      const currentLevel = aalData?.currentLevel;
      const nextLevel = aalData?.nextLevel;

      console.log(`[AuthContext] MFA Status - Level: ${currentLevel}, Factors: ${factorsData?.totp?.length || 0}`);

      if (hasVerifiedFactors) {
        if (currentLevel === 'aal2') {
          // Already verified
          setMfaRequired(false);
          setMfaVerified(true);
        } else {
          // Needs verification (Factors exist but only aal1)
          setMfaRequired(true);
          setMfaVerified(false);
        }
      } else {
        // No factors setup, standard login
        setMfaRequired(false);
        setMfaVerified(true); // Treated as verified for standard users
      }

    } catch (err) {
      console.error('[AuthContext] MFA check failed:', err);
    }
  }, []);

  /**
   * Robust Role Check with Retry and Fallback
   */
  const checkRole = useCallback(async (currentUser) => {
    if (!currentUser) return;
    
    const userId = currentUser.id;
    const email = currentUser.email || '';
    
    // Prevent re-entry if already checking
    if (isCheckingRoleRef.current) return;
    isCheckingRoleRef.current = true;
    setRoleError(null);
    setPendingInvites([]);
    
    console.log(`[AuthContext] 🔍 Starting role detection for: ${email} (${userId})`);

    try {
      // 1. Check Platform Staff Table First
      const { data: platformData, error: platformError } = await supabase
        .from('platform_staff')
        .select('role')
        .eq('user_id', userId)
        .maybeSingle();

      if (platformError && platformError.code !== 'PGRST116') {
         console.warn('[AuthContext] ⚠️ Platform check warning:', platformError.message);
      }

      const PLATFORM_ROLES = ['super_admin', 'admin', 'viewer'];
      
      if (platformData && PLATFORM_ROLES.includes(platformData.role)) {
        console.log(`[AuthContext] ✅ Identified as Platform Staff: ${platformData.role}`);
        setUserRole(platformData.role);
        setIsPlatformStaff(true);
        setTenant(null); 
        setUserRoleDefinition({ role_key: platformData.role, display_name: 'Platform Staff' });
        return; // Exit early
      }

      // 2. Check Tenant Members Table with Retry Logic
      let tenantData = null;
      let attempt = 0;
      const maxRetries = 3;
      let lastError = null;

      while (attempt < maxRetries && !tenantData) {
        try {
          if (attempt > 0) {
            const delay = 1000 * Math.pow(2, attempt - 1);
            if (attempt > 1) console.log(`[AuthContext] ⏳ Retry attempt ${attempt}/${maxRetries} for tenant data...`);
            await wait(delay);
          }

          const { data, error } = await supabase
            .from('tenant_members')
            .select(`
              role_key, 
              tenant_id, 
              organizations:tenant_id (
                id, 
                name, 
                slug,
                license_tier
              )
            `)
            .eq('user_id', userId)
            .maybeSingle();

          if (error && error.code !== 'PGRST116') throw error;
          tenantData = data;
          if (tenantData) break;

        } catch (err) {
          console.error(`[AuthContext] ❌ Tenant query attempt ${attempt + 1} failed:`, err.message);
          lastError = err;
        }
        attempt++;
      }

      // 3. Handle Tenant Data Found
      if (tenantData) {
        console.log(`[AuthContext] ✅ Identified as Tenant Member: ${tenantData.role_key}`);
        
        setUserRole(tenantData.role_key || 'tenant_member'); 
        setIsPlatformStaff(false);
        
        if (tenantData.organizations) {
          setTenant(tenantData.organizations);
        }

        // Fetch definition
        if (tenantData.role_key) {
           const { data: roleDef } = await supabase
              .from('tenant_role_definitions')
              .select('*')
              .eq('role_key', tenantData.role_key)
              .maybeSingle();
           
           setUserRoleDefinition(roleDef || { display_name: tenantData.role_key, role_key: tenantData.role_key });
        }
        return;
      }

      // 4. CHECK PENDING INVITATIONS
      console.log('[AuthContext] No active role. Checking for pending invitations...');
      try {
        const myInvites = await invitationService.getMyPendingInvites();
        if (myInvites && myInvites.length > 0) {
           console.log(`[AuthContext] 📬 Found ${myInvites.length} pending invites.`);
           setPendingInvites(myInvites);
           return; 
        }
      } catch (inviteErr) {
        console.warn("[AuthContext] Failed to check pending invites:", inviteErr);
      }

      // 5. FALLBACK / BYPASS LOGIC
      console.log('[AuthContext] ⚠️ No database role or invites found. Attempting metadata/bypass strategies...');
      
      const metaRole = currentUser?.user_metadata?.role || currentUser?.app_metadata?.role;
      const isEmailAdmin = email.toLowerCase().includes('admin') || email.toLowerCase().includes('demo');

      if (metaRole) {
         console.log(`[AuthContext] 🛡️ Fallback: Using Metadata Role: ${metaRole}`);
         setUserRole(metaRole);
         
         if (PLATFORM_ROLES.includes(metaRole)) {
            setIsPlatformStaff(true);
            setTenant(null);
         } else {
            setTenant({ id: 'stub-tenant-id', name: 'Temporary Context' }); 
            setIsPlatformStaff(false);
         }
         setUserRoleDefinition({ display_name: metaRole, role_key: metaRole });
         
      } else if (isEmailAdmin) {
         console.log(`[AuthContext] 🚨 BYPASS: Email contains 'admin/demo'. Granting temporary admin access.`);
         const bypassRole = 'admin'; 
         setUserRole(bypassRole);
         setIsPlatformStaff(false); 
         setTenant({ 
           id: 'bypass-tenant-id', 
           name: 'Admin Bypass Tenant',
           slug: 'admin-bypass'
         });
         setUserRoleDefinition({ 
           role_key: bypassRole, 
           display_name: 'Admin (Bypass)', 
           description: 'Temporary bypass role based on email pattern' 
         });
         toast({
           title: "Admin Bypass Active",
           description: "You have been granted temporary access based on your email pattern.",
           variant: "destructive"
         });

      } else {
         const errorMsg = lastError ? lastError.message : 'User not found in tenant_members table.';
         console.error('[AuthContext] ⛔ Role Detection Failed:', errorMsg);
         setRoleError({
           message: errorMsg,
           detail: 'No role found and no pending invites.',
           userId: userId
         });
         setUserRole(null);
         setTenant(null);
      }
      
    } catch (err) {
      console.error('[AuthContext] 💥 Critical Role Check Exception:', err);
      setRoleError({
        message: err.message || 'Unknown error during role check',
        userId: userId
      });
    } finally {
      isCheckingRoleRef.current = false;
    }
  }, [toast]);

  // Initial Session Load
  useEffect(() => {
    let mounted = true;

    async function getInitialSession() {
      try {
        setLoading(true);
        const { data: { session: initialSession }, error } = await supabase.auth.getSession();
        
        if (mounted) {
          if (initialSession) {
            setSession(initialSession);
            setUser(initialSession.user);
            setRawUser(initialSession.user);
            
            // Check MFA and Role
            await checkMfaStatus(initialSession);
            await checkRole(initialSession.user);
          } else {
            clearAuthState();
          }
        }
      } catch (error) {
        console.error('[AuthContext] Error getting session:', error);
      } finally {
        if (mounted) setLoading(false);
      }
    }

    getInitialSession();

    // Listen for Auth Changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, currentSession) => {
        if (!mounted) return;
        
        console.log(`[AuthContext] 🔔 Auth State Change: ${_event}`);
        
        if (_event === 'SIGNED_OUT') {
           clearAuthState();
           setLoading(false);
        } else if (_event === 'SIGNED_IN' || _event === 'TOKEN_REFRESHED' || _event === 'USER_UPDATED' || _event === 'MFA_CHALLENGE_VERIFIED') {
           setSession(currentSession);
           const newUser = currentSession?.user ?? null;
           setUser(newUser);
           setRawUser(newUser);
           
           if (newUser) {
             await checkMfaStatus(currentSession);
             await checkRole(newUser);
           }
           setLoading(false);
        }
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [checkRole, checkMfaStatus]);

  // Auth Methods
  const signUp = useCallback(async (email, password, options = {}) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/login`,
          ...options
        },
      });
      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error("Sign up error:", error);
      return { data: null, error };
    }
  }, []);

  const signIn = useCallback(async (email, password) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      
      if (error) throw error;

      // Check if MFA is required immediately after sign in
      const { data: factors } = await supabase.auth.mfa.listFactors();
      const hasFactors = factors?.totp?.length > 0;
      
      if (hasFactors) {
        setMfaRequired(true);
        return { data, error: null, mfaRequired: true };
      }

      return { data, error: null, mfaRequired: false };
    } catch (error) {
      return { data: null, error };
    }
  }, []);

  const verifyMfaChallenge = useCallback(async (code) => {
    try {
      const { data: factors } = await supabase.auth.mfa.listFactors();
      const totpFactor = factors?.totp?.[0];
      
      if (!totpFactor) throw new Error("No MFA factor found.");

      const { data, error } = await supabase.auth.mfa.challengeAndVerify({
        factorId: totpFactor.id,
        code
      });

      if (error) throw error;
      
      setMfaRequired(false);
      setMfaVerified(true);
      return { data, error: null };
    } catch (error) {
      return { data: null, error };
    }
  }, []);

  const signOut = useCallback(async () => {
    try {
      clearAuthState();
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      toast({
        title: "Signed Out",
        description: "You have been securely signed out.",
      });
    } catch (error) {
      console.error('Sign out error:', error);
    }
  }, [toast]);

  const value = {
    user,
    session,
    userRole,
    userRoleDefinition,
    tenant,
    isPlatformStaff,
    pendingInvites, 
    loading,
    roleError,
    rawUser,
    mfaRequired,
    mfaVerified,
    profile: user?.user_metadata || null,
    isInitialized: !loading,
    signUp,
    signIn,
    signOut,
    verifyMfaChallenge,
    refreshRole: () => user && checkRole(user)
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
