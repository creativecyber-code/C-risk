
// This file is a compatibility wrapper to resolve Context Provider mismatches.
// The application root (App.jsx) uses AuthProvider from './AuthContext'.
// Therefore, all components must consume the context from './AuthContext'.
// We re-export it here to ensure any legacy imports still point to the correct Context instance.

export { AuthProvider, useAuth } from './AuthContext';
