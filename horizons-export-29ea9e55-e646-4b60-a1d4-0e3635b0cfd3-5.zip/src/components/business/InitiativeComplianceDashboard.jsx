
import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
    Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { CheckCircle2, AlertTriangle, XCircle, Search, Download, FileText, Activity } from 'lucide-react';
import { businessInitService } from '@/services/businessInitService';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';

const InitiativeComplianceDashboard = ({ orgId }) => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
      status: 'ALL',
      regulation: 'ALL',
      risk: 'ALL'
  });
  const [selectedApp, setSelectedApp] = useState(null);

  useEffect(() => {
    if (orgId) loadData();
  }, [orgId]);

  const loadData = async () => {
    setLoading(true);
    try {
        const data = await businessInitService.getApplications(orgId);
        setApplications(data || []);
    } catch (err) {
        console.error("Failed to load apps", err);
    } finally {
        setLoading(false);
    }
  };

  // --- Logic Helpers ---

  const getComplianceStatus = (app) => {
      const gates = app.security_gates || [];
      if (gates.length === 0) return 'NOT ASSESSED';
      
      const blockingGates = gates.filter(g => g.is_blocking);
      if (blockingGates.length === 0) return 'NOT ASSESSED'; // Or Complied if no blocking? Usually requires at least one assessment.

      const allPassed = blockingGates.every(g => g.status === 'PASSED');
      if (allPassed) return 'COMPLIED';

      const anyRejected = blockingGates.some(g => g.status === 'FAILED');
      if (anyRejected) return 'PENDING'; // Per requirements (Rejected -> Pending)

      return 'PENDING';
  };

  const getComplianceColor = (status) => {
      switch(status) {
          case 'COMPLIED': return 'bg-green-100 text-green-700 border-green-200';
          case 'PENDING': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
          case 'NOT ASSESSED': return 'bg-slate-100 text-slate-500 border-slate-200';
          default: return 'bg-slate-100 text-slate-700';
      }
  };

  const mapTagsToCompliance = (regulations = []) => {
      if (!regulations) return [];
      const mappings = [
          { keyword: 'RBI', label: 'RBI Compliance' },
          { keyword: 'NPCI', label: 'NPCI Compliance' },
          { keyword: 'UIDAI', label: 'UIDAI Compliance' },
          { keyword: 'TPRM', label: 'TPRM Compliance' },
          { keyword: 'DPDP', label: 'DPDP Compliance' },
          { keyword: 'NIST', label: 'NIST Compliance' }
      ];

      const found = new Set();
      regulations.forEach(reg => {
          mappings.forEach(m => {
              if (reg && reg.toUpperCase().includes(m.keyword)) {
                  found.add(m.label);
              }
          });
      });

      return Array.from(found);
  };

  // --- Filtering ---
  
  const filteredApps = useMemo(() => {
      return applications.filter(app => {
          const status = getComplianceStatus(app);
          const tags = mapTagsToCompliance(app.regulations);
          
          const matchSearch = app.name.toLowerCase().includes(searchTerm.toLowerCase());
          const matchStatus = filters.status === 'ALL' || status === filters.status;
          const matchRisk = filters.risk === 'ALL' || app.inherent_risk_level === filters.risk;
          const matchReg = filters.regulation === 'ALL' || tags.some(t => t.includes(filters.regulation));

          return matchSearch && matchStatus && matchRisk && matchReg;
      });
  }, [applications, searchTerm, filters]);

  // --- Stats ---

  const stats = useMemo(() => {
      const total = applications.length;
      const complied = applications.filter(a => getComplianceStatus(a) === 'COMPLIED').length;
      const pending = applications.filter(a => getComplianceStatus(a) === 'PENDING').length;
      const notAssessed = applications.filter(a => getComplianceStatus(a) === 'NOT ASSESSED').length;
      
      return { total, complied, pending, notAssessed };
  }, [applications]);

  // --- Exports ---

  const handleExportPDF = () => {
      const doc = new jsPDF();
      doc.setFontSize(18);
      doc.text("Initiative Compliance Report", 14, 20);
      doc.setFontSize(10);
      doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 30);
      
      const tableRows = filteredApps.map(app => [
          app.name,
          app.business_unit,
          app.inherent_risk_level,
          getComplianceStatus(app),
          mapTagsToCompliance(app.regulations).join(', ') || '-'
      ]);

      doc.autoTable({
          startY: 40,
          head: [['Initiative', 'Business Unit', 'Risk', 'Status', 'Compliance Scope']],
          body: tableRows,
      });

      doc.save('compliance_report.pdf');
  };

  const handleExportCSV = () => {
      const data = filteredApps.map(app => ({
          Name: app.name,
          Unit: app.business_unit,
          Risk: app.inherent_risk_level,
          Compliance_Status: getComplianceStatus(app),
          Scope: mapTagsToCompliance(app.regulations).join('; ')
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Compliance");
      XLSX.writeFile(wb, "compliance_export.xlsx");
  };

  return (
    <div className="space-y-6">
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
              <CardContent className="pt-6">
                  <div className="text-sm font-medium text-slate-500">Total Initiatives</div>
                  <div className="text-2xl font-bold">{stats.total}</div>
              </CardContent>
          </Card>
          <Card>
              <CardContent className="pt-6">
                  <div className="text-sm font-medium text-slate-500 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600" /> Complied
                  </div>
                  <div className="text-2xl font-bold text-green-700">{stats.complied}</div>
              </CardContent>
          </Card>
          <Card>
              <CardContent className="pt-6">
                  <div className="text-sm font-medium text-slate-500 flex items-center gap-2">
                      <Activity className="w-4 h-4 text-yellow-600" /> Pending Review
                  </div>
                  <div className="text-2xl font-bold text-yellow-700">{stats.pending}</div>
              </CardContent>
          </Card>
          <Card>
              <CardContent className="pt-6">
                  <div className="text-sm font-medium text-slate-500 flex items-center gap-2">
                       <AlertTriangle className="w-4 h-4 text-slate-400" /> Not Assessed
                  </div>
                  <div className="text-2xl font-bold text-slate-600">{stats.notAssessed}</div>
              </CardContent>
          </Card>
      </div>

      {/* Filters & Actions */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex gap-2 items-center flex-1 w-full">
             <div className="relative w-full max-w-xs">
                 <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                 <Input 
                    placeholder="Search initiatives..." 
                    className="pl-10"
                    value={searchTerm} 
                    onChange={e => setSearchTerm(e.target.value)}
                 />
             </div>
             <Select value={filters.status} onValueChange={v => setFilters({...filters, status: v})}>
                 <SelectTrigger className="w-[150px]"><SelectValue placeholder="Status" /></SelectTrigger>
                 <SelectContent>
                     <SelectItem value="ALL">All Status</SelectItem>
                     <SelectItem value="COMPLIED">Complied</SelectItem>
                     <SelectItem value="PENDING">Pending</SelectItem>
                     <SelectItem value="NOT ASSESSED">Not Assessed</SelectItem>
                 </SelectContent>
             </Select>
             <Select value={filters.regulation} onValueChange={v => setFilters({...filters, regulation: v})}>
                 <SelectTrigger className="w-[150px]"><SelectValue placeholder="Regulation" /></SelectTrigger>
                 <SelectContent>
                     <SelectItem value="ALL">All Regulations</SelectItem>
                     <SelectItem value="RBI">RBI</SelectItem>
                     <SelectItem value="NPCI">NPCI</SelectItem>
                     <SelectItem value="DPDP">DPDP</SelectItem>
                     <SelectItem value="TPRM">TPRM</SelectItem>
                 </SelectContent>
             </Select>
          </div>
          <div className="flex gap-2">
             <Button variant="outline" onClick={handleExportCSV}>
                 <Download className="w-4 h-4 mr-2" /> CSV
             </Button>
             <Button variant="outline" onClick={handleExportPDF}>
                 <FileText className="w-4 h-4 mr-2" /> PDF
             </Button>
          </div>
      </div>

      {/* Main Table */}
      <Card>
          <CardHeader>
              <CardTitle>Compliance Status Registry</CardTitle>
          </CardHeader>
          <CardContent>
              <Table>
                  <TableHeader>
                      <TableRow>
                          <TableHead>Initiative Name</TableHead>
                          <TableHead>Business Unit</TableHead>
                          <TableHead>Risk Level</TableHead>
                          <TableHead>Compliance Scope</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Last Updated</TableHead>
                      </TableRow>
                  </TableHeader>
                  <TableBody>
                      {loading ? (
                          <TableRow><TableCell colSpan={6} className="text-center py-8">Loading...</TableCell></TableRow>
                      ) : filteredApps.length === 0 ? (
                          <TableRow><TableCell colSpan={6} className="text-center py-8 text-slate-500">No records found matching filters.</TableCell></TableRow>
                      ) : (
                          filteredApps.map(app => {
                              const status = getComplianceStatus(app);
                              const complianceTags = mapTagsToCompliance(app.regulations);
                              
                              return (
                                  <TableRow 
                                    key={app.id} 
                                    className="cursor-pointer hover:bg-slate-50"
                                    onClick={() => setSelectedApp(app)}
                                  >
                                      <TableCell className="font-medium text-blue-600">{app.name}</TableCell>
                                      <TableCell>{app.business_unit}</TableCell>
                                      <TableCell>
                                          <Badge variant={['High','Critical'].includes(app.inherent_risk_level) ? 'destructive' : 'secondary'}>
                                              {app.inherent_risk_level}
                                          </Badge>
                                      </TableCell>
                                      <TableCell>
                                          <div className="flex flex-wrap gap-1">
                                              {complianceTags.length > 0 ? complianceTags.map(tag => (
                                                  <Badge key={tag} variant="outline" className="text-[10px] px-1 py-0 h-5">
                                                      {tag.split(' ')[0]}
                                                  </Badge>
                                              )) : <span className="text-slate-400 text-xs">-</span>}
                                          </div>
                                      </TableCell>
                                      <TableCell>
                                          <Badge variant="outline" className={`${getComplianceColor(status)} border`}>
                                              {status}
                                          </Badge>
                                      </TableCell>
                                      <TableCell className="text-right text-xs text-slate-500">
                                          {new Date(app.updated_at).toLocaleDateString()}
                                      </TableCell>
                                  </TableRow>
                              );
                          })
                      )}
                  </TableBody>
              </Table>
          </CardContent>
      </Card>

      {/* Detail View Sheet */}
      <Sheet open={!!selectedApp} onOpenChange={(v) => !v && setSelectedApp(null)}>
          <SheetContent className="w-full sm:w-[540px] overflow-y-auto">
              <SheetHeader>
                  <SheetTitle>Compliance Details</SheetTitle>
                  <SheetDescription>{selectedApp?.name}</SheetDescription>
              </SheetHeader>
              
              {selectedApp && (
                  <div className="mt-6 space-y-6">
                      
                      {/* Status Header */}
                      <div className={`p-4 rounded-lg border flex items-center justify-between ${getComplianceColor(getComplianceStatus(selectedApp))}`}>
                          <div>
                              <div className="text-xs font-semibold opacity-80">OVERALL STATUS</div>
                              <div className="text-lg font-bold">{getComplianceStatus(selectedApp)}</div>
                          </div>
                          {getComplianceStatus(selectedApp) === 'COMPLIED' ? (
                              <CheckCircle2 className="w-8 h-8" />
                          ) : (
                              <Activity className="w-8 h-8" />
                          )}
                      </div>

                      {/* Applicable Regulations */}
                      <div>
                          <h4 className="text-sm font-semibold mb-2">Applicable Frameworks</h4>
                          <div className="flex flex-wrap gap-2">
                              {mapTagsToCompliance(selectedApp.regulations).map(tag => (
                                  <Badge key={tag} className="bg-slate-900">{tag}</Badge>
                              ))}
                              {mapTagsToCompliance(selectedApp.regulations).length === 0 && (
                                  <p className="text-sm text-slate-500 italic">No specific regulatory tags found.</p>
                              )}
                          </div>
                      </div>

                      {/* CISO Recommendation */}
                      <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                          <h4 className="text-sm font-semibold text-blue-900 mb-1">CISO Recommendation</h4>
                          <p className="text-sm text-blue-800">
                              {['Critical', 'High'].includes(selectedApp.inherent_risk_level) 
                                ? "Strict Compliance Review Required. Do not proceed to Go-Live until all Critical and High severity gates are passed. External audit recommended."
                                : "Standard Compliance Procedure. Ensure all automated gates are passed. Periodic review advised."}
                          </p>
                      </div>

                      {/* Security Gates Status */}
                      <div>
                          <h4 className="text-sm font-semibold mb-2">Security Gate Decisions</h4>
                          <div className="space-y-2">
                              {selectedApp.security_gates && selectedApp.security_gates.length > 0 ? (
                                  selectedApp.security_gates.map(gate => (
                                      <div key={gate.id} className="flex justify-between items-center p-2 border rounded bg-white">
                                          <div className="flex items-center gap-2">
                                              {gate.status === 'PASSED' ? <CheckCircle2 className="w-4 h-4 text-green-500" /> 
                                              : gate.status === 'FAILED' ? <XCircle className="w-4 h-4 text-red-500" />
                                              : <Activity className="w-4 h-4 text-yellow-500" />}
                                              <span className="text-sm font-medium capitalize">{gate.gate_type.replace('_',' ')}</span>
                                          </div>
                                          <Badge variant="outline" className="text-xs">{gate.status}</Badge>
                                      </div>
                                  ))
                              ) : (
                                  <p className="text-sm text-slate-500">No gates initialized.</p>
                              )}
                          </div>
                      </div>

                      {/* Action Items */}
                      <div>
                           <h4 className="text-sm font-semibold mb-2">Required Actions</h4>
                           <ul className="list-disc list-inside text-sm text-slate-700 space-y-1">
                               {getComplianceStatus(selectedApp) !== 'COMPLIED' && (
                                   <li>Resolve pending Security Gates.</li>
                               )}
                               {['Critical', 'High'].includes(selectedApp.inherent_risk_level) && (
                                   <li>Schedule VAPT and Architecture Review.</li>
                               )}
                               {mapTagsToCompliance(selectedApp.regulations).some(t => t.includes('RBI')) && (
                                   <li>Verify Data Localization compliance evidence.</li>
                               )}
                               {getComplianceStatus(selectedApp) === 'COMPLIED' && (
                                   <li className="text-green-600 font-medium">No pending actions. Ready for periodic review.</li>
                               )}
                           </ul>
                      </div>
                  </div>
              )}
          </SheetContent>
      </Sheet>
    </div>
  );
};

export default InitiativeComplianceDashboard;
