
import React, { useState } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, ArrowLeft, Save, AlertTriangle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { businessInitService } from '@/services/businessInitService';
import { useAuth } from '@/contexts/AuthContext';

const ApplicationIntakeWizard = ({ orgId, onSuccess, onCancel }) => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  
  const [formData, setFormData] = useState({
    name: '',
    business_unit: '',
    owner: '',
    type: '',
    description: '',
    budget_code: '',
    data_classification: {
      pii: false,
      spi: false,
      pci: false,
      financial: false
    },
    regulations: []
  });

  const updateData = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleDataClass = (key) => {
    setFormData(prev => ({
      ...prev,
      data_classification: {
        ...prev.data_classification,
        [key]: !prev.data_classification[key]
      }
    }));
  };

  const toggleRegulation = (reg) => {
    setFormData(prev => {
      const regs = prev.regulations.includes(reg)
        ? prev.regulations.filter(r => r !== reg)
        : [...prev.regulations, reg];
      return { ...prev, regulations: regs };
    });
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      // Map form data to DB schema
      const payload = {
        org_id: orgId,
        title: formData.name,
        description: `Business Unit: ${formData.business_unit}\n${formData.description}`,
        application_type: formData.type || 'web_application',
        intake_mode: 'manual',
        hosting: 'cloud', // Default to safe value
        internet_facing: false,
        vendor_involved: false,
        data_tags: formData.regulations,
        inherent_risk_rating: 'Low',
        inherent_risk_signed_off: false,
        status: 'draft',
        created_by: user?.id
      };

      await businessInitService.createInitiation(payload);
      toast({ title: "Application registered successfully" });
      onSuccess?.();
    } catch (error) {
      console.error("Registration error:", error);
      toast({ 
        title: "Registration failed", 
        description: error.message, 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-3xl mx-auto border-t-4 border-t-brand-600 shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>New Business Initiative</CardTitle>
            <CardDescription>Step {step} of 3: {
              step === 1 ? 'General Information' : 
              step === 2 ? 'Classification & Type' : 
              'Regulatory Context'
            }</CardDescription>
          </div>
          <div className="flex gap-1">
            {[1, 2, 3].map(i => (
              <div key={i} className={`h-2 w-8 rounded-full ${i <= step ? 'bg-brand-600' : 'bg-slate-200'}`} />
            ))}
          </div>
        </div>
      </CardHeader>

      <CardContent className="py-6">
        {step === 1 && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Application / Initiative Name</Label>
                <Input 
                  value={formData.name} 
                  onChange={e => updateData('name', e.target.value)} 
                  placeholder="e.g. Customer Portal 2.0"
                />
              </div>
              <div className="space-y-2">
                <Label>Business Unit</Label>
                <Input 
                  value={formData.business_unit} 
                  onChange={e => updateData('business_unit', e.target.value)} 
                  placeholder="e.g. Retail Banking"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Business Owner</Label>
                <Input 
                  value={formData.owner} 
                  onChange={e => updateData('owner', e.target.value)} 
                  placeholder="Owner email or name"
                />
              </div>
              <div className="space-y-2">
                <Label>Budget / Cost Code</Label>
                <Input 
                  value={formData.budget_code} 
                  onChange={e => updateData('budget_code', e.target.value)} 
                  placeholder="CC-2025-X01"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Description & Purpose</Label>
              <Textarea 
                value={formData.description}
                onChange={e => updateData('description', e.target.value)}
                placeholder="Briefly describe the business function and goal..."
                className="h-24"
              />
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div className="space-y-3">
              <Label>Application Type</Label>
              <div className="grid grid-cols-2 gap-4">
                {['Core', 'Digital', 'SaaS', 'Vendor'].map(type => (
                  <div 
                    key={type}
                    onClick={() => updateData('type', type)}
                    className={`p-4 border rounded-lg cursor-pointer transition-all hover:border-brand-500 ${formData.type === type ? 'border-brand-600 bg-brand-50' : 'bg-white'}`}
                  >
                    <div className="font-semibold">{type} Application</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {type === 'Core' && 'Critical business infrastructure'}
                      {type === 'Digital' && 'Customer facing web/mobile'}
                      {type === 'SaaS' && 'Third-party cloud software'}
                      {type === 'Vendor' && 'Outsourced processing/services'}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <Label>Data Classification (Check all that apply)</Label>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-start space-x-2 p-3 border rounded-md">
                  <Checkbox 
                    id="pii" 
                    checked={formData.data_classification.pii}
                    onCheckedChange={() => toggleDataClass('pii')}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="pii" className="font-semibold">PII (Personal)</Label>
                    <p className="text-xs text-muted-foreground">Names, Emails, Phones, IDs</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2 p-3 border rounded-md">
                  <Checkbox 
                    id="spi" 
                    checked={formData.data_classification.spi}
                    onCheckedChange={() => toggleDataClass('spi')}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="spi" className="font-semibold">SPI (Sensitive)</Label>
                    <p className="text-xs text-muted-foreground">Biometrics, Health, Religion</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2 p-3 border rounded-md">
                  <Checkbox 
                    id="pci" 
                    checked={formData.data_classification.pci}
                    onCheckedChange={() => toggleDataClass('pci')}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="pci" className="font-semibold">PCI / Card Data</Label>
                    <p className="text-xs text-muted-foreground">Credit/Debit Card Numbers</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2 p-3 border rounded-md">
                  <Checkbox 
                    id="financial" 
                    checked={formData.data_classification.financial}
                    onCheckedChange={() => toggleDataClass('financial')}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="financial" className="font-semibold">Financial Records</Label>
                    <p className="text-xs text-muted-foreground">Transactions, Balances, Accounts</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6">
            <div className="space-y-4">
              <Label>Regulatory Frameworks</Label>
              <div className="grid grid-cols-1 gap-2">
                {['RBI Cyber Security Framework', 'DPDP Act 2023', 'PCI DSS v4.0', 'SEBI Guidelines', 'GDPR'].map(reg => (
                  <div key={reg} className="flex items-center space-x-2 p-2 hover:bg-slate-50 rounded">
                    <Checkbox 
                      id={reg} 
                      checked={formData.regulations.includes(reg)}
                      onCheckedChange={() => toggleRegulation(reg)}
                    />
                    <Label htmlFor={reg} className="flex-1 cursor-pointer">{reg}</Label>
                    {reg.includes('DPDP') && formData.data_classification.pii && (
                      <Badge variant="outline" className="text-orange-600 bg-orange-50 border-orange-200">Recommended</Badge>
                    )}
                    {reg.includes('PCI') && formData.data_classification.pci && (
                      <Badge variant="outline" className="text-orange-600 bg-orange-50 border-orange-200">Recommended</Badge>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-md flex gap-3 items-start">
              <AlertTriangle className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <div className="text-sm text-blue-800">
                <p className="font-semibold mb-1">DPIA Trigger Warning</p>
                Based on your selection of <strong>{formData.data_classification.spi ? 'Sensitive Personal Data' : 'Personal Data'}</strong>, 
                a Data Privacy Impact Assessment (DPIA) will be automatically triggered after creation.
              </div>
            </div>
          </div>
        )}
      </CardContent>

      <CardFooter className="flex justify-between bg-slate-50/50 p-6">
        {step > 1 ? (
          <Button variant="outline" onClick={() => setStep(step - 1)}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Previous
          </Button>
        ) : (
          <Button variant="ghost" onClick={onCancel}>Cancel</Button>
        )}
        
        {step < 3 ? (
          <Button onClick={() => setStep(step + 1)} disabled={!formData.name && step === 1}>
            Next <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        ) : (
          <Button onClick={handleSubmit} disabled={loading} className="bg-brand-600 hover:bg-brand-700">
            {loading ? 'Registering...' : 'Register Application'} <Save className="ml-2 h-4 w-4" />
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default ApplicationIntakeWizard;
