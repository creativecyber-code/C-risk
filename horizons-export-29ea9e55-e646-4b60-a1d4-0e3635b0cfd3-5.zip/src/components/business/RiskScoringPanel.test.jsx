
import { describe, it, expect, vi } from 'vitest';
import { screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import RiskScoringPanel from './RiskScoringPanel';
import { renderWithProviders } from '@/test/utils';
import { businessInitService } from '@/services/businessInitService';
import { appFactory, assessmentFactory } from '@/test/factories';

// Test Suite 4, 6, 7
describe('RiskScoringPanel', () => {
  it('renders initial scores from props', () => {
    const mockApp = appFactory({
      assessment: assessmentFactory({ confidentiality_score: 3 })
    });

    renderWithProviders(<RiskScoringPanel app={mockApp} />);
    
    // Check if slider/badge reflects score 3
    // Note: Radix slider is tricky to test values directly without looking at attributes
    expect(screen.getByText('3/5')).toBeInTheDocument();
  });

  it('calculates FAIR ALE estimate dynamically (Requirement 6, 17)', () => {
    const mockApp = appFactory({
      assessment: assessmentFactory({ 
        confidentiality_score: 1, 
        regulatory_impact: 1, 
        financial_impact: 1 
      })
    });
    // Base 50k * 1 * 1 * 1 = 50k
    
    renderWithProviders(<RiskScoringPanel app={mockApp} />);
    expect(screen.getByText('$50,000')).toBeInTheDocument();
  });

  it('saves new scores when button clicked', async () => {
    const mockApp = appFactory({ assessment: assessmentFactory() });
    const onUpdate = vi.fn();
    
    vi.spyOn(businessInitService, 'updateAssessment').mockResolvedValue({});

    renderWithProviders(<RiskScoringPanel app={mockApp} onUpdate={onUpdate} />);
    
    const saveBtn = screen.getByText(/Calculate & Save Risk Profile/i);
    await userEvent.click(saveBtn);
    
    expect(businessInitService.updateAssessment).toHaveBeenCalled();
    await waitFor(() => expect(onUpdate).toHaveBeenCalled());
  });
});
