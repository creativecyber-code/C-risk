
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { businessInitService } from '@/services/businessInitService';

const RiskScoringPanel = ({ app, onUpdate }) => {
  const [scores, setScores] = useState({
    confidentiality_score: app.assessment?.confidentiality_score || 1,
    integrity_score: app.assessment?.integrity_score || 1,
    availability_score: app.assessment?.availability_score || 1,
    regulatory_impact: app.assessment?.regulatory_impact || 1,
    operational_impact: app.assessment?.operational_impact || 1,
    financial_impact: app.assessment?.financial_impact || 1
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleScoreChange = (key, value) => {
    setScores(prev => ({ ...prev, [key]: value[0] }));
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      await businessInitService.updateAssessment(app.id, scores);
      toast({ title: "Risk assessment updated" });
      onUpdate?.();
    } catch (error) {
      toast({ title: "Failed to update", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score) => {
    if (score >= 4) return 'bg-red-500';
    if (score >= 3) return 'bg-orange-500';
    if (score >= 2) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const dimensions = [
    { key: 'confidentiality_score', label: 'Confidentiality', desc: 'Impact of unauthorized data disclosure' },
    { key: 'integrity_score', label: 'Integrity', desc: 'Impact of data corruption or unauthorized modification' },
    { key: 'availability_score', label: 'Availability', desc: 'Impact of service downtime or disruption' },
    { key: 'regulatory_impact', label: 'Regulatory', desc: 'Potential for fines, legal action, or non-compliance' },
    { key: 'operational_impact', label: 'Operational', desc: 'Disruption to business processes and reputation' },
    { key: 'financial_impact', label: 'Financial', desc: 'Direct monetary loss potential' },
  ];

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Inherent Risk Scoring (FAIR Model)</CardTitle>
          <Badge variant={
            app.inherent_risk_level === 'Critical' ? 'destructive' : 
            app.inherent_risk_level === 'High' ? 'destructive' : 
            app.inherent_risk_level === 'Medium' ? 'default' : 'secondary'
          }>
            Current Level: {app.inherent_risk_level || 'Pending'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid md:grid-cols-2 gap-8">
          {dimensions.map(dim => (
            <div key={dim.key} className="space-y-3">
              <div className="flex justify-between">
                <Label className="font-medium text-base">{dim.label}</Label>
                <span className={`px-2 py-0.5 rounded text-white text-xs font-bold ${getScoreColor(scores[dim.key])}`}>
                  {scores[dim.key]}/5
                </span>
              </div>
              <p className="text-xs text-muted-foreground">{dim.desc}</p>
              <Slider
                value={[scores[dim.key]]}
                min={1}
                max={5}
                step={1}
                onValueChange={(val) => handleScoreChange(dim.key, val)}
                className="py-2"
              />
              <div className="flex justify-between text-[10px] text-muted-foreground uppercase tracking-wider">
                <span>Low</span>
                <span>Critical</span>
              </div>
            </div>
          ))}
        </div>

        <div className="pt-6 border-t flex items-center justify-between">
          <div className="text-sm">
            <span className="text-muted-foreground">Estimated FAIR ALE: </span>
            <span className="font-mono font-bold">
              ${(businessInitService.calculateFAIR(scores) || 0).toLocaleString()}
            </span>
          </div>
          <Button onClick={handleSave} disabled={loading}>
            {loading ? 'Calculating...' : 'Calculate & Save Risk Profile'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default RiskScoringPanel;
