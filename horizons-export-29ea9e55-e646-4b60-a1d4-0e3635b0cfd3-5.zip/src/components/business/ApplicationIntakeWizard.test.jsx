
import { describe, it, expect, vi } from 'vitest';
import { screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ApplicationIntakeWizard from './ApplicationIntakeWizard';
import { renderWithProviders } from '@/test/utils';
import { businessInitService } from '@/services/businessInitService';

// Mock Service
vi.mock('@/services/businessInitService', () => ({
  businessInitService: {
    createApplication: vi.fn().mockResolvedValue({ id: 'new-app' })
  }
}));

// Test Suite 2: Intake Wizard
describe('ApplicationIntakeWizard Component', () => {
  it('renders step 1 initially', () => {
    renderWithProviders(<ApplicationIntakeWizard orgId="org-1" />);
    expect(screen.getByText(/General Information/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Application \/ Initiative Name/i)).toBeInTheDocument();
  });

  it('validates required fields before proceeding (Requirement 2)', async () => {
    renderWithProviders(<ApplicationIntakeWizard orgId="org-1" />);
    
    const nextBtn = screen.getByText(/Next/i);
    expect(nextBtn).toBeDisabled();

    const nameInput = screen.getByLabelText(/Application \/ Initiative Name/i);
    await userEvent.type(nameInput, 'New Project');
    
    expect(nextBtn).toBeEnabled();
  });

  it('triggers DPIA warning when SPI is selected (Requirement 14)', async () => {
    renderWithProviders(<ApplicationIntakeWizard orgId="org-1" />);
    
    // Step 1
    await userEvent.type(screen.getByLabelText(/Application \/ Initiative Name/i), 'Test App');
    await userEvent.click(screen.getByText(/Next/i));

    // Step 2
    expect(screen.getByText(/Classification & Type/i)).toBeInTheDocument();
    const spiCheckbox = screen.getByLabelText(/SPI \(Sensitive\)/i);
    await userEvent.click(spiCheckbox);
    
    await userEvent.click(screen.getByText(/Next/i));

    // Step 3 - Check Warning
    expect(screen.getByText(/DPIA Trigger Warning/i)).toBeInTheDocument();
  });

  it('submits data correctly to service', async () => {
    renderWithProviders(<ApplicationIntakeWizard orgId="org-1" onSuccess={vi.fn()} />);
    
    // Fast forward through wizard
    await userEvent.type(screen.getByLabelText(/Application \/ Initiative Name/i), 'Final App');
    await userEvent.click(screen.getByText(/Next/i));
    
    // Step 2
    await userEvent.click(screen.getByText(/Core Application/i));
    await userEvent.click(screen.getByText(/Next/i));
    
    // Step 3
    const submitBtn = screen.getByText(/Register Application/i);
    await userEvent.click(submitBtn);

    await waitFor(() => {
      expect(businessInitService.createApplication).toHaveBeenCalledWith(
        expect.objectContaining({ 
          name: 'Final App',
          type: 'Core'
        }), 
        'org-1'
      );
    });
  });
});
