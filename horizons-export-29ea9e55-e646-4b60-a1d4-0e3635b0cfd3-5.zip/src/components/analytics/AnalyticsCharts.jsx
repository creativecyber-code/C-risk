
import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, AreaChart, Area, PieChart, Pie, Cell
} from 'recharts';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export const VolumeTrendChart = ({ data }) => (
  <Card>
    <CardHeader><CardTitle className="text-sm font-medium">Threat Volume Trends</CardTitle></CardHeader>
    <CardContent className="h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <defs>
            <linearGradient id="colorThreats" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="#8884d8" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="name" fontSize={12} />
          <YAxis fontSize={12} />
          <Tooltip 
            contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e2e8f0' }}
            itemStyle={{ color: '#1e293b' }}
          />
          <Area type="monotone" dataKey="threats" stroke="#8884d8" fillOpacity={1} fill="url(#colorThreats)" name="Active Threats" />
          <Line type="monotone" dataKey="riskScore" stroke="#ff7300" name="Avg Risk Score" strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>
    </CardContent>
  </Card>
);

export const StrideDistributionChart = ({ data }) => (
  <Card>
    <CardHeader><CardTitle className="text-sm font-medium">STRIDE Category Distribution</CardTitle></CardHeader>
    <CardContent className="h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            fill="#8884d8"
            paddingAngle={5}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
          <Legend verticalAlign="bottom" height={36} iconType="circle" />
        </PieChart>
      </ResponsiveContainer>
    </CardContent>
  </Card>
);

export const TopComponentsChart = ({ data }) => (
  <Card>
    <CardHeader><CardTitle className="text-sm font-medium">Top Affected Models/Components</CardTitle></CardHeader>
    <CardContent className="h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ left: 40 }}>
          <CartesianGrid strokeDasharray="3 3" horizontal={false} />
          <XAxis type="number" fontSize={12} />
          <YAxis dataKey="name" type="category" width={100} fontSize={11} />
          <Tooltip cursor={{ fill: '#f1f5f9' }} />
          <Bar dataKey="count" fill="#3b82f6" radius={[0, 4, 4, 0]} barSize={20} name="Threat Count" />
        </BarChart>
      </ResponsiveContainer>
    </CardContent>
  </Card>
);

export const HeatmapChart = ({ data }) => {
  const { grid, categories } = data;
  
  // Helper to determine color intensity
  const getColor = (val) => {
    if (val === 0) return 'bg-slate-100';
    if (val < 3) return 'bg-blue-200';
    if (val < 6) return 'bg-blue-400';
    return 'bg-blue-600 text-white';
  };

  return (
    <Card className="col-span-1 md:col-span-2">
      <CardHeader><CardTitle className="text-sm font-medium">Threat Heatmap (Severity vs Category)</CardTitle></CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr>
                <th className="text-left font-medium text-slate-500 pb-2">Severity</th>
                {categories.map(c => (
                  <th key={c} className="font-medium text-slate-500 pb-2 text-center text-xs">{c}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {grid.map(row => (
                <tr key={row.name}>
                  <td className="font-semibold text-slate-700 py-1">{row.name}</td>
                  {categories.map(c => (
                    <td key={c} className="p-1">
                      <div className={`h-8 rounded flex items-center justify-center text-xs font-medium transition-colors ${getColor(row[c])}`}>
                        {row[c] > 0 ? row[c] : '-'}
                      </div>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
};
