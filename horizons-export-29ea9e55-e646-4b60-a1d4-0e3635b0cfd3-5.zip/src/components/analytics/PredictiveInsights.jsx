
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { TrendingUp, TrendingDown, Minus, AlertTriangle, Lightbulb } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const PredictiveInsights = ({ prediction, anomalies }) => {
  const getTrendIcon = (trend) => {
    if (trend === 'increasing') return <TrendingUp className="w-5 h-5 text-red-500" />;
    if (trend === 'decreasing') return <TrendingDown className="w-5 h-5 text-green-500" />;
    return <Minus className="w-5 h-5 text-slate-500" />;
  };

  return (
    <div className="space-y-6">
      {/* Forecast Card */}
      <Card className="bg-gradient-to-br from-indigo-50 to-white border-indigo-100">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center gap-2 text-indigo-900">
            <Lightbulb className="w-5 h-5 text-indigo-600" /> AI Forecast
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm text-slate-500">Predicted Threat Volume (Next Month)</p>
              <div className="text-3xl font-bold text-slate-900 flex items-center gap-2">
                {prediction.nextMonth}
                {getTrendIcon(prediction.trend)}
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-400 uppercase tracking-wide">Trend</p>
              <p className={`font-semibold ${prediction.trend === 'increasing' ? 'text-red-600' : 'text-green-600'}`}>
                {prediction.trend.toUpperCase()}
              </p>
            </div>
          </div>
          <p className="text-sm text-slate-600">
            Based on historical data, we anticipate a <strong>{prediction.slope > 0 ? 'rise' : 'drop'}</strong> in threat activity. 
            Confidence level: <span className="font-medium">{prediction.confidence}</span>.
          </p>
        </CardContent>
      </Card>

      {/* Anomalies */}
      {anomalies.length > 0 && (
        <Card className="border-red-100">
           <CardHeader className="pb-2">
             <CardTitle className="text-sm font-medium text-red-700 flex items-center gap-2">
               <AlertTriangle className="w-4 h-4" /> Detected Anomalies
             </CardTitle>
           </CardHeader>
           <CardContent className="space-y-3">
             {anomalies.map(a => (
               <Alert key={a.id} variant="destructive" className="bg-white border-red-200">
                 <AlertTitle className="text-xs font-bold flex justify-between">
                   {a.title}
                   <span className="text-red-600">Risk: {a.risk}</span>
                 </AlertTitle>
                 <AlertDescription className="text-xs mt-1 text-slate-600">
                   {a.reason}
                 </AlertDescription>
               </Alert>
             ))}
           </CardContent>
        </Card>
      )}
    </div>
  );
};

export default PredictiveInsights;
