
import React from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';

/**
 * A wrapper component that prevents children from rendering until critical
 * context providers (specifically Auth) are fully initialized.
 * This eliminates the "Cannot read properties of null" race condition.
 */
const LoadingBoundary = ({ children }) => {
  const { isInitialized, loading } = useAuth();

  if (!isInitialized || loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-slate-200 border-t-brand-600"></div>
          <p className="text-sm font-medium text-slate-500">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return children;
};

export default LoadingBoundary;
