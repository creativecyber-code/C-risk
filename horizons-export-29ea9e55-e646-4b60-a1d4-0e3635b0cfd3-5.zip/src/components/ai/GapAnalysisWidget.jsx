
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from 'recharts';
import { AlertCircle, ShieldCheck } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const GapAnalysisWidget = ({ gapData }) => {
  if (!gapData) return null;

  const data = [
    { name: 'Critical Risks', value: gapData.riskProfile.critical, color: '#ef4444' },
    { name: 'High Risks', value: gapData.riskProfile.high, color: '#f97316' },
    { name: 'Medium Risks', value: gapData.riskProfile.medium, color: '#eab308' },
    { name: 'Low Risks', value: gapData.riskProfile.low, color: '#3b82f6' },
  ].filter(d => d.value > 0);

  // If no data, show "Safe" placeholder
  const displayData = data.length > 0 ? data : [{ name: 'No Risks Detected', value: 1, color: '#10b981' }];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-full">
      <Card className="border-slate-200 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
             <AlertCircle className="w-4 h-4 text-brand-600" />
             Risk Distribution
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[200px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={displayData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {displayData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <RechartsTooltip />
                <Legend iconSize={8} wrapperStyle={{ fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card className="border-slate-200 shadow-sm flex flex-col">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
             <ShieldCheck className="w-4 h-4 text-brand-600" />
             Coverage & Gaps
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col justify-center">
          <div className="mb-6 text-center">
             <div className="text-3xl font-bold text-slate-900">{gapData.coverageScore}%</div>
             <div className="text-xs text-slate-500 uppercase tracking-wider">STRIDE Coverage</div>
          </div>
          
          <div className="space-y-3">
             <h4 className="text-sm font-medium text-slate-700">Missing Categories:</h4>
             {gapData.missingCategories.length === 0 ? (
               <div className="text-sm text-green-600 flex items-center gap-2">
                 <ShieldCheck className="w-4 h-4" /> All categories covered!
               </div>
             ) : (
               <div className="flex flex-wrap gap-2">
                 {gapData.missingCategories.map(cat => (
                   <span key={cat} className="px-2 py-1 bg-red-50 text-red-600 rounded text-xs border border-red-100 font-medium">
                     {cat}
                   </span>
                 ))}
               </div>
             )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GapAnalysisWidget;
