
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, X, Shield, AlertTriangle, Sparkles, ChevronDown, ChevronUp, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

const SuggestionCard = ({ suggestion, onAccept, onReject }) => {
  const [expanded, setExpanded] = useState(false);

  const riskColor = {
    'Critical': 'text-red-600 bg-red-50 border-red-200',
    'High': 'text-orange-600 bg-orange-50 border-orange-200',
    'Medium': 'text-yellow-600 bg-yellow-50 border-yellow-200',
    'Low': 'text-blue-600 bg-blue-50 border-blue-200',
  }[suggestion.risk] || 'text-slate-600 bg-slate-50 border-slate-200';

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-md transition-shadow"
    >
      <div className="p-5">
        <div className="flex justify-between items-start mb-3">
          <div className="flex gap-3">
            <div className={cn("p-2 rounded-lg h-fit", riskColor)}>
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900 flex items-center gap-2">
                {suggestion.title}
                <Sparkles className="w-3 h-3 text-purple-500 animate-pulse" />
              </h3>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className="text-xs font-normal">{suggestion.category}</Badge>
                <span className="text-xs text-slate-400">•</span>
                <span className={cn("text-xs font-medium px-1.5 py-0.5 rounded", riskColor)}>
                  {suggestion.risk} Risk
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col items-end">
            <div className="flex items-center gap-1.5 mb-1">
               <span className="text-xs font-bold text-slate-700">{suggestion.confidence}% Match</span>
               <TooltipProvider>
                 <Tooltip>
                   <TooltipTrigger>
                     <Info className="w-3 h-3 text-slate-400" />
                   </TooltipTrigger>
                   <TooltipContent>AI Confidence Score based on model pattern matching</TooltipContent>
                 </Tooltip>
               </TooltipProvider>
            </div>
            <Progress value={suggestion.confidence} className="w-24 h-1.5" />
          </div>
        </div>

        <p className="text-sm text-slate-600 mb-4 leading-relaxed">
          {suggestion.description}
        </p>

        {expanded && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            className="border-t border-slate-100 pt-4 mb-4 space-y-4"
          >
            <div>
              <h4 className="text-xs font-semibold text-slate-900 uppercase tracking-wider mb-2">AI Reasoning</h4>
              <p className="text-sm text-slate-500 bg-slate-50 p-3 rounded-lg border border-slate-100">
                {suggestion.reasoning}
              </p>
            </div>

            <div>
              <h4 className="text-xs font-semibold text-slate-900 uppercase tracking-wider mb-2">Suggested Mitigation</h4>
              <div className="flex items-start gap-2 text-sm text-slate-600">
                <Shield className="w-4 h-4 text-green-600 mt-0.5 shrink-0" />
                <span>{suggestion.mitigation}</span>
              </div>
            </div>

            {suggestion.compliance && (
              <div>
                <h4 className="text-xs font-semibold text-slate-900 uppercase tracking-wider mb-2">Compliance Impact</h4>
                <div className="flex flex-wrap gap-2">
                  {suggestion.compliance.map(c => (
                    <Badge key={c} variant="secondary" className="text-[10px] bg-slate-100 text-slate-600 border-slate-200">
                      {c}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}

        <div className="flex items-center justify-between pt-2">
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-slate-500 hover:text-slate-900 p-0 h-auto font-normal"
            onClick={() => setExpanded(!expanded)}
          >
            {expanded ? (
              <><ChevronUp className="w-4 h-4 mr-1" /> Show Less</>
            ) : (
              <><ChevronDown className="w-4 h-4 mr-1" /> View Details & Mitigation</>
            )}
          </Button>

          <div className="flex gap-2">
            <Button size="sm" variant="outline" className="border-slate-200 hover:bg-red-50 hover:text-red-600 hover:border-red-200" onClick={() => onReject(suggestion)}>
              <X className="w-4 h-4 mr-2" /> Reject
            </Button>
            <Button size="sm" className="bg-brand-600 hover:bg-brand-700 text-white" onClick={() => onAccept(suggestion)}>
              <Check className="w-4 h-4 mr-2" /> Accept Threat
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default SuggestionCard;
