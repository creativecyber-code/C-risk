
import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Trash2, GripVertical } from 'lucide-react';

const CanvasElement = ({ element, onClick, onDrag, onDelete, isConnecting }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const dragStartPos = useRef({ x: 0, y: 0 });
  const elementStartPos = useRef({ x: 0, y: 0 });

  const handleMouseDown = (e) => {
    if (e.target.closest('.delete-btn')) return;
    
    setIsDragging(true);
    dragStartPos.current = { x: e.clientX, y: e.clientY };
    elementStartPos.current = { x: element.x, y: element.y };
    e.preventDefault();
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;

    const deltaX = e.clientX - dragStartPos.current.x;
    const deltaY = e.clientY - dragStartPos.current.y;

    onDrag(element.id, elementStartPos.current.x + deltaX, elementStartPos.current.y + deltaY);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  React.useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging]);

  const renderShape = () => {
    switch (element.type) {
      case 'process':
        return (
          <div className='w-32 h-32 rounded-full bg-blue-500/20 border-2 border-blue-500 flex items-center justify-center'>
            <span className='text-sm text-white font-medium text-center px-2'>{element.label}</span>
          </div>
        );
      case 'store':
        return (
          <div className='w-40 h-24 relative flex items-center justify-center'>
            <div className='absolute inset-0 border-t-2 border-b-2 border-green-500'></div>
            <div className='absolute top-2 left-0 right-0 border-t-2 border-green-500/50'></div>
            <div className='absolute bottom-2 left-0 right-0 border-b-2 border-green-500/50'></div>
            <span className='text-sm text-white font-medium text-center px-2 relative z-10 bg-slate-900/80 px-3 py-1 rounded'>
              {element.label}
            </span>
          </div>
        );
      case 'interactor':
        return (
          <div className='w-36 h-28 bg-purple-500/20 border-2 border-purple-500 rounded-lg flex items-center justify-center'>
            <span className='text-sm text-white font-medium text-center px-2'>{element.label}</span>
          </div>
        );
      case 'boundary':
        return (
          <div className='w-48 h-2 relative flex items-center justify-center'>
            <div className='absolute inset-0 border-t-2 border-red-500 border-dashed'></div>
            <span className='text-xs text-red-400 font-medium bg-slate-900 px-2 relative z-10'>
              {element.label}
            </span>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <motion.div
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ scale: 0, opacity: 0 }}
      transition={{ duration: 0.2 }}
      style={{
        position: 'absolute',
        left: element.x,
        top: element.y,
        transform: 'translate(-50%, -50%)',
        cursor: isDragging ? 'grabbing' : 'grab',
        zIndex: isDragging ? 10 : 2
      }}
      onMouseDown={handleMouseDown}
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      onMouseEnter={() => setShowControls(true)}
      onMouseLeave={() => setShowControls(false)}
      className={`group ${isConnecting ? 'ring-4 ring-yellow-500' : ''}`}
    >
      {renderShape()}
      
      {/* Controls */}
      {showControls && !isDragging && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className='absolute -top-10 left-1/2 -translate-x-1/2 flex gap-1 bg-slate-800 border border-slate-700 rounded-lg p-1 shadow-lg'
        >
          <button
            className='delete-btn p-1.5 hover:bg-red-500/20 rounded transition-colors'
            onClick={(e) => {
              e.stopPropagation();
              onDelete(element.id);
            }}
          >
            <Trash2 className='w-4 h-4 text-red-400' />
          </button>
          <div className='p-1.5 text-slate-400'>
            <GripVertical className='w-4 h-4' />
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default CanvasElement;
