
import React, { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { MessageSquare, CornerDownRight } from 'lucide-react';

const CommentItem = ({ comment, onReply }) => {
  const [isReplying, setIsReplying] = useState(false);
  const [replyText, setReplyText] = useState('');

  const handleSubmitReply = () => {
    if (!replyText.trim()) return;
    onReply(replyText, comment.id);
    setIsReplying(false);
    setReplyText('');
  };

  return (
    <div className="flex gap-3 mb-4">
      <Avatar className="w-8 h-8">
        <AvatarImage src={comment.user_profiles?.avatar_url} />
        <AvatarFallback className="text-xs">{comment.user_profiles?.full_name?.substring(0, 2).toUpperCase()}</AvatarFallback>
      </Avatar>
      <div className="flex-1">
        <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
          <div className="flex justify-between items-start mb-1">
            <span className="font-semibold text-sm text-slate-900">{comment.user_profiles?.full_name}</span>
            <span className="text-xs text-slate-400">{formatDistanceToNow(new Date(comment.created_at), { addSuffix: true })}</span>
          </div>
          <p className="text-sm text-slate-700 whitespace-pre-wrap">{comment.content}</p>
        </div>
        
        <div className="flex items-center gap-2 mt-1 ml-1">
          <Button variant="ghost" size="sm" className="h-6 text-xs text-slate-500" onClick={() => setIsReplying(!isReplying)}>
            Reply
          </Button>
        </div>

        {isReplying && (
          <div className="mt-2 flex gap-2">
             <Textarea 
               value={replyText} 
               onChange={(e) => setReplyText(e.target.value)} 
               placeholder="Write a reply..." 
               className="min-h-[60px] text-sm"
             />
             <Button size="sm" onClick={handleSubmitReply}>Post</Button>
          </div>
        )}

        {comment.replies && comment.replies.length > 0 && (
          <div className="mt-3 pl-4 border-l-2 border-slate-100">
            {comment.replies.map(reply => (
              <CommentItem key={reply.id} comment={reply} onReply={onReply} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const CommentsList = ({ comments, onAddComment }) => {
  const [newComment, setNewComment] = useState('');

  const handleSubmit = () => {
    if (!newComment.trim()) return;
    onAddComment(newComment, null);
    setNewComment('');
  };

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        {comments.map(comment => (
          <CommentItem key={comment.id} comment={comment} onReply={onAddComment} />
        ))}
        {comments.length === 0 && (
          <div className="text-center py-8 text-slate-500 text-sm">
            <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-20" />
            No comments yet. Start the discussion!
          </div>
        )}
      </div>

      <div className="border-t pt-4">
        <div className="flex gap-3">
           <Avatar className="w-8 h-8">
             <AvatarFallback>ME</AvatarFallback>
           </Avatar>
           <div className="flex-1 gap-2 flex flex-col">
             <Textarea 
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Add a comment... Use @ to mention"
                className="min-h-[80px]"
             />
             <div className="flex justify-between items-center">
                <span className="text-xs text-slate-400">Markdown supported</span>
                <Button onClick={handleSubmit} disabled={!newComment.trim()}>Post Comment</Button>
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default CommentsList;
