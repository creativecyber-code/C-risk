
import React, { useEffect, useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import CommentsList from './CommentsList';
import AssignmentControl from './AssignmentControl';
import ApprovalWorkflow from './ApprovalWorkflow';
import { collaborationService } from '@/services/collaborationService';
import { useToast } from '@/components/ui/use-toast';

const CollaborationPanel = ({ assessment, onAssessmentUpdate }) => {
  const [comments, setComments] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    if (assessment?.id) {
       loadComments();
    }
  }, [assessment?.id]);

  const loadComments = async () => {
    try {
      const data = await collaborationService.getComments(assessment.id);
      setComments(data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddComment = async (text, parentId) => {
    try {
      await collaborationService.addComment(assessment.id, text, parentId);
      loadComments(); // Refresh
      toast({ title: "Comment added" });
    } catch (e) {
      toast({ title: "Failed to add comment", variant: "destructive" });
    }
  };

  const handleAssign = async (userId) => {
    try {
      const updated = await collaborationService.assignThreat(assessment.id, userId);
      onAssessmentUpdate(updated);
      toast({ title: "Assignee updated" });
    } catch (e) {
      toast({ title: "Assignment failed", variant: "destructive" });
    }
  };

  const handleStatusChange = async (status) => {
    try {
       await collaborationService.updateAssignmentStatus(assessment.id, status);
       onAssessmentUpdate({ ...assessment, assignment_status: status });
       toast({ title: "Status updated" });
    } catch (e) {
      toast({ title: "Update failed", variant: "destructive" });
    }
  };

  return (
    <div className="h-full flex flex-col">
       <Tabs defaultValue="activity" className="flex-1">
         <TabsList className="w-full">
           <TabsTrigger value="activity" className="flex-1">Activity & Comments</TabsTrigger>
           <TabsTrigger value="workflow" className="flex-1">Workflow</TabsTrigger>
         </TabsList>

         <TabsContent value="activity" className="flex-1 h-full overflow-hidden flex flex-col pt-4">
            <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
               <CommentsList comments={comments} onAddComment={handleAddComment} />
            </div>
         </TabsContent>

         <TabsContent value="workflow" className="space-y-4 pt-4">
            <AssignmentControl 
               assessment={assessment} 
               onAssign={handleAssign}
               onStatusChange={handleStatusChange}
            />
            <ApprovalWorkflow assessment={assessment} />
         </TabsContent>
       </Tabs>
    </div>
  );
};

export default CollaborationPanel;
