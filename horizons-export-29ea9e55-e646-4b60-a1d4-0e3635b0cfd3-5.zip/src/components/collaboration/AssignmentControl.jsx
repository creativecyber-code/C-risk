
import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { UserPlus, CheckCircle2 } from 'lucide-react';

const AssignmentControl = ({ assessment, onAssign, onStatusChange }) => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUsers = async () => {
      // In real app, fetch users from the same Org
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      
      const { data: profile } = await supabase.from('user_profiles').select('org_id').eq('id', user.id).single();
      
      if (profile) {
        const { data } = await supabase.from('user_profiles').select('*').eq('org_id', profile.org_id);
        setUsers(data || []);
      }
      setLoading(false);
    };
    fetchUsers();
  }, []);

  const assignedUser = users.find(u => u.id === assessment.assigned_to);

  return (
    <div className="space-y-4 bg-slate-50 p-4 rounded-lg border">
       <h4 className="text-sm font-semibold flex items-center gap-2">
         <UserPlus className="w-4 h-4" /> Assignment
       </h4>
       
       <div className="grid gap-3">
         <div className="space-y-1">
           <Label className="text-xs text-slate-500">Assignee</Label>
           <Select 
             value={assessment.assigned_to || "unassigned"} 
             onValueChange={(v) => onAssign(v === "unassigned" ? null : v)}
           >
             <SelectTrigger className="w-full bg-white">
               <SelectValue placeholder="Unassigned">
                 {assignedUser ? (
                    <div className="flex items-center gap-2">
                       <Avatar className="w-5 h-5">
                         <AvatarImage src={assignedUser.avatar_url} />
                         <AvatarFallback className="text-[10px]">{assignedUser.full_name?.substring(0,2)}</AvatarFallback>
                       </Avatar>
                       <span>{assignedUser.full_name}</span>
                    </div>
                 ) : "Unassigned"}
               </SelectValue>
             </SelectTrigger>
             <SelectContent>
               <SelectItem value="unassigned">Unassigned</SelectItem>
               {users.map(u => (
                 <SelectItem key={u.id} value={u.id}>
                    <div className="flex items-center gap-2">
                       <Avatar className="w-5 h-5">
                         <AvatarImage src={u.avatar_url} />
                         <AvatarFallback className="text-[10px]">{u.full_name?.substring(0,2)}</AvatarFallback>
                       </Avatar>
                       <span>{u.full_name}</span>
                    </div>
                 </SelectItem>
               ))}
             </SelectContent>
           </Select>
         </div>

         <div className="space-y-1">
           <Label className="text-xs text-slate-500">Status</Label>
           <Select 
             value={assessment.assignment_status || "Open"} 
             onValueChange={(v) => onStatusChange(v)}
           >
             <SelectTrigger className="w-full bg-white">
               <SelectValue />
             </SelectTrigger>
             <SelectContent>
               <SelectItem value="Open">Open</SelectItem>
               <SelectItem value="In Progress">In Progress</SelectItem>
               <SelectItem value="Resolved">Resolved</SelectItem>
             </SelectContent>
           </Select>
         </div>
       </div>
    </div>
  );
};

export default AssignmentControl;
