
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { FileCheck, AlertCircle } from 'lucide-react';
import { collaborationService } from '@/services/collaborationService';
import { useToast } from '@/components/ui/use-toast';

const ApprovalWorkflow = ({ assessment }) => {
  const [showForm, setShowForm] = useState(false);
  const [justification, setJustification] = useState('');
  const [type, setType] = useState('Risk Acceptance');
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      await collaborationService.requestApproval(assessment.id, type, justification);
      toast({ title: "Approval Requested", description: "The risk approval request has been sent to admins." });
      setShowForm(false);
      setJustification('');
    } catch (error) {
      toast({ title: "Error", description: "Failed to submit approval request", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-slate-50 p-4 rounded-lg border space-y-4">
      <h4 className="text-sm font-semibold flex items-center gap-2">
         <FileCheck className="w-4 h-4" /> Approvals
      </h4>

      {/* Logic: if pending, show status. if nothing, show request button. */}
      {/* For simplicity in this demo, just allowing request submission anytime */}
      
      {!showForm ? (
         <Button variant="outline" className="w-full" onClick={() => setShowForm(true)}>
           Request Approval
         </Button>
      ) : (
         <div className="space-y-3 animate-in fade-in slide-in-from-top-2">
            <div className="space-y-1">
               <Label className="text-xs">Approval Type</Label>
               <div className="flex gap-2">
                  <Badge 
                    variant={type === 'Risk Acceptance' ? 'default' : 'outline'} 
                    className="cursor-pointer"
                    onClick={() => setType('Risk Acceptance')}
                  >
                    Risk Acceptance
                  </Badge>
                  <Badge 
                    variant={type === 'Mitigation Plan' ? 'default' : 'outline'}
                    className="cursor-pointer"
                    onClick={() => setType('Mitigation Plan')}
                  >
                    Mitigation Plan
                  </Badge>
               </div>
            </div>
            
            <div className="space-y-1">
               <Label className="text-xs">Justification</Label>
               <Textarea 
                 value={justification}
                 onChange={(e) => setJustification(e.target.value)}
                 placeholder="Why should this be approved?"
                 className="text-sm bg-white"
               />
            </div>

            <div className="flex gap-2">
               <Button size="sm" className="flex-1" onClick={handleSubmit} disabled={submitting}>Submit</Button>
               <Button size="sm" variant="ghost" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
         </div>
      )}
      
      {/* Helpful info */}
      <div className="text-[10px] text-slate-500 flex items-start gap-1">
         <AlertCircle className="w-3 h-3 mt-0.5" />
         Approvals are required for accepting High/Critical risks without mitigation.
      </div>
    </div>
  );
};

export default ApprovalWorkflow;
