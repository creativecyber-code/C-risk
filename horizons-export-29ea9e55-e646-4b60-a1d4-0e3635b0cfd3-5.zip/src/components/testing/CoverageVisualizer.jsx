
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, AreaChart, Area, XAxis, YAxis, CartesianGrid } from 'recharts';

const CoverageVisualizer = ({ coverage, trends }) => {
  if (!coverage) return null;

  const data = [
    { name: 'Covered', value: coverage.lines, color: '#22c55e' },
    { name: 'Uncovered', value: 100 - coverage.lines, color: '#e2e8f0' }
  ];

  const breakdown = [
    { name: 'Statements', value: coverage.statements, fullMark: 100 },
    { name: 'Branches', value: coverage.branches, fullMark: 100 },
    { name: 'Functions', value: coverage.functions, fullMark: 100 },
    { name: 'Lines', value: coverage.lines, fullMark: 100 },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card>
        <CardHeader><CardTitle className="text-sm">Total Code Coverage</CardTitle></CardHeader>
        <CardContent className="flex items-center justify-center h-[200px]">
           <div className="relative w-full h-full">
             <ResponsiveContainer width="100%" height="100%">
               <PieChart>
                 <Pie
                   data={data}
                   innerRadius={60}
                   outerRadius={80}
                   paddingAngle={0}
                   dataKey="value"
                   startAngle={90}
                   endAngle={-270}
                 >
                   {data.map((entry, index) => (
                     <Cell key={`cell-${index}`} fill={entry.color} />
                   ))}
                 </Pie>
                 <Tooltip />
               </PieChart>
             </ResponsiveContainer>
             <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
               <span className="text-3xl font-bold text-slate-800">{coverage.lines}%</span>
               <span className="text-xs text-slate-500">Line Coverage</span>
             </div>
           </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-sm">Coverage Breakdown</CardTitle></CardHeader>
        <CardContent className="space-y-4 pt-4">
           {breakdown.map((item) => (
             <div key={item.name} className="space-y-1">
               <div className="flex justify-between text-xs">
                 <span className="font-medium">{item.name}</span>
                 <span className={item.value < 80 ? 'text-orange-600' : 'text-green-600'}>{item.value}%</span>
               </div>
               <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                 <div 
                   className={`h-full rounded-full ${item.value < 80 ? 'bg-orange-400' : 'bg-green-500'}`} 
                   style={{ width: `${item.value}%` }} 
                 />
               </div>
             </div>
           ))}
        </CardContent>
      </Card>
      
      {trends && (
        <Card className="md:col-span-2">
          <CardHeader><CardTitle className="text-sm">Coverage Trend (Last 10 Runs)</CardTitle></CardHeader>
          <CardContent className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trends}>
                <defs>
                  <linearGradient id="colorCov" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="date" hide />
                <YAxis domain={[60, 100]} />
                <Tooltip />
                <Area type="monotone" dataKey="coverage" stroke="#16a34a" fillOpacity={1} fill="url(#colorCov)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default CoverageVisualizer;
