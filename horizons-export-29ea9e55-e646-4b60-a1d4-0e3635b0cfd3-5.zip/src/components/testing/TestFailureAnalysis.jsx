
import React from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertTriangle, Terminal } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

const TestFailureAnalysis = ({ failures }) => {
  if (!failures || failures.length === 0) return null;

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold flex items-center gap-2">
        <AlertTriangle className="w-5 h-5 text-red-600" />
        Failure Analysis ({failures.length})
      </h3>
      
      {failures.map((fail) => (
        <Alert key={fail.id} variant="destructive" className="bg-white border-red-200">
          <AlertTitle className="text-red-800 font-medium mb-2 break-all">
            {fail.test_name}
          </AlertTitle>
          <AlertDescription>
            <div className="text-xs font-mono bg-slate-950 text-red-200 p-3 rounded-md mt-2">
              <div className="mb-2 text-red-400 font-bold border-b border-red-900/50 pb-1">
                 {fail.error_message}
              </div>
              <ScrollArea className="h-24">
                 <pre className="whitespace-pre-wrap">{fail.stack_trace}</pre>
              </ScrollArea>
            </div>
            <div className="mt-2 text-xs text-red-600 flex gap-2">
               <span className="font-semibold">Recommendation:</span> 
               Check assertion logic in {fail.test_name.split(' - ')[0]} or investigate recent changes to related service logic.
            </div>
          </AlertDescription>
        </Alert>
      ))}
    </div>
  );
};

export default TestFailureAnalysis;
