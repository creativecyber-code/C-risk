
import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/customSupabaseClient';
import { AlertCircle, CheckCircle2, Clock, PlayCircle } from 'lucide-react';

const TestRunner = ({ runId, onComplete }) => {
  const [runData, setRunData] = useState(null);
  const [currentSuite, setCurrentSuite] = useState('Initializing...');

  useEffect(() => {
    if (!runId) return;

    // Initial Fetch
    fetchRun();

    // Realtime Subscription
    const channel = supabase
      .channel('test_runner')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'test_runs', 
        filter: `id=eq.${runId}` 
      }, (payload) => {
        setRunData(payload.new);
        if (payload.new.status !== 'running' && onComplete) {
          onComplete(payload.new);
        }
      })
      .subscribe();

    // Subscribe to suites to show progress text
    const suiteChannel = supabase
      .channel('suite_runner')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'test_suite_results',
        filter: `run_id=eq.${runId}`
      }, (payload) => {
        setCurrentSuite(payload.new.suite_name);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      supabase.removeChannel(suiteChannel);
    };
  }, [runId]);

  const fetchRun = async () => {
    const { data } = await supabase.from('test_runs').select('*').eq('id', runId).single();
    setRunData(data);
  };

  if (!runData) return <div className="p-4 text-center">Preparing Test Environment...</div>;

  const progress = runData.total_tests > 0 ? (runData.total_tests / 41) * 100 : 5; // Assuming ~41 tests in simulation

  return (
    <Card className="border-l-4 border-l-blue-600 animate-in fade-in slide-in-from-top-4">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
             <CardTitle className="flex items-center gap-2">
               {runData.status === 'running' && <PlayCircle className="w-5 h-5 text-blue-600 animate-pulse" />}
               {runData.status === 'passed' && <CheckCircle2 className="w-5 h-5 text-green-600" />}
               {runData.status === 'failed' && <AlertCircle className="w-5 h-5 text-red-600" />}
               Test Execution #{runData.id.slice(0, 8)}
             </CardTitle>
             <CardDescription>
                Running on {runData.environment} environment via CI Pipeline {runData.ci_pipeline_id}
             </CardDescription>
          </div>
          <Badge variant={runData.status === 'running' ? 'default' : 'secondary'} className="uppercase">
             {runData.status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-1">
             <div className="flex justify-between text-xs text-muted-foreground">
               <span>Executing: {runData.status === 'running' ? currentSuite : 'Completed'}</span>
               <span>{runData.total_tests} Tests Run</span>
             </div>
             <Progress value={runData.status === 'running' ? progress : 100} className="h-2" />
          </div>

          <div className="grid grid-cols-3 gap-4 pt-2">
             <div className="flex flex-col items-center p-2 bg-green-50 rounded-lg text-green-700">
               <span className="text-2xl font-bold">{runData.passed_tests}</span>
               <span className="text-xs font-medium">Passed</span>
             </div>
             <div className="flex flex-col items-center p-2 bg-red-50 rounded-lg text-red-700">
               <span className="text-2xl font-bold">{runData.failed_tests}</span>
               <span className="text-xs font-medium">Failed</span>
             </div>
             <div className="flex flex-col items-center p-2 bg-slate-50 rounded-lg text-slate-700">
               <span className="text-2xl font-bold">
                 {runData.duration_ms ? `${(runData.duration_ms/1000).toFixed(1)}s` : <Clock className="w-6 h-6 animate-spin text-slate-400" />}
               </span>
               <span className="text-xs font-medium">Duration</span>
             </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TestRunner;
