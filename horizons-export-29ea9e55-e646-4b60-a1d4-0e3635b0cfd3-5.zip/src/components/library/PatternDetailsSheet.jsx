
import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetFooter } from '@/components/ui/sheet';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Shield, Target, Zap, Lock, BookOpen, Star, AlertTriangle, ExternalLink, GitCommit } from 'lucide-react';

const PatternDetailsSheet = ({ pattern, open, onOpenChange, onImport }) => {
  if (!pattern) return null;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-xl md:max-w-2xl overflow-hidden flex flex-col p-0 gap-0 bg-white">
        {/* Header */}
        <div className="p-6 pb-4 border-b bg-slate-50">
          <div className="flex items-start justify-between gap-4 mb-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Badge className={pattern.severity === 'Critical' ? 'bg-red-600' : 'bg-slate-600'}>
                  {pattern.severity} Severity
                </Badge>
                <Badge variant="outline" className="text-slate-600 border-slate-300">
                  {pattern.stride_category}
                </Badge>
              </div>
              <SheetTitle className="text-2xl font-bold text-slate-900">{pattern.title}</SheetTitle>
            </div>
            <div className="text-center bg-white p-2 rounded-lg border shadow-sm">
              <div className="flex items-center justify-center gap-1 text-amber-500 font-bold text-lg">
                {pattern.rating_avg} <Star className="w-4 h-4 fill-current" />
              </div>
              <span className="text-xs text-slate-500">{pattern.usage_count} uses</span>
            </div>
          </div>
          <p className="text-slate-600 text-sm leading-relaxed">{pattern.description}</p>
        </div>

        {/* Content */}
        <ScrollArea className="flex-1">
          <div className="p-6">
            <Tabs defaultValue="details" className="w-full">
              <TabsList className="mb-6 w-full justify-start border-b rounded-none h-auto p-0 bg-transparent">
                <TabsTrigger value="details" className="rounded-none border-b-2 border-transparent data-[state=active]:border-brand-600 data-[state=active]:bg-transparent px-4 py-2">Details</TabsTrigger>
                <TabsTrigger value="mitigation" className="rounded-none border-b-2 border-transparent data-[state=active]:border-brand-600 data-[state=active]:bg-transparent px-4 py-2">Mitigation</TabsTrigger>
                <TabsTrigger value="context" className="rounded-none border-b-2 border-transparent data-[state=active]:border-brand-600 data-[state=active]:bg-transparent px-4 py-2">Context & CVEs</TabsTrigger>
                <TabsTrigger value="history" className="rounded-none border-b-2 border-transparent data-[state=active]:border-brand-600 data-[state=active]:bg-transparent px-4 py-2">Version History</TabsTrigger>
              </TabsList>

              <TabsContent value="details" className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-50 p-4 rounded-lg border">
                    <h4 className="flex items-center gap-2 font-semibold text-sm text-slate-900 mb-2">
                      <Target className="w-4 h-4 text-brand-600" /> Affected Components
                    </h4>
                    <ul className="list-disc list-inside text-sm text-slate-600 space-y-1">
                      {pattern.affected_components?.map((c, i) => <li key={i}>{c}</li>) || <li>Unspecified</li>}
                    </ul>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-lg border">
                    <h4 className="flex items-center gap-2 font-semibold text-sm text-slate-900 mb-2">
                      <Zap className="w-4 h-4 text-orange-500" /> Attack Vectors
                    </h4>
                    <ul className="list-disc list-inside text-sm text-slate-600 space-y-1">
                      {pattern.attack_vectors?.map((v, i) => <li key={i}>{v}</li>) || <li>Unspecified</li>}
                    </ul>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Impact Analysis</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="border p-3 rounded-md">
                      <span className="block text-slate-500 text-xs uppercase tracking-wide">Likelihood</span>
                      <span className="font-medium text-slate-900">{pattern.likelihood || 'Unknown'}</span>
                    </div>
                    <div className="border p-3 rounded-md">
                      <span className="block text-slate-500 text-xs uppercase tracking-wide">Impact</span>
                      <span className="font-medium text-slate-900">{pattern.impact || 'Unknown'}</span>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="mitigation" className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
                <div className="bg-green-50 border border-green-200 rounded-lg p-5">
                  <h4 className="flex items-center gap-2 font-semibold text-green-800 mb-3">
                    <Shield className="w-5 h-5" /> Recommended Strategy
                  </h4>
                  <p className="text-green-800/80 text-sm leading-relaxed whitespace-pre-line">
                    {pattern.mitigation_strategies}
                  </p>
                </div>
                
                <div>
                   <h4 className="font-semibold text-slate-900 mb-3">Standard Controls</h4>
                   <div className="flex flex-wrap gap-2">
                     <Badge variant="secondary" className="px-3 py-1">Input Validation</Badge>
                     <Badge variant="secondary" className="px-3 py-1">Output Encoding</Badge>
                     <Badge variant="secondary" className="px-3 py-1">Least Privilege</Badge>
                   </div>
                </div>
              </TabsContent>

              <TabsContent value="context" className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
                 {pattern.cvss_vector && (
                   <div className="border rounded-lg p-4 bg-slate-50">
                     <h4 className="text-sm font-semibold text-slate-900 mb-1">CVSS Vector</h4>
                     <code className="text-xs bg-slate-200 px-2 py-1 rounded text-slate-700 block w-full overflow-x-auto">
                       {pattern.cvss_vector}
                     </code>
                   </div>
                 )}
                 
                 <div>
                   <h4 className="flex items-center gap-2 font-semibold text-slate-900 mb-3">
                     <AlertTriangle className="w-4 h-4 text-red-500" /> Related CVEs
                   </h4>
                   {pattern.cve_references && pattern.cve_references.length > 0 ? (
                     <div className="space-y-2">
                       {pattern.cve_references.map((cve, i) => (
                         <div key={i} className="flex items-center justify-between p-3 border rounded-md hover:bg-slate-50 transition-colors">
                           <span className="font-mono text-sm font-medium text-blue-600">{cve}</span>
                           <ExternalLink className="w-3 h-3 text-slate-400" />
                         </div>
                       ))}
                     </div>
                   ) : (
                     <p className="text-sm text-slate-500">No specific CVEs linked to this generalized pattern.</p>
                   )}
                 </div>
              </TabsContent>

              <TabsContent value="history" className="space-y-4 animate-in fade-in slide-in-from-bottom-2">
                <div className="relative border-l border-slate-200 pl-4 ml-2 space-y-6">
                  <div className="relative">
                    <span className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-brand-500 border-2 border-white ring-1 ring-slate-200"></span>
                    <p className="text-xs text-slate-400 mb-0.5">Current Version</p>
                    <div className="flex items-center gap-2">
                       <h5 className="text-sm font-medium text-slate-900">v1.2 - Updated Mitigation</h5>
                       <Badge variant="secondary" className="text-[10px] h-5">Latest</Badge>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">Refined mitigation steps based on OWASP 2024 guidance.</p>
                  </div>
                  
                  <div className="relative opacity-60">
                    <span className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-slate-300 border-2 border-white ring-1 ring-slate-200"></span>
                    <p className="text-xs text-slate-400 mb-0.5">2 months ago</p>
                    <h5 className="text-sm font-medium text-slate-900">v1.1 - Added CVEs</h5>
                  </div>
                  
                  <div className="relative opacity-60">
                    <span className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-slate-300 border-2 border-white ring-1 ring-slate-200"></span>
                    <p className="text-xs text-slate-400 mb-0.5">6 months ago</p>
                    <h5 className="text-sm font-medium text-slate-900">v1.0 - Initial Creation</h5>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </ScrollArea>

        <SheetFooter className="p-6 border-t bg-slate-50">
          <Button className="w-full bg-brand-600 hover:bg-brand-700" onClick={() => onImport(pattern)}>
            <BookOpen className="w-4 h-4 mr-2" />
            Add to Threat Model
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
};

export default PatternDetailsSheet;
