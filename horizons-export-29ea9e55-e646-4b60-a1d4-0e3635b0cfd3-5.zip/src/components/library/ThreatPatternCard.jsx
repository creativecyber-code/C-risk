
import React from 'react';
import { Star, ShieldAlert, GitBranch, Copy, ArrowRight, Activity } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { cn } from '@/lib/utils';

const ThreatPatternCard = ({ pattern, onViewDetails, onImport }) => {
  const getSeverityColor = (sev) => {
    switch (sev?.toLowerCase()) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <Card className="flex flex-col h-full hover:shadow-md transition-shadow duration-200 border-slate-200">
      <CardHeader className="p-4 pb-2 space-y-2">
        <div className="flex justify-between items-start gap-2">
          <Badge variant="outline" className={cn("capitalize font-semibold", getSeverityColor(pattern.severity))}>
            {pattern.severity}
          </Badge>
          <div className="flex items-center text-amber-500 text-xs font-medium">
            <Star className="w-3 h-3 fill-current mr-1" />
            {pattern.rating_avg || '0.0'}
          </div>
        </div>
        <h3 className="font-semibold text-slate-900 line-clamp-2 leading-tight min-h-[2.5rem]">
          {pattern.title}
        </h3>
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <Badge variant="secondary" className="bg-slate-100 text-slate-600 hover:bg-slate-200">
            {pattern.stride_category}
          </Badge>
          {pattern.industry && pattern.industry[0] && (
            <span className="truncate max-w-[100px]">{pattern.industry[0]}</span>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="p-4 pt-2 flex-1">
        <p className="text-sm text-slate-600 line-clamp-3 mb-4">
          {pattern.description}
        </p>
        
        <div className="flex items-center gap-4 text-xs text-slate-400 mt-auto">
           <div className="flex items-center gap-1">
             <Activity className="w-3 h-3" />
             {pattern.usage_count} uses
           </div>
           {pattern.cve_references && pattern.cve_references.length > 0 && (
             <div className="flex items-center gap-1 text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">
               <ShieldAlert className="w-3 h-3" />
               CVE Linked
             </div>
           )}
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-2 border-t bg-slate-50/50 flex gap-2">
        <Button 
          variant="outline" 
          size="sm" 
          className="flex-1 bg-white hover:bg-slate-50"
          onClick={() => onViewDetails(pattern)}
        >
          Details
        </Button>
        <Button 
          size="sm" 
          className="flex-1 bg-brand-600 hover:bg-brand-700"
          onClick={() => onImport(pattern)}
        >
          <Copy className="w-3 h-3 mr-2" />
          Use
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ThreatPatternCard;
