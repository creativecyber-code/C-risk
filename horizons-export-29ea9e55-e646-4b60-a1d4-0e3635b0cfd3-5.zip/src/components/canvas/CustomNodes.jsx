
import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';
import { Database, Monitor, Cog, Shield } from 'lucide-react';

// Common handle styles
const handleStyle = { width: 8, height: 8, background: '#555' };

export const ProcessNode = memo(({ data, selected }) => {
  return (
    <div className={`
        w-16 h-16 rounded-full flex items-center justify-center bg-white border-2 shadow-sm relative
        ${selected ? 'border-blue-500 shadow-md ring-2 ring-blue-200' : 'border-slate-400'}
    `}>
      <Handle type="target" position={Position.Top} style={handleStyle} />
      <Handle type="target" position={Position.Left} style={handleStyle} />
      
      <div className="flex flex-col items-center p-2 text-center">
        <Cog className="w-6 h-6 text-blue-600" />
        <span className="text-[9px] leading-tight font-medium mt-1 truncate w-14">{data.label}</span>
      </div>

      <Handle type="source" position={Position.Right} style={handleStyle} />
      <Handle type="source" position={Position.Bottom} style={handleStyle} />
    </div>
  );
});

export const StoreNode = memo(({ data, selected }) => {
  return (
    <div className={`
        min-w-[100px] px-3 py-2 bg-white border-y-2 border-x-0 border-slate-800 shadow-sm relative flex items-center gap-2
        ${selected ? 'ring-2 ring-green-200 bg-green-50' : ''}
    `}>
      <Handle type="target" position={Position.Top} style={handleStyle} />
      <Handle type="target" position={Position.Left} style={handleStyle} />
      
      <Database className="w-4 h-4 text-green-700" />
      <span className="text-xs font-semibold">{data.label}</span>

      <Handle type="source" position={Position.Right} style={handleStyle} />
      <Handle type="source" position={Position.Bottom} style={handleStyle} />
    </div>
  );
});

export const InteractorNode = memo(({ data, selected }) => {
  return (
    <div className={`
        min-w-[100px] h-12 bg-white border-2 rounded-sm flex items-center justify-center px-2 shadow-sm relative
        ${selected ? 'border-purple-500 shadow-md ring-2 ring-purple-200' : 'border-slate-600'}
    `}>
      <Handle type="target" position={Position.Top} style={handleStyle} />
      <Handle type="target" position={Position.Left} style={handleStyle} />
      
      <div className="flex items-center gap-2">
        <Monitor className="w-4 h-4 text-purple-600" />
        <span className="text-xs font-bold">{data.label}</span>
      </div>

      <Handle type="source" position={Position.Right} style={handleStyle} />
      <Handle type="source" position={Position.Bottom} style={handleStyle} />
    </div>
  );
});

export const TrustBoundaryNode = memo(({ data, selected, width, height }) => {
  return (
    <div 
        className={`
            border-2 border-dashed border-red-400 bg-red-50/10 rounded-lg relative group
            ${selected ? 'bg-red-50/30 border-red-600' : ''}
        `}
        style={{ width: '100%', height: '100%', minWidth: 200, minHeight: 200 }}
    >
       <div className="absolute -top-3 left-4 bg-white px-2 border border-red-200 rounded-full text-[10px] text-red-600 font-bold flex items-center gap-1">
          <Shield className="w-3 h-3" />
          {data.label || 'Trust Boundary'}
       </div>
    </div>
  );
});
