
import React, { useState } from 'react';
import { 
  Save, Trash2, Download, MousePointer2, 
  Layout, ZoomIn, ZoomOut, AlertCircle, GitCommit 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import ModelManagementPanel from '@/components/ModelManagementPanel';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { versionControlService } from '@/services/versionControlService';
import { useToast } from '@/components/ui/use-toast';

const Toolbar = ({ 
  tools, 
  selectedTool, 
  onSelectTool, 
  onClear, 
  onExport, 
  threats, 
  elementsCount,
  currentModel,
  onModelLoad,
  onModelCreate,
  onSave,
  isSaving
}) => {
  const [versionDialogOpen, setVersionDialogOpen] = useState(false);
  const [versionTag, setVersionTag] = useState('');
  const [versionDesc, setVersionDesc] = useState('');
  const [creatingVersion, setCreatingVersion] = useState(false);
  const { toast } = useToast();

  const handleCreateVersion = async () => {
    if (!currentModel) return;
    setCreatingVersion(true);
    try {
      // First ensure live state is saved
      await onSave(); 
      // Then create version
      await versionControlService.createVersion(currentModel.id, {
        tag: versionTag || `v${new Date().toISOString().slice(0,10)}`,
        description: versionDesc
      });
      toast({ title: "Version snapshot created!" });
      setVersionDialogOpen(false);
      setVersionTag('');
      setVersionDesc('');
    } catch (error) {
      toast({ title: "Failed to create version", description: error.message, variant: "destructive" });
    } finally {
      setCreatingVersion(false);
    }
  };

  return (
    <div className='w-16 bg-slate-800 border-r border-slate-700 flex flex-col items-center py-4 z-50 shadow-xl'>
      <TooltipProvider delayDuration={0}>
        <div className="space-y-4 w-full flex flex-col items-center">
          <ModelManagementPanel 
            currentModelId={currentModel?.id}
            onModelLoad={onModelLoad}
            onModelCreate={onModelCreate}
          />
          
          <Separator className="bg-slate-700 w-8" />

          {/* Tools */}
          {tools.map((tool) => (
            <Tooltip key={tool.id}>
              <TooltipTrigger asChild>
                <Button
                  variant={selectedTool === tool.id ? 'default' : 'ghost'}
                  size="icon"
                  onClick={() => onSelectTool(tool.id)}
                  className={`
                    w-10 h-10 rounded-xl transition-all duration-200
                    ${selectedTool === tool.id 
                      ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50 scale-105' 
                      : 'text-slate-400 hover:text-white hover:bg-slate-700'}
                  `}
                >
                  <tool.icon className="w-5 h-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right" className="bg-slate-900 border-slate-700 text-slate-200">
                <p className="font-semibold">{tool.name}</p>
                <p className="text-xs text-slate-500">{tool.description}</p>
              </TooltipContent>
            </Tooltip>
          ))}

          <Separator className="bg-slate-700 w-8" />
          
          {/* Actions */}
          <div className="flex flex-col gap-2">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={onSave}
                  disabled={!currentModel || isSaving}
                  className="text-slate-400 hover:text-green-400 hover:bg-green-900/20"
                >
                  <Save className={`w-5 h-5 ${isSaving ? 'animate-pulse' : ''}`} />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">Save Progress</TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setVersionDialogOpen(true)}
                  disabled={!currentModel}
                  className="text-slate-400 hover:text-purple-400 hover:bg-purple-900/20"
                >
                  <GitCommit className="w-5 h-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">Create Version Snapshot</TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={onExport}
                  disabled={elementsCount === 0}
                  className="text-slate-400 hover:text-blue-400 hover:bg-blue-900/20"
                >
                  <Download className="w-5 h-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">Export JSON</TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={onClear}
                  disabled={elementsCount === 0}
                  className="text-slate-400 hover:text-red-400 hover:bg-red-900/20"
                >
                  <Trash2 className="w-5 h-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">Clear Canvas</TooltipContent>
            </Tooltip>
          </div>
        </div>
      </TooltipProvider>

      {/* Version Dialog */}
      <Dialog open={versionDialogOpen} onOpenChange={setVersionDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Version Snapshot</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
             <div className="space-y-2">
               <Label>Version Tag</Label>
               <Input 
                 placeholder="e.g. v1.0.2 or 'Release Candidate'" 
                 value={versionTag}
                 onChange={e => setVersionTag(e.target.value)}
               />
             </div>
             <div className="space-y-2">
               <Label>Description</Label>
               <Input 
                 placeholder="What changed in this version?" 
                 value={versionDesc}
                 onChange={e => setVersionDesc(e.target.value)}
               />
             </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setVersionDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreateVersion} disabled={creatingVersion}>
              {creatingVersion ? 'Creating...' : 'Create Snapshot'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Toolbar;
