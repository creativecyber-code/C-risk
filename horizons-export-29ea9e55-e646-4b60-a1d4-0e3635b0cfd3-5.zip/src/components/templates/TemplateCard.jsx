
import React from 'react';
import { Shield, BarChart3, Users, ArrowRight, Building, Gauge } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const TemplateCard = ({ template, onSelect }) => {
  return (
    <Card className="group hover:shadow-lg transition-all duration-300 border-slate-200 overflow-hidden flex flex-col h-full">
      <div className="relative h-40 overflow-hidden bg-slate-100">
        <img 
          src={template.previewImage} 
          alt={template.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-3 right-3">
          <Badge className={`${
            template.complexity === 'Basic' ? 'bg-green-500' : 
            template.complexity === 'Intermediate' ? 'bg-blue-500' : 'bg-purple-500'
          }`}>
            {template.complexity}
          </Badge>
        </div>
        <div className="absolute top-3 left-3">
           <Badge variant="secondary" className="bg-white/90 text-slate-800 backdrop-blur-sm shadow-sm">
             {template.source === 'SYSTEM' ? 'Official' : 'Custom'}
           </Badge>
        </div>
      </div>
      
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start gap-2">
          <CardTitle className="text-lg font-bold text-slate-900 line-clamp-1" title={template.name}>
            {template.name}
          </CardTitle>
        </div>
        <CardDescription className="line-clamp-2 min-h-[40px]">
          {template.description}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="pb-3 flex-1">
        <div className="flex flex-wrap gap-2 text-sm text-slate-600">
          <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-1 rounded border">
            <Building className="w-3.5 h-3.5 text-slate-400" />
            <span>{template.industry}</span>
          </div>
          <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-1 rounded border">
            <Shield className="w-3.5 h-3.5 text-red-400" />
            <span>{template.threatCount > 0 ? `~${template.threatCount} Threats` : 'N/A'}</span>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="pt-0">
        <Button 
          onClick={() => onSelect(template)} 
          className="w-full bg-white text-brand-600 border border-brand-200 hover:bg-brand-50 group-hover:border-brand-300 shadow-sm"
        >
          View Details <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
        </Button>
      </CardFooter>
    </Card>
  );
};

export default TemplateCard;
