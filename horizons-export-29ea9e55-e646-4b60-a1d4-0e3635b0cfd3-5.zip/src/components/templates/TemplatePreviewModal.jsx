
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ShieldAlert, CheckCircle2, Loader2, Layout, Crosshair } from 'lucide-react';
import { templateService } from '@/services/templateService';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';

const TemplatePreviewModal = ({ template, isOpen, onClose }) => {
  const [modelName, setModelName] = useState(`Copy of ${template?.name || 'Model'}`);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  if (!template) return null;

  const handleUseTemplate = async () => {
    setLoading(true);
    try {
      const newModelId = await templateService.useTemplate(template.id, modelName);
      toast({
        title: "Template Applied Successfully",
        description: "Redirecting you to the canvas...",
      });
      // Small delay for toast visibility
      setTimeout(() => {
        onClose();
        navigate(`/model/${newModelId}`);
      }, 500);
    } catch (error) {
      toast({
        title: "Error applying template",
        description: error.message,
        variant: "destructive"
      });
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <DialogTitle className="text-2xl">{template.name}</DialogTitle>
            <Badge variant="outline" className="text-brand-600 border-brand-200 bg-brand-50">
              {template.complexity}
            </Badge>
          </div>
          <DialogDescription className="text-base mt-2">
            {template.description}
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="diagram" className="w-full mt-4">
          <TabsList className="grid w-full grid-cols-2 md:w-[400px]">
            <TabsTrigger value="diagram">Architecture Diagram</TabsTrigger>
            <TabsTrigger value="details">Threat Details</TabsTrigger>
          </TabsList>
          
          <TabsContent value="diagram" className="space-y-4">
             {/* Mock Canvas Preview */}
             <div className="w-full h-[300px] bg-slate-50 rounded-lg border border-slate-200 relative overflow-hidden flex items-center justify-center">
                {/* Simplified SVG representation of elements */}
                <svg className="w-full h-full absolute inset-0 pointer-events-none opacity-50">
                   <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                      <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#e2e8f0" strokeWidth="1"/>
                   </pattern>
                   <rect width="100%" height="100%" fill="url(#grid)" />
                </svg>
                
                <div className="relative z-10 w-full h-full p-8">
                   {template.elements?.map((el, i) => (
                      <div 
                        key={i}
                        className="absolute w-24 h-16 bg-white border-2 border-slate-400 rounded flex items-center justify-center text-[10px] text-center shadow-sm"
                        style={{ 
                           // Scale down positions for preview
                           left: `${el.x * 0.6}px`, 
                           top: `${el.y * 0.6}px`,
                           borderColor: el.type === 'store' ? '#22c55e' : el.type === 'process' ? '#3b82f6' : '#a855f7'
                        }}
                      >
                         {el.label}
                      </div>
                   ))}
                   {/* Fallback if no elements array (rare) */}
                   {!template.elements && (
                     <div className="text-slate-400 flex flex-col items-center">
                        <Layout className="w-12 h-12 mb-2"/>
                        <span>Preview not available</span>
                     </div>
                   )}
                </div>
             </div>

             <div className="grid grid-cols-2 gap-4">
               <div className="bg-slate-50 p-4 rounded-lg">
                 <h4 className="font-semibold text-sm text-slate-900 mb-2 flex items-center gap-2">
                   <CheckCircle2 className="w-4 h-4 text-green-600"/> Common Use Cases
                 </h4>
                 <ul className="text-sm text-slate-600 space-y-1 ml-6 list-disc">
                   {template.useCases?.map((uc, i) => <li key={i}>{uc}</li>) || <li>General Purpose</li>}
                 </ul>
               </div>
               <div className="bg-red-50 p-4 rounded-lg">
                 <h4 className="font-semibold text-sm text-red-900 mb-2 flex items-center gap-2">
                   <Crosshair className="w-4 h-4 text-red-600"/> Known Hotspots
                 </h4>
                 <ul className="text-sm text-red-700 space-y-1 ml-6 list-disc">
                    {template.hotspots?.map((hs, i) => <li key={i}>{hs}</li>) || <li>Standard OWASP Threats</li>}
                 </ul>
               </div>
             </div>
          </TabsContent>

          <TabsContent value="details">
            <div className="bg-white rounded-lg border p-6 space-y-4">
               <div>
                  <h3 className="font-medium text-slate-900 mb-2">Threat Profile</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                     <div className="p-3 bg-slate-50 rounded border text-center">
                        <div className="text-2xl font-bold text-slate-900">{template.elements?.length || 0}</div>
                        <div className="text-xs text-slate-500 uppercase tracking-wider">Elements</div>
                     </div>
                     <div className="p-3 bg-slate-50 rounded border text-center">
                        <div className="text-2xl font-bold text-slate-900">{template.connections?.length || 0}</div>
                        <div className="text-xs text-slate-500 uppercase tracking-wider">Flows</div>
                     </div>
                     <div className="p-3 bg-red-50 rounded border border-red-100 text-center">
                        <div className="text-2xl font-bold text-red-600">~{template.threatCount || 'N/A'}</div>
                        <div className="text-xs text-red-400 uppercase tracking-wider">Est. Threats</div>
                     </div>
                  </div>
               </div>
               
               <div>
                  <h3 className="font-medium text-slate-900 mb-2">Industry Standard</h3>
                  <p className="text-sm text-slate-600">
                     This template is designed for the <strong>{template.industry}</strong> sector and adheres to common architectural patterns found in that domain. 
                     It provides a baseline for threat modeling but should be customized to your specific implementation.
                  </p>
               </div>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter className="flex-col sm:flex-row gap-4 border-t pt-6 mt-6">
           <div className="flex-1 w-full">
              <Label htmlFor="model-name" className="mb-2 block">New Model Name</Label>
              <Input 
                id="model-name" 
                value={modelName} 
                onChange={(e) => setModelName(e.target.value)}
                placeholder="Enter name for your model"
              />
           </div>
           <div className="flex items-end gap-2">
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button onClick={handleUseTemplate} disabled={loading} className="min-w-[140px]">
                 {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : null}
                 Use Template
              </Button>
           </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default TemplatePreviewModal;
