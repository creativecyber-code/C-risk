
import React from 'react';
import { motion } from 'framer-motion';
import { Tag, Scale, MapPin, Activity, FileCheck, Check, Banknote, ShieldCheck, Database, Server } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const FadeIn = ({ children, delay = 0, className }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-50px" }}
    transition={{ duration: 0.5, delay, ease: "easeOut" }}
    className={className}
  >
    {children}
  </motion.div>
);

const FeatureCard = ({ icon: Icon, title, description, benefits, badge, delay }) => (
  <FadeIn delay={delay} className="h-full">
    <Card className="h-full border-slate-200 shadow-sm hover:shadow-xl hover:border-blue-200 transition-all duration-300 group bg-white">
      <CardContent className="p-8 flex flex-col h-full">
        <div className="mb-6 flex items-start justify-between">
          <div className="p-3 bg-blue-50 rounded-xl group-hover:bg-blue-600 transition-colors duration-300">
            <Icon className="w-8 h-8 text-blue-600 group-hover:text-white transition-colors duration-300" />
          </div>
          {badge && (
            <Badge variant="outline" className="border-blue-200 text-blue-700 bg-blue-50/50">
              {badge}
            </Badge>
          )}
        </div>
        
        <h3 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-blue-800 transition-colors">
          {title}
        </h3>
        
        <p className="text-slate-600 mb-6 leading-relaxed flex-grow">
          {description}
        </p>
        
        <div className="space-y-3 pt-6 border-t border-slate-100">
          {benefits.map((benefit, idx) => (
            <div key={idx} className="flex items-start gap-2 text-sm text-slate-700">
              <Check className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
              <span>{benefit}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  </FadeIn>
);

const ComparisonRow = ({ label, manual, automated }) => (
  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-4 border-b border-slate-100 last:border-0 hover:bg-slate-50/50 transition-colors px-4 rounded-lg">
    <div className="font-semibold text-slate-900 flex items-center">{label}</div>
    <div className="text-slate-500 text-sm flex items-center gap-2">
      <span className="w-2 h-2 rounded-full bg-red-400"></span>
      {manual}
    </div>
    <div className="text-blue-700 font-medium text-sm flex items-center gap-2">
      <span className="w-2 h-2 rounded-full bg-blue-500"></span>
      {automated}
    </div>
  </div>
);

const ProductFeatures = () => {
  const features = [
    {
      icon: Tag,
      title: "Dynamic Classification Taxonomy",
      description: "Move beyond rigid templates. Configure bespoke data schemas that align perfectly with your organization's internal vocabulary while maintaining strict governance standards.",
      benefits: [
        "Fully customizable labels (Confidential, Restricted, SPII)",
        "Granular attribute tagging for business context",
        "Inheritance-based classification rules"
      ],
      badge: "Configurable"
    },
    {
      icon: Scale,
      title: "Regulatory Autopilot (DPDP & RBI)",
      description: "Our AI-enabled engine automatically maps data elements to specific clauses in the DPDP Act 2023 and RBI Master Directions, drastically reducing compliance fatigue.",
      benefits: [
        "Pre-built libraries for BFSI regulations",
        "Auto-identification of PII & Financial Data",
        "Instant gap analysis against new circulars"
      ],
      badge: "AI-Powered"
    },
    {
      icon: MapPin,
      title: "Data Sovereignty Tracker",
      description: "Ensure strict adherence to data localization norms. The system automatically tags data residency requirements and flags cross-border transfer risks in real-time.",
      benefits: [
        "Geo-location tagging for all data assets",
        "Cross-border transfer impact analysis",
        "Localization enforcement for critical financial data"
      ],
      badge: "RBI Compliant"
    },
    {
      icon: Activity,
      title: "Real-time Risk Vitals",
      description: "A live health dashboard for your data privacy posture. Instantly visualize high-risk exposure areas and track privacy impact scores across your entire application portfolio.",
      benefits: [
        "Live privacy impact scoring",
        "Heatmaps for high-risk processing activities",
        "Trend analysis for risk reduction"
      ],
      badge: "Live Monitoring"
    },
    {
      icon: FileCheck,
      title: "Automated Compliance Workflows",
      description: "Transform reactive audits into proactive governance. The system detects high-risk processing triggers and automatically initiates DPIA/PIA assessments with AI drafting support.",
      benefits: [
        "Auto-trigger DPIA based on classification",
        "AI-assisted report drafting & generation",
        "Audit-ready trail for regulatory inquiries"
      ],
      badge: "Automation"
    }
  ];

  return (
    <section id="features" className="py-24 bg-gradient-to-b from-white to-slate-50 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-slate-200 to-transparent"></div>
      <div className="absolute -left-20 top-40 w-96 h-96 bg-blue-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
      <div className="absolute -right-20 top-40 w-96 h-96 bg-cyan-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>

      <div className="container mx-auto px-6 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <FadeIn>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-blue-700 text-xs font-bold uppercase tracking-widest mb-4">
              <ShieldCheck className="w-3 h-3" />
              Advanced Data Governance
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 tracking-tight">
              AI-Powered Data Classification <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-500">
                & Privacy Engine
              </span>
            </h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              Purpose-built for the banking sector to automate privacy operations, enforce sovereignty, and ensure audit-readiness without the manual overhead.
            </p>
          </FadeIn>
        </div>

        {/* Feature Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-24">
          {features.map((feature, index) => (
            <div key={index} className={cn(index === 3 || index === 4 ? "md:col-span-1 lg:col-span-1.5" : "")}>
               <FeatureCard {...feature} delay={index * 0.1} />
            </div>
          ))}
        </div>

        {/* Comparison Section */}
        <FadeIn className="bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden">
          <div className="grid lg:grid-cols-5 h-full">
            <div className="lg:col-span-2 bg-slate-900 p-10 text-white flex flex-col justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-blue-900/20 z-0"></div>
              <div className="relative z-10">
                <h3 className="text-2xl font-bold mb-4">Manual vs. Automated</h3>
                <p className="text-slate-300 mb-8">
                  See how C-RISK transforms compliance operations from a cost center into a strategic advantage.
                </p>
                <div className="space-y-4">
                   <div className="flex items-center gap-4">
                     <div className="p-3 bg-white/10 rounded-lg backdrop-blur-sm">
                       <Banknote className="w-6 h-6 text-green-400" />
                     </div>
                     <div>
                       <div className="text-2xl font-bold text-green-400">65%</div>
                       <div className="text-sm text-slate-400">Cost Reduction</div>
                     </div>
                   </div>
                   <div className="flex items-center gap-4">
                     <div className="p-3 bg-white/10 rounded-lg backdrop-blur-sm">
                       <Database className="w-6 h-6 text-blue-400" />
                     </div>
                     <div>
                       <div className="text-2xl font-bold text-blue-400">100%</div>
                       <div className="text-sm text-slate-400">Inventory Visibility</div>
                     </div>
                   </div>
                </div>
              </div>
            </div>
            
            <div className="lg:col-span-3 p-8 lg:p-10">
              <div className="space-y-2">
                <div className="grid grid-cols-3 gap-4 pb-4 border-b border-slate-200 text-xs font-bold uppercase tracking-wider text-slate-500 px-4">
                  <div>Capability</div>
                  <div>Legacy / Manual</div>
                  <div className="text-blue-700">C-RISK Platform</div>
                </div>
                <ComparisonRow 
                  label="Classification" 
                  manual="User-reported spreadsheets" 
                  automated="Policy-driven & AI-suggested" 
                />
                <ComparisonRow 
                  label="DPDP/RBI Mapping" 
                  manual="Ad-hoc consultant reviews" 
                  automated="Real-time library mapping" 
                />
                <ComparisonRow 
                  label="Risk Assessment" 
                  manual="Quarterly static reports" 
                  automated="Live Health Score Dashboard" 
                />
                <ComparisonRow 
                  label="Cross-Border Ops" 
                  manual="Post-incident discovery" 
                  automated="Pre-emptive sovereignty blocks" 
                />
                <ComparisonRow 
                  label="DPIA Triggering" 
                  manual="Manual intuition" 
                  automated="Automated logic gates" 
                />
              </div>
            </div>
          </div>
        </FadeIn>

      </div>
    </section>
  );
};

export default ProductFeatures;
