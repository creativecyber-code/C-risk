
import React, { useEffect, useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { auditService } from '@/services/auditService';

const SecurityAlertsPanel = () => {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    loadAlerts();
  }, []);

  const loadAlerts = async () => {
    try {
      const data = await auditService.getSecurityAlerts();
      setAlerts(data || []);
    } catch (e) {
      console.error(e);
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'text-red-600 bg-red-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-blue-600 bg-blue-100';
    }
  };

  return (
    <Card className="h-full border-slate-200 shadow-sm flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-bold flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            Security Alerts
          </CardTitle>
          <span className="text-xs font-medium text-slate-500">{alerts.length} Total</span>
        </div>
      </CardHeader>
      <CardContent className="flex-1 min-h-0 relative p-0">
        <ScrollArea className="h-[300px] md:h-[400px]">
          <div className="p-6 pt-0 space-y-4">
            {alerts.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3 opacity-20" />
                <p>No active security alerts.</p>
                <p className="text-xs mt-1">System is healthy.</p>
              </div>
            ) : (
              alerts.map(alert => (
                <div key={alert.id} className="flex gap-4 p-4 rounded-lg bg-slate-50 border border-slate-100 hover:border-slate-200 transition-colors">
                  <div className={`w-2 h-2 rounded-full mt-2 shrink-0 ${
                    alert.severity === 'critical' ? 'bg-red-500' : 
                    alert.severity === 'high' ? 'bg-orange-500' : 'bg-blue-500'
                  }`} />
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <h4 className="font-semibold text-sm text-slate-900">{alert.title}</h4>
                      <span className="text-[10px] text-slate-400 whitespace-nowrap">
                        {new Date(alert.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-1 line-clamp-2">{alert.description}</p>
                    <div className="flex gap-2 mt-3">
                      <span className={`text-[10px] px-2 py-0.5 rounded font-medium capitalize ${getSeverityColor(alert.severity)}`}>
                        {alert.severity}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-200 text-slate-600 font-medium">
                        {alert.status}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
            
            {/* Example Mock Alerts if DB is empty for demo */}
            {alerts.length === 0 && (
              <>
                 <div className="flex gap-4 p-4 rounded-lg bg-red-50/50 border border-red-100">
                  <div className="w-2 h-2 rounded-full mt-2 shrink-0 bg-red-500" />
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <h4 className="font-semibold text-sm text-red-900">Unusual Login Activity</h4>
                      <span className="text-[10px] text-red-400">2 min ago</span>
                    </div>
                    <p className="text-xs text-red-700 mt-1">Multiple failed login attempts detected from IP 192.168.1.1</p>
                    <div className="flex gap-2 mt-3">
                      <span className="text-[10px] px-2 py-0.5 rounded font-medium capitalize text-red-600 bg-red-100">Critical</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-white text-slate-600 font-medium border">Open</span>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default SecurityAlertsPanel;
