
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { RefreshCw, Key, ShieldCheck, Lock } from 'lucide-react';
import { encryptionService } from '@/services/encryptionService';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { auditService } from '@/services/auditService';

const KeyManagementPanel = () => {
  const [currentKey, setCurrentKey] = useState(null);
  const [loading, setLoading] = useState(true);
  const [rotating, setRotating] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchKeyStatus();
  }, []);

  const fetchKeyStatus = async () => {
    try {
      const { data } = await supabase
        .from('security_keys')
        .select('*')
        .eq('status', 'active')
        .order('version', { ascending: false })
        .limit(1)
        .single();
      
      setCurrentKey(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleRotate = async () => {
    setRotating(true);
    try {
      await encryptionService.rotateKey();
      await auditService.logAction('ENCRYPTION_ROTATE', 'security_keys', { reason: 'manual_rotation' });
      await fetchKeyStatus();
      toast({ title: "Key Rotated", description: "A new encryption key version is now active." });
    } catch (error) {
      toast({ title: "Rotation Failed", description: error.message, variant: "destructive" });
    } finally {
      setRotating(false);
    }
  };

  return (
    <Card className="border-slate-200 shadow-sm h-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="text-lg font-bold flex items-center gap-2">
              <Key className="w-5 h-5 text-brand-600" />
              Encryption Management
            </CardTitle>
            <CardDescription>Manage your data encryption keys (DEK)</CardDescription>
          </div>
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
             <ShieldCheck className="w-3 h-3 mr-1" /> Active
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="bg-slate-50 p-4 rounded-lg border border-slate-100 space-y-4">
          <div className="flex justify-between items-center">
             <span className="text-sm font-medium text-slate-500">Current Key Version</span>
             <span className="font-mono text-lg font-bold text-slate-900">v{currentKey?.version || '0'}</span>
          </div>
          <div className="flex justify-between items-center">
             <span className="text-sm font-medium text-slate-500">Algorithm</span>
             <Badge variant="secondary">AES-GCM-256</Badge>
          </div>
          <div className="flex justify-between items-center">
             <span className="text-sm font-medium text-slate-500">Created At</span>
             <span className="text-sm text-slate-700">{currentKey ? new Date(currentKey.created_at).toLocaleDateString() : '-'}</span>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-slate-500">Encryption Health</span>
            <span className="text-green-600 font-medium">100% Secured</span>
          </div>
          <Progress value={100} className="h-2 bg-slate-100" indicatorClassName="bg-green-500" />
        </div>

        <div className="rounded-md bg-blue-50 p-3 flex gap-3 items-start text-xs text-blue-700">
          <Lock className="w-4 h-4 shrink-0 mt-0.5" />
          <p>
            Your data is protected using end-to-end encryption standards. Rotating keys will re-encrypt new data with the new key, while keeping old keys available for decryption.
          </p>
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          onClick={handleRotate} 
          disabled={rotating || loading} 
          className="w-full bg-slate-900 hover:bg-slate-800"
        >
          {rotating ? <RefreshCw className="w-4 h-4 animate-spin mr-2" /> : <RefreshCw className="w-4 h-4 mr-2" />}
          Rotate Encryption Key
        </Button>
      </CardFooter>
    </Card>
  );
};

export default KeyManagementPanel;
