
import React, { useState, useRef, useMemo } from 'react';
import { 
  Upload, FileText, Table as TableIcon, ArrowRight, Check, 
  AlertTriangle, Settings, Loader2, Download, Database,
  Trash2, Edit, Copy, Filter, ArrowUpDown, X, Search, CheckSquare, Square,
  RotateCcw, Save
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from '@/components/ui/use-toast';
import { aiParsingService } from '@/services/aiParsingService';
import { regulatoryImportService } from '@/services/regulatoryImportService';

const STEP_UPLOAD = 1;
const STEP_MAPPING = 2;
const STEP_PREVIEW = 3;
const STEP_IMPORTING = 4;
const STEP_COMPLETE = 5;

const RegulatoryImportWizard = ({ onComplete }) => {
  const { toast } = useToast();
  const fileInputRef = useRef(null);

  // Wizard State
  const [step, setStep] = useState(STEP_UPLOAD);
  
  // Data State
  const [file, setFile] = useState(null);
  const [parsing, setParsing] = useState(false);
  const [parsedData, setParsedData] = useState(null);
  const [mapping, setMapping] = useState({});
  const [mappedData, setMappedData] = useState([]);
  
  // Selection & Bulk Actions State
  const [selectedIndices, setSelectedIndices] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('ALL'); 
  const [filterSeverity, setFilterSeverity] = useState('ALL'); 
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const [deletedItemsHistory, setDeletedItemsHistory] = useState([]); 

  // Editing State
  const [editItem, setEditItem] = useState(null); 
  const [isBulkEditOpen, setIsBulkEditOpen] = useState(false);
  const [bulkEditFields, setBulkEditFields] = useState({ severity: 'NO_CHANGE', category_name: '' });

  // Deletion State
  const [itemsToDelete, setItemsToDelete] = useState([]);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  // Import Progress State
  const [importProgress, setImportProgress] = useState(0);
  const [importStats, setImportStats] = useState({ total: 0, success: 0, failed: 0 });

  // System fields mapping
  const SYSTEM_FIELDS = [
    { key: 'category_name', label: 'Risk Category', required: true },
    { key: 'regulation_name', label: 'Regulation Name', required: true },
    { key: 'description', label: 'Description', required: false },
    { key: 'severity', label: 'Severity Level', required: false },
    { key: 'control_code', label: 'Control Code', required: false },
    { key: 'control_name', label: 'Control Title', required: false },
    { key: 'control_description', label: 'Control Description', required: false }
  ];

  // --- Helpers for Data Management ---

  const getFilteredAndSortedData = useMemo(() => {
    let data = [...mappedData];

    // 1. Text Search
    if (searchTerm) {
      const lowerTerm = searchTerm.toLowerCase();
      data = data.filter(item => 
        (item.regulation_name || '').toLowerCase().includes(lowerTerm) ||
        (item.category_name || '').toLowerCase().includes(lowerTerm) ||
        (item.description || '').toLowerCase().includes(lowerTerm)
      );
    }

    // 2. Filter by Severity
    if (filterSeverity !== 'ALL') {
      data = data.filter(item => 
        (item.severity || 'Medium').toLowerCase() === filterSeverity.toLowerCase()
      );
    }

    // 3. Filter by Type
    if (filterType !== 'ALL') {
       if (filterType === 'HAS_CONTROLS') {
         data = data.filter(item => item.control_items?.length > 0 || item.control_code);
       } else if (filterType === 'NO_CONTROLS') {
         data = data.filter(item => !item.control_items?.length && !item.control_code);
       }
    }

    // 4. Sort
    if (sortConfig.key) {
      data.sort((a, b) => {
        const valA = (a[sortConfig.key] || '').toString().toLowerCase();
        const valB = (b[sortConfig.key] || '').toString().toLowerCase();
        if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
        if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return data;
  }, [mappedData, searchTerm, sortConfig, filterSeverity, filterType]);

  // --- Handlers: File & Parsing ---

  const handleFileSelect = async (e) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;
    
    setFile(selectedFile);
    setParsing(true);

    try {
      const result = await aiParsingService.parseFile(selectedFile);
      setParsedData(result);
      
      if (result.type === 'spreadsheet') {
        const suggested = aiParsingService.suggestMapping(result.headers);
        setMapping(suggested);
        setStep(STEP_MAPPING);
      } else {
        const initialData = result.extractedData.map((item, idx) => ({ ...item, _id: idx }));
        setMappedData(initialData);
        setStep(STEP_PREVIEW);
      }
    } catch (error) {
      toast({
        title: "Parsing Failed",
        description: error.message,
        variant: "destructive"
      });
      setFile(null);
    } finally {
      setParsing(false);
    }
  };

  const handleMappingChange = (systemField, fileHeader) => {
    setMapping(prev => ({ ...prev, [systemField]: fileHeader }));
  };

  const applyMapping = () => {
    const missing = SYSTEM_FIELDS.filter(f => f.required && !mapping[f.key]);
    if (missing.length > 0) {
      toast({
        title: "Missing Mapping",
        description: `Please map required fields: ${missing.map(m => m.label).join(', ')}`,
        variant: "destructive"
      });
      return;
    }

    const transformed = parsedData.rows.map((row, idx) => {
      const item = { _id: idx }; 
      Object.entries(mapping).forEach(([key, header]) => {
        item[key] = row[header];
      });
      return item;
    });

    setMappedData(transformed);
    setStep(STEP_PREVIEW);
  };

  // --- Handlers: Selection & Bulk Operations ---

  const toggleSelection = (id) => {
    setSelectedIndices(prev => {
      if (prev.includes(id)) {
        return prev.filter(i => i !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  const toggleSelectAll = (checked) => {
    if (checked) {
      // Only select visible items based on current filter
      const allVisibleIds = getFilteredAndSortedData.map(item => item._id);
      
      // Combine with existing (or replace - "Select All" usually implies current view)
      // We will replace selection with current view to match standard table behavior
      setSelectedIndices(allVisibleIds);
    } else {
      setSelectedIndices([]);
    }
  };

  const handleSort = (key) => {
    setSortConfig(current => ({
      key,
      direction: current.key === key && current.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const initiateDelete = (idsToDelete) => {
    if (idsToDelete.length === 0) return;
    setItemsToDelete(idsToDelete);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    const ids = itemsToDelete;
    const items = mappedData.filter(item => ids.includes(item._id));
    
    // Save to history for undo
    setDeletedItemsHistory(prev => [...prev, ...items]);

    setMappedData(prev => prev.filter(item => !ids.includes(item._id)));
    setSelectedIndices(prev => prev.filter(id => !ids.includes(id)));
    
    setIsDeleteDialogOpen(false);
    setItemsToDelete([]);

    toast({
      title: "Items Deleted",
      description: (
        <div className="flex items-center gap-2">
          <span>Removed {ids.length} items.</span>
          <Button 
            variant="link" 
            className="h-auto p-0 text-white font-bold underline"
            onClick={handleUndoDelete}
          >
            Undo
          </Button>
        </div>
      ),
      className: "bg-slate-900 text-white border-slate-800"
    });
  };

  const handleUndoDelete = () => {
    if (deletedItemsHistory.length === 0) return;
    
    setMappedData(prev => {
      // Re-add items and sort by ID
      const restored = [...prev, ...deletedItemsHistory].sort((a,b) => a._id - b._id);
      return restored;
    });
    setDeletedItemsHistory([]);
    toast({ title: "Undo Successful", description: "All deleted items restored." });
  };

  const handleBulkEdit = () => {
    const updates = {};
    if (bulkEditFields.severity && bulkEditFields.severity !== 'NO_CHANGE') updates.severity = bulkEditFields.severity;
    if (bulkEditFields.category_name && bulkEditFields.category_name.trim() !== '') updates.category_name = bulkEditFields.category_name;
    
    if (Object.keys(updates).length === 0) {
      setIsBulkEditOpen(false);
      return;
    }

    setMappedData(prev => prev.map(item => 
      selectedIndices.includes(item._id) ? { ...item, ...updates } : item
    ));

    setIsBulkEditOpen(false);
    setBulkEditFields({ severity: 'NO_CHANGE', category_name: '' });
    setSelectedIndices([]); 
    toast({ title: "Bulk Update Applied", description: `Updated ${selectedIndices.length} items.` });
  };

  const handleSingleEditSave = () => {
    if (!editItem) return;
    setMappedData(prev => prev.map(item => item._id === editItem._id ? editItem : item));
    setEditItem(null);
    toast({ title: "Item Updated" });
  };

  const handleDuplicate = (idsToDuplicate) => {
    // Generate new unique IDs based on max existing ID + randomness
    const maxId = mappedData.reduce((max, item) => Math.max(max, typeof item._id === 'number' ? item._id : 0), 0);
    
    const newItems = idsToDuplicate.map((id, index) => {
      const original = mappedData.find(item => item._id === id);
      if (!original) return null;
      
      return { 
        ...original, 
        _id: maxId + index + 1 + Math.random(), // Ensure uniqueness
        regulation_name: `${original.regulation_name} (Copy)`
      };
    }).filter(Boolean);

    setMappedData(prev => [...prev, ...newItems]);
    toast({ title: "Items Duplicated", description: `Created ${newItems.length} copies.` });
  };

  // --- Handlers: Import Execution ---

  const handleImport = async () => {
    if (mappedData.length === 0) {
      toast({ title: "Nothing to import", variant: "destructive" });
      return;
    }

    setStep(STEP_IMPORTING);
    setImportProgress(0);
    
    let successCount = 0;
    let failCount = 0;
    const total = mappedData.length;

    try {
      const importLog = await regulatoryImportService.createImportLog(
        file.name, 
        file.type, 
        total
      );

      for (let i = 0; i < total; i++) {
        try {
          // Clean data before sending (remove UI specific _id)
          const { _id, ...record } = mappedData[i];
          await regulatoryImportService.processRecord(record);
          successCount++;
        } catch (e) {
          console.error("Record import failed:", e);
          failCount++;
        }
        setImportProgress(Math.round(((i + 1) / total) * 100));
      }

      await regulatoryImportService.completeImport(importLog.id, successCount);
      setImportStats({ total, success: successCount, failed: failCount });
      setStep(STEP_COMPLETE);

    } catch (globalError) {
      toast({ title: "Import Failed", description: globalError.message, variant: "destructive" });
    }
  };

  const resetWizard = () => {
    setStep(STEP_UPLOAD);
    setFile(null);
    setParsedData(null);
    setMappedData([]);
    setImportProgress(0);
    setSelectedIndices([]);
    setDeletedItemsHistory([]);
  };

  // --- Renders ---

  if (step === STEP_UPLOAD) {
    return (
      <Card className="border-dashed border-2 shadow-none bg-slate-50/50">
        <CardContent className="pt-10 pb-10 flex flex-col items-center justify-center min-h-[300px]">
          <div className="bg-blue-100 p-4 rounded-full mb-4">
            {parsing ? <Loader2 className="h-8 w-8 text-blue-600 animate-spin" /> : <Upload className="h-8 w-8 text-blue-600" />}
          </div>
          <h3 className="text-xl font-semibold mb-2">{parsing ? "Analyzing..." : "Upload Regulations"}</h3>
          <p className="text-slate-500 text-center max-w-sm mb-6">
            {parsing ? "Structuring data..." : "Drag and drop CSV, Excel, or PDF to extract content."}
          </p>
          <div className="flex gap-4">
             <input type="file" ref={fileInputRef} className="hidden" accept=".csv,.xlsx,.xls,.pdf" onChange={handleFileSelect} disabled={parsing} />
             <Button onClick={() => fileInputRef.current?.click()} disabled={parsing}>{parsing ? "Processing..." : "Select File"}</Button>
             <Button variant="outline" onClick={() => toast({ title: "Template Download", description: "Downloading..." })}><Download className="h-4 w-4 mr-2" /> Template</Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (step === STEP_MAPPING) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Map Columns</CardTitle>
          <CardDescription>Match your file columns to the system fields.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-8">
            <div className="space-y-4">
              {SYSTEM_FIELDS.map((field) => (
                <div key={field.key} className="grid grid-cols-12 gap-4 items-center">
                  <div className="col-span-5"><Label className={field.required ? "font-bold" : ""}>{field.label} {field.required && <span className="text-red-500">*</span>}</Label></div>
                  <div className="col-span-1 flex justify-center"><ArrowRight className="h-4 w-4 text-slate-400" /></div>
                  <div className="col-span-6">
                    <Select value={mapping[field.key] || ''} onValueChange={(val) => handleMappingChange(field.key, val)}>
                      <SelectTrigger><SelectValue placeholder="Select Column" /></SelectTrigger>
                      <SelectContent>{parsedData.headers.map(header => <SelectItem key={header} value={header}>{header}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                </div>
              ))}
            </div>
            <div className="bg-slate-50 p-4 rounded-lg border">
              <h4 className="font-semibold mb-2 flex items-center gap-2"><TableIcon className="h-4 w-4" /> Data Preview</h4>
              <ScrollArea className="h-[300px]">
                <table className="text-xs w-full">
                  <thead><tr>{parsedData.headers.slice(0, 3).map(h => <th key={h} className="text-left p-2 border-b font-medium text-slate-500">{h}</th>)}</tr></thead>
                  <tbody>{parsedData.rows.slice(0, 5).map((row, i) => <tr key={i} className="border-b last:border-0">{parsedData.headers.slice(0, 3).map((h, j) => <td key={j} className="p-2 truncate max-w-[100px]">{row[h]}</td>)}</tr>)}</tbody>
                </table>
              </ScrollArea>
            </div>
          </div>
        </CardContent>
        <CardFooter className="justify-between"><Button variant="ghost" onClick={resetWizard}>Cancel</Button><Button onClick={applyMapping}>Next: Review Data</Button></CardFooter>
      </Card>
    );
  }

  if (step === STEP_PREVIEW) {
    const displayData = getFilteredAndSortedData;
    // Check if ALL visible items are selected
    const allSelected = displayData.length > 0 && displayData.every(item => selectedIndices.includes(item._id));
    // Check if SOME visible items are selected but not all
    const isIndeterminate = displayData.some(item => selectedIndices.includes(item._id)) && !allSelected;

    return (
      <Card className="flex flex-col h-[700px] border-0 shadow-none">
        <CardHeader className="border-b pb-4 px-0">
          <div className="flex flex-col gap-4">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle>Review & Import</CardTitle>
                <CardDescription>Verify {mappedData.length} records before importing.</CardDescription>
              </div>
              <div className="flex gap-2">
                 {deletedItemsHistory.length > 0 && (
                  <Button variant="outline" size="sm" onClick={handleUndoDelete} className="text-slate-600 border-dashed border-slate-300">
                    <RotateCcw className="w-3 h-3 mr-2" /> Undo Delete ({deletedItemsHistory.length})
                  </Button>
                )}
              </div>
            </div>

            {/* Filters Bar */}
            <div className="flex gap-2 items-center flex-wrap">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                <Input 
                  placeholder="Search by name, category..." 
                  className="pl-9 w-[280px] h-9" 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Select value={filterSeverity} onValueChange={setFilterSeverity}>
                <SelectTrigger className="w-[130px] h-9">
                   <div className="flex items-center gap-2">
                     <Filter className="w-3 h-3 text-slate-500" />
                     <span className="truncate">{filterSeverity === 'ALL' ? 'Severity' : filterSeverity}</span>
                   </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All Severities</SelectItem>
                  <SelectItem value="Critical">Critical</SelectItem>
                  <SelectItem value="High">High</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="Low">Low</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-[140px] h-9">
                   <div className="flex items-center gap-2">
                     <FileText className="w-3 h-3 text-slate-500" />
                     <span className="truncate">{filterType === 'ALL' ? 'All Types' : filterType === 'HAS_CONTROLS' ? 'With Controls' : 'No Controls'}</span>
                   </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All Types</SelectItem>
                  <SelectItem value="HAS_CONTROLS">With Controls</SelectItem>
                  <SelectItem value="NO_CONTROLS">No Controls</SelectItem>
                </SelectContent>
              </Select>

               <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="h-9 ml-auto">
                      <ArrowUpDown className="w-3 h-3 mr-2" /> Sort
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleSort('regulation_name')}>Regulation Name</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleSort('category_name')}>Category</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleSort('severity')}>Severity</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
            </div>
          </div>
          
          {/* Bulk Action Toolbar */}
          <div className={`flex items-center justify-between mt-4 p-2 rounded-md border transition-colors ${selectedIndices.length > 0 ? 'bg-blue-50 border-blue-200' : 'bg-slate-50 border-slate-200'}`}>
            <div className="flex items-center gap-3 pl-2">
              <div className="flex items-center gap-3">
                <Checkbox 
                  checked={allSelected ? true : isIndeterminate ? "indeterminate" : false}
                  onCheckedChange={toggleSelectAll}
                  aria-label="Select all"
                  className="translate-y-[1px]"
                />
                <span className={`text-sm font-medium ${selectedIndices.length > 0 ? 'text-blue-700' : 'text-slate-500'}`}>
                  {selectedIndices.length} selected
                </span>
              </div>
              
              <div className="h-4 w-px bg-slate-300 mx-2" />
              
              <div className="flex items-center gap-1">
                <Button 
                  size="sm" 
                  variant="ghost" 
                  className={`h-8 hover:bg-white/50 ${selectedIndices.length === 0 ? 'opacity-50 pointer-events-none' : 'text-red-600 hover:text-red-700'}`} 
                  onClick={() => initiateDelete(selectedIndices)}
                  disabled={selectedIndices.length === 0}
                >
                  <Trash2 className="w-4 h-4 mr-2" /> Delete
                </Button>
                
                <Dialog open={isBulkEditOpen} onOpenChange={setIsBulkEditOpen}>
                  <DialogTrigger asChild>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className={`h-8 hover:bg-white/50 ${selectedIndices.length === 0 ? 'opacity-50 pointer-events-none' : 'text-blue-600 hover:text-blue-700'}`}
                      disabled={selectedIndices.length === 0}
                    >
                      <Edit className="w-4 h-4 mr-2" /> Edit
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit {selectedIndices.length} Items</DialogTitle>
                      <DialogDescription>Apply changes to all selected rows.</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Severity Level</Label>
                        <Select 
                          value={bulkEditFields.severity} 
                          onValueChange={(val) => setBulkEditFields(prev => ({...prev, severity: val}))}
                        >
                          <SelectTrigger><SelectValue placeholder="No Change" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="NO_CHANGE">-- No Change --</SelectItem>
                            <SelectItem value="Critical">Critical</SelectItem>
                            <SelectItem value="High">High</SelectItem>
                            <SelectItem value="Medium">Medium</SelectItem>
                            <SelectItem value="Low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Risk Category Name</Label>
                        <Input 
                          placeholder="Leave empty to keep existing"
                          value={bulkEditFields.category_name}
                          onChange={(e) => setBulkEditFields(prev => ({...prev, category_name: e.target.value}))}
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsBulkEditOpen(false)}>Cancel</Button>
                      <Button onClick={handleBulkEdit}>Apply Changes</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                <Button 
                  size="sm" 
                  variant="ghost" 
                  className={`h-8 hover:bg-white/50 ${selectedIndices.length === 0 ? 'opacity-50 pointer-events-none' : 'text-slate-600'}`} 
                  onClick={() => handleDuplicate(selectedIndices)}
                  disabled={selectedIndices.length === 0}
                >
                  <Copy className="w-4 h-4 mr-2" /> Duplicate
                </Button>
              </div>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="flex-1 p-0 overflow-hidden bg-slate-50/30 border rounded-md mb-4 mt-2">
          <ScrollArea className="h-full">
            <div className="min-w-full inline-block align-middle">
               <div className="border-b bg-slate-100 flex text-xs font-semibold text-slate-500 uppercase tracking-wider py-2 px-4 sticky top-0 z-10">
                 <div className="w-[50px] flex-none"></div>
                 <div className="flex-1 px-2">Regulation</div>
                 <div className="w-[150px] px-2">Category</div>
                 <div className="w-[100px] px-2 text-center">Severity</div>
                 <div className="w-[100px] px-2 text-right">Actions</div>
               </div>
               
               <div className="divide-y divide-slate-200">
                  {displayData.map((item) => (
                    <div 
                      key={item._id} 
                      className={`flex items-center py-3 px-4 transition-colors hover:bg-white ${selectedIndices.includes(item._id) ? 'bg-blue-50/50 hover:bg-blue-50' : 'bg-white'}`}
                    >
                      <div className="w-[50px] flex-none flex items-center justify-center">
                        <Checkbox 
                          checked={selectedIndices.includes(item._id)}
                          onCheckedChange={() => toggleSelection(item._id)}
                        />
                      </div>
                      
                      <div className="flex-1 min-w-0 px-2">
                        <div className="font-medium text-sm text-slate-900 truncate">{item.regulation_name}</div>
                        <div className="text-xs text-slate-500 truncate mt-0.5">{item.description}</div>
                        {item.control_code && (
                           <div className="mt-1 inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-800">
                             Control: {item.control_code}
                           </div>
                        )}
                      </div>

                      <div className="w-[150px] flex-none px-2">
                        <div className="text-xs font-medium text-slate-700 truncate" title={item.category_name}>
                          {item.category_name}
                        </div>
                      </div>

                      <div className="w-[100px] flex-none px-2 flex justify-center">
                        <Badge className={`
                          ${item.severity?.toLowerCase() === 'critical' ? 'bg-rose-100 text-rose-800 hover:bg-rose-100' : ''}
                          ${item.severity?.toLowerCase() === 'high' ? 'bg-red-100 text-red-700 hover:bg-red-100' : ''}
                          ${item.severity?.toLowerCase() === 'medium' ? 'bg-amber-100 text-amber-700 hover:bg-amber-100' : ''}
                          ${item.severity?.toLowerCase() === 'low' ? 'bg-blue-100 text-blue-700 hover:bg-blue-100' : ''}
                          ${!item.severity ? 'bg-slate-100 text-slate-600 hover:bg-slate-100' : ''}
                        `}>
                          {item.severity || 'Medium'}
                        </Badge>
                      </div>

                      <div className="w-[100px] flex-none px-2 flex justify-end gap-1">
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          className="h-7 w-7 text-slate-400 hover:text-blue-600" 
                          onClick={() => setEditItem(item)}
                          title="Edit Item"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </Button>
                         <Button 
                          size="icon" 
                          variant="ghost" 
                          className="h-7 w-7 text-slate-400 hover:text-slate-600" 
                          onClick={() => handleDuplicate([item._id])}
                          title="Duplicate Item"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </Button>
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          className="h-7 w-7 text-slate-400 hover:text-red-600" 
                          onClick={() => initiateDelete([item._id])}
                          title="Delete Item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  ))}
               </div>
            </div>
            
            {displayData.length === 0 && (
              <div className="text-center py-12 text-slate-400 flex flex-col items-center">
                <Filter className="w-12 h-12 mb-2 opacity-20" />
                <p>No items found matching your filters.</p>
                <Button variant="link" onClick={() => { setSearchTerm(''); setFilterSeverity('ALL'); setFilterType('ALL'); }}>Clear Filters</Button>
              </div>
            )}
          </ScrollArea>
        </CardContent>

        <CardFooter className="justify-between px-0 pt-2">
          <Button variant="ghost" onClick={resetWizard}>Cancel Import</Button>
          <Button onClick={handleImport} className="bg-green-600 hover:bg-green-700 min-w-[150px]">
            <Database className="h-4 w-4 mr-2" /> 
            Import {mappedData.length} Records
          </Button>
        </CardFooter>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This will remove {itemsToDelete.length} item(s) from your import list.
                You can undo this action immediately after if needed.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
                Delete Items
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Single Item Edit Modal */}
        <Dialog open={!!editItem} onOpenChange={(open) => !open && setEditItem(null)}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Edit Regulation</DialogTitle>
            </DialogHeader>
            {editItem && (
              <div className="space-y-4 py-2">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Regulation Name</Label>
                    <Input 
                      value={editItem.regulation_name || ''} 
                      onChange={e => setEditItem({...editItem, regulation_name: e.target.value})} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Input 
                      value={editItem.category_name || ''} 
                      onChange={e => setEditItem({...editItem, category_name: e.target.value})} 
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Input 
                    value={editItem.description || ''} 
                    onChange={e => setEditItem({...editItem, description: e.target.value})} 
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Severity</Label>
                    <Select 
                      value={editItem.severity || 'Medium'} 
                      onValueChange={v => setEditItem({...editItem, severity: v})}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Critical">Critical</SelectItem>
                        <SelectItem value="High">High</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="Low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditItem(null)}>Cancel</Button>
              <Button onClick={handleSingleEditSave} className="bg-blue-600 hover:bg-blue-700">
                <Save className="w-4 h-4 mr-2" /> Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </Card>
    );
  }

  // Step 4: Importing
  if (step === STEP_IMPORTING) {
    return (
      <Card>
        <CardContent className="pt-12 pb-12 flex flex-col items-center justify-center text-center">
          <div className="w-full max-w-md space-y-6">
            <h3 className="text-2xl font-bold animate-pulse">Importing Regulations...</h3>
            <Progress value={importProgress} className="h-3" />
            <p className="text-slate-500">Processing record {Math.round((importProgress / 100) * mappedData.length)} of {mappedData.length}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Step 5: Complete
  if (step === STEP_COMPLETE) {
    return (
      <Card className="border-green-200 bg-green-50/30">
        <CardContent className="pt-10 pb-10 flex flex-col items-center justify-center text-center">
          <div className="h-16 w-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
            <Check className="h-8 w-8 text-green-600" />
          </div>
          <h3 className="text-2xl font-bold text-green-900 mb-2">Import Successful</h3>
          <p className="text-green-700 max-w-md mb-8">
            Successfully processed {importStats.total} records. Your regulatory library has been updated with {importStats.success} new entries.
          </p>
          <div className="flex gap-4">
            <Button onClick={onComplete} variant="outline" className="bg-white">View Library</Button>
            <Button onClick={resetWizard}>Import Another File</Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return null;
};

export default RegulatoryImportWizard;
