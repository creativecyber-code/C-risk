
import React, { useState, useEffect } from 'react';
import { 
  Plus, Trash2, Save, FileText, AlertTriangle, List, 
  ShieldCheck, ArrowRight, CheckCircle2, UploadCloud, History 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';
import { contentPushService } from '@/services/contentPushService';
import { regulatoryImportService } from '@/services/regulatoryImportService';
import RegulatoryImportWizard from './RegulatoryImportWizard';

const RegulatoryLibraryManager = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('regulations');
  
  // Data
  const [categories, setCategories] = useState([]);
  const [regulations, setRegulations] = useState([]);
  const [importHistory, setImportHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showImportWizard, setShowImportWizard] = useState(false);

  // Forms
  const [newCategory, setNewCategory] = useState({ name: '', description: '', severity: 'Medium' });
  const [newRegulation, setNewRegulation] = useState({
    regulation_name: '', description: '', category_id: '', control_items: []
  });
  
  // Temp Control Item Input
  const [tempControl, setTempControl] = useState({ code: '', name: '', description: '' });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [cats, regs, history] = await Promise.all([
        contentPushService.getRiskCategories(),
        contentPushService.getRegulations(),
        regulatoryImportService.getImportHistory().catch(() => []) // Handle potential error if table not ready
      ]);
      setCategories(cats || []);
      setRegulations(regs || []);
      setImportHistory(history || []);
    } catch (e) {
      toast({ title: "Failed to load library data", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  // --- Category Handlers ---
  const handleCreateCategory = async () => {
    if (!newCategory.name) return toast({ title: "Name required", variant: "destructive" });
    try {
      await contentPushService.createRiskCategory(newCategory);
      setNewCategory({ name: '', description: '', severity: 'Medium' });
      loadData();
      toast({ title: "Risk Category Created" });
    } catch (e) {
      toast({ title: "Error creating category", variant: "destructive" });
    }
  };

  const handleDeleteCategory = async (id) => {
    if (!window.confirm("Delete this category?")) return;
    try {
      await contentPushService.deleteRiskCategory(id);
      loadData();
      toast({ title: "Category Deleted" });
    } catch (e) {
      toast({ title: "Cannot delete category in use", variant: "destructive" });
    }
  };

  // --- Regulation Handlers ---
  const handleAddControl = () => {
    if (!tempControl.code || !tempControl.name) return;
    setNewRegulation(prev => ({
      ...prev,
      control_items: [...prev.control_items, { ...tempControl, id: Date.now() }]
    }));
    setTempControl({ code: '', name: '', description: '' });
  };

  const handleRemoveControl = (id) => {
    setNewRegulation(prev => ({
      ...prev,
      control_items: prev.control_items.filter(c => c.id !== id)
    }));
  };

  const handleCreateRegulation = async () => {
    if (!newRegulation.regulation_name || !newRegulation.category_id) {
      return toast({ title: "Name and Category are required", variant: "destructive" });
    }
    try {
      await contentPushService.createRegulation(newRegulation);
      setNewRegulation({ regulation_name: '', description: '', category_id: '', control_items: [] });
      loadData();
      toast({ title: "Regulation Drafted" });
    } catch (e) {
      toast({ title: "Error creating regulation", variant: "destructive" });
    }
  };

  const handleDeleteRegulation = async (id) => {
    if (!window.confirm("Delete this regulation?")) return;
    try {
      await contentPushService.deleteRegulation(id);
      loadData();
      toast({ title: "Regulation Deleted" });
    } catch (e) {
      toast({ title: "Delete failed", variant: "destructive" });
    }
  };

  const handleImportComplete = () => {
    setShowImportWizard(false);
    loadData();
  };

  if (showImportWizard) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">Import Regulations</h2>
          <Button variant="outline" onClick={() => setShowImportWizard(false)}>
            Back to Library
          </Button>
        </div>
        <RegulatoryImportWizard onComplete={handleImportComplete} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Master Regulatory Library</h2>
          <p className="text-slate-500">Centralized repository for compliance standards and risk frameworks.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowImportWizard(true)} className="border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100">
            <UploadCloud className="w-4 h-4 mr-2" /> AI Import
          </Button>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-[400px]">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="regulations">Regulations</TabsTrigger>
              <TabsTrigger value="categories">Categories</TabsTrigger>
              <TabsTrigger value="imports">History</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        
        {/* --- REGULATIONS TAB --- */}
        <TabsContent value="regulations" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Create Form */}
            <Card className="lg:col-span-1 border-slate-200 shadow-sm h-fit">
              <CardHeader className="bg-slate-50 border-b">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Plus className="w-5 h-5 text-blue-600" /> New Regulation
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 p-6">
                <div className="space-y-2">
                  <Label>Regulation Title <span className="text-red-500">*</span></Label>
                  <Input 
                    value={newRegulation.regulation_name}
                    onChange={e => setNewRegulation({...newRegulation, regulation_name: e.target.value})}
                    placeholder="e.g. GDPR Compliance Framework" 
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Risk Category <span className="text-red-500">*</span></Label>
                  <Select 
                    value={newRegulation.category_id}
                    onValueChange={v => setNewRegulation({...newRegulation, category_id: v})}
                  >
                    <SelectTrigger><SelectValue placeholder="Select Category" /></SelectTrigger>
                    <SelectContent>
                      {categories.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea 
                    value={newRegulation.description}
                    onChange={e => setNewRegulation({...newRegulation, description: e.target.value})}
                    placeholder="Brief overview..." 
                  />
                </div>

                <div className="border rounded-md p-3 bg-slate-50 space-y-3">
                  <Label className="text-xs font-semibold text-slate-500 uppercase">Add Control Items</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Input 
                      placeholder="Code" 
                      className="col-span-1"
                      value={tempControl.code}
                      onChange={e => setTempControl({...tempControl, code: e.target.value})}
                    />
                    <Input 
                      placeholder="Control Name" 
                      className="col-span-2"
                      value={tempControl.name}
                      onChange={e => setTempControl({...tempControl, name: e.target.value})}
                    />
                  </div>
                  <Textarea 
                    placeholder="Control Description" 
                    className="h-16"
                    value={tempControl.description}
                    onChange={e => setTempControl({...tempControl, description: e.target.value})}
                  />
                  <Button size="sm" variant="secondary" onClick={handleAddControl} className="w-full">
                    <Plus className="w-4 h-4 mr-2" /> Add Control Item
                  </Button>
                  
                  {newRegulation.control_items.length > 0 && (
                    <div className="space-y-2 mt-2 max-h-40 overflow-y-auto">
                      {newRegulation.control_items.map((c) => (
                        <div key={c.id} className="flex justify-between items-start text-sm bg-white p-2 rounded border">
                          <div>
                            <span className="font-mono font-bold text-xs mr-2">{c.code}</span>
                            <span>{c.name}</span>
                          </div>
                          <button onClick={() => handleRemoveControl(c.id)} className="text-red-500 hover:text-red-700">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={handleCreateRegulation}>
                  <Save className="w-4 h-4 mr-2" /> Save to Library
                </Button>
              </CardContent>
            </Card>

            {/* List View */}
            <div className="lg:col-span-2 space-y-4">
              <h3 className="font-semibold text-slate-700">Existing Library Content</h3>
              {loading ? (
                <div className="flex justify-center p-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div></div>
              ) : regulations.length === 0 ? (
                <Card className="bg-slate-50 border-dashed">
                  <CardContent className="flex flex-col items-center justify-center py-12 text-slate-400">
                    <FileText className="w-12 h-12 mb-2 opacity-50" />
                    <p>No regulations defined yet.</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-4">
                  {regulations.map(reg => (
                    <Card key={reg.id} className="group hover:border-blue-300 transition-colors">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="outline" className="bg-slate-100">{reg.category?.name || 'Uncategorized'}</Badge>
                              <span className="text-xs text-slate-400">{new Date(reg.created_at).toLocaleDateString()}</span>
                            </div>
                            <CardTitle className="text-lg">{reg.regulation_name}</CardTitle>
                          </div>
                          <Button variant="ghost" size="icon" className="text-slate-400 hover:text-red-500" onClick={() => handleDeleteRegulation(reg.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        <CardDescription>{reg.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center gap-4 text-sm text-slate-600">
                          <div className="flex items-center gap-1">
                            <List className="w-4 h-4" /> 
                            {reg.control_items?.length || 0} Controls
                          </div>
                          <div className="flex items-center gap-1">
                            <ShieldCheck className="w-4 h-4" />
                            Status: <span className="text-green-600 font-medium">Ready</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        {/* --- CATEGORIES TAB --- */}
        <TabsContent value="categories" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-1 h-fit">
              <CardHeader><CardTitle>Add Risk Category</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Category Name</Label>
                  <Input value={newCategory.name} onChange={e => setNewCategory({...newCategory, name: e.target.value})} placeholder="e.g. Data Privacy" />
                </div>
                <div className="space-y-2">
                  <Label>Severity Level</Label>
                  <Select value={newCategory.severity} onValueChange={v => setNewCategory({...newCategory, severity: v})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Critical">Critical</SelectItem>
                      <SelectItem value="High">High</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="Low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea value={newCategory.description} onChange={e => setNewCategory({...newCategory, description: e.target.value})} />
                </div>
                <Button onClick={handleCreateCategory} className="w-full">Create Category</Button>
              </CardContent>
            </Card>

            <div className="md:col-span-2">
              <div className="rounded-md border bg-white">
                <table className="w-full text-sm text-left">
                  <thead className="bg-slate-50 text-slate-500 font-medium border-b">
                    <tr>
                      <th className="p-4">Name</th>
                      <th className="p-4">Severity</th>
                      <th className="p-4">Description</th>
                      <th className="p-4 w-[50px]"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {categories.map(cat => (
                      <tr key={cat.id} className="border-b last:border-0 hover:bg-slate-50">
                        <td className="p-4 font-medium">{cat.name}</td>
                        <td className="p-4">
                          <Badge className={
                            cat.severity === 'Critical' ? 'bg-red-100 text-red-800' :
                            cat.severity === 'High' ? 'bg-orange-100 text-orange-800' :
                            'bg-blue-100 text-blue-800'
                          }>
                            {cat.severity}
                          </Badge>
                        </td>
                        <td className="p-4 text-slate-500 truncate max-w-xs">{cat.description}</td>
                        <td className="p-4">
                          <button onClick={() => handleDeleteCategory(cat.id)} className="text-slate-400 hover:text-red-500">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                    {categories.length === 0 && (
                      <tr><td colSpan={4} className="p-8 text-center text-slate-400">No categories found</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* --- IMPORTS HISTORY TAB --- */}
        <TabsContent value="imports">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5 text-slate-500" /> Import History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <table className="w-full text-sm text-left">
                  <thead className="bg-slate-50 border-b">
                    <tr>
                      <th className="p-4 font-medium text-slate-500">File Name</th>
                      <th className="p-4 font-medium text-slate-500">Date</th>
                      <th className="p-4 font-medium text-slate-500">Status</th>
                      <th className="p-4 font-medium text-slate-500">Records</th>
                      <th className="p-4 font-medium text-slate-500">Imported By</th>
                    </tr>
                  </thead>
                  <tbody>
                    {importHistory.map((log) => (
                      <tr key={log.id} className="border-b last:border-0">
                        <td className="p-4 flex items-center gap-2">
                          <FileText className="h-4 w-4 text-blue-500" />
                          {log.filename}
                        </td>
                        <td className="p-4 text-slate-500">
                          {new Date(log.created_at).toLocaleString()}
                        </td>
                        <td className="p-4">
                          <Badge variant={log.status === 'completed' ? 'default' : 'destructive'} className="capitalize">
                            {log.status.replace('_', ' ')}
                          </Badge>
                        </td>
                        <td className="p-4">
                          {log.imported_count} / {log.total_records}
                        </td>
                        <td className="p-4 text-slate-500">
                          {log.importer?.email || 'Unknown'}
                        </td>
                      </tr>
                    ))}
                    {importHistory.length === 0 && (
                      <tr>
                        <td colSpan={5} className="p-8 text-center text-slate-500">No import history found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default RegulatoryLibraryManager;
