
import React, { useState, useEffect } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Activity, 
  Database, 
  HardDrive, 
  Server, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle,
  RefreshCw,
  Clock
} from 'lucide-react';
import { platformService } from '@/services/platformService';

const StatusRow = ({ icon: Icon, label, status, latency, details }) => {
  const getStatusColor = (s) => {
    switch (s?.toLowerCase()) {
      case 'healthy': return 'text-green-500 bg-green-500/10 border-green-500/20';
      case 'degraded': return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
      case 'down': return 'text-red-500 bg-red-500/10 border-red-500/20';
      default: return 'text-slate-500 bg-slate-500/10 border-slate-500/20';
    }
  };

  const getStatusIcon = (s) => {
    switch (s?.toLowerCase()) {
      case 'healthy': return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'degraded': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'down': return <XCircle className="h-4 w-4 text-red-500" />;
      default: return <Activity className="h-4 w-4 text-slate-500" />;
    }
  };

  return (
    <div className="flex items-center justify-between p-3 rounded-lg border border-slate-800 bg-slate-900/50">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-full bg-slate-800">
          <Icon className="h-4 w-4 text-slate-300" />
        </div>
        <div>
          <p className="text-sm font-medium text-slate-200">{label}</p>
          {details && <p className="text-xs text-slate-500">{details}</p>}
        </div>
      </div>
      <div className="flex items-center gap-3">
        {latency !== undefined && (
          <span className="text-xs font-mono text-slate-500 flex items-center gap-1">
            <Clock className="h-3 w-3" /> {latency}ms
          </span>
        )}
        <div className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border text-xs font-medium capitalize ${getStatusColor(status)}`}>
          {getStatusIcon(status)}
          {status}
        </div>
      </div>
    </div>
  );
};

const SystemStatusDialog = ({ open, onOpenChange }) => {
  const [loading, setLoading] = useState(false);
  const [healthData, setHealthData] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  const fetchHealth = async () => {
    setLoading(true);
    try {
      const data = await platformService.getSystemHealth();
      setHealthData(data);
      setLastUpdated(new Date());
    } catch (error) {
      console.error("Failed to fetch system status", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) {
      fetchHealth();
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-950 border-slate-800 text-slate-200 sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-blue-500" />
            System Status
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            Real-time operational status of platform components.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 space-y-3">
          {loading && !healthData ? (
             <div className="h-48 flex flex-col items-center justify-center space-y-3 text-slate-500">
               <RefreshCw className="h-8 w-8 animate-spin text-blue-500" />
               <p className="text-sm">Running diagnostics...</p>
             </div>
          ) : healthData ? (
            <div className="space-y-3 animate-in fade-in slide-in-from-bottom-2 duration-300">
              <StatusRow 
                icon={Database} 
                label="Primary Database" 
                status={healthData.database.status} 
                latency={healthData.database.latency} 
                details={healthData.database.message || "PostgreSQL Cluster"}
              />
              <StatusRow 
                icon={Server} 
                label="API Gateway" 
                status={healthData.api.status} 
                latency={healthData.api.latency}
                details="RESTful Endpoints"
              />
              <StatusRow 
                icon={HardDrive} 
                label="Storage Service" 
                status={healthData.storage.status} 
                details={`${healthData.storage.count} Buckets Online`}
              />
              <StatusRow 
                icon={ShieldCheck} 
                label="Error Rate (24h)" 
                status={healthData.errors.status} 
                details={`${healthData.errors.count} recorded incidents`}
              />
            </div>
          ) : null}
        </div>

        <DialogFooter className="flex-row items-center justify-between sm:justify-between">
          <div className="text-xs text-slate-500 flex items-center gap-1">
            {lastUpdated && (
              <>Updated: {lastUpdated.toLocaleTimeString()}</>
            )}
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={fetchHealth} 
            disabled={loading}
            className="border-slate-700 hover:bg-slate-800 text-slate-300"
          >
            <RefreshCw className={`h-3 w-3 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default SystemStatusDialog;
