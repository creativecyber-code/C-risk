
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, Database, AlertTriangle, CheckCircle } from 'lucide-react';

const GlobalHealthMap = () => {
  // Mock Data for "Fleet Command" view
  const regions = [
    { id: 'us-east', name: 'US East (Virginia)', status: 'Healthy', latency: '24ms', load: 45 },
    { id: 'eu-west', name: 'EU West (Ireland)', status: 'Healthy', latency: '85ms', load: 32 },
    { id: 'apac', name: 'Asia Pacific (Singapore)', status: 'Degraded', latency: '145ms', load: 78 },
  ];

  const tenants = [
    { name: 'Acme Corp', status: 'Active', tier: 'Enterprise', storage: 85, alerts: 0 },
    { name: 'Globex Inc', status: 'Active', tier: 'Growth', storage: 42, alerts: 2 },
    { name: 'Soylent Corp', status: 'Suspended', tier: 'Free', storage: 12, alerts: 0 },
    { name: 'Umbrella Corp', status: 'Active', tier: 'Enterprise', storage: 92, alerts: 5 },
  ];

  return (
    <div className="space-y-6">
      {/* Infrastructure Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {regions.map(region => (
          <Card key={region.id} className="bg-slate-900 border-slate-800 text-slate-200">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-sm font-medium text-slate-400">{region.name}</CardTitle>
                {region.status === 'Healthy' ? (
                  <Activity className="h-4 w-4 text-emerald-500" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-amber-500 animate-pulse" />
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold mb-1">{region.status}</div>
              <div className="flex gap-4 text-xs text-slate-500">
                <span>Latency: {region.latency}</span>
                <span>Load: {region.load}%</span>
              </div>
              <div className="mt-3 h-1 w-full bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className={`h-full ${region.load > 70 ? 'bg-amber-500' : 'bg-emerald-500'}`} 
                  style={{ width: `${region.load}%` }} 
                />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tenant Health Grid */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-slate-200">Tenant Status Matrix</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {tenants.map((t, idx) => (
              <div key={idx} className="p-4 rounded-lg border border-slate-800 bg-slate-950/50 hover:bg-slate-800/50 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <span className="font-medium text-slate-200">{t.name}</span>
                  <Badge variant="outline" className={t.status === 'Active' ? 'border-emerald-500/30 text-emerald-400' : 'border-red-500/30 text-red-400'}>
                    {t.status}
                  </Badge>
                </div>
                
                <div className="space-y-3 mt-4">
                  <div className="flex justify-between text-xs text-slate-400">
                    <span className="flex items-center gap-1"><Database className="h-3 w-3" /> Storage</span>
                    <span>{t.storage}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${t.storage > 90 ? 'bg-red-500' : 'bg-blue-500'}`} 
                      style={{ width: `${t.storage}%` }} 
                    />
                  </div>

                  {t.alerts > 0 && (
                    <div className="flex items-center gap-2 text-xs text-red-400 bg-red-950/30 p-2 rounded">
                      <AlertTriangle className="h-3 w-3" />
                      {t.alerts} Critical Security Alerts
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GlobalHealthMap;
