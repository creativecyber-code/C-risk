
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const RegulationRecommender = ({ keywords = [] }) => {
  const regulations = [];
  
  if (keywords.includes('Financial Data')) {
    regulations.push('RBI Master Direction');
    regulations.push('PCI DSS');
  }
  if (keywords.includes('PII')) {
    regulations.push('DPDP Act 2023');
  }

  if (regulations.length === 0) return null;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">Applicable Regulations</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {regulations.map(reg => (
            <Badge key={reg} variant="outline" className="border-blue-200 bg-blue-50 text-blue-700">
              {reg}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default RegulationRecommender;
