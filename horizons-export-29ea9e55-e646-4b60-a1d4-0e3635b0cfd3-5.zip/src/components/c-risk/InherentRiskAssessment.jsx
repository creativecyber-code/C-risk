
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Calculator, Zap, ArrowRight, Info } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const InherentRiskAssessment = ({ onSave, readOnly, appId, onNext, initialScores, initialFAIR }) => {
  // Dimensions
  const [scores, setScores] = useState({
    likelihood: 5,
    impact: 5,
    complexity: 5,
    velocity: 5,
    detectability: 5
  });

  // Quantitative Inputs (FAIR-lite)
  const [fairData, setFairData] = useState({
    assetValue: 1000000, // Monetary value of asset
    threatFreq: 10,      // % Chance per year (0-100) or Count
    vulnImpact: 50       // % Impact Severity (0-100)
  });

  // Load initial data if provided (e.g., when returning to tab)
  useEffect(() => {
    if (initialScores) setScores(initialScores);
    if (initialFAIR) {
        // Reverse calculate if we only have ALE? No, usually stored in separate object. 
        // For now just keep defaults unless full object passed, assumes state management handles this.
    }
  }, [initialScores, initialFAIR]);

  const handleScoreChange = (dim, val) => {
    setScores(prev => ({ ...prev, [dim]: val[0] }));
  };

  const calculateQualitativeScore = () => {
    const sum = Object.values(scores).reduce((a, b) => a + b, 0);
    const rawScore = (sum / 50) * 100; // 5 dimensions * 10 max = 50
    return Math.min(100, Math.round(rawScore));
  };

  const calculateALE = () => {
    // Formula: ALE = (Asset Value × Threat Frequency × Vulnerability Impact) / 100
    const asset = parseFloat(fairData.assetValue) || 0;
    const freq = parseFloat(fairData.threatFreq) || 0;
    const vuln = parseFloat(fairData.vulnImpact) || 0;
    
    return (asset * freq * vuln) / 100;
  };

  const riskScore = calculateQualitativeScore();
  const ale = calculateALE();
  
  // Logic: FAIR Required for Medium, High, Critical
  const isHighRisk = riskScore > 40; 
  
  // Determine Risk Label
  const getRiskLabel = (score) => {
     if (score > 75) return "CRITICAL";
     if (score > 40) return "HIGH";
     if (score > 20) return "MEDIUM";
     return "LOW";
  };
  
  const riskLabel = getRiskLabel(riskScore);

  const handleSave = () => {
    console.log("Saving Risk Assessment with Label:", riskLabel);
    
    onSave({
      qualitative_scores: scores,
      quantitative_ale: ale,
      overall_score: riskScore,
      risk_label: riskLabel, // Explicitly pass the calculated string
      risk_dimensions: scores
    });
    
    // Trigger next step navigation if provided
    if (onNext) onNext();
  };

  const chartData = Object.entries(scores).map(([key, value]) => ({
    name: key.charAt(0).toUpperCase() + key.slice(1),
    score: value,
    fullMark: 10
  }));

  const CustomBadge = ({ children, variant, className }) => (
    <span className={`inline-flex items-center justify-center rounded-full px-2.5 py-0.5 text-xs font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 ${
      variant === 'destructive' ? 'bg-red-500 text-white' : 'bg-slate-900 text-white'
    } ${className}`}>
      {children}
    </span>
  );

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-yellow-600" />
              Risk Dimensions (Qualitative)
            </CardTitle>
            <CardDescription>Score key dimensions (1-10) to determine inherent risk level.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {Object.keys(scores).map(dim => (
              <div key={dim} className="space-y-2">
                <div className="flex justify-between">
                  <Label className="capitalize font-medium text-slate-700">{dim}</Label>
                  <span className="font-mono text-sm font-bold text-slate-900">{scores[dim]}/10</span>
                </div>
                <Slider 
                  value={[scores[dim]]} 
                  max={10} 
                  step={1} 
                  onValueChange={(v) => handleScoreChange(dim, v)}
                  disabled={readOnly}
                  className={
                    scores[dim] > 7 ? "text-red-600" : 
                    scores[dim] > 4 ? "text-yellow-600" : "text-green-600"
                  }
                />
              </div>
            ))}
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card className="h-full flex flex-col">
            <CardHeader>
              <CardTitle>Risk Heat Map Analysis</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col justify-between">
               <div className="h-64 w-full">
                 <ResponsiveContainer width="100%" height="100%">
                   <BarChart data={chartData}>
                     <XAxis dataKey="name" fontSize={12} stroke="#888888" />
                     <YAxis hide domain={[0, 10]} />
                     <Tooltip 
                        cursor={{fill: 'transparent'}} 
                        contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                     />
                     <Bar dataKey="score" fill="#4f46e5" radius={[4, 4, 0, 0]} barSize={40} />
                   </BarChart>
                 </ResponsiveContainer>
               </div>
               
               <div className="mt-6 p-6 rounded-xl bg-slate-50 border border-slate-200 flex justify-between items-center">
                 <div>
                   <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">Inherent Risk Score</p>
                   <p className={`text-4xl font-extrabold tracking-tight mt-1 ${riskScore > 75 ? 'text-red-600' : riskScore > 40 ? 'text-orange-600' : 'text-emerald-600'}`}>
                     {riskScore}/100
                   </p>
                 </div>
                 <div className="text-right">
                   <p className="text-sm font-medium text-slate-500 uppercase tracking-wider mb-2">Risk Level</p>
                   <CustomBadge className="text-lg px-4 py-1" variant={riskScore > 75 ? "destructive" : "default"}>
                     {riskLabel}
                   </CustomBadge>
                 </div>
               </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card className={`border-l-4 transition-all duration-300 ${isHighRisk ? "border-l-orange-500 shadow-md" : "border-l-slate-200 opacity-60 grayscale"}`}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
                <CardTitle className="flex items-center gap-2">
                    <Calculator className="h-5 w-5 text-emerald-600" />
                    Quantitative Financial Impact (FAIR Model)
                </CardTitle>
                <CardDescription>Required for Medium, High, and Critical Risks. Calculates Annual Loss Expectancy (ALE).</CardDescription>
            </div>
            {!isHighRisk && <Badge variant="outline" className="text-slate-500">Not Required for Low Risk</Badge>}
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-8 items-start">
            <div className="space-y-3">
              <Label className="text-base">Asset Value ($)</Label>
              <Input 
                type="number" 
                className="h-12 text-lg font-mono"
                value={fairData.assetValue}
                onChange={e => setFairData(p => ({...p, assetValue: parseFloat(e.target.value) || 0}))}
                disabled={readOnly || !isHighRisk}
              />
              <p className="text-xs text-slate-500 flex items-center gap-1">
                 <Info className="w-3 h-3" /> Total monetary value of the asset/data.
              </p>
            </div>
            <div className="space-y-3">
              <Label className="text-base">Threat Frequency (Annual)</Label>
              <Input 
                type="number" 
                className="h-12 text-lg font-mono"
                value={fairData.threatFreq}
                onChange={e => setFairData(p => ({...p, threatFreq: parseFloat(e.target.value) || 0}))}
                disabled={readOnly || !isHighRisk}
              />
              <p className="text-xs text-slate-500 flex items-center gap-1">
                 <Info className="w-3 h-3" /> Estimated number of threat events per year.
              </p>
            </div>
            <div className="space-y-3">
              <Label className="text-base">Vulnerability Impact (%)</Label>
              <Input 
                type="number" 
                max={100}
                className="h-12 text-lg font-mono"
                value={fairData.vulnImpact}
                onChange={e => setFairData(p => ({...p, vulnImpact: parseFloat(e.target.value) || 0}))}
                disabled={readOnly || !isHighRisk}
              />
              <p className="text-xs text-slate-500 flex items-center gap-1">
                 <Info className="w-3 h-3" /> Average loss magnitude (%) per event.
              </p>
            </div>
          </div>

          <div className="mt-8 p-8 bg-slate-900 text-white rounded-xl flex items-center justify-between relative overflow-hidden group">
             <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
                 <Calculator className="w-32 h-32 text-white" />
             </div>
             
             <div className="relative z-10">
               <p className="text-emerald-400 text-sm font-bold uppercase tracking-widest mb-1">Projected Annual Impact</p>
               <h3 className="text-2xl font-bold text-white">Annual Loss Expectancy (ALE)</h3>
               <p className="text-slate-400 text-xs mt-2 font-mono opacity-70">Formula: (Asset Value × Frequency × Impact%) / 100</p>
             </div>
             <div className="text-5xl font-mono font-bold tracking-tight text-emerald-400 relative z-10 drop-shadow-lg">
               {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(ale)}
             </div>
          </div>
        </CardContent>
      </Card>

      {!readOnly && (
        <div className="flex justify-end pt-4 border-t">
          <Button onClick={handleSave} size="lg" className="px-8 h-12 text-lg bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-900/20">
            Proceed to Risk Questionnaire <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  );
};

export default InherentRiskAssessment;
