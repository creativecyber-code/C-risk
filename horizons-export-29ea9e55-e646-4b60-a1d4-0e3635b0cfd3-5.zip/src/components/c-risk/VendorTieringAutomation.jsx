
import React from 'react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

const VendorTieringAutomation = ({ onVendorStatusChange }) => {
  const handleToggle = (checked) => {
    onVendorStatusChange({ status: checked ? 'Active' : null });
  };

  return (
    <div className="flex items-center space-x-2">
      <Switch id="vendor-mode" onCheckedChange={handleToggle} />
      <Label htmlFor="vendor-mode">Third-Party Vendor Involved?</Label>
    </div>
  );
};

export default VendorTieringAutomation;
