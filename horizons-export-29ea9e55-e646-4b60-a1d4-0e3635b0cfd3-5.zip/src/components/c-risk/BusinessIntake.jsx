
import React, { useState, useEffect } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { AlertCircle, Search, Check, ArrowRight, Loader2, Info, RefreshCcw, LayoutTemplate, ShieldAlert, Building2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { cRiskService } from '@/services/cRiskService';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';

const BusinessIntake = ({ onSave, userOrgId }) => {
  const [scenarios, setScenarios] = useState([]);
  const [loadingScenarios, setLoadingScenarios] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedScenario, setSelectedScenario] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const { register, control, handleSubmit, setValue, watch, formState: { errors } } = useForm({
    defaultValues: {
      name: '',
      type: '',
      business_unit: '',
      description: '',
      hosting_type: 'cloud',
      internet_facing: false,
      vendor_involved: false,
      data_tags: [],
      inherent_risk_rating: 'Low',
      // Accountability (RACI)
      business_owner: '',
      technical_owner: '',
      data_owner: '',
      infosec_contact: '',
      infosec_involved: false,
      rfp_ready: false,
    }
  });

  const fetchScenarios = async () => {
    setLoadingScenarios(true);
    try {
      const data = await cRiskService.getScenarioLibrary();
      if (data && data.length > 0) {
        setScenarios(data);
      } else {
        setScenarios([]); 
      }
    } catch (error) {
      console.error("BusinessIntake: Failed to load scenarios", error);
      toast({
         title: "Error loading catalog",
         description: "Could not fetch business scenarios. Please try refreshing.",
         variant: "destructive"
      });
      setScenarios([]);
    } finally {
      setLoadingScenarios(false);
    }
  };

  useEffect(() => {
    fetchScenarios();
  }, []);

  const handleScenarioSelect = (scenario) => {
    // 1. Set Selected Scenario State
    setSelectedScenario(scenario);
    
    // 2. Map Risk Level using service helper
    // Mapping rules from prompt: Low->Low, Medium->Medium, High->High, Critical->Very High
    let mappedRisk = 'Low';
    if (scenario.risk_level === 'Critical') mappedRisk = 'Critical'; // Prompt said 'Very High', but standardizing on 'Critical' for UI consistency unless 'Very High' is required by schema.
    else if (scenario.risk_level === 'High') mappedRisk = 'High';
    else if (scenario.risk_level === 'Medium') mappedRisk = 'Medium';
    
    // 3. Pre-fill Form Fields
    setValue('name', scenario.title);
    setValue('description', scenario.description || '');
    setValue('business_unit', scenario.business_unit || '');
    setValue('type', scenario.type ? scenario.type.toLowerCase().replace(/\s+/g, '') : 'webapp');
    
    // Auto-select hosting if inferred from scenario type or description (simplified logic)
    // In a real app, scenario table would have 'default_hosting' column
    if (scenario.title.toLowerCase().includes('saas') || scenario.type === 'Vendor') {
       setValue('hosting_type', 'saas');
       setValue('vendor_involved', true);
    } else {
       setValue('hosting_type', 'cloud');
       setValue('vendor_involved', false);
    }

    // Default internet facing if webapp
    if (scenario.type === 'Web Application' || scenario.type === 'API') {
       setValue('internet_facing', true);
    } else {
       setValue('internet_facing', false);
    }

    setValue('data_tags', scenario.compliance_tags || []);
    setValue('inherent_risk_rating', mappedRisk);
    
    // Explicitly set the hidden scenario_id value if needed later, though we pass it via selectedScenario obj
  };

  const filteredScenarios = scenarios.filter(s => {
    const term = searchTerm.toLowerCase();
    return (
       (s.title && s.title.toLowerCase().includes(term)) || 
       (s.description && s.description.toLowerCase().includes(term)) ||
       (s.category && s.category.toLowerCase().includes(term))
    );
  });

  const getRiskBadgeColor = (level) => {
    switch (level?.toLowerCase()) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-green-100 text-green-800 border-green-200';
    }
  };

  const onSubmit = async (data) => {
    setIsSubmitting(true);
    try {
      const finalScenarioId = selectedScenario?.scenario_id || null;
      
      await onSave({
        ...data,
        scenario_id: finalScenarioId
      });
    } catch (error) {
      console.error(error);
      toast({ title: "Submission failed", description: error.message, variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Scenario Catalog (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
           <Card className="h-[calc(100vh-200px)] min-h-[600px] border-slate-200 shadow-sm flex flex-col">
              <CardHeader className="pb-3 bg-slate-50 border-b">
                 <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-2">
                       <LayoutTemplate className="h-4 w-4" /> Scenario Catalog
                    </CardTitle>
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={fetchScenarios} title="Reload Catalog">
                       <RefreshCcw className={`h-3 w-3 ${loadingScenarios ? 'animate-spin' : ''}`} />
                    </Button>
                 </div>
                 <div className="relative mt-3">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-slate-400" />
                    <Input 
                      placeholder="Search by title, category..." 
                      className="pl-8 h-9 text-sm bg-white" 
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                 </div>
              </CardHeader>
              <CardContent className="p-0 flex-1 overflow-hidden">
                 <ScrollArea className="h-full">
                    <div className="divide-y divide-slate-100">
                       {loadingScenarios ? (
                          <div className="p-8 text-center text-sm text-slate-500 flex flex-col items-center justify-center gap-3 h-64">
                             <Loader2 className="h-8 w-8 animate-spin text-blue-500" /> 
                             <span>Loading Library...</span>
                          </div>
                       ) : filteredScenarios.length === 0 ? (
                          <div className="p-8 text-center text-sm text-slate-400 flex flex-col items-center gap-2">
                             <AlertCircle className="h-8 w-8 text-slate-300" />
                             <span>No scenarios found.</span>
                             <Button variant="link" onClick={() => setSearchTerm('')} className="text-blue-500">Clear Filters</Button>
                          </div>
                       ) : (
                          filteredScenarios.map((scenario) => (
                             <button
                                key={scenario.scenario_id || scenario.id}
                                type="button"
                                onClick={() => handleScenarioSelect(scenario)}
                                className={cn(
                                   "text-left p-4 w-full transition-all hover:bg-slate-50 focus:outline-none focus:bg-slate-50",
                                   selectedScenario?.scenario_id === scenario.scenario_id 
                                     ? "bg-blue-50/60 border-l-4 border-l-blue-600 shadow-inner" 
                                     : "border-l-4 border-l-transparent"
                                )}
                             >
                                <div className="flex justify-between items-start mb-2">
                                   <div className="space-y-1 pr-2">
                                      <h4 className="font-semibold text-sm text-slate-900 leading-snug">
                                        {scenario.title}
                                      </h4>
                                      <div className="flex flex-wrap gap-1.5">
                                         <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-600 border border-slate-200">
                                            {scenario.category}
                                         </span>
                                         <span className={cn("inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium border", getRiskBadgeColor(scenario.risk_level))}>
                                            {scenario.risk_level} Risk
                                         </span>
                                      </div>
                                   </div>
                                   {selectedScenario?.scenario_id === scenario.scenario_id && (
                                      <div className="h-5 w-5 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm">
                                         <Check className="h-3 w-3 text-white" />
                                      </div>
                                   )}
                                </div>
                                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                                   {scenario.description}
                                </p>
                             </button>
                          ))
                       )}
                    </div>
                 </ScrollArea>
              </CardContent>
           </Card>
        </div>

        {/* Right Column: Detailed Form (8 cols) */}
        <div className="lg:col-span-8">
           <form onSubmit={handleSubmit(onSubmit)} className="h-full">
              <Card className="border-t-4 border-t-blue-600 shadow-md h-full flex flex-col">
                 <CardHeader className="border-b bg-white pb-6">
                    <div className="flex justify-between items-start">
                       <div>
                          <CardTitle className="text-xl">Initiative Details</CardTitle>
                          <CardDescription className="mt-1">
                             Configure the business and technical context for your new initiative.
                          </CardDescription>
                       </div>
                    </div>
                    
                    {/* Selected Scenario Summary Card */}
                    {selectedScenario && (
                       <div className="mt-4 p-4 bg-blue-50/50 rounded-lg border border-blue-100 animate-in fade-in slide-in-from-top-2 duration-300">
                          <div className="flex items-start gap-3">
                             <div className="p-2 bg-white rounded-md shadow-sm border border-blue-100">
                                <ShieldAlert className="h-5 w-5 text-blue-600" />
                             </div>
                             <div className="flex-1">
                                <h4 className="text-sm font-semibold text-blue-900">
                                   Applying Scenario: {selectedScenario.title}
                                </h4>
                                <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-4">
                                   <div>
                                      <span className="text-xs text-slate-500 uppercase tracking-wide block">Category</span>
                                      <span className="text-sm font-medium text-slate-700">{selectedScenario.category}</span>
                                   </div>
                                   <div>
                                      <span className="text-xs text-slate-500 uppercase tracking-wide block">Risk Level</span>
                                      <Badge variant="outline" className={cn("mt-0.5 font-normal", getRiskBadgeColor(selectedScenario.risk_level))}>
                                         {selectedScenario.risk_level}
                                      </Badge>
                                   </div>
                                   <div>
                                      <span className="text-xs text-slate-500 uppercase tracking-wide block">Type</span>
                                      <span className="text-sm font-medium text-slate-700">{selectedScenario.type || 'N/A'}</span>
                                   </div>
                                   <div>
                                      <span className="text-xs text-slate-500 uppercase tracking-wide block">Business Unit</span>
                                      <span className="text-sm font-medium text-slate-700">{selectedScenario.business_unit || 'N/A'}</span>
                                   </div>
                                </div>
                             </div>
                          </div>
                       </div>
                    )}
                 </CardHeader>
                 
                 <CardContent className="flex-1 overflow-y-auto p-6 space-y-8">
                    
                    {/* Section 1: Core Details */}
                    <div className="space-y-4">
                       <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                          <span className="bg-slate-100 text-slate-600 h-6 w-6 rounded-full flex items-center justify-center text-xs">1</span>
                          General Information
                       </h3>
                       
                       <div className="grid gap-5 pl-8">
                          <div className="grid gap-2">
                             <Label htmlFor="name">Initiative Name <span className="text-red-500">*</span></Label>
                             <Input id="name" {...register('name', { required: true })} placeholder="e.g. Customer Portal 2.0" className="max-w-xl" />
                             {errors.name && <span className="text-xs text-red-500">Name is required</span>}
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-3xl">
                             <div className="grid gap-2">
                                <Label htmlFor="type">Application Type <span className="text-red-500">*</span></Label>
                                <Controller
                                   name="type"
                                   control={control}
                                   rules={{ required: true }}
                                   render={({ field }) => (
                                      <Select onValueChange={field.onChange} value={field.value || undefined}>
                                         <SelectTrigger>
                                            <SelectValue placeholder="Select type" />
                                         </SelectTrigger>
                                         <SelectContent>
                                            <SelectItem value="webapp">Web Application</SelectItem>
                                            <SelectItem value="mobile">Mobile App</SelectItem>
                                            <SelectItem value="api">API / Microservice</SelectItem>
                                            <SelectItem value="desktop">Desktop Application</SelectItem>
                                            <SelectItem value="infrastructure">Infrastructure / Network</SelectItem>
                                            <SelectItem value="process">Business Process</SelectItem>
                                            <SelectItem value="vendor">Vendor / SaaS</SelectItem>
                                            <SelectItem value="core">Core Banking</SelectItem>
                                         </SelectContent>
                                      </Select>
                                   )}
                                />
                                {errors.type && <span className="text-xs text-red-500">Type is required</span>}
                             </div>
                             
                             <div className="grid gap-2">
                                <Label htmlFor="business_unit">Business Unit</Label>
                                <div className="relative">
                                   <Building2 className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                                   <Input id="business_unit" {...register('business_unit')} placeholder="e.g. Retail Banking" className="pl-9" />
                                </div>
                             </div>
                          </div>

                          <div className="grid gap-2 max-w-3xl">
                             <Label htmlFor="description">Description & Purpose</Label>
                             <Textarea 
                                id="description" 
                                {...register('description')} 
                                placeholder="Describe the business goal, key features, and intended user base..." 
                                className="h-24 resize-none"
                             />
                          </div>
                       </div>
                    </div>

                    <Separator />

                    {/* Section 2: Technical Context */}
                    <div className="space-y-4">
                       <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                          <span className="bg-slate-100 text-slate-600 h-6 w-6 rounded-full flex items-center justify-center text-xs">2</span>
                          Technical Context
                       </h3>
                       
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pl-8 max-w-4xl">
                          <div className="space-y-4">
                             <div className="grid gap-2">
                                <Label htmlFor="hosting">Hosting Model</Label>
                                <Controller
                                   name="hosting_type"
                                   control={control}
                                   render={({ field }) => (
                                      <Select onValueChange={field.onChange} value={field.value || 'cloud'}>
                                         <SelectTrigger>
                                            <SelectValue placeholder="Select hosting" />
                                         </SelectTrigger>
                                         <SelectContent>
                                            <SelectItem value="cloud">Public Cloud (AWS/Azure/GCP)</SelectItem>
                                            <SelectItem value="onprem">On-Premise DC</SelectItem>
                                            <SelectItem value="hybrid">Hybrid Cloud</SelectItem>
                                            <SelectItem value="saas">SaaS (Vendor Hosted)</SelectItem>
                                         </SelectContent>
                                      </Select>
                                   )}
                                />
                             </div>
                          </div>

                          <div className="space-y-3 pt-1">
                             <div className="flex items-start space-x-3 p-3 rounded-md border border-slate-200 bg-slate-50/50">
                                <Checkbox 
                                  id="internet_facing" 
                                  checked={watch('internet_facing')}
                                  onCheckedChange={(c) => setValue('internet_facing', c)} 
                                  className="mt-0.5"
                                />
                                <div className="space-y-1">
                                   <Label htmlFor="internet_facing" className="font-medium cursor-pointer">Internet Facing?</Label>
                                   <p className="text-xs text-slate-500">Accessible from public internet without VPN</p>
                                </div>
                             </div>
                             <div className="flex items-start space-x-3 p-3 rounded-md border border-slate-200 bg-slate-50/50">
                                <Checkbox 
                                  id="vendor_involved" 
                                  checked={watch('vendor_involved')}
                                  onCheckedChange={(c) => setValue('vendor_involved', c)} 
                                  className="mt-0.5"
                                />
                                <div className="space-y-1">
                                   <Label htmlFor="vendor_involved" className="font-medium cursor-pointer">Vendor / Third-Party?</Label>
                                   <p className="text-xs text-slate-500">Development or hosting by external party</p>
                                </div>
                             </div>
                          </div>
                       </div>
                    </div>

                    <Separator />
                       
                    {/* Section 3: Accountability */}
                    <div className="space-y-4">
                       <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                          <span className="bg-slate-100 text-slate-600 h-6 w-6 rounded-full flex items-center justify-center text-xs">3</span>
                          Ownership (RACI)
                       </h3>
                       
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-8 max-w-4xl">
                          <div className="grid gap-2">
                             <Label>Business Owner</Label>
                             <Input {...register('business_owner')} placeholder="Name or Email" />
                          </div>
                          <div className="grid gap-2">
                             <Label>Technical Owner</Label>
                             <Input {...register('technical_owner')} placeholder="Name or Email" />
                          </div>
                          <div className="grid gap-2">
                             <Label>Data Owner</Label>
                             <Input {...register('data_owner')} placeholder="Name or Email" />
                          </div>
                          <div className="grid gap-2">
                             <Label>InfoSec Contact</Label>
                             <Input {...register('infosec_contact')} placeholder="Security SPOC" />
                          </div>
                       </div>
                    </div>

                 </CardContent>
                 
                 <div className="p-6 bg-slate-50 border-t flex justify-between items-center">
                    <div className="text-xs text-slate-500">
                       {selectedScenario ? (
                          <span className="flex items-center gap-1.5">
                             <Check className="h-3 w-3 text-green-600" />
                             Scenario linked: <strong>{selectedScenario.scenario_id}</strong>
                          </span>
                       ) : (
                          <span>No scenario linked (Manual Entry)</span>
                       )}
                    </div>
                    <Button type="submit" className="bg-blue-600 hover:bg-blue-700 min-w-[140px]" disabled={isSubmitting}>
                       {isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <>Next Step <ArrowRight className="ml-2 h-4 w-4" /></>}
                    </Button>
                 </div>
              </Card>
           </form>
        </div>

      </div>
    </div>
  );
};

export default BusinessIntake;
