
import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { cRiskService } from '@/services/cRiskService';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { AlertTriangle, CheckCircle2, DollarSign, Activity, FileText, ArrowRight } from 'lucide-react';
import { formatCurrency } from '@/utils/exportUtils';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';

const ConditionalWorkflows = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [data, setData] = useState(null);

  useEffect(() => {
    // Immediate state check to prevent flicker
    if (!user?.user_metadata?.org_id) return;
    
    let isMounted = true;

    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Optimistic UI: We don't block render. Loading state handles Skeletons.
        const stats = await cRiskService.getPortfolioSummary(user.user_metadata.org_id);
        
        if (isMounted) {
          setData(stats);
          setLoading(false);
        }
      } catch (err) {
        console.error("Dashboard Fetch Error:", err);
        if (isMounted) {
          setError("Failed to load portfolio data.");
          setLoading(false);
        }
      }
    };

    fetchDashboardData();

    return () => { isMounted = false; };
  }, [user]);

  // If we have an error, show it but keep the structure
  if (error) {
    return (
      <Alert variant="destructive" className="mb-6">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription className="flex items-center gap-2">
          {error}
          <Button variant="outline" size="sm" onClick={() => window.location.reload()} className="h-7 px-2 bg-white/50">Retry</Button>
        </AlertDescription>
      </Alert>
    );
  }

  // Initial Empty State (No Data but not Loading)
  if (!loading && (!data || data.totalApps === 0)) {
    return (
      <Card className="bg-slate-50 border-dashed animate-in fade-in duration-500">
        <CardContent className="flex flex-col items-center justify-center h-64 text-center">
          <FileText className="w-12 h-12 text-slate-300 mb-4" />
          <h3 className="text-lg font-medium text-slate-900">No Initiatives Found</h3>
          <p className="text-slate-500 mb-4 max-w-sm">
            Get started by registering a new business application or technology initiative.
          </p>
          <Button>Create First Initiative <ArrowRight className="ml-2 h-4 w-4" /></Button>
        </CardContent>
      </Card>
    );
  }

  // --- Render with Skeletons if loading ---
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard 
          loading={loading}
          title="Total Initiatives" 
          value={data?.totalApps} 
          icon={<FileText className="w-5 h-5" />} 
          color="blue"
        />
        <KpiCard 
          loading={loading}
          title="High/Critical Risk" 
          value={data?.highRiskCount} 
          icon={<AlertTriangle className="w-5 h-5" />} 
          color="red"
        />
        <KpiCard 
          loading={loading}
          title="Portfolio Exposure (ALE)" 
          value={data ? formatCurrency(data.totalALE) : null} 
          icon={<DollarSign className="w-5 h-5" />} 
          color="emerald"
          subtitle="Annualized Loss Expectancy"
        />
        <KpiCard 
          loading={loading}
          title="Pending Approval" 
          value={data?.pendingApproval} 
          icon={<Activity className="w-5 h-5" />} 
          color="orange"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Risk Distribution Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Risk Distribution</CardTitle>
            <CardDescription>Initiatives by Inherent Risk Level</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            {loading ? (
              <div className="flex items-center justify-center h-full">
                <Skeleton className="h-[200px] w-[200px] rounded-full" />
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data.riskDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {data.riskDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend verticalAlign="bottom" height={36} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Recent Activity List */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recent Initiatives</CardTitle>
            <CardDescription>Latest applications entering the pipeline</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {loading ? (
                Array(4).fill(0).map((_, i) => (
                  <div key={i} className="flex items-center space-x-4">
                    <Skeleton className="h-12 w-2 rounded-full" />
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-4 w-[200px]" />
                      <Skeleton className="h-3 w-[150px]" />
                    </div>
                  </div>
                ))
              ) : (
                data.recentApps.map((app) => (
                  <div key={app.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-slate-50 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-10 rounded-full ${
                        app.inherent_risk_level === 'Critical' ? 'bg-red-500' :
                        app.inherent_risk_level === 'High' ? 'bg-orange-500' :
                        app.inherent_risk_level === 'Medium' ? 'bg-yellow-500' :
                        'bg-green-500'
                      }`} />
                      <div>
                        <h4 className="font-medium text-sm text-slate-900">{app.name}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-slate-500">Stage: {app.stage || 'Intake'}</span>
                          <span className="text-[10px] px-1.5 py-0.5 bg-slate-100 rounded text-slate-600 border border-slate-200">
                            {new Date(app.updated_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                        app.status === 'Approved' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {app.status}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Regulatory Readiness View */}
      <Card className="bg-gradient-to-r from-slate-900 to-slate-800 text-white border-0">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-green-400" />
            Regulatory Readiness Status
          </CardTitle>
          <CardDescription className="text-slate-300">
            Automated gap analysis against RBI Master Directions & DPDP Act 2023
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div className="p-4 bg-white/10 rounded-lg backdrop-blur-sm">
              {loading ? <Skeleton className="h-8 w-16 mx-auto bg-slate-700" /> : (
                <div className="text-3xl font-bold text-green-400 mb-1">
                  {Math.round((data.recentApps.filter(a => a.status === 'Approved').length / (data.totalApps || 1)) * 100)}%
                </div>
              )}
              <div className="text-sm text-slate-300 mt-2">Overall Compliance Score</div>
            </div>
            <div className="p-4 bg-white/10 rounded-lg backdrop-blur-sm">
               {loading ? <Skeleton className="h-8 w-16 mx-auto bg-slate-700" /> : (
                <div className="text-3xl font-bold text-blue-400 mb-1">
                  {data.recentApps.filter(a => a.stage === 'INTAKE').length}
                </div>
               )}
              <div className="text-sm text-slate-300 mt-2">New Intakes (Needs Mapping)</div>
            </div>
            <div className="p-4 bg-white/10 rounded-lg backdrop-blur-sm">
               {loading ? <Skeleton className="h-8 w-16 mx-auto bg-slate-700" /> : (
                <div className="text-3xl font-bold text-orange-400 mb-1">
                  {data.highRiskCount}
                </div>
               )}
              <div className="text-sm text-slate-300 mt-2">DPIA Required (High Risk)</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const KpiCard = ({ loading, title, value, icon, color, subtitle }) => (
  <Card className={`border-l-4 border-l-${color}-500 shadow-sm`}>
    <CardContent className="pt-6">
      <div className="flex justify-between items-start">
        <div className="w-full">
          <p className="text-sm font-medium text-slate-500">{title}</p>
          {loading ? (
             <Skeleton className="h-8 w-24 mt-1" />
          ) : (
             <h3 className="text-3xl font-bold text-slate-900 truncate">{value}</h3>
          )}
        </div>
        <div className={`p-2 bg-${color}-50 rounded-lg text-${color}-600`}>
          {icon}
        </div>
      </div>
      {subtitle && !loading && <p className="text-xs text-slate-400 mt-2">{subtitle}</p>}
    </CardContent>
  </Card>
);

export default ConditionalWorkflows;
