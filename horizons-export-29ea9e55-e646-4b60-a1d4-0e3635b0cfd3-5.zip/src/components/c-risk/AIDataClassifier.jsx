
import React, { useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Sparkles } from 'lucide-react';

const AIDataClassifier = ({ textContext, onClassificationChange }) => {
  
  useEffect(() => {
    if (!textContext) return;
    
    // Mock AI Analysis
    const keywords = [];
    const lowerText = textContext.toLowerCase();
    
    if (lowerText.includes('payment') || lowerText.includes('card') || lowerText.includes('upi')) {
      keywords.push('Financial Data');
    }
    if (lowerText.includes('email') || lowerText.includes('phone') || lowerText.includes('name')) {
      keywords.push('PII');
    }
    if (lowerText.includes('password') || lowerText.includes('secret')) {
      keywords.push('Credentials');
    }

    onClassificationChange({ keywords });
  }, [textContext, onClassificationChange]);

  if (!textContext) return null;

  return (
    <div className="mt-2 p-3 bg-indigo-50 rounded-md border border-indigo-100">
      <div className="flex items-center gap-2 mb-2">
        <Sparkles className="h-4 w-4 text-indigo-600" />
        <span className="text-xs font-semibold text-indigo-800">AI Suggested Classification</span>
      </div>
      <div className="flex flex-wrap gap-2">
        <Badge variant="secondary" className="bg-white">Analysis Active...</Badge>
      </div>
    </div>
  );
};

export default AIDataClassifier;
