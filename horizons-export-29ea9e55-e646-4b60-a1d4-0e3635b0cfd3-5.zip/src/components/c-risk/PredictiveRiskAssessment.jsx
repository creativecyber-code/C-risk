
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

const PredictiveRiskAssessment = ({ keywords = [], onRiskSelect, currentRiskLevel }) => {
  // Simple logic to determine risk based on keywords
  const riskScore = keywords.length * 30; 
  const calculatedLevel = riskScore > 70 ? 'High' : riskScore > 30 ? 'Medium' : 'Low';

  React.useEffect(() => {
    if (calculatedLevel !== currentRiskLevel) {
      onRiskSelect(calculatedLevel);
    }
  }, [calculatedLevel, currentRiskLevel, onRiskSelect]);

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">Predictive Risk Score</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Risk Level</span>
            <span className={`font-bold ${calculatedLevel === 'High' ? 'text-red-600' : 'text-blue-600'}`}>
              {calculatedLevel}
            </span>
          </div>
          <Progress value={Math.min(riskScore, 100)} className="h-2" />
          <p className="text-xs text-muted-foreground mt-2">
            Based on {keywords.length} identified risk factors.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default PredictiveRiskAssessment;
