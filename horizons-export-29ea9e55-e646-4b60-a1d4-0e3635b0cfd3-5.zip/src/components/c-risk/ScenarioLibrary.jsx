
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { bfsiScenarios } from '@/data/bfsiScenarios';
import { ShieldAlert, Info, CheckCircle } from 'lucide-react';

const ScenarioLibrary = ({ onSelectScenario }) => {
  const [selectedCategory, setSelectedCategory] = useState("Branch Operations");
  const [selectedScenarios, setSelectedScenarios] = useState([]);

  const categories = [
    "Branch Operations",
    "Assets/Lending",
    "Liabilities/Deposits",
    "Payments/High Risk",
    "Regulatory/Mandatory"
  ];

  const filteredScenarios = bfsiScenarios.filter(s => s.category === selectedCategory);

  const getRiskColor = (level) => {
    switch (level) {
      case 'Critical': return 'bg-red-100 text-red-700 border-red-200';
      case 'High': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'Medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default: return 'bg-green-100 text-green-700 border-green-200';
    }
  };

  const handleToggleScenario = (scenario) => {
    setSelectedScenarios(prev => {
      const exists = prev.find(s => s.id === scenario.id);
      if (exists) {
        return prev.filter(s => s.id !== scenario.id);
      } else {
        return [...prev, scenario];
      }
    });
  };

  const handleProceed = () => {
    // If multiple scenarios are selected, we might need to aggregate risk
    // For now, let's pass the first one as primary, or pass all.
    // The parent component expects a single object with scenario details or a list.
    // Based on requirements, let's assume we pass the highest risk one as the "primary" scenario
    // but include the list of all selected IDs.
    
    if (selectedScenarios.length === 0) return;

    // Find highest risk level
    const riskOrder = { 'Critical': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
    const highestRiskScenario = [...selectedScenarios].sort((a, b) => riskOrder[b.risk_level] - riskOrder[a.risk_level])[0];

    onSelectScenario({
      ...highestRiskScenario, // Use highest risk scenario as base template
      selected_scenario_ids: selectedScenarios.map(s => s.id),
      aggregated_risk_level: highestRiskScenario.risk_level // This is passed to parent, but parent must map it to DB field
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center bg-slate-50 p-3 rounded-lg border">
         <div className="text-sm font-medium text-slate-700">
           {selectedScenarios.length} scenarios selected
         </div>
         <Button size="sm" onClick={handleProceed} disabled={selectedScenarios.length === 0} className="bg-blue-600 hover:bg-blue-700 text-white">
           Proceed to Risk Assessment
         </Button>
      </div>

      <Tabs defaultValue="Branch Operations" value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
        <ScrollArea className="w-full whitespace-nowrap pb-2">
          <TabsList className="flex w-max space-x-2">
            {categories.map(cat => (
              <TabsTrigger key={cat} value={cat} className="px-4">
                {cat}
              </TabsTrigger>
            ))}
          </TabsList>
        </ScrollArea>
        
        <div className="mt-4">
           <ScrollArea className="h-[450px] pr-4">
             <div className="grid grid-cols-1 gap-4">
               {filteredScenarios.map((scenario) => {
                 const isSelected = selectedScenarios.some(s => s.id === scenario.id);
                 return (
                   <Card 
                     key={scenario.id} 
                     className={`cursor-pointer transition-colors border-l-4 ${isSelected ? 'border-l-blue-600 border-blue-200 bg-blue-50/50' : 'border-l-transparent hover:border-l-blue-400'}`}
                     onClick={() => handleToggleScenario(scenario)}
                   >
                     <CardHeader className="pb-2">
                       <div className="flex justify-between items-start">
                          <div className="flex items-start gap-3">
                              <Checkbox checked={isSelected} onCheckedChange={() => handleToggleScenario(scenario)} id={`chk-${scenario.id}`} />
                              <div>
                                  <CardTitle className="text-base font-semibold">{scenario.title}</CardTitle>
                                  <CardDescription className="text-xs mt-1">{scenario.description}</CardDescription>
                              </div>
                          </div>
                          <Badge variant="outline" className={`${getRiskColor(scenario.risk_level)} text-xs ml-2 shrink-0`}>
                              {scenario.risk_level} Risk
                          </Badge>
                       </div>
                     </CardHeader>
                     <CardContent>
                       <div className="flex flex-wrap gap-2 ml-7">
                          {scenario.compliance_tags.map(tag => (
                              <Badge key={tag} variant="secondary" className="text-[10px] bg-slate-100 text-slate-600 border-slate-200">
                                  {tag}
                              </Badge>
                          ))}
                       </div>
                       <div className="flex justify-between items-center mt-2 ml-7">
                          <span className="text-xs text-slate-400 font-mono">{scenario.business_unit}</span>
                       </div>
                     </CardContent>
                   </Card>
                 );
               })}
             </div>
           </ScrollArea>
        </div>
      </Tabs>
    </div>
  );
};

export default ScenarioLibrary;
