
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, AlertTriangle, ShieldAlert, ArrowRight, ShieldCheck, HelpCircle } from 'lucide-react';
import { riskQuestionnaires } from '@/data/riskQuestionnaires';

const DynamicRiskQuestionnaire = ({ riskLevel, onComplete, initialResponses, readOnly }) => {
  const [responses, setResponses] = useState(initialResponses || {});
  const [submitted, setSubmitted] = useState(false);

  // Debugging log for incoming props
  useEffect(() => {
    console.log("DynamicRiskQuestionnaire mounted with Risk Level:", riskLevel);
  }, [riskLevel]);

  useEffect(() => {
    if (initialResponses && Object.keys(initialResponses).length > 0) {
        setResponses(initialResponses);
        setSubmitted(true);
    }
  }, [initialResponses]);

  // Normalize risk level (Case Insensitive & Handle Nulls)
  const normalizeRisk = (level) => {
    if (!level) return 'Low'; // Default to Low if missing
    
    const strLevel = String(level).toUpperCase();
    
    if (['CRITICAL', 'VERY HIGH', 'SEVERE'].includes(strLevel)) return 'Critical';
    if (['HIGH'].includes(strLevel)) return 'High';
    if (['MEDIUM', 'MODERATE'].includes(strLevel)) return 'Medium';
    
    return 'Low';
  };

  const normalizedRiskLevel = normalizeRisk(riskLevel);

  // Handle Low Risk Scenario - Early Return
  if (normalizedRiskLevel === 'Low') {
    return (
      <Card className="border-l-4 border-l-green-500 bg-green-50/20">
        <CardHeader>
          <div className="flex items-center gap-2 text-green-700">
            <ShieldCheck className="h-8 w-8" />
            <CardTitle>Low Risk - Questionnaire Not Required</CardTitle>
          </div>
          <CardDescription>
            Based on your risk assessment ({riskLevel || 'Low'}), this initiative is classified as <strong>Low Risk</strong>. 
            No detailed risk control questionnaire is required at this stage.
          </CardDescription>
        </CardHeader>
        <CardFooter className="pt-4 border-t bg-white/50">
          {!readOnly && !submitted ? (
             <Button 
                className="bg-green-600 hover:bg-green-700 text-white"
                onClick={() => {
                   setSubmitted(true);
                   onComplete({ level: 'Low', status: 'Skipped', completedAt: new Date().toISOString() });
                }}
             >
                Confirm & Proceed to Security Gates <ArrowRight className="ml-2 h-4 w-4" />
             </Button>
          ) : (
             <div className="flex items-center text-green-700 font-medium">
                <CheckCircle2 className="h-4 w-4 mr-2" /> Low Risk Accepted
             </div>
          )}
        </CardFooter>
      </Card>
    );
  }

  const questionnaire = riskQuestionnaires[normalizedRiskLevel];

  // Fallback if mapping fails
  if (!questionnaire) {
      console.error("No questionnaire found for:", normalizedRiskLevel);
      return (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Configuration Error</AlertTitle>
          <AlertDescription>
            Could not load questionnaire for risk level: {normalizedRiskLevel}. 
            Please check system configuration.
          </AlertDescription>
        </Alert>
      );
  }

  const handleResponseChange = (questionId, value) => {
    if (readOnly || submitted) return;
    setResponses(prev => ({
      ...prev,
      [questionId]: value
    }));
  };

  const isComplete = questionnaire.questions.every(q => responses[q.id] !== undefined);

  const handleSubmit = () => {
    console.log("Submitting Questionnaire:", responses);
    setSubmitted(true);
    
    // Generate Summary
    const summary = {
      level: normalizedRiskLevel,
      totalQuestions: questionnaire.questions.length,
      yesCount: Object.values(responses).filter(v => v === 'Yes').length,
      noCount: Object.values(responses).filter(v => v === 'No').length,
      responses: responses,
      completedAt: new Date().toISOString()
    };

    onComplete(summary);
  };

  const getBorderColor = (level) => {
    switch (level) {
      case 'Critical': return 'border-red-500';
      case 'High': return 'border-orange-500';
      case 'Medium': return 'border-yellow-500';
      default: return 'border-green-500';
    }
  };

  const getBadgeVariant = (level) => {
    switch (level) {
      case 'Critical': return 'destructive';
      case 'High': return 'destructive'; 
      case 'Medium': return 'secondary'; 
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      <Alert className={`${getBorderColor(normalizedRiskLevel)} border-l-4 bg-slate-50`}>
        <ShieldAlert className={`h-5 w-5 ${
            normalizedRiskLevel === 'Critical' ? 'text-red-600' : 
            normalizedRiskLevel === 'High' ? 'text-orange-600' : 'text-yellow-600'
        }`} />
        <AlertTitle className="text-slate-900 font-semibold flex items-center gap-2">
          {questionnaire.title}
        </AlertTitle>
        <AlertDescription className="text-slate-600 mt-1">
          {questionnaire.description}
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
             <CardTitle className="text-lg">Risk Controls Checklist</CardTitle>
             <Badge variant={getBadgeVariant(normalizedRiskLevel)} className="text-xs">
                {questionnaire.questions.length} Questions
             </Badge>
          </div>
          <CardDescription>Please answer all questions honestly. Responses are audited.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {questionnaire.questions.map((q, index) => (
            <div key={q.id} className="p-4 rounded-lg border bg-slate-50/50 hover:bg-slate-50 transition-colors">
              <div className="flex flex-col md:flex-row justify-between gap-4">
                <div className="space-y-1 flex-1">
                   <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-slate-400 bg-slate-200 px-1.5 rounded">
                        {q.id}
                      </span>
                      <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-100">
                        {q.regulatory_driver}
                      </span>
                   </div>
                   <p className="font-medium text-slate-900 text-sm mt-1">{q.text}</p>
                </div>
                
                <div className="flex items-center gap-6 min-w-[140px]">
                  <RadioGroup 
                    value={responses[q.id]} 
                    onValueChange={(val) => handleResponseChange(q.id, val)}
                    className="flex items-center gap-4"
                    disabled={readOnly || submitted}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Yes" id={`${q.id}-yes`} />
                      <Label htmlFor={`${q.id}-yes`} className="cursor-pointer font-normal">Yes</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="No" id={`${q.id}-no`} />
                      <Label htmlFor={`${q.id}-no`} className="cursor-pointer font-normal">No</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
        <CardFooter className="bg-slate-50 p-4 border-t flex justify-end">
          {!readOnly && !submitted ? (
            <Button 
              onClick={handleSubmit} 
              disabled={!isComplete}
              className={`${normalizedRiskLevel === 'Critical' ? 'bg-red-600 hover:bg-red-700' : 'bg-slate-900'}`}
            >
              Submit Assessment <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          ) : (
             <div className="flex items-center text-green-600 font-medium text-sm">
                <CheckCircle2 className="h-4 w-4 mr-2" /> Assessment Completed
             </div>
          )}
        </CardFooter>
      </Card>
    </div>
  );
};

export default DynamicRiskQuestionnaire;
