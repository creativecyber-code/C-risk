
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ShieldCheck, Server, Lock, FileText, CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';

const RiskAssessmentSummary = ({ appData, questionnaireSummary }) => {
  if (!appData) return null;

  const getRiskColor = (level) => {
    switch(level) {
      case 'Critical': return 'text-red-600 bg-red-50 border-red-200';
      case 'High': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'Medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      default: return 'text-green-600 bg-green-50 border-green-200';
    }
  };

  const riskLevel = appData.inherent_risk_level || 'Medium';
  const responses = questionnaireSummary?.responses || {};

  const actionItems = [];
  if (riskLevel === 'Critical' || riskLevel === 'High') {
    actionItems.push({ team: 'Legal', item: 'Review DPDP Data Processing Agreement' });
    actionItems.push({ team: 'IT Security', item: 'Schedule VAPT & Architecture Review' });
  }
  if (responses['HR-02'] === 'No' || responses['CR-01'] === 'No') {
     actionItems.push({ team: 'Engineering', item: 'Remediate Encryption/Localization Gaps immediately' });
  }
  if (riskLevel === 'Medium') {
    actionItems.push({ team: 'IT Ops', item: 'Verify Backup & Restoration Procedures' });
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Project Details */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="h-4 w-4 text-blue-600" /> Project Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
             <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                   <p className="text-slate-500">Application Name</p>
                   <p className="font-semibold">{appData.name}</p>
                </div>
                <div>
                   <p className="text-slate-500">Business Unit</p>
                   <p className="font-semibold">{appData.business_unit}</p>
                </div>
                <div>
                   <p className="text-slate-500">Risk Category</p>
                   <Badge variant="outline" className={`${getRiskColor(riskLevel)}`}>
                      {riskLevel} Risk
                   </Badge>
                </div>
                <div>
                   <p className="text-slate-500">Scenario Type</p>
                   <p className="font-semibold">{appData.type}</p>
                </div>
             </div>
          </CardContent>
        </Card>

        {/* CISO Recommendation */}
        <Card>
          <CardHeader>
             <CardTitle className="text-base flex items-center gap-2">
               <ShieldCheck className="h-4 w-4 text-emerald-600" /> CISO Recommendation
             </CardTitle>
          </CardHeader>
          <CardContent>
             <div className="p-4 bg-slate-50 rounded border text-sm">
                {riskLevel === 'Critical' ? (
                   <p className="text-red-700 font-medium flex items-start gap-2">
                      <XCircle className="h-5 w-5 shrink-0" />
                      Strict Security Controls Required. Mandatory External Audit and CISO Sign-off before Go-Live. 
                      Ensure Data Localization.
                   </p>
                ) : riskLevel === 'High' ? (
                   <p className="text-orange-700 font-medium flex items-start gap-2">
                      <AlertTriangle className="h-5 w-5 shrink-0" />
                      Enhanced Due Diligence. Implement Encryption at Rest & Transit. 
                      Review Third-Party Access Controls.
                   </p>
                ) : (
                   <p className="text-green-700 font-medium flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 shrink-0" />
                      Standard Security Controls Apply. Proceed with Standard Operating Procedures.
                   </p>
                )}
             </div>
          </CardContent>
        </Card>
      </div>

      {/* Compliance Status Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
             <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                   <div className="p-2 bg-blue-50 rounded-lg text-blue-600"><Server className="h-5 w-5" /></div>
                   <div>
                      <p className="text-xs text-slate-500 font-medium uppercase">Hosting</p>
                      <p className="font-bold text-slate-900">
                         {responses['CR-01'] === 'Yes' ? 'India (Localized)' : 
                          responses['HR-04'] === 'Yes' ? 'Empanelled Cloud' : 'Review Required'}
                      </p>
                   </div>
                </div>
             </CardContent>
          </Card>
          <Card>
             <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                   <div className="p-2 bg-purple-50 rounded-lg text-purple-600"><Lock className="h-5 w-5" /></div>
                   <div>
                      <p className="text-xs text-slate-500 font-medium uppercase">Encryption</p>
                      <p className="font-bold text-slate-900">
                         {responses['HR-02'] === 'Yes' ? 'AES-256 Enabled' : 'Standard'}
                      </p>
                   </div>
                </div>
             </CardContent>
          </Card>
          <Card>
             <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                   <div className="p-2 bg-pink-50 rounded-lg text-pink-600"><FileText className="h-5 w-5" /></div>
                   <div>
                      <p className="text-xs text-slate-500 font-medium uppercase">DPDP Impact</p>
                      <p className="font-bold text-slate-900">
                         {responses['HR-01'] === 'Yes' ? 'High (PII Present)' : 'Low'}
                      </p>
                   </div>
                </div>
             </CardContent>
          </Card>
      </div>

      {/* Action Items */}
      <Card>
         <CardHeader>
            <CardTitle className="text-base">Remediation Action Items</CardTitle>
         </CardHeader>
         <CardContent>
            {actionItems.length > 0 ? (
               <ul className="space-y-3">
                  {actionItems.map((action, i) => (
                     <li key={i} className="flex items-center justify-between p-3 border rounded bg-slate-50">
                        <span className="text-sm font-medium text-slate-700">{action.item}</span>
                        <Badge variant="secondary">{action.team}</Badge>
                     </li>
                  ))}
               </ul>
            ) : (
               <p className="text-sm text-slate-500 italic">No critical remediation actions identified.</p>
            )}
         </CardContent>
      </Card>
    </div>
  );
};

export default RiskAssessmentSummary;
