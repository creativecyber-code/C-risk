
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, XCircle, Clock, AlertTriangle, FileText } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const WorkflowApprovals = ({ applicationId, currentStage = 'SECURITY_REVIEW', onApprove, onReject }) => {
  const { toast } = useToast();
  const [approvals, setApprovals] = useState([
    { id: 1, role: 'Team Lead', name: 'John Doe', status: 'APPROVED', date: '2024-01-15', comments: 'Technical feasibility confirmed.' },
    { id: 2, role: 'Business Owner', name: 'Jane Smith', status: 'APPROVED', date: '2024-01-16', comments: 'Budget approved.' },
    { id: 3, role: 'InfoSec', name: 'Pending Assignment', status: 'PENDING', date: null, sla_due: '2024-01-20' },
    { id: 4, role: 'CISO', name: 'Pending', status: 'LOCKED', date: null }
  ]);

  const handleAction = (action) => {
    if (action === 'approve') {
      setApprovals(prev => prev.map(a => a.role === 'InfoSec' ? { ...a, status: 'APPROVED', date: new Date().toISOString().split('T')[0], name: 'Current User' } : a));
      toast({ title: "Approved", description: "Workflow moved to next stage." });
      if (onApprove) onApprove();
    } else {
      toast({ title: "Rejected", description: "Application returned to draft." });
      if (onReject) onReject();
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-blue-600" />
              Approval Chain
            </CardTitle>
            <CardDescription>Multi-level approval workflow with SLA tracking.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {approvals.map((step, index) => (
                <div key={step.id} className="flex items-start gap-4 relative">
                  {index !== approvals.length - 1 && (
                    <div className="absolute left-5 top-10 bottom-[-24px] w-0.5 bg-slate-200" />
                  )}
                  
                  <div className={`p-2 rounded-full z-10 ${
                    step.status === 'APPROVED' ? 'bg-green-100 text-green-600' :
                    step.status === 'PENDING' ? 'bg-blue-100 text-blue-600' :
                    'bg-slate-100 text-slate-400'
                  }`}>
                    {step.status === 'APPROVED' ? <CheckCircle2 className="h-5 w-5" /> :
                     step.status === 'PENDING' ? <Clock className="h-5 w-5" /> :
                     <XCircle className="h-5 w-5" />}
                  </div>

                  <div className="flex-1 bg-slate-50 p-4 rounded-lg border">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-semibold text-sm">{step.role}</h4>
                        <p className="text-xs text-slate-500">{step.name}</p>
                      </div>
                      <Badge variant={
                        step.status === 'APPROVED' ? 'default' :
                        step.status === 'PENDING' ? 'secondary' : 'outline'
                      }>
                        {step.status}
                      </Badge>
                    </div>
                    
                    {step.comments && (
                      <p className="mt-2 text-sm text-slate-600 bg-white p-2 rounded border">
                        "{step.comments}"
                      </p>
                    )}

                    {step.status === 'PENDING' && step.sla_due && (
                      <div className="mt-2 flex items-center gap-2 text-xs text-amber-600 font-medium">
                        <AlertTriangle className="h-3 w-3" />
                        SLA Due: {step.sla_due}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Current Action</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                <p className="text-sm text-blue-800 font-medium mb-1">Pending Your Review</p>
                <p className="text-xs text-blue-600">As InfoSec Approver</p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" className="w-full border-red-200 text-red-700 hover:bg-red-50" onClick={() => handleAction('reject')}>
                  Reject
                </Button>
                <Button className="w-full bg-green-600 hover:bg-green-700" onClick={() => handleAction('approve')}>
                  Approve
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Budget Impact</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Est. Cost</span>
                  <span className="font-mono">$50,000</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Risk Exposure (ALE)</span>
                  <span className="font-mono text-red-600">$12,500</span>
                </div>
                <div className="pt-2 border-t flex justify-between font-medium">
                  <span>Total Risk-Adj.</span>
                  <span>$62,500</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default WorkflowApprovals;
