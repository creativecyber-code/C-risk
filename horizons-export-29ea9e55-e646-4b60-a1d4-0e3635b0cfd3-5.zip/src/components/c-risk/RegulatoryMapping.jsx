
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { CheckCircle2 } from 'lucide-react';

const RegulatoryMapping = ({ mappings = [] }) => {
  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>Applicable Compliance Controls</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Framework / Act</TableHead>
                <TableHead>Reference</TableHead>
                <TableHead>Requirement</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mappings.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                    No regulatory mappings triggered yet. Complete classification.
                  </TableCell>
                </TableRow>
              ) : (
                mappings.map((m, i) => (
                  <TableRow key={i}>
                    <TableCell className="font-medium">{m.act}</TableCell>
                    <TableCell className="font-mono text-xs">{m.section}</TableCell>
                    <TableCell className="text-sm text-slate-600">{m.requirement}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-slate-50 text-slate-600">
                        Pending Evidence
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))
              )}
              {/* Static examples if empty for demo */}
              {mappings.length === 0 && (
                <>
                  <TableRow>
                    <TableCell className="font-medium">RBI Master Direction</TableCell>
                    <TableCell className="font-mono text-xs">Para 4.1</TableCell>
                    <TableCell className="text-sm">Cyber Security Policy Approval</TableCell>
                    <TableCell><Badge className="bg-green-100 text-green-800 border-green-200">Compliant</Badge></TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">DPDP Act 2023</TableCell>
                    <TableCell className="font-mono text-xs">Section 9</TableCell>
                    <TableCell className="text-sm">Data Principal Consent Architecture</TableCell>
                    <TableCell><Badge variant="outline">Gap Identified</Badge></TableCell>
                  </TableRow>
                </>
              )}
            </TableBody>
          </Table>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default RegulatoryMapping;
