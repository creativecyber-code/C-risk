
import React from 'react';
import { Button } from '@/components/ui/button';
import { Upload } from 'lucide-react';

const DocumentParser = ({ onExtract }) => {
  const handleSimulateUpload = () => {
    // Simulate parsing a document
    onExtract({
      vendor_name: 'Acme Corp Solutions',
      hosting_location: 'AWS Mumbai (ap-south-1)',
      access_control: 'SSO via Okta'
    });
  };

  return (
    <div className="border-2 border-dashed border-slate-200 rounded-lg p-6 text-center hover:bg-slate-50 transition-colors">
      <Upload className="h-8 w-8 mx-auto text-slate-400 mb-2" />
      <h3 className="text-sm font-medium text-slate-900">Upload SOW or Architecture Doc</h3>
      <p className="text-xs text-slate-500 mt-1 mb-4">PDF, DOCX supported. AI will extract vendor & data details.</p>
      <Button variant="outline" size="sm" onClick={handleSimulateUpload}>
        Simulate Upload & Parse
      </Button>
    </div>
  );
};

export default DocumentParser;
