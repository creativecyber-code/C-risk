
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Database, Globe, Lock, AlertTriangle } from 'lucide-react';

const DataClassification = ({ initialData, onSave, readOnly }) => {
  const [dataTypes, setDataTypes] = useState(initialData?.dataTypes || []);
  const [residency, setResidency] = useState(initialData?.residency || 'India');
  const [classificationLevel, setClassificationLevel] = useState('Public');

  // Taxonomy Logic
  useEffect(() => {
    if (dataTypes.includes('biometric') || dataTypes.includes('financial') || dataTypes.includes('passwords')) {
      setClassificationLevel('Restricted');
    } else if (dataTypes.includes('pii') || dataTypes.includes('internal')) {
      setClassificationLevel('Confidential');
    } else if (dataTypes.includes('business')) {
      setClassificationLevel('Internal');
    } else {
      setClassificationLevel('Public');
    }
  }, [dataTypes]);

  const handleTypeToggle = (type) => {
    if (readOnly) return;
    setDataTypes(prev => prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]);
  };

  const handleSave = () => {
    onSave({
      dataTypes,
      residency,
      classificationLevel
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5 text-indigo-600" />
            Data Classification Taxonomy
          </CardTitle>
          <CardDescription>Categorize data sensitivity to automate security controls (DPDP/RBI compliant).</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <Label className="text-base font-semibold">Data Elements Involved</Label>
              <div className="space-y-2">
                {[
                  { id: 'public', label: 'Public Marketing Data' },
                  { id: 'business', label: 'Internal Business Logic / Code' },
                  { id: 'pii', label: 'PII (Name, Email, Mobile) - DPDP' },
                  { id: 'financial', label: 'Financial (Bank Account, UPI) - RBI' },
                  { id: 'biometric', label: 'Biometric / Aadhaar Data' },
                  { id: 'passwords', label: 'Secrets / Keys / Passwords' }
                ].map((item) => (
                  <div key={item.id} className="flex items-center space-x-2 border p-3 rounded hover:bg-slate-50">
                    <Checkbox 
                      id={item.id} 
                      checked={dataTypes.includes(item.id)}
                      onCheckedChange={() => handleTypeToggle(item.id)}
                      disabled={readOnly}
                    />
                    <Label htmlFor={item.id} className="cursor-pointer flex-1">{item.label}</Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-6">
              <div className="p-6 bg-slate-50 rounded-xl border text-center">
                <Label className="text-slate-500 uppercase text-xs tracking-wider">Calculated Classification</Label>
                <div className="mt-2 flex justify-center">
                  {classificationLevel === 'Restricted' && <Badge variant="destructive" className="text-lg px-4 py-1">Restricted</Badge>}
                  {classificationLevel === 'Confidential' && <Badge className="bg-orange-500 text-lg px-4 py-1">Confidential</Badge>}
                  {classificationLevel === 'Internal' && <Badge className="bg-blue-500 text-lg px-4 py-1">Internal</Badge>}
                  {classificationLevel === 'Public' && <Badge variant="outline" className="text-lg px-4 py-1">Public</Badge>}
                </div>
                <p className="mt-4 text-sm text-slate-600">
                  {classificationLevel === 'Restricted' && "Requires highest encryption, MFA enforcement, and audit logging."}
                  {classificationLevel === 'Confidential' && "Requires standard encryption and access controls."}
                  {classificationLevel === 'Internal' && "Authorized employees only."}
                </p>
              </div>

              <div className="space-y-3">
                <Label className="flex items-center gap-2">
                  <Globe className="h-4 w-4" /> Data Residency & Sovereignty
                </Label>
                <RadioGroup 
                  value={residency} 
                  onValueChange={readOnly ? undefined : setResidency}
                  className="grid grid-cols-1 gap-2"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="India" id="r-in" />
                    <Label htmlFor="r-in">India (Strict Localization)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Hybrid" id="r-hy" />
                    <Label htmlFor="r-hy">Hybrid (Mirroring Allowed)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Global" id="r-gl" />
                    <Label htmlFor="r-gl">Global / Cloud Native</Label>
                  </div>
                </RadioGroup>
              </div>
            </div>
          </div>

          {(dataTypes.includes('pii') || dataTypes.includes('biometric')) && (
            <Alert className="bg-amber-50 border-amber-200">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <AlertTitle className="text-amber-800">Automated Trigger: DPIA Required</AlertTitle>
              <AlertDescription className="text-amber-700">
                Selection of PII/Biometrics has triggered a mandatory Data Protection Impact Assessment (DPIA) under DPDP Act 2023.
              </AlertDescription>
            </Alert>
          )}

          {!readOnly && (
            <div className="flex justify-end">
              <Button onClick={handleSave} size="lg">Save & Assess Risks</Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default DataClassification;
