
import React, { useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle2, XCircle, Lock, AlertTriangle, ArrowRight } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const SecurityGating = ({ gates = [], onUpdateStatus, onDeploy, appId, validationState, riskLevel }) => {
  
  // Validation Logic
  const validations = useMemo(() => {
    // If Risk is Low, Questionnaire is NOT required.
    const isLowRisk = !['Critical', 'High', 'Medium', 'Severe', 'Very High'].includes(riskLevel);
    
    // Basic checks that are always required
    const checks = [
      { 
        id: 'val_dimensions', 
        label: 'Risk Dimensions (Qualitative)', 
        passed: validationState?.dimensionsCompleted || false 
      }
    ];

    // FAIR Assessment usually for > Low risk, but keeping it flexible based on validationState passed from parent
    if (!isLowRisk) {
        checks.push({
             id: 'val_fair', 
             label: 'FAIR Assessment (Quantitative)', 
             passed: validationState?.fairCompleted || false 
        });
    }

    // Questionnaire check - Conditional
    const questionnaireCheck = {
        id: 'val_questionnaire',
        label: isLowRisk ? 'Risk Questionnaire (Skipped for Low Risk)' : 'Risk Questionnaire',
        passed: isLowRisk ? true : (validationState?.questionnaireCompleted || false)
    };
    
    checks.push(questionnaireCheck);

    return checks;
  }, [validationState, riskLevel]);

  const allValidationsPassed = validations.every(v => v.passed);

  const getStatusColor = (status) => {
    switch(status) {
      case 'PASSED': return 'bg-green-100 text-green-700 border-green-200';
      case 'FAILED': return 'bg-red-100 text-red-700 border-red-200';
      case 'PENDING': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Pre-flight Validation Check */}
      <Card className="border-l-4 border-l-blue-600 shadow-sm">
         <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
               <CheckCircle2 className="h-5 w-5 text-blue-600" />
               Pre-Approval Validation Checks
            </CardTitle>
         </CardHeader>
         <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
               {validations.map(val => (
                  <div key={val.id} className={`p-4 rounded-lg border flex items-center gap-3 ${val.passed ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                     {val.passed ? (
                        <CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" />
                     ) : (
                        <XCircle className="h-5 w-5 text-red-600 shrink-0" />
                     )}
                     <div>
                        <p className={`text-sm font-semibold ${val.passed ? 'text-green-800' : 'text-red-800'}`}>
                           {val.label}
                        </p>
                        <p className="text-xs text-slate-500 mt-0.5">
                           {val.passed ? 'Completed' : 'Required'}
                        </p>
                     </div>
                  </div>
               ))}
            </div>
            
            {!allValidationsPassed && (
               <Alert variant="destructive" className="mt-4 bg-red-50 text-red-800 border-red-200">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Approval Blocked</AlertTitle>
                  <AlertDescription>
                     You cannot proceed with Security Gates until all Risk Assessment steps are completed.
                  </AlertDescription>
               </Alert>
            )}
         </CardContent>
      </Card>

      {/* Security Gates List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {gates.map((gate) => (
          <Card key={gate.id} className={`${gate.status === 'PASSED' ? 'opacity-70' : ''}`}>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                   {gate.is_blocking && <Lock className="h-4 w-4 text-slate-400" />}
                   <CardTitle className="text-base">{gate.gate_type.replace('_', ' ')} Review</CardTitle>
                </div>
                <Badge variant="outline" className={getStatusColor(gate.status)}>
                  {gate.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-slate-500 mb-4">
                 {gate.gate_type === 'CONTRACT' && "Legal review of vendor SOW and MSA."}
                 {gate.gate_type === 'ARCHITECTURE' && "Review of high-level design and data flow."}
                 {gate.gate_type === 'TPRM' && "Third-party vendor risk assessment."}
                 {gate.gate_type === 'APPSEC' && "SAST/DAST scan results and report."}
              </div>
              
              {gate.status !== 'PASSED' && (
                <div className="flex gap-2">
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="w-full border-green-200 hover:bg-green-50 text-green-700"
                    onClick={() => onUpdateStatus(gate.id, 'PASSED')}
                    disabled={!allValidationsPassed} // Block buttons if validation fails
                  >
                    Mark Passed
                  </Button>
                  <Button 
                     size="sm" 
                     variant="ghost" 
                     className="w-full text-red-600 hover:bg-red-50"
                     onClick={() => onUpdateStatus(gate.id, 'FAILED')}
                     disabled={!allValidationsPassed}
                  >
                    Fail
                  </Button>
                </div>
              )}
              {gate.status === 'PASSED' && (
                 <div className="text-xs text-green-600 font-medium flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3" /> Gate Cleared
                 </div>
              )}
            </CardContent>
          </Card>
        ))}
        {gates.length === 0 && (
           <div className="col-span-2 text-center py-12 text-slate-400 border-2 border-dashed rounded-xl">
              No security gates configured for this application type.
           </div>
        )}
      </div>

      <CardFooter className="bg-slate-900 text-white rounded-lg p-6 flex justify-between items-center">
        <div>
          <h4 className="font-semibold text-lg">Production Deployment</h4>
          <p className="text-slate-400 text-sm">All blocking gates must be passed to deploy.</p>
        </div>
        <Button 
          onClick={() => onDeploy(appId)} 
          disabled={!allValidationsPassed || gates.some(g => g.is_blocking && g.status !== 'PASSED')}
          className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold"
        >
          Approve for Go-Live <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </CardFooter>
    </div>
  );
};

export default SecurityGating;
