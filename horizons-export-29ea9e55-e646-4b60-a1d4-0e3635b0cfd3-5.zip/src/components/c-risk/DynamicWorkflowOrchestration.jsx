
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { CheckCircle2 } from 'lucide-react';

const DynamicWorkflowOrchestration = ({ riskLevel }) => {
  const steps = [
    { name: 'Business Intake', status: 'active' },
    { name: 'Data Classification', status: 'pending' },
    { name: 'Risk Assessment', status: 'pending' },
  ];

  if (riskLevel === 'High') {
    steps.push({ name: 'CISO Approval', status: 'pending' });
    steps.push({ name: 'External Audit', status: 'pending' });
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">Dynamic Workflow</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {steps.map((step, i) => (
            <div key={i} className="flex items-center gap-2 text-sm">
              <div className={`h-2 w-2 rounded-full ${step.status === 'active' ? 'bg-blue-500' : 'bg-slate-200'}`} />
              <span className={step.status === 'active' ? 'font-medium' : 'text-slate-500'}>
                {step.name}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default DynamicWorkflowOrchestration;
