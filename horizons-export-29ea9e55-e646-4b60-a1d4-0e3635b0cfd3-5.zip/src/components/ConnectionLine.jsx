
import React from 'react';

const ConnectionLine = ({ fromX, fromY, toX, toY, isThreatened = false }) => {
  // Calculate control points for curved line
  const dx = toX - fromX;
  const dy = toY - fromY;
  const controlX1 = fromX + dx * 0.5;
  const controlY1 = fromY;
  const controlX2 = fromX + dx * 0.5;
  const controlY2 = toY;

  const path = `M ${fromX} ${fromY} C ${controlX1} ${controlY1}, ${controlX2} ${controlY2}, ${toX} ${toY}`;

  // Calculate angle for arrowhead
  const angle = Math.atan2(toY - fromY, toX - fromX);
  const arrowLength = 12;
  const arrowWidth = 8;

  const arrowPoints = [
    [toX, toY],
    [
      toX - arrowLength * Math.cos(angle) + arrowWidth * Math.sin(angle),
      toY - arrowLength * Math.sin(angle) - arrowWidth * Math.cos(angle)
    ],
    [
      toX - arrowLength * Math.cos(angle) - arrowWidth * Math.sin(angle),
      toY - arrowLength * Math.sin(angle) + arrowWidth * Math.cos(angle)
    ]
  ].map(p => p.join(',')).join(' ');

  const strokeColor = isThreatened ? '#ef4444' : '#22c55e'; // Red for threat, Green for safe

  return (
    <g>
      <path
        d={path}
        stroke={strokeColor}
        strokeWidth='2'
        fill='none'
        strokeDasharray={isThreatened ? '0' : '5,5'} // Solid line for threat, dashed for normal
        className='transition-colors duration-300'
      />
      <polygon
        points={arrowPoints}
        fill={strokeColor}
        className='transition-colors duration-300'
      />
    </g>
  );
};

export default ConnectionLine;
