
import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2 } from 'lucide-react';

const ProtectedRoute = ({ children, allowedRole }) => {
  const { user, loading, userRole, mfaRequired } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
          <p className="text-sm text-slate-500 font-medium">Verifying Session...</p>
        </div>
      </div>
    );
  }

  // 1. Check User Existence
  if (!user) {
    // Redirect to login but save the attempted location
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // 2. Check MFA Status
  // If MFA is required but not yet verified, redirect to verification page
  if (mfaRequired) {
    return <Navigate to="/mfa-verify" replace />;
  }

  // 3. Check Role (Optional)
  // If the route has a specific allowedRole requirement
  if (allowedRole && allowedRole === 'tenant' && userRole === 'platform_staff') {
     // Platform staff shouldn't be in tenant routes usually, or handled differently
     // For now, we allow them or redirect to platform console
     return <Navigate to="/platform-console" replace />;
  }

  return children;
};

export default ProtectedRoute;
