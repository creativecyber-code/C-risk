
import React, { useState, useEffect, useRef } from 'react';
import { 
  Smartphone, Tablet, Monitor, RotateCw, X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

// Device Definitions
const DEVICES = [
  { id: 'iphone-se', name: 'iPhone SE', width: 375, height: 667, type: 'mobile', bezel: '4px' },
  { id: 'iphone-12', name: 'iPhone 12/13/14', width: 390, height: 844, type: 'mobile', bezel: '5px' },
  { id: 'pixel-7', name: 'Pixel 7', width: 412, height: 915, type: 'mobile', bezel: '3px' },
  { id: 'ipad-mini', name: 'iPad Mini', width: 768, height: 1024, type: 'tablet', bezel: '8px' },
  { id: 'ipad-air', name: 'iPad Air', width: 820, height: 1180, type: 'tablet', bezel: '8px' },
  { id: 'desktop-hd', name: 'Desktop HD', width: 1920, height: 1080, type: 'desktop', bezel: '12px' },
];

export function MobilePreviewSimulator() {
  const [isOpen, setIsOpen] = useState(false);
  const [isSimulated, setIsSimulated] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState(DEVICES[1]); 
  const [orientation, setOrientation] = useState('portrait'); 
  const [scale, setScale] = useState(100);
  const [iframeUrl, setIframeUrl] = useState('');
  const iframeRef = useRef(null);

  // 1. Check if we are currently running inside the simulation to avoid recursion
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('preview') === 'true') {
      setIsSimulated(true);
      document.body.classList.add('is-mobile-simulation');
      
      // Add touch cursor style for simulation safely
      if (!document.getElementById('mobile-sim-styles')) {
        const style = document.createElement('style');
        style.id = 'mobile-sim-styles';
        style.innerHTML = `
          * { cursor: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="rgba(0,0,0,0.3)" stroke="white" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>') 12 12, auto !important; }
          ::-webkit-scrollbar { width: 4px; }
          ::-webkit-scrollbar-track { background: transparent; }
          ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
        `;
        document.head.appendChild(style);
      }
    }
  }, []);

  // 2. Sync URL when opening simulator
  useEffect(() => {
    if (isOpen) {
      const currentUrl = new URL(window.location.href);
      currentUrl.searchParams.set('preview', 'true');
      setIframeUrl(currentUrl.toString());
    }
  }, [isOpen]);

  // If we are INSIDE the iframe, do not render the simulator controls
  if (isSimulated) return null;

  const handleDeviceChange = (deviceId) => {
    const device = DEVICES.find(d => d.id === deviceId);
    if (device) setSelectedDevice(device);
  };

  const toggleOrientation = () => {
    setOrientation(prev => prev === 'portrait' ? 'landscape' : 'portrait');
  };

  const displayWidth = orientation === 'portrait' ? selectedDevice.width : selectedDevice.height;
  const displayHeight = orientation === 'portrait' ? selectedDevice.height : selectedDevice.width;

  return (
    <>
      {/* Floating Toggle Button */}
      {!isOpen && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-4">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  onClick={() => setIsOpen(true)}
                  size="icon" 
                  className="h-14 w-14 rounded-full shadow-xl bg-slate-900 hover:bg-slate-800 text-white border-2 border-slate-700"
                >
                  <Smartphone className="h-6 w-6" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left">
                <p>Mobile Preview</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      )}

      {/* Main Simulator Overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-950/95 backdrop-blur-sm flex flex-col animate-in fade-in duration-200">
          
          {/* Toolbar */}
          <div className="flex items-center justify-between px-6 py-3 bg-slate-900 border-b border-slate-800 text-slate-100 shadow-md flex-none">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <span className="bg-blue-600 p-1.5 rounded-md"><Smartphone className="w-4 h-4 text-white" /></span>
                <span className="font-semibold tracking-tight">Device Simulator</span>
              </div>

              <div className="h-6 w-px bg-slate-700" />

              <div className="flex items-center gap-2">
                <label className="text-xs text-slate-400 font-medium uppercase">Device</label>
                <Select value={selectedDevice.id} onValueChange={handleDeviceChange}>
                  <SelectTrigger className="w-[180px] h-8 bg-slate-800 border-slate-700 text-slate-200 focus:ring-slate-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-slate-200">
                    {DEVICES.map(d => (
                      <SelectItem key={d.id} value={d.id} className="focus:bg-slate-700 focus:text-white">
                        <div className="flex items-center gap-2">
                          {d.type === 'mobile' && <Smartphone className="w-3 h-3" />}
                          {d.type === 'tablet' && <Tablet className="w-3 h-3" />}
                          {d.type === 'desktop' && <Monitor className="w-3 h-3" />}
                          {d.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center gap-2">
                 <label className="text-xs text-slate-400 font-medium uppercase">Orientation</label>
                 <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={toggleOrientation}
                    className="h-8 px-2 text-slate-300 hover:text-white hover:bg-slate-800"
                    title="Rotate Device"
                 >
                    <RotateCw className={cn("w-4 h-4 mr-2 transition-transform", orientation === 'landscape' && "rotate-90")} />
                    {orientation === 'portrait' ? 'Portrait' : 'Landscape'}
                 </Button>
              </div>

               <div className="flex items-center gap-2">
                 <label className="text-xs text-slate-400 font-medium uppercase">Scale</label>
                 <div className="flex items-center bg-slate-800 rounded-md border border-slate-700">
                    <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-slate-300 hover:text-white" onClick={() => setScale(s => Math.max(25, s - 10))}>-</Button>
                    <span className="w-10 text-center text-xs font-mono">{scale}%</span>
                    <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-slate-300 hover:text-white" onClick={() => setScale(s => Math.min(150, s + 10))}>+</Button>
                 </div>
                 <Button variant="ghost" size="sm" className="h-7 text-xs text-slate-400 hover:text-white" onClick={() => setScale(100)}>Reset</Button>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <Badge variant="outline" className="bg-slate-900 border-slate-700 text-slate-400 font-mono hidden md:flex">
                {displayWidth} x {displayHeight}
              </Badge>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setIsOpen(false)}
                className="h-8 w-8 text-slate-400 hover:text-white hover:bg-red-500/20 hover:text-red-400 rounded-full"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>

          <div className="flex-1 overflow-hidden relative bg-[url('https://grainy-gradients.vercel.app/noise.svg')] bg-slate-900/50 flex items-center justify-center p-8">
            <div 
              className="relative transition-all duration-500 ease-in-out shadow-2xl bg-black rounded-[3rem] border-slate-800"
              style={{
                width: `${displayWidth}px`,
                height: `${displayHeight}px`,
                transform: `scale(${scale / 100})`,
                borderWidth: selectedDevice.bezel,
                boxShadow: '0 0 0 2px #334155, 0 25px 50px -12px rgba(0, 0, 0, 0.75)'
              }}
            >
              {selectedDevice.type === 'mobile' && orientation === 'portrait' && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[24px] w-[120px] bg-black rounded-b-2xl z-20 flex justify-center items-center">
                  <div className="w-16 h-1 rounded-full bg-slate-900/50" />
                </div>
              )}

              <div className="w-full h-full bg-white rounded-[2.5rem] overflow-hidden relative">
                {iframeUrl && (
                  <iframe
                    ref={iframeRef}
                    src={iframeUrl}
                    title="Mobile Preview"
                    className="w-full h-full border-0 bg-white"
                    sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-modals"
                  />
                )}
              </div>
              
              <div className="absolute -right-[2px] top-[100px] w-[3px] h-[60px] bg-slate-700 rounded-r-md" />
              <div className="absolute -left-[2px] top-[80px] w-[3px] h-[40px] bg-slate-700 rounded-l-md" />
              <div className="absolute -left-[2px] top-[130px] w-[3px] h-[40px] bg-slate-700 rounded-l-md" />

            </div>
          </div>
        </div>
      )}
    </>
  );
}
