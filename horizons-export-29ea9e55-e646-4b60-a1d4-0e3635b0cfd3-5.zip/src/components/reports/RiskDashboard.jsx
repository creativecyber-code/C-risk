
import React from 'react';
import { 
  ScatterChart, Scatter, XAxis, YAxis, ZAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, Cell, ReferenceLine
} from 'recharts';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const RiskDashboard = ({ data }) => {
  if (!data) return <div>Loading...</div>;

  const { threats } = data;

  // Prepare Scatter Plot Data (Impact vs Likelihood)
  const scatterData = threats.map(t => ({
    ...t,
    x: t.likelihood,
    y: t.impact,
    z: 100 // Size of bubble
  }));

  const getColor = (impact, likelihood) => {
    const score = impact * likelihood;
    if (score > 60) return '#ef4444'; // Critical
    if (score > 30) return '#f97316'; // High
    if (score > 10) return '#eab308'; // Medium
    return '#3b82f6'; // Low
  };

  return (
    <div className="space-y-6">
      {/* Risk Matrix / Scatter Plot */}
      <Card>
        <CardHeader>
          <CardTitle>Risk Matrix Analysis</CardTitle>
          <CardDescription>Visualizing threats by Likelihood vs. Impact</CardDescription>
        </CardHeader>
        <CardContent className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" dataKey="x" name="Likelihood" domain={[0, 10]} label={{ value: 'Likelihood', position: 'bottom', offset: 0 }} />
              <YAxis type="number" dataKey="y" name="Impact" domain={[0, 10]} label={{ value: 'Impact', angle: -90, position: 'left' }} />
              <ZAxis type="number" dataKey="z" range={[60, 400]} />
              <RechartsTooltip cursor={{ strokeDasharray: '3 3' }} content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <div className="bg-white p-3 border border-slate-200 shadow-lg rounded-lg">
                      <p className="font-bold text-slate-800">{data.title}</p>
                      <p className="text-sm text-slate-500">Likelihood: {data.likelihood} | Impact: {data.impact}</p>
                      <p className="text-xs text-slate-400 mt-1">ID: {data.id}</p>
                    </div>
                  );
                }
                return null;
              }} />
              
              {/* Quadrant Lines */}
              <ReferenceLine x={5} stroke="#94a3b8" strokeDasharray="3 3" />
              <ReferenceLine y={5} stroke="#94a3b8" strokeDasharray="3 3" />

              <Scatter name="Threats" data={scatterData}>
                {scatterData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getColor(entry.impact, entry.likelihood)} />
                ))}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Detailed Threat Table */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed Threat Register</CardTitle>
          <CardDescription>Comprehensive list of identified risks and their metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Threat Title</TableHead>
                <TableHead>Asset</TableHead>
                <TableHead>Severity</TableHead>
                <TableHead>Likelihood</TableHead>
                <TableHead>Impact</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {threats.map((threat) => (
                <TableRow key={threat.id}>
                  <TableCell className="font-mono text-xs text-slate-500">{threat.id}</TableCell>
                  <TableCell className="font-medium text-slate-900">{threat.title}</TableCell>
                  <TableCell className="text-slate-600">{threat.asset}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={`
                      ${threat.severity === 'Critical' ? 'bg-red-50 text-red-700 border-red-200' :
                        threat.severity === 'High' ? 'bg-orange-50 text-orange-700 border-orange-200' :
                        threat.severity === 'Medium' ? 'bg-yellow-50 text-yellow-700 border-yellow-200' :
                        'bg-blue-50 text-blue-700 border-blue-200'}
                    `}>
                      {threat.severity}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">{threat.likelihood}</TableCell>
                  <TableCell className="text-center">{threat.impact}</TableCell>
                  <TableCell>
                    <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                      threat.status === 'Open' ? 'bg-slate-100 text-slate-600' :
                      threat.status === 'Mitigated' ? 'bg-green-100 text-green-700' :
                      'bg-amber-100 text-amber-700'
                    }`}>
                      {threat.status}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default RiskDashboard;
