
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Save, FileText, Download, LayoutTemplate } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { reportService } from '@/services/reportService';

const WIDGET_OPTIONS = [
  { id: 'executive_summary', label: 'Executive Summary Text' },
  { id: 'risk_score_card', label: 'Risk Score KPI' },
  { id: 'threat_severity_chart', label: 'Threat Severity Chart' },
  { id: 'compliance_matrix', label: 'Compliance Status Matrix' },
  { id: 'mitigation_status_pie', label: 'Mitigation Status Chart' },
  { id: 'top_risks_table', label: 'Top 5 Risks Table' },
  { id: 'risk_heatmap', label: 'Risk Heatmap' },
  { id: 'stride_chart', label: 'STRIDE Distribution' }
];

const CustomReportBuilder = ({ onSave }) => {
  const [reportName, setReportName] = useState('');
  const [selectedWidgets, setSelectedWidgets] = useState([]);
  const [layout, setLayout] = useState('single');
  const { toast } = useToast();

  const handleToggleWidget = (id) => {
    setSelectedWidgets(prev => 
      prev.includes(id) ? prev.filter(w => w !== id) : [...prev, id]
    );
  };

  const handleSaveTemplate = async () => {
    if (!reportName || selectedWidgets.length === 0) {
      toast({ title: "Incomplete Template", description: "Please name your report and select at least one widget.", variant: "destructive" });
      return;
    }
    
    try {
      await reportService.createTemplate(reportName, "Custom generated template", { widgets: selectedWidgets, layout });
      toast({ title: "Template Saved", description: "Your custom report template is ready." });
      setReportName('');
      setSelectedWidgets([]);
    } catch (e) {
      toast({ title: "Error saving template", variant: "destructive" });
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <Card className="border-2 border-dashed border-slate-200 bg-slate-50 min-h-[500px] flex flex-col items-center justify-center p-8">
           {selectedWidgets.length === 0 ? (
             <div className="text-center text-slate-400">
               <LayoutTemplate className="w-16 h-16 mx-auto mb-4 opacity-50" />
               <h3 className="text-lg font-medium">Canvas Empty</h3>
               <p className="text-sm">Select widgets from the right panel to build your report.</p>
             </div>
           ) : (
             <div className={`w-full grid gap-4 ${layout === 'grid' ? 'grid-cols-2' : 'grid-cols-1'}`}>
               {selectedWidgets.map(id => (
                 <div key={id} className="bg-white border rounded-lg p-6 shadow-sm flex items-center justify-between">
                   <span className="font-medium text-slate-700">{WIDGET_OPTIONS.find(w => w.id === id)?.label}</span>
                   <Button variant="ghost" size="sm" onClick={() => handleToggleWidget(id)} className="text-red-500 hover:text-red-700 h-8">Remove</Button>
                 </div>
               ))}
             </div>
           )}
        </Card>
      </div>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Report Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Report Name</Label>
              <Input placeholder="e.g. Monthly Executive Brief" value={reportName} onChange={e => setReportName(e.target.value)} />
            </div>
            
            <div className="space-y-2">
              <Label>Layout Style</Label>
              <Select value={layout} onValueChange={setLayout}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="single">Single Column</SelectItem>
                  <SelectItem value="grid">Two Column Grid</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
             <CardTitle className="text-base">Available Widgets</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {WIDGET_OPTIONS.map(widget => (
              <div key={widget.id} className="flex items-center space-x-2">
                <Checkbox 
                  id={widget.id} 
                  checked={selectedWidgets.includes(widget.id)}
                  onCheckedChange={() => handleToggleWidget(widget.id)}
                />
                <Label htmlFor={widget.id} className="cursor-pointer">{widget.label}</Label>
              </div>
            ))}
          </CardContent>
          <CardFooter>
            <Button className="w-full gap-2" onClick={handleSaveTemplate}>
              <Save className="w-4 h-4" /> Save Template
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default CustomReportBuilder;
