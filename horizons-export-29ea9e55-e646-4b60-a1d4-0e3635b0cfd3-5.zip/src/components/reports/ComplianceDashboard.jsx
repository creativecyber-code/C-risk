
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { FileCheck, AlertCircle, ShieldCheck, XCircle } from 'lucide-react';

const ComplianceDashboard = ({ data }) => {
  if (!data) return <div>Loading...</div>;

  const { complianceData } = data;

  return (
    <div className="space-y-6">
      {/* 1. Framework Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {complianceData.map(fw => (
          <Card key={fw.name} className="border-t-4 border-t-slate-200 hover:border-t-blue-500 transition-colors">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">{fw.name}</CardTitle>
                <StatusBadge status={fw.status} />
              </div>
              <CardDescription>Regulatory Framework Compliance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mt-4 mb-2 flex justify-between text-sm font-medium text-slate-600">
                <span>Compliance Score</span>
                <span>{fw.score}%</span>
              </div>
              <Progress value={fw.score} className="h-2 mb-6" />

              <div className="bg-slate-50 rounded-lg p-3 border border-slate-100">
                 <p className="text-xs font-semibold text-slate-500 uppercase mb-1">Critical Gap</p>
                 <div className="flex items-start gap-2">
                   {fw.gap !== 'None' ? (
                     <AlertCircle className="w-4 h-4 text-orange-500 mt-0.5" />
                   ) : (
                     <ShieldCheck className="w-4 h-4 text-green-500 mt-0.5" />
                   )}
                   <span className="text-sm text-slate-700">{fw.gap}</span>
                 </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 2. Detailed Controls Table */}
      <Card>
        <CardHeader>
          <CardTitle>Control Gap Analysis</CardTitle>
          <CardDescription>Detailed breakdown of control failures and remediation requirements</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-3 text-left font-medium text-slate-500">Control ID</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-500">Description</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-500">Framework(s)</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-500">Status</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-500">Remediation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <ControlRow 
                  id="AC-01" 
                  desc="Access Control Policy Review" 
                  frameworks={['SOC2', 'ISO27001']} 
                  status="Failed" 
                  remediation="Update policy doc" 
                />
                <ControlRow 
                  id="DS-05" 
                  desc="Data at Rest Encryption" 
                  frameworks={['GDPR', 'HIPAA']} 
                  status="Passed" 
                  remediation="-" 
                />
                <ControlRow 
                  id="NS-03" 
                  desc="Network Segmentation" 
                  frameworks={['PCI-DSS']} 
                  status="Warning" 
                  remediation="Verify DMZ rules" 
                />
                <ControlRow 
                  id="LG-02" 
                  desc="Audit Logging Retention" 
                  frameworks={['All']} 
                  status="Passed" 
                  remediation="-" 
                />
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const StatusBadge = ({ status }) => {
  if (status === 'Compliant') {
    return (
      <Badge className="bg-green-100 text-green-700 hover:bg-green-200 border-green-200 flex gap-1">
        <ShieldCheck className="w-3 h-3" /> Compliant
      </Badge>
    );
  } else if (status === 'At Risk') {
    return (
      <Badge className="bg-orange-100 text-orange-700 hover:bg-orange-200 border-orange-200 flex gap-1">
        <AlertCircle className="w-3 h-3" /> At Risk
      </Badge>
    );
  }
  return (
    <Badge className="bg-red-100 text-red-700 hover:bg-red-200 border-red-200 flex gap-1">
      <XCircle className="w-3 h-3" /> Non-Compliant
    </Badge>
  );
};

const ControlRow = ({ id, desc, frameworks, status, remediation }) => (
  <tr className="hover:bg-slate-50/50">
    <td className="px-4 py-3 font-mono text-slate-500 text-xs">{id}</td>
    <td className="px-4 py-3 font-medium text-slate-700">{desc}</td>
    <td className="px-4 py-3 text-slate-500">
      <div className="flex gap-1 flex-wrap">
        {frameworks.map(f => <span key={f} className="bg-slate-100 px-1.5 py-0.5 rounded text-[10px]">{f}</span>)}
      </div>
    </td>
    <td className="px-4 py-3">
      {status === 'Passed' && <span className="text-green-600 flex items-center gap-1 text-xs font-medium"><ShieldCheck className="w-3 h-3"/> Passed</span>}
      {status === 'Failed' && <span className="text-red-600 flex items-center gap-1 text-xs font-medium"><XCircle className="w-3 h-3"/> Failed</span>}
      {status === 'Warning' && <span className="text-orange-600 flex items-center gap-1 text-xs font-medium"><AlertCircle className="w-3 h-3"/> Review</span>}
    </td>
    <td className="px-4 py-3 text-slate-500 text-xs">{remediation}</td>
  </tr>
);

export default ComplianceDashboard;
