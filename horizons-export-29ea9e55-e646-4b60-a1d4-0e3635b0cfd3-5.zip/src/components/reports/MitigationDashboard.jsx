
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { CheckCircle2, Clock, CircleDashed, ArrowRight } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

const MitigationDashboard = ({ data }) => {
  if (!data) return <div>Loading...</div>;

  const { mitigationStats, threats } = data;
  const total = mitigationStats.reduce((acc, curr) => acc + curr.value, 0);

  // Mock Action Plan Data
  const actionPlan = threats.filter(t => t.status !== 'Mitigated').slice(0, 5);

  return (
    <div className="space-y-6">
      {/* 1. Summary Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatusCard title="Open" count={mitigationStats.find(s=>s.name==='Open')?.value} total={total} color="red" icon={<CircleDashed />} />
        <StatusCard title="In Progress" count={mitigationStats.find(s=>s.name==='In Progress')?.value} total={total} color="amber" icon={<Clock />} />
        <StatusCard title="Completed" count={mitigationStats.find(s=>s.name==='Completed')?.value} total={total} color="emerald" icon={<CheckCircle2 />} />
        <StatusCard title="Verified" count={mitigationStats.find(s=>s.name==='Verified')?.value} total={total} color="blue" icon={<CheckCircle2 />} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 2. Charts */}
        <Card>
          <CardHeader>
            <CardTitle>Mitigation Progress</CardTitle>
            <CardDescription>Current status of all identified threats</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
             <ResponsiveContainer width="100%" height="100%">
               <BarChart data={mitigationStats} layout="vertical" margin={{ left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                  <XAxis type="number" />
                  <YAxis dataKey="name" type="category" width={80} tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                    {mitigationStats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
               </BarChart>
             </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* 3. Priority Action Items */}
        <Card>
           <CardHeader>
             <CardTitle>Priority Remediation Actions</CardTitle>
             <CardDescription>Top threats requiring immediate fixes</CardDescription>
           </CardHeader>
           <CardContent>
             <div className="space-y-4">
               {actionPlan.map(item => (
                 <div key={item.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                         <span className={`w-2 h-2 rounded-full ${
                           item.severity === 'Critical' ? 'bg-red-500' : 'bg-orange-500'
                         }`} />
                         <span className="font-medium text-slate-800 text-sm">{item.title}</span>
                      </div>
                      <p className="text-xs text-slate-500 pl-4">Asset: {item.asset}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-xs font-medium text-slate-500 bg-white px-2 py-1 rounded border">
                        {item.status}
                      </span>
                      <ArrowRight className="w-4 h-4 text-slate-400 cursor-pointer hover:text-blue-500" />
                    </div>
                 </div>
               ))}
             </div>
           </CardContent>
        </Card>
      </div>

      {/* 4. Timeline / Tracker */}
      <Card>
        <CardHeader>
          <CardTitle>Remediation Tracking</CardTitle>
          <CardDescription>Tracking progress against SLA targets</CardDescription>
        </CardHeader>
        <CardContent>
           <div className="space-y-6">
             {[
               { name: 'Critical Vulnerabilities', val: 85, label: '85% (3 overdue)', sla: '48h' },
               { name: 'High Risk Items', val: 60, label: '60% (On track)', sla: '14 days' },
               { name: 'Medium Risk Items', val: 30, label: '30% (Delayed)', sla: '30 days' },
             ].map(tracker => (
               <div key={tracker.name}>
                 <div className="flex justify-between text-sm mb-2">
                   <span className="font-medium text-slate-700">{tracker.name}</span>
                   <span className="text-slate-500">SLA: {tracker.sla} • <span className="font-semibold text-slate-900">{tracker.label}</span></span>
                 </div>
                 <Progress value={tracker.val} className="h-2" />
               </div>
             ))}
           </div>
        </CardContent>
      </Card>
    </div>
  );
};

const StatusCard = ({ title, count, total, color, icon }) => (
  <Card className={`border-l-4 border-l-${color}-500`}>
    <CardContent className="p-4 flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-slate-500">{title}</p>
        <div className="flex items-baseline gap-2 mt-1">
          <h3 className="text-2xl font-bold text-slate-900">{count}</h3>
          <span className="text-xs text-slate-400">/ {total}</span>
        </div>
      </div>
      <div className={`p-2 rounded-full bg-${color}-50 text-${color}-600`}>
        {React.cloneElement(icon, { className: 'w-5 h-5' })}
      </div>
    </CardContent>
  </Card>
);

export default MitigationDashboard;
