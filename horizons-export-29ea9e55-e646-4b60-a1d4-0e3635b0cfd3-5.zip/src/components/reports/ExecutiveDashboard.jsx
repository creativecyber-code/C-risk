
// This file is deprecated and replaced by ExecutiveDashboardReport.jsx to avoid naming conflicts.
// Re-exporting to prevent breaking existing imports temporarily, but users should migrate.
import ExecutiveDashboardReport from './ExecutiveDashboardReport';
export default ExecutiveDashboardReport;
