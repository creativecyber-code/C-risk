
import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
  PieChart, Pie, Legend, LineChart, Line
} from 'recharts';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { ShieldAlert, DollarSign, Scale, Users, TrendingUp, AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import { formatCurrency } from '@/utils/exportUtils';
import { Badge } from '@/components/ui/badge';

const ExecutiveDashboardReport = ({ data }) => {
  if (!data) return <div>Loading report data...</div>;

  const { summary, businessImpact, riskOwnership, investmentData, decisionPoints, heatmapData, topFinancialRisks } = data;

  return (
    <div className="space-y-6">
      {/* 1. KPI Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard 
          title="Financial Exposure (ALE)" 
          value={formatCurrency(summary.financialExposure)} 
          trend="+5%" 
          trendDirection="up"
          icon={<DollarSign className="w-5 h-5 text-emerald-600" />}
          subtext="Total Annual Loss Expectancy"
          color="emerald"
        />
        <KPICard 
          title="Overall Risk Score" 
          value={summary.riskScore} 
          trend="-0.4" 
          trendDirection="down"
          icon={<ShieldAlert className="w-5 h-5 text-orange-600" />}
          subtext="Out of 10.0 (High)"
          color="orange"
        />
        <KPICard 
          title="Compliance Status" 
          value={`${summary.complianceScore}%`} 
          trend="+2%" 
          trendDirection="up"
          trendGood={true}
          icon={<Scale className="w-5 h-5 text-blue-600" />}
          subtext="Across 4 Frameworks"
          color="blue"
        />
        <KPICard 
          title="Active Critical Threats" 
          value={summary.activeThreats} 
          trend="-3" 
          trendDirection="down"
          trendGood={true}
          icon={<AlertTriangle className="w-5 h-5 text-amber-600" />}
          subtext="Requiring immediate attention"
          color="amber"
        />
      </div>

      {/* 2. Financial Exposure Breakdown (FAIR) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2 border-emerald-100">
           <CardHeader>
             <CardTitle className="text-lg flex items-center gap-2">
               <DollarSign className="w-5 h-5 text-emerald-600" />
               Financial Exposure Analysis (FAIR Model)
             </CardTitle>
             <CardDescription>Top risks contributing to Annual Loss Expectancy (ALE)</CardDescription>
           </CardHeader>
           <CardContent>
             <div className="h-[300px]">
               {(!topFinancialRisks || topFinancialRisks.length === 0 || topFinancialRisks.every(r => r.value === 0)) ? (
                 <div className="h-full flex flex-col items-center justify-center text-slate-400 border border-dashed rounded bg-slate-50">
                    <DollarSign className="w-10 h-10 mb-2 opacity-50" />
                    <p>No financial data available yet.</p>
                    <p className="text-xs">Add loss magnitude in risk assessments to populate.</p>
                 </div>
               ) : (
                 <ResponsiveContainer width="100%" height="100%">
                   <BarChart data={topFinancialRisks} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                     <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                     <XAxis type="number" tickFormatter={(value) => `$${value/1000}k`} />
                     <YAxis dataKey="name" type="category" width={150} tick={{fontSize: 12}} />
                     <Tooltip formatter={(value) => formatCurrency(value)} />
                     <Bar dataKey="value" fill="#059669" radius={[0, 4, 4, 0]} barSize={20} name="Annual Loss Expectancy" />
                   </BarChart>
                 </ResponsiveContainer>
               )}
             </div>
           </CardContent>
        </Card>

        <Card>
          <CardHeader>
             <CardTitle className="text-lg">Business Impact</CardTitle>
             <CardDescription>Qualitative assessment</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
             <div className="p-3 bg-emerald-50 rounded border border-emerald-100">
                <h4 className="font-semibold text-emerald-800 text-sm mb-1">Financial</h4>
                <p className="text-xs text-emerald-700">{businessImpact.financial}</p>
             </div>
             <ImpactItem label="Compliance" value={businessImpact.compliance} severity="Medium" />
             <ImpactItem label="Reputation" value={businessImpact.reputation} severity="Medium" />
             <ImpactItem label="Operational" value={businessImpact.operational} severity="Low" />
          </CardContent>
        </Card>
      </div>

      {/* 3. Accepted Risks / Decision Points */}
      <Card className="border-orange-200 bg-orange-50/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                Executive Decision Points & Accepted Risks
                <Badge variant="outline" className="bg-orange-100 text-orange-800 border-orange-200">
                  {decisionPoints.length} Items
                </Badge>
              </CardTitle>
              <CardDescription>Risks formally accepted by the business or requiring sign-off.</CardDescription>
            </div>
            <CheckCircle2 className="w-6 h-6 text-orange-500" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {decisionPoints.length === 0 ? (
               <p className="text-sm text-slate-500 italic">No active decision points or accepted risks.</p>
            ) : (
              decisionPoints.map((point, index) => (
                <div key={point.id || index} className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg bg-white border-slate-200 shadow-sm">
                  <div className="flex items-start gap-4 flex-1">
                    <div className={`p-2 rounded-full mt-1 shrink-0 ${
                      point.impact === 'Critical' ? 'bg-red-100 text-red-600' :
                      point.impact === 'High' ? 'bg-orange-100 text-orange-600' :
                      'bg-blue-100 text-blue-600'
                    }`}>
                      <AlertTriangle className="w-5 h-5" />
                    </div>
                    <div className="w-full">
                      <div className="flex justify-between md:justify-start gap-2 mb-1">
                        <h4 className="font-semibold text-slate-900">{point.title}</h4>
                        {point.isReal && <Badge variant="secondary" className="text-[10px]">Accepted Risk</Badge>}
                      </div>
                      
                      <div className="text-sm text-slate-500 flex flex-wrap gap-x-4 gap-y-1">
                        <span>Owner: {point.owner}</span>
                        {point.modelName && <span>• Source: {point.modelName}</span>}
                        {point.financialImpact > 0 && (
                          <span className="font-medium text-emerald-700">• Cost: {formatCurrency(point.financialImpact)}/yr</span>
                        )}
                        <span>• Updated: {point.deadline}</span>
                      </div>
                      
                      {point.justification && (
                        <div className="mt-2 text-sm bg-slate-50 p-2 rounded border border-slate-100 text-slate-700 italic">
                          <span className="font-medium not-italic text-slate-900">Justification: </span>
                          "{point.justification}"
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {!point.isReal && (
                    <div className="mt-4 md:mt-0 flex gap-3 shrink-0">
                       <button className="px-4 py-2 text-sm font-medium text-slate-600 bg-white border border-slate-300 rounded hover:bg-slate-50">Defer</button>
                       <button className="px-4 py-2 text-sm font-medium text-white bg-slate-900 rounded hover:bg-slate-800">Approve Action</button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* 4. Ownership & Investment */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Risk Ownership</CardTitle>
            <CardDescription>Distribution of risk responsibility by department</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={riskOwnership}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {riskOwnership.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend verticalAlign="bottom" height={36} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Investment vs Risk Reduction</CardTitle>
            <CardDescription>Projected impact of security spending</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={investmentData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" fontSize={12} />
                <YAxis yAxisId="left" fontSize={12} />
                <YAxis yAxisId="right" orientation="right" fontSize={12} unit="%" />
                <Tooltip />
                <Legend />
                <Line yAxisId="left" type="monotone" dataKey="investment" name="Investment ($)" stroke="#3b82f6" strokeWidth={2} />
                <Line yAxisId="right" type="monotone" dataKey="riskReduction" name="Risk Reduction (%)" stroke="#10b981" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// Helper Components
const KPICard = ({ title, value, trend, trendDirection, trendGood, icon, subtext, color }) => {
  const isPositive = trendDirection === 'up';
  let trendColor = 'text-slate-500';
  if (trendGood !== undefined) {
    if ((isPositive && trendGood) || (!isPositive && !trendGood)) {
      trendColor = 'text-green-600';
    } else {
      trendColor = 'text-red-600';
    }
  }

  return (
    <Card className={`border-t-4 border-t-${color}-500 shadow-sm`}>
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <p className="text-sm font-medium text-slate-500">{title}</p>
            <h3 className="text-3xl font-bold text-slate-900 mt-1">{value}</h3>
          </div>
          <div className={`p-2 rounded-lg bg-${color}-50`}>
            {icon}
          </div>
        </div>
        <div className="flex items-center justify-between">
           <span className={`text-xs font-medium ${trendColor} flex items-center`}>
             {trendDirection === 'up' ? '↑' : '↓'} {trend}
             <span className="text-slate-400 font-normal ml-1">vs last month</span>
           </span>
        </div>
        <p className="text-xs text-slate-400 mt-2 border-t pt-2">{subtext}</p>
      </CardContent>
    </Card>
  );
};

const ImpactItem = ({ label, value, severity }) => (
  <div className="flex items-start gap-3 p-3 rounded-lg border border-slate-100 hover:bg-slate-50 transition-colors">
    <div className={`w-1.5 h-full min-h-[40px] rounded-full self-stretch ${
      severity === 'High' ? 'bg-red-500' : 
      severity === 'Medium' ? 'bg-orange-400' : 'bg-blue-400'
    }`} />
    <div className="flex-1">
      <div className="flex justify-between items-center mb-1">
        <h4 className="font-semibold text-slate-800 text-sm">{label} Impact</h4>
        <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
          severity === 'High' ? 'bg-red-100 text-red-700' : 
          severity === 'Medium' ? 'bg-orange-100 text-orange-700' : 'bg-blue-100 text-blue-700'
        }`}>{severity}</span>
      </div>
      <p className="text-sm text-slate-600 leading-relaxed">{value}</p>
    </div>
  </div>
);

export default ExecutiveDashboardReport;
