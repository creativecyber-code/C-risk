
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardContent, CardFooter, CardTitle, CardDescription } from '@/components/ui/card';
import { CheckCircle2, AlertCircle, Signal, Plug } from 'lucide-react';

const IntegrationCard = ({ tool, isConnected, onConnect, onConfigure, connectionData }) => {
  return (
    <Card className="flex flex-col h-full hover:shadow-md transition-shadow border-slate-200">
      <CardHeader className="flex flex-row gap-4 items-start pb-2">
        <div className="w-12 h-12 rounded-lg bg-slate-100 border p-2 flex items-center justify-center overflow-hidden shrink-0">
          <img src={tool.logo} alt={tool.name} className="w-full h-full object-contain" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start">
            <CardTitle className="text-base font-bold truncate pr-2" title={tool.name}>
              {tool.name}
            </CardTitle>
            {isConnected ? (
              <Badge className="bg-green-500 hover:bg-green-600 gap-1 pl-1 pr-2">
                <CheckCircle2 className="w-3 h-3" /> Connected
              </Badge>
            ) : (
              <Badge variant="outline" className="text-slate-500 border-slate-200">
                {tool.difficulty} Setup
              </Badge>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">{tool.category}</p>
        </div>
      </CardHeader>

      <CardContent className="flex-1 pb-4">
        <CardDescription className="line-clamp-3 text-sm">
          {tool.description}
        </CardDescription>
        
        {isConnected && connectionData && (
          <div className="mt-4 p-3 bg-slate-50 rounded-md border text-xs space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Status</span>
              <span className="font-medium text-green-600 flex items-center gap-1">
                <Signal className="w-3 h-3" /> Active
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Last Sync</span>
              <span className="font-medium text-slate-700">
                {connectionData.last_sync_at ? new Date(connectionData.last_sync_at).toLocaleDateString() : 'Never'}
              </span>
            </div>
          </div>
        )}
      </CardContent>

      <CardFooter className="pt-0 border-t bg-slate-50/50 p-4 mt-auto">
        {isConnected ? (
          <Button 
            variant="outline" 
            className="w-full border-slate-300 text-slate-700 hover:bg-white hover:text-brand-600"
            onClick={() => onConfigure(tool.id)}
          >
            Configure
          </Button>
        ) : (
          <Button 
            className="w-full bg-slate-900 hover:bg-slate-800"
            onClick={() => onConnect(tool)}
          >
            <Plug className="w-4 h-4 mr-2" /> Connect
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default IntegrationCard;
