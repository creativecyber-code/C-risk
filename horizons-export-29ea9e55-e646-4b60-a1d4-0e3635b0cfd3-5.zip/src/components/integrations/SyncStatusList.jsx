
import React, { useState, useEffect } from 'react';
import { Check, AlertCircle, RefreshCw, ArrowRight, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { integrationService } from '@/services/integrationService';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const SyncStatusList = ({ integrations }) => {
  const [threats, setThreats] = useState([]);
  const [selectedThreats, setSelectedThreats] = useState([]);
  const [targetIntegration, setTargetIntegration] = useState('');
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const { toast } = useToast();

  // Filter only integrations that support syncing (Ticket/Issue/Cloud)
  const syncTargets = integrations.filter(i => 
    ['jira', 'azure-devops', 'github', 'trello', 'servicenow'].includes(i.provider_key) || 
    ['Ticketing', 'Project Mgmt'].includes(i.toolInfo.category)
  );

  useEffect(() => {
    fetchThreats();
  }, []);

  const fetchThreats = async () => {
    setLoading(true);
    // Fetch recent threats
    const { data } = await supabase
      .from('threat_assessments')
      .select('id, title, risk_score, status, created_at')
      .order('created_at', { ascending: false })
      .limit(20);
    
    if (data) setThreats(data);
    setLoading(false);
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      setSelectedThreats(threats.map(t => t.id));
    } else {
      setSelectedThreats([]);
    }
  };

  const handleSelectOne = (id, checked) => {
    if (checked) {
      setSelectedThreats(prev => [...prev, id]);
    } else {
      setSelectedThreats(prev => prev.filter(tid => tid !== id));
    }
  };

  const handleBulkSync = async () => {
    if (!targetIntegration || selectedThreats.length === 0) return;
    
    setSyncing(true);
    try {
      const threatsToSync = threats.filter(t => selectedThreats.includes(t.id));
      await integrationService.bulkSync(targetIntegration, threatsToSync);
      
      toast({
        title: "Bulk Sync Complete",
        description: `Successfully pushed ${selectedThreats.length} items to external tool.`,
      });
      
      setSelectedThreats([]);
    } catch (error) {
      toast({
        title: "Sync Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setSyncing(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row justify-between items-end md:items-center gap-4 bg-slate-50 p-4 rounded-lg border">
        <div className="space-y-1">
          <h3 className="font-semibold text-slate-900">Bulk Synchronization</h3>
          <p className="text-sm text-slate-500">Push selected threats to external issue trackers.</p>
        </div>
        
        <div className="flex gap-2 items-center w-full md:w-auto">
          <Select value={targetIntegration} onValueChange={setTargetIntegration}>
            <SelectTrigger className="w-[200px] bg-white">
              <SelectValue placeholder="Select Destination..." />
            </SelectTrigger>
            <SelectContent>
              {syncTargets.length === 0 ? (
                <SelectItem value="none" disabled>No compatible tools connected</SelectItem>
              ) : (
                syncTargets.map(t => (
                  <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
          
          <Button 
            onClick={handleBulkSync} 
            disabled={!targetIntegration || selectedThreats.length === 0 || syncing}
          >
            {syncing ? <RefreshCw className="w-4 h-4 mr-2 animate-spin"/> : <RefreshCw className="w-4 h-4 mr-2"/>}
            Sync {selectedThreats.length > 0 ? `(${selectedThreats.length})` : ''}
          </Button>
        </div>
      </div>

      <div className="rounded-md border bg-white">
        <div className="p-4 grid grid-cols-12 gap-4 border-b bg-slate-50 font-medium text-sm text-slate-500">
          <div className="col-span-1 text-center">
            <Checkbox 
              checked={selectedThreats.length === threats.length && threats.length > 0}
              onCheckedChange={handleSelectAll}
            />
          </div>
          <div className="col-span-5">Threat Title</div>
          <div className="col-span-2">Risk</div>
          <div className="col-span-2">Status</div>
          <div className="col-span-2 text-right">Last Synced</div>
        </div>
        
        <div className="max-h-[500px] overflow-y-auto">
          {loading ? (
            <div className="p-8 text-center text-slate-500">Loading threats...</div>
          ) : threats.length === 0 ? (
            <div className="p-8 text-center text-slate-500">No threats found to sync.</div>
          ) : (
            threats.map(threat => (
              <div key={threat.id} className="p-4 grid grid-cols-12 gap-4 border-b last:border-0 items-center hover:bg-slate-50 transition-colors text-sm">
                <div className="col-span-1 text-center">
                  <Checkbox 
                    checked={selectedThreats.includes(threat.id)}
                    onCheckedChange={(c) => handleSelectOne(threat.id, c)}
                  />
                </div>
                <div className="col-span-5 font-medium text-slate-900 truncate">
                  {threat.title}
                </div>
                <div className="col-span-2">
                  <Badge variant={threat.risk_score > 70 ? "destructive" : threat.risk_score > 40 ? "secondary" : "outline"}>
                    Score: {threat.risk_score}
                  </Badge>
                </div>
                <div className="col-span-2">
                  <span className={`text-xs px-2 py-1 rounded-full ${threat.status === 'Open' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                    {threat.status || 'New'}
                  </span>
                </div>
                <div className="col-span-2 text-right text-slate-400 text-xs">
                  Not Synced
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default SyncStatusList;
