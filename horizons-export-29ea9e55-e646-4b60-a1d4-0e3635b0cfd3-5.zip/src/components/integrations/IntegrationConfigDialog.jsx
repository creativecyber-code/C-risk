
import React, { useState, useEffect } from 'react';
import { 
  Dialog, DialogContent, DialogHeader, DialogTitle, 
  DialogDescription, DialogFooter 
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Loader2, AlertCircle, RefreshCw, Trash2, Webhook, Activity } from 'lucide-react';
import { integrationService } from '@/services/integrationService';
import { useToast } from '@/components/ui/use-toast';

const IntegrationConfigDialog = ({ tool, existingConnection, isOpen, onClose, onRefresh }) => {
  const [loading, setLoading] = useState(false);
  const [credentials, setCredentials] = useState({});
  const [config, setConfig] = useState({
    syncFrequency: 'daily',
    syncThreats: true,
    syncCompliance: true,
    twoWaySync: false
  });
  const [activeTab, setActiveTab] = useState('setup');
  const [logs, setLogs] = useState([]);
  const [showDisconnectDialog, setShowDisconnectDialog] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      if (existingConnection) {
        // Pre-fill config if connected
        setConfig({ ...config, ...existingConnection.config });
        // Don't pre-fill credentials for security simulation
        setActiveTab('settings');
        fetchLogs();
      } else {
        setCredentials({});
        setActiveTab('setup');
      }
    }
  }, [isOpen, existingConnection, tool]);

  const fetchLogs = async () => {
    if (!existingConnection) return;
    try {
      const data = await integrationService.getLogs(existingConnection.id);
      setLogs(data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleCredentialChange = (field, value) => {
    setCredentials(prev => ({ ...prev, [field]: value }));
  };

  const handleConnect = async () => {
    setLoading(true);
    try {
      await integrationService.connectIntegration(tool.id, credentials, config);
      toast({ title: "Connected Successfully", description: `${tool.name} is now connected.` });
      onRefresh();
      onClose();
    } catch (error) {
      toast({ title: "Connection Failed", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleSyncNow = async () => {
    setLoading(true);
    try {
      const res = await integrationService.syncNow(existingConnection.id);
      toast({ title: "Sync Complete", description: res.message });
      fetchLogs();
      onRefresh();
    } catch (error) {
      toast({ title: "Sync Failed", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnect = async () => {
    setLoading(true);
    try {
      await integrationService.disconnectIntegration(existingConnection.id);
      toast({ title: "Disconnected", description: `${tool.name} removed successfully.` });
      setShowDisconnectDialog(false);
      onRefresh();
      onClose();
    } catch (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  if (!tool) return null;

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-slate-100 rounded-md flex items-center justify-center p-1 border">
                <img src={tool.logo} alt={tool.name} className="w-full h-full object-contain" />
              </div>
              <div>
                <DialogTitle>{existingConnection ? `Manage ${tool.name}` : `Connect ${tool.name}`}</DialogTitle>
                <DialogDescription>
                  {existingConnection ? 'View logs, adjust settings, or sync data.' : 'Enter your credentials to establish a secure connection.'}
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="setup" disabled={existingConnection}>Setup & Auth</TabsTrigger>
              <TabsTrigger value="settings" disabled={!existingConnection}>Mapping & Config</TabsTrigger>
              <TabsTrigger value="logs" disabled={!existingConnection}>Activity Logs</TabsTrigger>
            </TabsList>

            <TabsContent value="setup" className="space-y-4 py-4">
              {!existingConnection && (
                <Alert className="bg-blue-50 border-blue-200">
                  <AlertCircle className="h-4 w-4 text-blue-600" />
                  <AlertTitle className="text-blue-800">Prerequisites</AlertTitle>
                  <AlertDescription className="text-blue-700">
                    You will need an API Key with read/write permissions from your {tool.name} admin console.
                  </AlertDescription>
                </Alert>
              )}

              <div className="grid gap-4">
                {tool.setupFields.map((field) => (
                  <div key={field.name} className="grid gap-2">
                    <Label htmlFor={field.name}>{field.label}</Label>
                    <Input
                      id={field.name}
                      type={field.type}
                      placeholder={field.placeholder || ''}
                      value={credentials[field.name] || ''}
                      onChange={(e) => handleCredentialChange(field.name, e.target.value)}
                      disabled={existingConnection}
                    />
                  </div>
                ))}
              </div>
              
              {!existingConnection && (
                <DialogFooter className="mt-6">
                  <Button variant="outline" onClick={onClose}>Cancel</Button>
                  <Button onClick={handleConnect} disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Connect Integration
                  </Button>
                </DialogFooter>
              )}
            </TabsContent>

            <TabsContent value="settings" className="space-y-6 py-4">
              <div className="space-y-4 border rounded-lg p-4">
                <h3 className="font-medium text-sm text-slate-900">Data Mapping</h3>
                <div className="flex items-center justify-between">
                  <Label htmlFor="sync-threats" className="flex flex-col">
                    <span>Sync Identified Threats</span>
                    <span className="font-normal text-xs text-slate-500">Push new threats to external tool</span>
                  </Label>
                  <Switch 
                    id="sync-threats" 
                    checked={config.syncThreats}
                    onCheckedChange={(c) => setConfig({...config, syncThreats: c})} 
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="sync-compliance" className="flex flex-col">
                    <span>Sync Compliance Status</span>
                    <span className="font-normal text-xs text-slate-500">Update compliance checklists automatically</span>
                  </Label>
                  <Switch 
                    id="sync-compliance" 
                    checked={config.syncCompliance}
                    onCheckedChange={(c) => setConfig({...config, syncCompliance: c})} 
                  />
                </div>
              </div>

              <div className="space-y-4 border rounded-lg p-4">
                <h3 className="font-medium text-sm text-slate-900">Webhook Configuration</h3>
                <div className="bg-slate-50 p-3 rounded border flex items-center justify-between gap-2">
                   <div className="flex-1 truncate text-xs font-mono text-slate-600">
                     https://api.creativecyber.com/webhooks/v1/int/{existingConnection?.id || '...'}
                   </div>
                   <Button size="sm" variant="ghost" className="h-6 text-xs">Copy</Button>
                </div>
                <p className="text-xs text-slate-500">
                  Configure this URL in {tool.name} to receive real-time updates.
                </p>
              </div>

              <div className="flex justify-between items-center pt-4 border-t">
                <Button 
                  variant="destructive" 
                  size="sm" 
                  onClick={() => setShowDisconnectDialog(true)} 
                  disabled={loading}
                >
                  <Trash2 className="w-4 h-4 mr-2" /> Disconnect
                </Button>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => toast({ title: "Settings Saved" })}>Save Changes</Button>
                  <Button size="sm" onClick={handleSyncNow} disabled={loading}>
                     {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : <RefreshCw className="w-4 h-4 mr-2" />}
                     Sync Now
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="logs" className="space-y-4 py-4">
              <div className="h-[300px] overflow-y-auto border rounded-md bg-slate-50 p-2 space-y-2">
                {logs.length === 0 ? (
                  <div className="text-center text-slate-400 py-8 text-sm">No logs recorded yet.</div>
                ) : (
                  logs.map(log => (
                    <div key={log.id} className="bg-white p-3 rounded border shadow-sm text-sm">
                      <div className="flex justify-between mb-1">
                        <span className={`font-medium ${
                          log.status === 'success' ? 'text-green-600' : 
                          log.status === 'error' ? 'text-red-600' : 'text-yellow-600'
                        }`}>
                          {log.status.toUpperCase()}
                        </span>
                        <span className="text-slate-400 text-xs">
                          {new Date(log.created_at).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-slate-700">{log.message}</p>
                      {log.details && (
                        <pre className="mt-2 text-[10px] bg-slate-100 p-1 rounded overflow-x-auto">
                          {JSON.stringify(log.details, null, 2)}
                        </pre>
                      )}
                    </div>
                  ))
                )}
              </div>
              <div className="flex justify-end">
                <Button variant="outline" size="sm" onClick={fetchLogs} disabled={loading}>
                  <RefreshCw className="w-4 h-4 mr-2" /> Refresh Logs
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showDisconnectDialog} onOpenChange={setShowDisconnectDialog}>
        <AlertDialogContent>
          <AlertDialogTitle>Disconnect Integration?</AlertDialogTitle>
          <AlertDialogDescription>
            This will stop all data syncing with {tool?.name}. You can reconnect anytime.
          </AlertDialogDescription>
          <div className="flex justify-end gap-2">
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDisconnect} 
              disabled={loading}
              className="bg-red-600 hover:bg-red-700"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              Disconnect
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default IntegrationConfigDialog;
