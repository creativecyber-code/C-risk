
import React, { useEffect, useState } from 'react';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { roleService } from '@/services/roleService';
import { Loader2 } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

export function TenantRoleSelect({ value, onValueChange, placeholder = "Select a role", className }) {
  const [roles, setRoles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    async function loadRoles() {
      try {
        const data = await roleService.getTenantRoles();
        if (mounted) setRoles(data);
      } catch (error) {
        console.error("Failed to load roles", error);
      } finally {
        if (mounted) setLoading(false);
      }
    }
    loadRoles();
    return () => { mounted = false; };
  }, []);

  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger className={className}>
        <SelectValue placeholder={loading ? "Loading roles..." : placeholder} />
      </SelectTrigger>
      <SelectContent>
        {loading ? (
          <div className="flex items-center justify-center p-2 text-muted-foreground text-sm">
            <Loader2 className="h-4 w-4 animate-spin mr-2" /> Loading...
          </div>
        ) : (
          <SelectGroup>
            <SelectLabel>Available Roles</SelectLabel>
            {roles.map((role) => (
              <SelectItem key={role.role_key} value={role.role_key}>
                <div className="flex flex-col items-start text-left">
                  <span className="font-medium">{role.display_name}</span>
                  {role.description && (
                    <span className="text-[10px] text-muted-foreground line-clamp-1 max-w-[200px]">
                      {role.description}
                    </span>
                  )}
                </div>
              </SelectItem>
            ))}
          </SelectGroup>
        )}
      </SelectContent>
    </Select>
  );
}
