
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { 
  Bell, 
  LogOut, 
  LayoutDashboard, 
  Users, 
  UserCircle 
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export function TenantHeader() {
  const { user, signOut, tenant } = useAuth();
  const location = useLocation();

  const isActive = (path) => location.pathname === path || (path !== '/app-dashboard' && location.pathname.startsWith(path));

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Link to="/app-dashboard" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
                <div className="h-8 w-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold shadow-sm">
                  {tenant?.name ? tenant.name.charAt(0).toUpperCase() : 'C'}
                </div>
                <div className="flex flex-col">
                    <span className="font-bold text-sm leading-none text-slate-900">
                      {tenant?.name || 'C-RISK'}
                    </span>
                    <span className="text-[10px] font-medium text-slate-500 uppercase tracking-wider">
                      {tenant ? 'Tenant Portal' : 'Gateway'}
                    </span>
                </div>
            </Link>
            
            <nav className="hidden md:flex items-center space-x-1">
                <Link to="/app-dashboard/overview">
                    <Button variant={isActive('/app-dashboard/overview') || location.pathname === '/app-dashboard' ? "secondary" : "ghost"} size="sm" className="gap-2">
                        <LayoutDashboard className="h-4 w-4" /> Overview
                    </Button>
                </Link>
                <Link to="/app-dashboard/team">
                    <Button variant={isActive('/app-dashboard/team') ? "secondary" : "ghost"} size="sm" className="gap-2">
                        <Users className="h-4 w-4" /> Team
                    </Button>
                </Link>
                 <Link to="/app-dashboard/profile">
                    <Button variant={isActive('/app-dashboard/profile') ? "secondary" : "ghost"} size="sm" className="gap-2">
                        <UserCircle className="h-4 w-4" /> Profile
                    </Button>
                </Link>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            {tenant?.license_tier && (
               <Badge variant="outline" className="hidden lg:flex border-blue-200 text-blue-700 bg-blue-50">
                 {tenant.license_tier} Plan
               </Badge>
            )}
            <Button variant="ghost" size="icon" className="text-slate-500">
              <Bell className="h-5 w-5" />
            </Button>
            <Separator orientation="vertical" className="h-6" />
            <div className="flex items-center gap-3">
               <div className="text-right hidden md:block">
                 <p className="text-sm font-medium text-slate-700">{user?.user_metadata?.full_name || 'Tenant User'}</p>
                 <p className="text-xs text-slate-500">{user?.email}</p>
               </div>
               <Button variant="outline" size="sm" onClick={signOut} className="border-slate-200 hover:bg-slate-50 text-slate-600">
                 <LogOut className="h-4 w-4 mr-2" /> Sign Out
               </Button>
            </div>
          </div>
        </div>
      </header>
  );
}
