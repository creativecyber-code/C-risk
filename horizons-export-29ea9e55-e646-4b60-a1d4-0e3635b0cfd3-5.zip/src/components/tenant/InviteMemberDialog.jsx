
import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { TenantRoleSelect } from '@/components/tenant/TenantRoleSelect';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Mail, Shield, Check, Copy, Link as LinkIcon, AlertTriangle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export function InviteMemberDialog({ open, onOpenChange, onSuccess }) {
  const { tenant, user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [inviteResult, setInviteResult] = useState(null); // { link, email, role }
  const [copied, setCopied] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    role: ''
  });

  const resetForm = () => {
    setFormData({ email: '', role: '' });
    setInviteResult(null);
    setCopied(false);
  };

  const handleOpenChange = (isOpen) => {
    if (!isOpen) {
        resetForm();
    }
    onOpenChange(isOpen);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.email || !formData.role) {
        toast({ title: "Validation Error", description: "Please fill in all fields", variant: "destructive" });
        return;
    }

    setLoading(true);
    try {
        // Generate a random token for the invite link
        const token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 7); // 7 days expiry

        // Insert invitation record
        const { error } = await supabase
            .from('tenant_invitations')
            .insert({
                tenant_id: tenant.id,
                email: formData.email,
                role: formData.role, 
                token: token,
                status: 'pending',
                expires_at: expiresAt.toISOString(),
                created_by: user.id
            });

        if (error) throw error;

        // Generate the full invite link
        const inviteLink = `${window.location.origin}/tenant-user-invite?code=${token}`;

        setInviteResult({
            link: inviteLink,
            email: formData.email,
            role: formData.role
        });
        
        onSuccess?.();
        toast({ title: "Invitation Created", description: "Share the link below with the user." });

    } catch (error) {
        console.error("Invite error:", error);
        toast({ 
            title: "Error Creating Invite", 
            description: error.message || "Could not process invitation.", 
            variant: "destructive" 
        });
    } finally {
        setLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (inviteResult?.link) {
        navigator.clipboard.writeText(inviteResult.link);
        setCopied(true);
        toast({ title: "Copied!", description: "Invite link copied to clipboard." });
        setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Invite Team Member</DialogTitle>
          <DialogDescription>
            {inviteResult 
                ? "Invitation created successfully! Share this link with the user." 
                : `Create an invitation for a new user to join ${tenant?.name || 'this organization'}.`
            }
          </DialogDescription>
        </DialogHeader>

        {inviteResult ? (
            <div className="space-y-6 py-4 animate-in fade-in slide-in-from-bottom-4 duration-300">
                <Alert className="bg-green-50 border-green-200">
                    <Check className="h-4 w-4 text-green-600" />
                    <AlertTitle className="text-green-800">Invitation Active</AlertTitle>
                    <AlertDescription className="text-green-700">
                        An invite for <strong>{inviteResult.email}</strong> has been generated.
                    </AlertDescription>
                </Alert>

                <div className="space-y-2">
                    <Label className="text-sm font-medium text-slate-700">Shareable Invite Link</Label>
                    <div className="flex items-center gap-2">
                        <div className="relative flex-1">
                            <LinkIcon className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                            <Input 
                                value={inviteResult.link} 
                                readOnly 
                                className="pl-9 bg-slate-50 text-slate-600 font-mono text-xs pr-2"
                            />
                        </div>
                        <Button onClick={copyToClipboard} className="shrink-0" variant={copied ? "outline" : "default"}>
                            {copied ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                            {copied ? "Copied" : "Copy"}
                        </Button>
                    </div>
                    <p className="text-[10px] text-slate-500">
                        This link is valid for 7 days. Anyone with this link can join as <strong>{inviteResult.role}</strong>.
                    </p>
                </div>

                <DialogFooter className="sm:justify-between flex-row-reverse">
                    <Button onClick={() => handleOpenChange(false)}>Done</Button>
                    <Button variant="ghost" onClick={resetForm} className="text-slate-500">Invite Another</Button>
                </DialogFooter>
            </div>
        ) : (
            <form onSubmit={handleSubmit} className="space-y-4 py-4">
            <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center gap-2">
                    <Mail className="h-3 w-3" /> Email Address
                </Label>
                <Input
                id="email"
                type="email"
                placeholder="colleague@company.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                />
            </div>
            <div className="space-y-2">
                <Label htmlFor="role" className="flex items-center gap-2">
                    <Shield className="h-3 w-3" /> Role Assignment
                </Label>
                <TenantRoleSelect
                value={formData.role}
                onValueChange={(val) => setFormData({ ...formData, role: val })}
                className="w-full"
                />
                <p className="text-[10px] text-muted-foreground">
                    Select the access level for this user based on the organization's role definitions.
                </p>
            </div>

            <div className="bg-amber-50 p-3 rounded-md border border-amber-100 flex gap-3 items-start">
                 <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
                 <p className="text-xs text-amber-700">
                    The user will be required to set up Multi-Factor Authentication (MFA) immediately upon registration.
                 </p>
            </div>

            <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => handleOpenChange(false)}>Cancel</Button>
                <Button type="submit" disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Generate Invite Link
                </Button>
            </DialogFooter>
            </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
