
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ChevronRight, ChevronDown, Building, Users, Briefcase, Plus, Trash2 } from 'lucide-react';

const OrgHierarchy = () => {
  // Simple recursive structure for demo
  const [tree, setTree] = useState([
    {
      id: 'root',
      type: 'Organization',
      name: 'Acme Corp',
      isOpen: true,
      children: [
        {
          id: 'div-1', type: 'Division', name: 'Engineering', isOpen: true, children: [
            { id: 'team-1', type: 'Team', name: 'Frontend', children: [] },
            { id: 'team-2', type: 'Team', name: 'Backend', children: [] }
          ]
        },
        {
          id: 'div-2', type: 'Division', name: 'Sales', children: [] }
      ]
    }
  ]);

  const toggleNode = (nodeId) => {
    // Basic toggle logic (would need deep clone/search in real app)
    // For demo visual only
    console.log("Toggle node", nodeId);
  };

  const TreeNode = ({ node, level = 0 }) => {
    const Icon = node.type === 'Organization' ? Building : node.type === 'Division' ? Briefcase : Users;
    
    return (
      <div className="select-none">
        <div 
          className="flex items-center gap-2 p-2 hover:bg-slate-50 rounded cursor-pointer group"
          style={{ paddingLeft: `${level * 24 + 8}px` }}
        >
          <div className="p-1 rounded hover:bg-slate-200 text-slate-400">
            {node.children && node.children.length > 0 ? <ChevronDown className="w-4 h-4" /> : <div className="w-4 h-4" />}
          </div>
          <Icon className="w-4 h-4 text-indigo-600" />
          <span className="text-sm font-medium">{node.name}</span>
          <span className="text-[10px] text-slate-400 uppercase ml-2 bg-slate-100 px-1 rounded">{node.type}</span>
          
          <div className="ml-auto opacity-0 group-hover:opacity-100 flex gap-1">
            <Button size="icon" variant="ghost" className="h-6 w-6"><Plus className="w-3 h-3" /></Button>
            {level > 0 && <Button size="icon" variant="ghost" className="h-6 w-6 text-red-500"><Trash2 className="w-3 h-3" /></Button>}
          </div>
        </div>
        {node.children && node.children.map(child => (
          <TreeNode key={child.id} node={child} level={level + 1} />
        ))}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-3 gap-6 h-[500px]">
      <Card className="col-span-2 flex flex-col">
        <CardHeader>
          <CardTitle>Organization Structure</CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto">
          <div className="border rounded-lg p-2">
            {tree.map(node => <TreeNode key={node.id} node={node} />)}
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader><CardTitle>Details</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Entity Name</label>
            <Input placeholder="Select node..." />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Description</label>
            <Input placeholder="Optional..." />
          </div>
          <div className="pt-4 border-t">
            <p className="text-xs text-slate-500">
              Defining your hierarchy allows for granular reporting and risk aggregation roll-ups.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default OrgHierarchy;
