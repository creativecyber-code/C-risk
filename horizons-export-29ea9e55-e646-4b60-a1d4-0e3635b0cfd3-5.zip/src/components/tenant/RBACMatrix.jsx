
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Save, RefreshCw } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const MODULES = ['Risk Management', 'Compliance', 'Audit Logs', 'User Management', 'Settings'];
const PERMISSIONS = ['Create', 'Read', 'Update', 'Delete', 'Approve'];
const ROLES = ['Tenant Admin', 'Risk Manager', 'Auditor', 'Viewer'];

const RBACMatrix = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  // Mock Matrix State
  const [matrix, setMatrix] = useState({});

  const togglePermission = (role, module, perm) => {
    const key = `${role}-${module}-${perm}`;
    setMatrix(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleSave = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast({ title: "Policies Updated", description: "RBAC Matrix has been saved successfully." });
    }, 1000);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Access Control Matrix</CardTitle>
          <CardDescription>Define granular permissions per role and module.</CardDescription>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setMatrix({})}><RefreshCw className="w-4 h-4 mr-2" /> Reset</Button>
          <Button onClick={handleSave} disabled={loading}>
            {loading ? 'Saving...' : <><Save className="w-4 h-4 mr-2" /> Save Changes</>}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          {ROLES.map(role => (
            <div key={role} className="mb-8">
              <h3 className="text-sm font-bold uppercase tracking-wide text-slate-500 mb-3 bg-slate-50 p-2 rounded">{role}</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[200px]">Module</TableHead>
                    {PERMISSIONS.map(p => (
                      <TableHead key={p} className="text-center w-[100px]">{p}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {MODULES.map(module => (
                    <TableRow key={module}>
                      <TableCell className="font-medium">{module}</TableCell>
                      {PERMISSIONS.map(perm => {
                        const isChecked = matrix[`${role}-${module}-${perm}`] || 
                                          (role === 'Tenant Admin'); // Admin always checked mock
                        const isDisabled = role === 'Tenant Admin'; // Cannot revoke admin rights easily
                        
                        return (
                          <TableCell key={perm} className="text-center">
                            <div className="flex justify-center">
                              <Checkbox 
                                checked={isChecked} 
                                onCheckedChange={() => togglePermission(role, module, perm)}
                                disabled={isDisabled}
                              />
                            </div>
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default RBACMatrix;
