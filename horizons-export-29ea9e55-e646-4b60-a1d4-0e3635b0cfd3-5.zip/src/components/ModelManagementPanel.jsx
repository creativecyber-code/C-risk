
import React, { useState, useEffect } from 'react';
import { Plus, Trash2, FolderOpen, Loader2, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { threatModelService } from '@/services/threatModelService';
import { useToast } from '@/components/ui/use-toast';

const ModelManagementPanel = ({ currentModelId, onModelLoad, onModelCreate }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [models, setModels] = useState([]);
  const [loading, setLoading] = useState(false);
  const [newModelName, setNewModelName] = useState('');
  const { toast } = useToast();

  const fetchModels = async () => {
    setLoading(true);
    try {
      const data = await threatModelService.listModels();
      setModels(data);
    } catch (error) {
      toast({
        title: "Error fetching models",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchModels();
    }
  }, [isOpen]);

  const handleCreate = async () => {
    if (!newModelName.trim()) return;
    setLoading(true);
    try {
      const model = await threatModelService.createModel(newModelName);
      setModels([model, ...models]);
      setNewModelName('');
      onModelCreate(model);
      setIsOpen(false);
      toast({ title: "Model created successfully" });
    } catch (error) {
      toast({ title: "Creation failed", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (e, id) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to delete this model?')) return;
    
    try {
      await threatModelService.deleteModel(id);
      setModels(models.filter(m => m.id !== id));
      toast({ title: "Model deleted" });
    } catch (error) {
      toast({ title: "Delete failed", description: error.message, variant: "destructive" });
    }
  };

  const handleLoad = async (model) => {
    setLoading(true);
    try {
      await onModelLoad(model.id);
      setIsOpen(false);
    } catch (error) {
      toast({ title: "Load failed", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2 bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700">
          <FolderOpen className="w-4 h-4" />
          My Models
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md bg-slate-900 border-slate-700 text-slate-100">
        <DialogHeader>
          <DialogTitle>Threat Models</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="New Model Name"
              value={newModelName}
              onChange={(e) => setNewModelName(e.target.value)}
              className="flex-1 bg-slate-800 border border-slate-700 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Button onClick={handleCreate} disabled={loading || !newModelName.trim()}>
              <Plus className="w-4 h-4" />
            </Button>
          </div>

          <div className="h-[300px] overflow-y-auto space-y-2 pr-2">
            {loading && models.length === 0 ? (
              <div className="flex justify-center p-4">
                <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
              </div>
            ) : models.length === 0 ? (
              <p className="text-center text-slate-500 text-sm py-8">No models found. Create one to get started.</p>
            ) : (
              models.map((model) => (
                <div
                  key={model.id}
                  onClick={() => handleLoad(model)}
                  className={`
                    group flex items-center justify-between p-3 rounded-lg cursor-pointer border transition-all
                    ${currentModelId === model.id 
                      ? 'bg-blue-900/20 border-blue-500/50' 
                      : 'bg-slate-800 border-slate-700 hover:border-slate-600'}
                  `}
                >
                  <div>
                    <h4 className="font-medium text-sm text-slate-200">{model.name}</h4>
                    <p className="text-xs text-slate-500">
                      Last updated: {new Date(model.updated_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-slate-400 hover:text-red-400 hover:bg-red-900/20"
                      onClick={(e) => handleDelete(e, model.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ModelManagementPanel;
