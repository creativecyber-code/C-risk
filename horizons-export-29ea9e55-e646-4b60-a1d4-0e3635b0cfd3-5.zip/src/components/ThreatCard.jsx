
import React from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, X, FileText, Lock } from 'lucide-react';

const ThreatCard = ({ threat, onClose, suggestedThreats = [] }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="absolute z-50 bg-slate-900 border border-slate-700 shadow-xl rounded-lg w-80 pointer-events-auto overflow-hidden flex flex-col max-h-96"
      style={{ left: threat.x + 20, top: threat.y + 20 }}
    >
      <div className="flex justify-between items-center p-3 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-2 text-red-400 font-semibold text-sm">
          <AlertTriangle className="w-4 h-4" />
          <span>Trust Boundary Violation</span>
        </div>
        <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
          <X className="w-4 h-4" />
        </button>
      </div>
      
      <div className="p-3 overflow-y-auto custom-scrollbar">
        <p className="text-xs text-slate-400 mb-3">
          This data flow crosses a trust boundary. Based on banking security standards, the following threats may apply:
        </p>
        <div className="space-y-3">
          {suggestedThreats.map((t, i) => (
            <div key={i} className="bg-slate-950/50 rounded-md p-3 border border-slate-800 hover:border-slate-700 transition-colors">
              <div className="flex justify-between items-start mb-1.5">
                <span className="font-medium text-slate-200 text-sm leading-tight">{t.title}</span>
                <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold whitespace-nowrap ml-2 ${
                  t.risk === 'High' || t.risk === 'Critical' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'
                }`}>
                  {t.risk}
                </span>
              </div>
              
              <div className="flex items-center gap-1.5 mb-2">
                 <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">{t.category}</span>
                 <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">{t.stride}</span>
              </div>

              <p className="text-xs text-slate-500 leading-relaxed mb-2">{t.description}</p>
              
              {(t.compliance || t.mitigation) && (
                <div className="pt-2 mt-2 border-t border-slate-800 grid gap-2">
                  {t.compliance && (
                     <div className="flex gap-1.5 text-[10px] text-blue-400/80">
                       <FileText className="w-3 h-3 shrink-0" />
                       <span>{t.compliance}</span>
                     </div>
                  )}
                  {t.mitigation && (
                     <div className="flex gap-1.5 text-[10px] text-green-400/80">
                       <Lock className="w-3 h-3 shrink-0" />
                       <span>{t.mitigation}</span>
                     </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default ThreatCard;
