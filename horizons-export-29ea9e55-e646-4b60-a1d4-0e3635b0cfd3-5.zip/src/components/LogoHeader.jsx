
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { LOGO_URL, COMPANY_NAME } from '@/lib/constants';
import { ImageOff } from 'lucide-react';

const LogoHeader = ({ size = 'medium', className, showText = true, linkTo = '/' }) => {
  const [imageError, setImageError] = useState(false);

  // Size mapping
  const sizeClasses = {
    small: "h-8",
    medium: "h-12", 
    large: "h-16", 
    xl: "h-24"
  };

  const imgSize = sizeClasses[size] || sizeClasses.medium;

  return (
    <Link 
      to={linkTo} 
      className={cn(
        "flex flex-col items-center justify-center gap-2 hover:opacity-90 transition-opacity select-none", 
        className
      )}
      aria-label={`${COMPANY_NAME} Home`}
    >
      <div className={cn("relative flex items-center justify-center", imgSize)}>
        {!imageError ? (
          <img 
            src={LOGO_URL} 
            alt={`${COMPANY_NAME} Logo`}
            className="h-full w-auto object-contain"
            onError={() => setImageError(true)}
          />
        ) : (
          <div className="flex items-center justify-center h-full w-full bg-slate-100 rounded text-slate-400 px-2 border border-slate-200">
             <ImageOff className="h-5 w-5 mr-2" />
             <span className="text-xs font-semibold">{COMPANY_NAME}</span>
          </div>
        )}
      </div>
      
      {showText && (
        <span className={cn(
          "font-bold tracking-tight text-slate-900",
          size === 'small' ? 'text-sm' : 
          size === 'medium' ? 'text-lg' : 
          size === 'large' ? 'text-xl' : 'text-2xl'
        )}>
          {COMPANY_NAME}
        </span>
      )}
    </Link>
  );
};

export default LogoHeader;
