
import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';

class DebugErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("DebugErrorBoundary caught an error:", error, errorInfo);
    this.setState({ errorInfo });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-8 bg-slate-950 min-h-screen text-slate-200 font-mono">
          <div className="max-w-2xl mx-auto border border-red-800 bg-red-950/30 p-6 rounded-lg">
            <div className="flex items-center gap-3 mb-4 text-red-500">
              <AlertTriangle className="h-8 w-8" />
              <h1 className="text-xl font-bold">Component Crash Detected</h1>
            </div>
            
            <p className="mb-4 text-slate-300">
              The application encountered an error while rendering this component.
            </p>

            <div className="bg-black/50 p-4 rounded overflow-auto max-h-64 mb-4 text-xs">
              <p className="text-red-400 font-bold mb-2">{this.state.error && this.state.error.toString()}</p>
              <pre className="text-slate-500">{this.state.errorInfo && this.state.errorInfo.componentStack}</pre>
            </div>

            <Button 
              variant="outline" 
              onClick={() => window.location.reload()}
              className="border-slate-700 hover:bg-slate-800 text-white"
            >
              Reload Page
            </Button>
          </div>
        </div>
      );
    }

    return this.props.children; 
  }
}

export default DebugErrorBoundary;
