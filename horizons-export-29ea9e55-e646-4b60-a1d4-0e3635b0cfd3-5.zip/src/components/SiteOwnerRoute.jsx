
import React, { useEffect, useState } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Loader2 } from 'lucide-react';

const SiteOwnerRoute = () => {
  const { user, loading: authLoading } = useAuth();
  const [isSiteOwner, setIsSiteOwner] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const checkRole = async () => {
      if (!user) {
        setChecking(false);
        return;
      }

      try {
        // Check profile role
        const { data, error } = await supabase
          .from('user_profiles')
          .select('role')
          .eq('id', user.id)
          .single();

        if (error) throw error;
        
        // Allow 'Site Owner' or specific admin email for fallback
        if (data?.role === 'Site Owner' || user.email === 'admin@creativecyber.com') {
          setIsSiteOwner(true);
        }
      } catch (error) {
        console.error('Error checking site owner status:', error);
      } finally {
        setChecking(false);
      }
    };

    if (!authLoading) {
      checkRole();
    }
  }, [user, authLoading]);

  if (authLoading || checking) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-brand-600" />
      </div>
    );
  }

  return isSiteOwner ? <Outlet /> : <Navigate to="/dashboard" replace />;
};

export default SiteOwnerRoute;
