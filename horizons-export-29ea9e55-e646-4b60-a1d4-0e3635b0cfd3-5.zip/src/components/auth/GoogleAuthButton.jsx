
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, AlertCircle } from 'lucide-react';

const GoogleAuthButton = ({ text = "Continue with Google", className }) => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleGoogleLogin = async () => {
    setLoading(true);
    console.log("[GoogleAuth] Initiating OAuth flow...");
    
    try {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          queryParams: {
            access_type: 'offline',
            prompt: 'consent',
          },
          redirectTo: `${window.location.origin}/dashboard`,
        },
      });

      if (error) throw error;
      
    } catch (error) {
      console.error("[GoogleAuth] Error:", error);
      
      let errorMessage = error.message || "Failed to initiate Google login";
      
      if (error.message?.includes('provider is not enabled')) {
        errorMessage = "Google Login is not enabled. Please contact the administrator.";
      }

      toast({
        title: "Authentication Error",
        description: errorMessage,
        variant: "destructive",
        action: <AlertCircle className="h-5 w-5" />
      });
      setLoading(false);
    }
  };

  return (
    <Button 
      variant="outline" 
      type="button" 
      onClick={handleGoogleLogin} 
      disabled={loading}
      className={`w-full relative ${className} bg-white hover:bg-slate-50 text-slate-700 border-slate-200`}
    >
      {loading ? (
        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
      ) : (
        <svg className="mr-2 h-4 w-4" aria-hidden="true" focusable="false" data-prefix="fab" data-icon="google" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512">
          <path fill="#4285F4" d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h236.1c2.3 12.7 3.9 24.9 3.9 41.4z"></path>
          <path fill="#34A853" d="M248 504c64.1 0 122.5-22.9 167.3-61.9l-67.5-64.9c-20.7 14.1-47.5 22.4-78.8 22.4-60.8 0-112.5-41.2-131-96.6l-65.7 51.5C108.8 456.9 173.3 504 248 504z"></path>
          <path fill="#FBBC05" d="M117 303c-5.8-17.5-9-36.1-9-56s3.2-38.5 9-56l-65.7-51.5C23.9 179.5 0 216.4 0 256s23.9 76.5 51.3 116.5l65.7-51.5z"></path>
          <path fill="#EA4335" d="M248 76.7c33.5 0 63.8 11.5 88.2 34.3l66.4-66.4C362.5 16.3 308.8 0 248 0 173.3 0 108.8 47.1 72.3 103.5l65.7 51.5c18.5-55.4 70.2-96.6 131-96.6z"></path>
        </svg>
      )}
      {text}
    </Button>
  );
};

export default GoogleAuthButton;
