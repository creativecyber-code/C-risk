
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardContent, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { ShieldCheck, AlertCircle, Loader2, ArrowRight } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

const MFAVerification = ({ onSuccess }) => {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { verifyMfaChallenge, signOut } = useAuth();

  const handleVerify = async (e) => {
    e.preventDefault();
    if (code.length !== 6) return;

    setLoading(true);
    setError(null);

    try {
      const { data, error } = await verifyMfaChallenge(code);
      
      if (error) {
        throw error;
      }
      
      if (onSuccess) onSuccess();

    } catch (err) {
      console.error("MFA Verify Error:", err);
      setError("Invalid code. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const value = e.target.value.replace(/\D/g, '').slice(0, 6);
    setCode(value);
    if (error) setError(null);
  };

  return (
    <Card className="w-full max-w-md shadow-xl border-t-4 border-t-blue-600">
      <CardHeader className="text-center pb-2">
        <div className="mx-auto bg-blue-50 p-4 rounded-full w-fit mb-4 border border-blue-100">
          <ShieldCheck className="h-10 w-10 text-blue-600" />
        </div>
        <CardTitle className="text-2xl font-bold text-slate-900">Security Check</CardTitle>
        <CardDescription className="text-base mt-2">
          Enter the 6-digit code from your authenticator app to verify your identity.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6 pt-4">
        {error && (
          <Alert variant="destructive" className="animate-in fade-in slide-in-from-top-1">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleVerify} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="mfa-code" className="sr-only">Authentication Code</Label>
            <Input
              id="mfa-code"
              type="text"
              placeholder="000 000"
              className="text-center text-3xl font-mono tracking-[0.5em] h-14 border-slate-300 focus:border-blue-500 transition-all placeholder:tracking-normal placeholder:text-slate-300"
              value={code}
              onChange={handleInputChange}
              maxLength={6}
              autoFocus
              autoComplete="one-time-code"
              disabled={loading}
            />
          </div>

          <Button 
            type="submit" 
            className="w-full h-11 bg-blue-600 hover:bg-blue-700 text-lg shadow-sm"
            disabled={loading || code.length !== 6}
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Verifying...
              </>
            ) : (
              <>
                Verify Login <ArrowRight className="ml-2 h-5 w-5" />
              </>
            )}
          </Button>
        </form>
      </CardContent>

      <CardFooter className="flex flex-col gap-4 border-t bg-slate-50 p-6 rounded-b-xl">
        <div className="text-center space-y-2">
          <p className="text-xs text-slate-500">
            Lost your device?{' '}
            <button className="text-blue-600 hover:underline font-medium">
              Use a recovery code
            </button>
          </p>
          <div className="pt-2">
            <Button variant="ghost" size="sm" onClick={() => signOut()} className="text-slate-500 hover:text-slate-800">
              Return to Login
            </Button>
          </div>
        </div>
      </CardFooter>
    </Card>
  );
};

export default MFAVerification;
