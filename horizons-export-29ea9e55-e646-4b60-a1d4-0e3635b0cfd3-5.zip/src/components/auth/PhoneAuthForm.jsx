
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Phone, ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useNavigate } from 'react-router-dom';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const PhoneAuthForm = ({ onSuccess, mode = 'signin' }) => {
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState('phone'); // 'phone' or 'otp'
  const [loading, setLoading] = useState(false);
  const [providerError, setProviderError] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSendOtp = async (e) => {
    e.preventDefault();
    setProviderError(false);
    
    if (!phone || phone.length < 10) {
      toast({ title: "Invalid Phone", description: "Please enter a valid phone number with country code (e.g., +1...)", variant: "destructive" });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOtp({
        phone: phone,
      });

      if (error) {
        // Check specifically for the provider disabled error
        if (error.message?.includes('phone_provider_disabled') || error.code === 'phone_provider_disabled') {
          setProviderError(true);
          throw new Error("SMS authentication is not enabled in the database settings.");
        }
        throw error;
      }

      setStep('otp');
      toast({ title: "OTP Sent", description: `Verification code sent to ${phone}` });
    } catch (error) {
      console.error(error);
      toast({ 
        title: "Error sending OTP", 
        description: error.message || "Failed to send verification code", 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    if (!otp || otp.length < 6) {
      toast({ title: "Invalid OTP", description: "Please enter the 6-digit code", variant: "destructive" });
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.auth.verifyOtp({
        phone: phone,
        token: otp,
        type: 'sms',
      });

      if (error) throw error;

      toast({ title: "Verified", description: "Phone number authenticated successfully!" });
      
      if (onSuccess) {
        onSuccess(data);
      } else {
        navigate('/dashboard');
      }
    } catch (error) {
      console.error(error);
      toast({ 
        title: "Verification Failed", 
        description: error.message || "Invalid code", 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      {providerError && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Configuration Required</AlertTitle>
          <AlertDescription>
            Phone authentication is currently disabled. Please enable the <strong>Phone Provider</strong> in your Supabase Authentication settings.
          </AlertDescription>
        </Alert>
      )}

      {step === 'phone' ? (
        <form onSubmit={handleSendOtp} className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
          <div className="space-y-2">
            <Label htmlFor="phone">Mobile Number</Label>
            <div className="relative">
              <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="phone"
                type="tel"
                placeholder="+1 555 000 0000"
                className="pl-9"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                disabled={loading}
              />
            </div>
            <p className="text-xs text-muted-foreground">
              Enter your number with country code. Standard SMS rates apply.
            </p>
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ArrowRight className="mr-2 h-4 w-4" />}
            Send Login Code
          </Button>
        </form>
      ) : (
        <form onSubmit={handleVerifyOtp} className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
          <div className="text-center mb-4">
             <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-green-100 text-green-600 mb-2">
                <Phone className="h-6 w-6" />
             </div>
             <h3 className="text-lg font-medium">Verify your number</h3>
             <p className="text-sm text-muted-foreground">Enter the code sent to {phone}</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="otp">Verification Code</Label>
            <Input
              id="otp"
              type="text"
              placeholder="123456"
              className="text-center text-lg tracking-widest"
              maxLength={6}
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              disabled={loading}
            />
          </div>
          
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle2 className="mr-2 h-4 w-4" />}
            Verify & Login
          </Button>
          
          <div className="text-center">
            <Button 
              type="button" 
              variant="link" 
              className="text-xs" 
              onClick={() => setStep('phone')}
              disabled={loading}
            >
              Change phone number
            </Button>
          </div>
        </form>
      )}
    </div>
  );
};

export default PhoneAuthForm;
