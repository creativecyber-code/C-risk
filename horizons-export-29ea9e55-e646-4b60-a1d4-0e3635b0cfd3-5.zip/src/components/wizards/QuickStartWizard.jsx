
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Check, ChevronRight, ChevronLeft, Layout, Users, 
  Settings, Save, Sparkles, AlertCircle 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { wizardService } from '@/services/wizardService';
import { templateService } from '@/services/templateService';

// Sub-components for steps
import TemplateSelectionStep from './steps/TemplateSelectionStep';
import ModelDetailsStep from './steps/ModelDetailsStep';
import CustomizationStep from './steps/CustomizationStep';
import TeamStep from './steps/TeamStep';
import ReviewStep from './steps/ReviewStep';

const STEPS = [
  { id: 'template', title: 'Select Template', icon: Layout },
  { id: 'details', title: 'Model Details', icon: Settings },
  { id: 'customize', title: 'Customize', icon: Sparkles },
  { id: 'team', title: 'Add Team', icon: Users },
  { id: 'review', title: 'Review', icon: Check }
];

const QuickStartWizard = ({ onClose }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    templateId: '',
    template: null,
    name: '',
    description: '',
    customization: { addedComponents: [] },
    teamMembers: []
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Load draft on mount
  useEffect(() => {
    const load = async () => {
      const draft = await wizardService.loadDraft('current-user');
      if (draft) setFormData(draft);
    };
    load();
  }, []);

  // Auto-save on change
  useEffect(() => {
    wizardService.saveDraft('current-user', formData);
  }, [formData]);

  const handleNext = () => {
    if (currentStep < STEPS.length - 1) {
      if (validateStep(currentStep)) {
        setCurrentStep(prev => prev + 1);
      }
    } else {
      handleFinish();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const validateStep = (stepIndex) => {
    switch (stepIndex) {
      case 0: // Template
        if (!formData.templateId) {
          toast({ title: "Selection Required", description: "Please select a template to continue.", variant: "destructive" });
          return false;
        }
        return true;
      case 1: // Details
        if (!formData.name) {
          toast({ title: "Name Required", description: "Please provide a name for your threat model.", variant: "destructive" });
          return false;
        }
        return true;
      default:
        return true;
    }
  };

  const handleFinish = async () => {
    setLoading(true);
    try {
      const modelId = await wizardService.createModelFromWizard(formData);
      await wizardService.clearDraft('current-user');
      toast({ title: "Success!", description: "Threat model created successfully." });
      navigate(`/model/${modelId}`);
    } catch (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const updateData = (key, value) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const StepComponent = [
    TemplateSelectionStep,
    ModelDetailsStep,
    CustomizationStep,
    TeamStep,
    ReviewStep
  ][currentStep];

  return (
    <div className="flex flex-col h-full max-h-[85vh] bg-white rounded-xl shadow-2xl overflow-hidden border border-slate-200">
      {/* Header */}
      <div className="bg-slate-900 text-white p-6 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-brand-400" />
            Quick Start Wizard
          </h2>
          <p className="text-slate-400 text-sm mt-1">Create a comprehensive threat model in minutes</p>
        </div>
        <div className="flex items-center gap-2">
           <span className="text-sm font-medium text-slate-400">Step {currentStep + 1} of {STEPS.length}</span>
           <div className="w-32 h-2 bg-slate-800 rounded-full overflow-hidden">
             <div 
               className="h-full bg-brand-500 transition-all duration-500 ease-out" 
               style={{ width: `${((currentStep + 1) / STEPS.length) * 100}%` }}
             />
           </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden flex">
        {/* Sidebar Steps */}
        <div className="w-64 bg-slate-50 border-r border-slate-200 p-6 hidden md:block">
          <div className="space-y-1">
            {STEPS.map((step, index) => {
              const Icon = step.icon;
              const isActive = index === currentStep;
              const isCompleted = index < currentStep;
              
              return (
                <div 
                  key={step.id}
                  className={`
                    flex items-center gap-3 p-3 rounded-lg text-sm font-medium transition-colors
                    ${isActive ? 'bg-white text-brand-600 shadow-sm border border-slate-200' : 'text-slate-500'}
                    ${isCompleted ? 'text-green-600' : ''}
                  `}
                >
                  <div className={`
                    w-6 h-6 rounded-full flex items-center justify-center text-xs
                    ${isActive ? 'bg-brand-100 text-brand-600' : isCompleted ? 'bg-green-100 text-green-600' : 'bg-slate-200 text-slate-500'}
                  `}>
                    {isCompleted ? <Check className="w-3 h-3" /> : index + 1}
                  </div>
                  {step.title}
                </div>
              );
            })}
          </div>
        </div>

        {/* Dynamic Step Content */}
        <div className="flex-1 overflow-y-auto p-8 relative">
          <AnimatePresence mode='wait'>
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              <StepComponent 
                data={formData} 
                updateData={updateData} 
              />
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Footer Controls */}
      <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-between items-center">
        <Button variant="ghost" onClick={onClose} className="text-slate-500">
          Cancel
        </Button>
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            onClick={handleBack} 
            disabled={currentStep === 0 || loading}
          >
            <ChevronLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <Button 
            onClick={handleNext} 
            disabled={loading}
            className="min-w-[120px] bg-brand-600 hover:bg-brand-700"
          >
            {loading ? 'Creating...' : currentStep === STEPS.length - 1 ? 'Create Model' : 'Next Step'}
            {!loading && currentStep !== STEPS.length - 1 && <ChevronRight className="w-4 h-4 ml-2" />}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QuickStartWizard;
