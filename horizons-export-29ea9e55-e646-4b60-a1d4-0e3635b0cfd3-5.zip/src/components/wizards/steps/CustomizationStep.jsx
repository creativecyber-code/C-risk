
import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const COMPONENT_TYPES = [
  { type: 'process', label: 'Web Server', icon: 'server' },
  { type: 'store', label: 'Database', icon: 'database' },
  { type: 'interactor', label: 'External User', icon: 'user' },
  { type: 'process', label: 'Microservice', icon: 'cpu' }
];

const CustomizationStep = ({ data, updateData }) => {
  const handleAddComponent = (compType) => {
    const newComp = {
      id: `custom-${Date.now()}`,
      type: compType.type,
      label: `New ${compType.label}`,
      x: 100, 
      y: 100
    };
    
    const currentAdded = data.customization?.addedComponents || [];
    updateData('customization', {
      ...data.customization,
      addedComponents: [...currentAdded, newComp]
    });
  };

  const handleRemove = (id) => {
    const currentAdded = data.customization?.addedComponents || [];
    updateData('customization', {
      ...data.customization,
      addedComponents: currentAdded.filter(c => c.id !== id)
    });
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Customize Architecture</h2>
        <p className="text-slate-500 mt-1">Add extra components to the base template if needed.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Available Components */}
        <div className="space-y-4">
          <h3 className="font-semibold text-slate-700">Add Components</h3>
          <div className="grid grid-cols-2 gap-3">
            {COMPONENT_TYPES.map((comp, idx) => (
              <Button 
                key={idx} 
                variant="outline" 
                className="justify-start h-auto py-3"
                onClick={() => handleAddComponent(comp)}
              >
                <Plus className="w-4 h-4 mr-2 text-brand-600" />
                {comp.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Selected List */}
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
          <h3 className="font-semibold text-slate-700 mb-4">Included Components</h3>
          
          <div className="space-y-2">
            {/* Template Base Components (Read Only View) */}
            <div className="text-xs font-semibold text-slate-400 uppercase mb-2">From Template</div>
            {data.template?.elements?.map(el => (
              <div key={el.id} className="flex items-center justify-between bg-white p-2 rounded border border-slate-200 opacity-75">
                <span className="text-sm">{el.label}</span>
                <Badge variant="secondary" className="text-[10px]">Template</Badge>
              </div>
            ))}

            {/* Added Custom Components */}
            {data.customization?.addedComponents?.length > 0 && (
              <>
                <div className="text-xs font-semibold text-slate-400 uppercase mt-4 mb-2">Custom Added</div>
                {data.customization.addedComponents.map(el => (
                  <div key={el.id} className="flex items-center justify-between bg-white p-2 rounded border border-brand-200 shadow-sm">
                     <span className="text-sm font-medium">{el.label}</span>
                     <Button variant="ghost" size="sm" onClick={() => handleRemove(el.id)} className="h-6 w-6 p-0 text-red-400 hover:text-red-600">
                       <Trash2 className="w-3 h-3" />
                     </Button>
                  </div>
                ))}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomizationStep;
