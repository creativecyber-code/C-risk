
import React, { useEffect, useState } from 'react';
import { Search, Loader2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { templateService } from '@/services/templateService';
import TemplateCard from '@/components/templates/TemplateCard';

const TemplateSelectionStep = ({ data, updateData }) => {
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const load = async () => {
      const tpls = await templateService.getTemplates();
      setTemplates(tpls);
      setLoading(false);
    };
    load();
  }, []);

  const handleSelect = (tpl) => {
    updateData('templateId', tpl.id);
    updateData('template', tpl);
    // Auto-fill name if empty
    if (!data.name) updateData('name', `${tpl.name} Instance`);
  };

  const filtered = templates.filter(t => 
    t.name.toLowerCase().includes(search.toLowerCase()) || 
    t.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="text-center max-w-2xl mx-auto mb-8">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Choose a Starting Point</h2>
        <p className="text-slate-500">
          Select a template that best matches your architecture. We'll pre-populate components, threats, and mitigations for you.
        </p>
      </div>

      <div className="relative max-w-md mx-auto mb-8">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input 
          placeholder="Search templates (e.g., Microservices, AWS...)" 
          className="pl-10"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-brand-600" /></div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pb-4">
          {filtered.map(tpl => (
            <div 
              key={tpl.id} 
              className={`
                cursor-pointer transition-all ring-2 ring-offset-2 rounded-xl
                ${data.templateId === tpl.id ? 'ring-brand-500 scale-[1.02]' : 'ring-transparent hover:ring-slate-200'}
              `}
              onClick={() => handleSelect(tpl)}
            >
              <TemplateCard template={tpl} onSelect={() => handleSelect(tpl)} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default TemplateSelectionStep;
