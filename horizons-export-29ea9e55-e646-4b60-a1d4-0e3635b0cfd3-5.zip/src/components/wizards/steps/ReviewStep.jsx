
import React from 'react';
import { CheckCircle2, ShieldCheck, Layers, Users } from 'lucide-react';
import { Card } from '@/components/ui/card';

const ReviewStep = ({ data }) => {
  const totalComponents = (data.template?.elements?.length || 0) + (data.customization?.addedComponents?.length || 0);

  return (
    <div className="space-y-8 max-w-2xl mx-auto">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-slate-900">Ready to Create?</h2>
        <p className="text-slate-500 mt-2">Review your configuration before generating the model.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-4 bg-brand-50 border-brand-100">
          <div className="flex items-start gap-3">
             <Layers className="w-5 h-5 text-brand-600 mt-1" />
             <div>
               <h3 className="font-semibold text-brand-900">Template</h3>
               <p className="text-sm text-brand-700">{data.template?.name}</p>
               <div className="mt-2 text-xs text-brand-600">
                 {data.template?.industry} • {data.template?.complexity}
               </div>
             </div>
          </div>
        </Card>

        <Card className="p-4 bg-green-50 border-green-100">
          <div className="flex items-start gap-3">
             <ShieldCheck className="w-5 h-5 text-green-600 mt-1" />
             <div>
               <h3 className="font-semibold text-green-900">Details</h3>
               <p className="text-sm text-green-700">{data.name}</p>
               <div className="mt-2 text-xs text-green-600">
                 {totalComponents} Components • {data.template?.threatCount} Est. Threats
               </div>
             </div>
          </div>
        </Card>
      </div>

      <div className="bg-white rounded-xl border p-6 space-y-4 shadow-sm">
        <h3 className="font-semibold text-slate-900 border-b pb-2">Configuration Summary</h3>
        
        <div className="grid grid-cols-2 gap-y-4 text-sm">
           <div className="text-slate-500">Model Name</div>
           <div className="font-medium">{data.name}</div>

           <div className="text-slate-500">Base Template</div>
           <div className="font-medium">{data.template?.name}</div>

           <div className="text-slate-500">Custom Components</div>
           <div className="font-medium">{data.customization?.addedComponents?.length || 0} added</div>

           <div className="text-slate-500">Team Members</div>
           <div className="font-medium">{data.teamMembers.length} invited</div>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-100">
           <div className="flex items-center gap-2 text-sm text-slate-600">
             <CheckCircle2 className="w-4 h-4 text-green-500" />
             <span>Automated STRIDE analysis will run immediately upon creation.</span>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ReviewStep;
