
import React, { useState } from 'react';
import { Plus, User, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

const TeamStep = ({ data, updateData }) => {
  const [email, setEmail] = useState('');

  const handleAdd = () => {
    if (email && !data.teamMembers.includes(email)) {
      updateData('teamMembers', [...data.teamMembers, email]);
      setEmail('');
    }
  };

  const handleRemove = (emailToRemove) => {
    updateData('teamMembers', data.teamMembers.filter(e => e !== emailToRemove));
  };

  return (
    <div className="max-w-xl mx-auto space-y-8">
      <div className="text-center mb-4">
        <h2 className="text-2xl font-bold text-slate-900">Team Access</h2>
        <p className="text-slate-500 mt-2">Invite collaborators to work on this model.</p>
      </div>

      <div className="bg-white p-6 rounded-xl border shadow-sm space-y-6">
         <div className="flex gap-2">
           <Input 
             placeholder="colleague@example.com" 
             value={email}
             onChange={(e) => setEmail(e.target.value)}
             onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
           />
           <Button onClick={handleAdd} disabled={!email}>
             <Plus className="w-4 h-4 mr-2" /> Add
           </Button>
         </div>

         <div className="space-y-3">
           {data.teamMembers.length === 0 ? (
             <div className="text-center text-slate-400 py-4 text-sm">
               No team members added yet. You can add them later.
             </div>
           ) : (
             data.teamMembers.map((member, i) => (
               <div key={i} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                 <div className="flex items-center gap-3">
                   <Avatar className="h-8 w-8">
                     <AvatarFallback className="bg-brand-100 text-brand-600">
                       <User className="w-4 h-4" />
                     </AvatarFallback>
                   </Avatar>
                   <span className="text-sm font-medium text-slate-700">{member}</span>
                 </div>
                 <Button variant="ghost" size="sm" onClick={() => handleRemove(member)}>
                   <X className="w-4 h-4 text-slate-400 hover:text-red-500" />
                 </Button>
               </div>
             ))
           )}
         </div>
      </div>
    </div>
  );
};

export default TeamStep;
