
import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const ModelDetailsStep = ({ data, updateData }) => {
  return (
    <div className="max-w-xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-slate-900">Model Details</h2>
        <p className="text-slate-500 mt-2">Define the scope and context of your threat model.</p>
      </div>

      <div className="space-y-4 bg-white p-6 rounded-xl border shadow-sm">
        <div className="space-y-2">
          <Label htmlFor="name">Model Name</Label>
          <Input 
            id="name" 
            value={data.name} 
            onChange={(e) => updateData('name', e.target.value)}
            placeholder="e.g. Payment Gateway Service V2"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="desc">Description</Label>
          <Textarea 
            id="desc" 
            value={data.description} 
            onChange={(e) => updateData('description', e.target.value)}
            placeholder="Describe the architecture, purpose, and key data flows..."
            rows={4}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Owner</Label>
            <Input value="Current User (You)" disabled className="bg-slate-50" />
          </div>
          <div className="space-y-2">
            <Label>Visibility</Label>
            <Select defaultValue="private">
              <SelectTrigger>
                <SelectValue placeholder="Select visibility" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="private">Private</SelectItem>
                <SelectItem value="org">Organization Wide</SelectItem>
                <SelectItem value="public">Public</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModelDetailsStep;
