
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Shield, Smartphone, Key, AlertTriangle, CheckCircle2, ArrowRight } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const SecuritySettings = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [factors, setFactors] = useState([]);
  const [backupCodesAvailable, setBackupCodesAvailable] = useState(false);
  const [factorToRemove, setFactorToRemove] = useState(null);

  useEffect(() => {
    fetchSecurityStatus();
  }, []);

  const fetchSecurityStatus = async () => {
    try {
      setLoading(true);
      // 1. Fetch Factors
      const { data, error } = await supabase.auth.mfa.listFactors();
      if (error) throw error;
      const verified = data.totp.filter(f => f.status === 'verified');
      setFactors(verified);

      // 2. Check for backup codes (RPC)
      const { data: mfaStatus, error: statusError } = await supabase.rpc('get_user_mfa_status', { 
        p_user_id: (await supabase.auth.getUser()).data.user.id 
      });
      
      if (!statusError && mfaStatus) {
         setBackupCodesAvailable(mfaStatus.backup_codes_remaining > 0);
      }

    } catch (error) {
      console.error('Error fetching security status:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUnenroll = async () => {
    if (!factorToRemove) return;
    try {
      setLoading(true);
      const { error } = await supabase.auth.mfa.unenroll({ factorId: factorToRemove });
      if (error) throw error;
      
      toast({ title: "MFA Factor Removed", description: "You have disabled this authentication method." });
      setFactorToRemove(null);
      fetchSecurityStatus();
    } catch (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const navigateToSetup = () => {
    navigate('/mfa-setup');
  };

  if (loading) {
    return <div className="py-4 text-sm text-slate-500">Checking security configuration...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 pb-2">
        <div className="p-2 bg-slate-100 rounded-lg">
           <Shield className="w-6 h-6 text-slate-700" />
        </div>
        <div>
          <h3 className="text-lg font-medium text-slate-900">Authentication Methods</h3>
          <p className="text-sm text-slate-500">Manage how you sign in to C-RISK.</p>
        </div>
      </div>

      {factors.length === 0 ? (
        <Card className="border-l-4 border-l-amber-500">
          <CardContent className="pt-6">
            <div className="flex gap-4 items-start">
              <AlertTriangle className="w-6 h-6 text-amber-500 shrink-0 mt-1" />
              <div className="space-y-2">
                <h3 className="font-semibold text-amber-800">MFA is Disabled</h3>
                <p className="text-sm text-slate-600 max-w-lg">
                  Your account is currently protected only by a password. Enabling Multi-Factor Authentication (MFA) adds a critical layer of security against unauthorized access.
                </p>
                <Button onClick={navigateToSetup} className="mt-2 bg-amber-600 hover:bg-amber-700 text-white">
                  Enable MFA Now <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Active Factors</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
             {factors.map(factor => (
                <div key={factor.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100 mb-2">
                   <div className="flex items-center gap-3">
                      <div className="bg-white p-2 rounded shadow-sm">
                         <Smartphone className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                         <p className="font-medium text-slate-900">Authenticator App (TOTP)</p>
                         <p className="text-xs text-slate-500">Added: {new Date(factor.created_at).toLocaleDateString()}</p>
                      </div>
                   </div>
                   <AlertDialog>
                      <AlertDialogTrigger asChild>
                         <Button variant="ghost" size="sm" onClick={() => setFactorToRemove(factor.id)} className="text-red-600 hover:text-red-700 hover:bg-red-50">
                            Remove
                         </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                         <AlertDialogTitle>Remove this authentication method?</AlertDialogTitle>
                         <AlertDialogDescription>
                            Removing this factor will lower your account security. If this is your only factor, MFA will be disabled.
                         </AlertDialogDescription>
                         <div className="flex gap-3 justify-end mt-4">
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleUnenroll} className="bg-red-600 hover:bg-red-700">
                               Yes, Remove It
                            </AlertDialogAction>
                         </div>
                      </AlertDialogContent>
                   </AlertDialog>
                </div>
             ))}

             <div className="mt-6 pt-4 border-t border-slate-100">
                <div className="flex items-center justify-between">
                   <div className="flex items-center gap-3">
                      <Key className="w-4 h-4 text-slate-400" />
                      <div>
                         <p className="text-sm font-medium text-slate-700">Recovery Codes</p>
                         <p className="text-xs text-slate-500">
                            {backupCodesAvailable 
                               ? "Backup codes are active." 
                               : "No backup codes found."}
                         </p>
                      </div>
                   </div>
                   <Button variant="outline" size="sm" onClick={navigateToSetup}>
                      Regenerate Codes
                   </Button>
                </div>
             </div>
          </CardContent>
          <CardFooter className="bg-slate-50 p-3 rounded-b-xl border-t border-slate-100 flex justify-center">
             <Button variant="link" size="sm" onClick={navigateToSetup} className="text-blue-600">
                Add Another Device
             </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
};

export default SecuritySettings;
