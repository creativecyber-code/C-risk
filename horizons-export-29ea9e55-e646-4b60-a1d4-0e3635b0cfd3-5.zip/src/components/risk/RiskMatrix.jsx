
import React from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, ZAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { getRiskLevel } from '@/utils/riskCalculations';

const RiskMatrix = ({ threats, onThreatClick }) => {
  const data = threats.map(t => ({
    x: t.likelihood_score,
    y: t.impact_score,
    z: 1, // Bubble size
    name: t.title,
    id: t.threat_source_id,
    risk: t.risk_score
  }));

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 border border-slate-700 p-2 rounded shadow-xl text-xs text-white z-50">
          <p className="font-bold mb-1">{data.name}</p>
          <p>Impact: {data.y}</p>
          <p>Likelihood: {data.x}</p>
          <p className="mt-1">Risk Score: <span className="font-bold">{data.risk}</span></p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full h-[400px] relative bg-slate-50 rounded-lg border border-slate-200">
      {/* Background Zones */}
      <div className="absolute inset-0 m-[40px] mb-[30px] ml-[50px] pointer-events-none opacity-20">
        <div className="w-full h-full grid grid-cols-2 grid-rows-2">
           <div className="bg-yellow-200 border-r border-b border-white"></div> {/* Low/Med */}
           <div className="bg-orange-200 border-b border-white"></div> {/* High */}
           <div className="bg-green-200 border-r border-white"></div> {/* Low */}
           <div className="bg-red-200"></div> {/* Critical */}
        </div>
      </div>

      <ResponsiveContainer width="100%" height="100%">
        <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
          <XAxis 
            type="number" 
            dataKey="x" 
            name="Likelihood" 
            unit="" 
            domain={[0, 10]} 
            label={{ value: 'Likelihood', position: 'bottom', offset: 0 }} 
          />
          <YAxis 
            type="number" 
            dataKey="y" 
            name="Impact" 
            unit="" 
            domain={[0, 10]} 
            label={{ value: 'Impact', angle: -90, position: 'left' }} 
          />
          <ZAxis type="number" dataKey="z" range={[100, 100]} />
          <Tooltip content={<CustomTooltip />} cursor={{ strokeDasharray: '3 3' }} />
          <Scatter name="Threats" data={data} onClick={(p) => onThreatClick(p.payload)}>
            {data.map((entry, index) => {
              const level = getRiskLevel(entry.risk);
              return <Cell key={`cell-${index}`} fill={level.color.replace('bg-', 'rgb(var(--color-').replace(')', '))')} className={level.text.replace('text-', 'fill-')} />;
            })}
          </Scatter>
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
};

export default RiskMatrix;
