
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { getRiskLevel, calculateFAIR, formatCurrency } from '@/utils/riskCalculations';
import { AlertTriangle, Info, Calculator, DollarSign, Percent } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const RiskAssessmentModal = ({ isOpen, onClose, assessment, onSave }) => {
  const [formData, setFormData] = useState({
    impact: '5',
    likelihood: '5',
    status: 'Open',
    justification: '',
    // FAIR Parameters
    tef: '1.0',
    vulnerability: '100',
    lossMagnitude: '0'
  });

  useEffect(() => {
    if (assessment) {
      setFormData({
        impact: assessment.impact_score?.toString() || '5',
        likelihood: assessment.likelihood_score?.toString() || '5',
        status: assessment.status || 'Open',
        justification: assessment.justification || '',
        tef: assessment.tef?.toString() || '1.0',
        vulnerability: assessment.vulnerability_percentage?.toString() || '100',
        lossMagnitude: assessment.loss_magnitude?.toString() || '0'
      });
    }
  }, [assessment]);

  // Qualitative Score
  const impactVal = parseFloat(formData.impact);
  const likelihoodVal = parseFloat(formData.likelihood);
  const riskScore = ((impactVal * 0.6) + (likelihoodVal * 0.4)).toFixed(1);
  const riskLevel = getRiskLevel(riskScore);

  // Quantitative Score (FAIR)
  const tef = parseFloat(formData.tef) || 0;
  const vulnerability = parseFloat(formData.vulnerability) || 0;
  const lossMagnitude = parseFloat(formData.lossMagnitude) || 0;
  const ale = calculateFAIR(tef, vulnerability, lossMagnitude);

  const handleSave = () => {
    onSave({
      ...assessment,
      impact_score: impactVal,
      likelihood_score: likelihoodVal,
      risk_score: parseFloat(riskScore),
      status: formData.status,
      justification: formData.justification,
      // FAIR Data
      tef: tef,
      vulnerability_percentage: vulnerability,
      loss_magnitude: lossMagnitude,
      ale: ale
    });
    onClose();
  };

  const SCORE_OPTIONS = [
    { value: '1', label: '1 - Very Low' },
    { value: '2', label: '2 - Low' },
    { value: '3', label: '3 - Low-Medium' },
    { value: '4', label: '4 - Medium' },
    { value: '5', label: '5 - Medium' },
    { value: '6', label: '6 - Medium-High' },
    { value: '7', label: '7 - High' },
    { value: '8', label: '8 - Very High' },
    { value: '9', label: '9 - Critical' },
    { value: '10', label: '10 - Extreme' },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex flex-col gap-1">
            <span>Assess Risk</span>
            <span className="text-sm font-normal text-slate-500">{assessment?.title}</span>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="qualitative" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="qualitative">Qualitative (Score)</TabsTrigger>
            <TabsTrigger value="quantitative">Quantitative (FAIR)</TabsTrigger>
          </TabsList>
          
          <div className="py-2 min-h-[300px]">
            {/* --- Qualitative Tab --- */}
            <TabsContent value="qualitative" className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Impact Score (1-10)</Label>
                  <Select 
                    value={formData.impact} 
                    onValueChange={(v) => setFormData({...formData, impact: v})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SCORE_OPTIONS.map(opt => (
                        <SelectItem key={`impact-${opt.value}`} value={opt.value}>
                          {opt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-[10px] text-slate-500">Severity of damage if exploited.</p>
                </div>

                <div className="space-y-2">
                  <Label>Likelihood Score (1-10)</Label>
                  <Select 
                    value={formData.likelihood} 
                    onValueChange={(v) => setFormData({...formData, likelihood: v})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SCORE_OPTIONS.map(opt => (
                        <SelectItem key={`like-${opt.value}`} value={opt.value}>
                          {opt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-[10px] text-slate-500">Probability of occurrence.</p>
                </div>
              </div>

              <div className="bg-slate-50 p-4 rounded-lg border border-slate-100 flex items-center justify-between">
                <div className="text-sm font-medium text-slate-600">Calculated Risk Score</div>
                <div className="flex items-center gap-3">
                  <span className={`text-3xl font-bold ${riskLevel.text}`}>{riskScore}</span>
                  <Badge className={riskLevel.color}>{riskLevel.label}</Badge>
                </div>
              </div>
            </TabsContent>

            {/* --- Quantitative (FAIR) Tab --- */}
            <TabsContent value="quantitative" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs font-semibold uppercase text-slate-500">Threat Event Freq.</Label>
                  <div className="relative">
                    <Input 
                      type="number" 
                      step="0.1"
                      min="0"
                      value={formData.tef} 
                      onChange={(e) => setFormData({...formData, tef: e.target.value})}
                      className="pl-8"
                    />
                    <Calculator className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
                  </div>
                  <p className="text-[10px] text-slate-400">Times per year threat occurs.</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs font-semibold uppercase text-slate-500">Vulnerability (%)</Label>
                  <div className="relative">
                    <Input 
                      type="number" 
                      min="0"
                      max="100"
                      value={formData.vulnerability} 
                      onChange={(e) => setFormData({...formData, vulnerability: e.target.value})}
                      className="pl-8"
                    />
                    <Percent className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
                  </div>
                  <p className="text-[10px] text-slate-400">Prob. of successful exploit.</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs font-semibold uppercase text-slate-500">Loss Magnitude</Label>
                  <div className="relative">
                    <Input 
                      type="number" 
                      min="0"
                      value={formData.lossMagnitude} 
                      onChange={(e) => setFormData({...formData, lossMagnitude: e.target.value})}
                      className="pl-8"
                    />
                    <DollarSign className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
                  </div>
                  <p className="text-[10px] text-slate-400">Financial loss per event ($).</p>
                </div>
              </div>

              <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-100 flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-medium text-emerald-800 flex items-center gap-2">
                    <Calculator className="w-4 h-4" />
                    Annual Loss Expectancy (ALE)
                  </div>
                  <p className="text-xs text-emerald-600 mt-1">
                    Risk = TEF × Vuln% × Loss
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-3xl font-bold text-emerald-700 tracking-tight">
                    {formatCurrency(ale)}
                  </span>
                </div>
              </div>
            </TabsContent>
          </div>

          <Separator className="my-4" />

          {/* Common Fields */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Status</Label>
              <Select 
                value={formData.status} 
                onValueChange={(v) => setFormData({...formData, status: v})}
              >
                <SelectTrigger className={
                  formData.status === 'Accepted' ? 'border-orange-300 bg-orange-50 text-orange-800' :
                  formData.status === 'Mitigated' ? 'border-green-300 bg-green-50 text-green-800' : ''
                }>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Open">Open</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="Mitigated">Mitigated</SelectItem>
                  <SelectItem value="Accepted">Accepted (Risk Acceptance)</SelectItem>
                  <SelectItem value="False Positive">False Positive</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.status === 'Accepted' && (
              <div className="space-y-2 animate-in fade-in slide-in-from-top-1">
                <Label className="flex items-center gap-2">
                  Business Justification <span className="text-red-500">*</span>
                  <Info className="w-3 h-3 text-slate-400" />
                </Label>
                <Textarea
                  value={formData.justification}
                  onChange={(e) => setFormData({...formData, justification: e.target.value})}
                  placeholder="Why is the business accepting this risk? (Required for executive reporting)"
                  className="min-h-[100px]"
                />
                <p className="text-xs text-orange-600 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" />
                  This will be logged in the Executive Risk Report.
                </p>
              </div>
            )}
          </div>

          <DialogFooter className="mt-6">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSave}>Save Assessment</Button>
          </DialogFooter>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default RiskAssessmentModal;
