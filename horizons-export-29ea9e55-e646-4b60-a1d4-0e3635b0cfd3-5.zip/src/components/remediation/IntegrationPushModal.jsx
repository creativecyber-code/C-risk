
import React, { useState, useEffect } from 'react';
import { DialogFooter, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { integrationService } from '@/services/integrationService';
import { remediationService } from '@/services/remediationService';
import { Loader2, ArrowRight } from 'lucide-react';

const IntegrationPushModal = ({ selectedThreats, onClose, onSuccess }) => {
  const [integrations, setIntegrations] = useState([]);
  const [selectedIntegration, setSelectedIntegration] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingIntegrations, setLoadingIntegrations] = useState(true);
  const [pushResult, setPushResult] = useState(null);

  useEffect(() => {
    const loadIntegrations = async () => {
      try {
        const data = await integrationService.getMyIntegrations();
        // Filter for ticketing/issue tracking tools ideally, but we'll show all active
        setIntegrations(data.filter(i => i.status === 'active'));
      } catch (err) {
        console.error(err);
      } finally {
        setLoadingIntegrations(false);
      }
    };
    loadIntegrations();
  }, []);

  const handlePush = async () => {
    if (!selectedIntegration || selectedThreats.length === 0) return;

    setLoading(true);
    const results = { success: 0, failed: 0 };

    try {
      const integration = integrations.find(i => i.id === selectedIntegration);
      
      // Process serially to avoid overwhelming mock backend (and for better UX demo)
      for (const threat of selectedThreats) {
        try {
          const { externalId, url } = await integrationService.pushThreatToExternal(selectedIntegration, threat);
          
          // Update threat record
          await remediationService.saveThreatExternalRef(threat.id, integration.provider_key, externalId, url);
          
          results.success++;
        } catch (error) {
          console.error(`Failed to push threat ${threat.id}`, error);
          results.failed++;
        }
      }
      
      setPushResult(results);
      if (results.success > 0) {
        setTimeout(() => onSuccess(results), 1500); // Wait a bit then close
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  if (pushResult) {
    return (
      <div className="py-6 text-center space-y-4">
         <div className="flex justify-center">
            <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center text-green-600">
               <ArrowRight className="h-6 w-6" />
            </div>
         </div>
         <h3 className="text-lg font-medium">Sync Complete</h3>
         <p className="text-slate-500">
           Successfully pushed {pushResult.success} items. 
           {pushResult.failed > 0 && ` Failed: ${pushResult.failed}.`}
         </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pt-4">
      <DialogHeader>
        <DialogTitle>Push to External Tool</DialogTitle>
        <DialogDescription>
          Sync {selectedThreats.length} selected threat(s) to your project management tool.
        </DialogDescription>
      </DialogHeader>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Select Destination</Label>
          <Select value={selectedIntegration} onValueChange={setSelectedIntegration} disabled={loading}>
            <SelectTrigger>
              <SelectValue placeholder={loadingIntegrations ? "Loading..." : "Select integration"} />
            </SelectTrigger>
            <SelectContent>
              {integrations.length === 0 && !loadingIntegrations ? (
                <SelectItem value="none" disabled>No active integrations found</SelectItem>
              ) : (
                integrations.map(i => (
                  <SelectItem key={i.id} value={i.id}>{i.name} ({i.provider_key})</SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
          {integrations.length === 0 && !loadingIntegrations && (
             <p className="text-xs text-red-500">Please configure integrations in Settings first.</p>
          )}
        </div>

        <div className="bg-slate-50 p-3 rounded-md border text-sm text-slate-600">
          <p className="font-medium mb-1">Mapping Preview:</p>
          <ul className="list-disc pl-4 space-y-1 text-xs">
             <li>Threat Title → Issue Summary</li>
             <li>Risk Score → Priority/Severity</li>
             <li>Description → Description</li>
             <li>Mitigation → Acceptance Criteria</li>
          </ul>
        </div>
      </div>

      <DialogFooter>
        <Button variant="outline" onClick={onClose} disabled={loading}>Cancel</Button>
        <Button 
          onClick={handlePush} 
          disabled={!selectedIntegration || loading || selectedThreats.length === 0}
          className="bg-brand-600 hover:bg-brand-700"
        >
          {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin"/> Syncing...</> : 'Push Threats'}
        </Button>
      </DialogFooter>
    </div>
  );
};

export default IntegrationPushModal;
