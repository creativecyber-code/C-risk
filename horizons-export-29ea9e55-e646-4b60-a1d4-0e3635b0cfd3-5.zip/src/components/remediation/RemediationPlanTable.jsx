
import React, { useState, useMemo } from 'react';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowUpDown, Filter, MoreHorizontal, CheckCircle2, 
  ExternalLink, Share2, Search, XCircle, LayoutGrid
} from 'lucide-react';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, 
  DropdownMenuSeparator, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const RemediationPlanTable = ({ 
  threats, 
  onCloseThreat, 
  onPushThreat, 
  onSelectionChange 
}) => {
  const [sortConfig, setSortConfig] = useState({ key: 'risk_score', direction: 'desc' });
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [filterText, setFilterText] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [severityFilter, setSeverityFilter] = useState('all');
  const [modelFilter, setModelFilter] = useState('all');

  // Derive unique model names for filter dropdown
  const modelNames = useMemo(() => {
    const names = new Set(threats.map(t => t.model_name || 'Unknown'));
    return Array.from(names).sort();
  }, [threats]);

  // Handle Selection
  const toggleSelection = (id) => {
    const newSelection = new Set(selectedIds);
    if (newSelection.has(id)) newSelection.delete(id);
    else newSelection.add(id);
    setSelectedIds(newSelection);
    onSelectionChange(Array.from(newSelection));
  };

  const toggleAll = () => {
    if (selectedIds.size === filteredThreats.length) {
      setSelectedIds(new Set());
      onSelectionChange([]);
    } else {
      const allIds = new Set(filteredThreats.map(t => t.id));
      setSelectedIds(allIds);
      onSelectionChange(Array.from(allIds));
    }
  };

  // Sort & Filter
  const filteredThreats = useMemo(() => {
    return threats.filter(t => {
      const matchesText = t.title?.toLowerCase().includes(filterText.toLowerCase());
      const matchesStatus = statusFilter === 'all' || t.status === statusFilter;
      const matchesModel = modelFilter === 'all' || t.model_name === modelFilter;
      
      let matchesSeverity = true;
      if (severityFilter !== 'all') {
        const score = t.risk_score || 0;
        if (severityFilter === 'High') matchesSeverity = score >= 70;
        else if (severityFilter === 'Medium') matchesSeverity = score >= 30 && score < 70;
        else if (severityFilter === 'Low') matchesSeverity = score < 30;
      }

      return matchesText && matchesStatus && matchesSeverity && matchesModel;
    }).sort((a, b) => {
      if (!sortConfig.key) return 0;
      const aVal = a[sortConfig.key] || '';
      const bVal = b[sortConfig.key] || '';
      
      if (a[sortConfig.key] === b[sortConfig.key]) return 0;
      
      const comparison = aVal > bVal ? 1 : -1;
      return sortConfig.direction === 'asc' ? comparison : -comparison;
    });
  }, [threats, filterText, statusFilter, severityFilter, modelFilter, sortConfig]);

  const handleSort = (key) => {
    setSortConfig(current => ({
      key,
      direction: current.key === key && current.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const getSeverityBadge = (score) => {
    if (score >= 80) return <Badge className="bg-red-100 text-red-800 hover:bg-red-200 border-none">Critical</Badge>;
    if (score >= 60) return <Badge className="bg-orange-100 text-orange-800 hover:bg-orange-200 border-none">High</Badge>;
    if (score >= 30) return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200 border-none">Medium</Badge>;
    return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200 border-none">Low</Badge>;
  };

  const getStatusBadge = (status) => {
    const styles = {
      'Open': 'bg-slate-100 text-slate-800',
      'In Progress': 'bg-blue-100 text-blue-800',
      'Resolved': 'bg-green-100 text-green-800',
      'Closed': 'bg-gray-100 text-gray-800 line-through'
    };
    return <Badge className={`border-none ${styles[status] || styles['Open']}`}>{status || 'Open'}</Badge>;
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col xl:flex-row gap-4 justify-between items-start xl:items-center">
        <div className="relative w-full xl:w-80">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-slate-500" />
          <Input 
            placeholder="Search by threat title..." 
            className="pl-8"
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
          />
        </div>
        
        <div className="flex flex-wrap gap-2 w-full xl:w-auto">
           <Select value={modelFilter} onValueChange={setModelFilter}>
             <SelectTrigger className="w-[180px]">
               <LayoutGrid className="w-3 h-3 mr-2" />
               <SelectValue placeholder="All Models" />
             </SelectTrigger>
             <SelectContent>
               <SelectItem value="all">All Models</SelectItem>
               {modelNames.map(name => (
                 <SelectItem key={name} value={name}>{name}</SelectItem>
               ))}
             </SelectContent>
           </Select>

           <Select value={statusFilter} onValueChange={setStatusFilter}>
             <SelectTrigger className="w-[130px]">
               <Filter className="w-3 h-3 mr-2" />
               <SelectValue placeholder="Status" />
             </SelectTrigger>
             <SelectContent>
               <SelectItem value="all">All Status</SelectItem>
               <SelectItem value="Open">Open</SelectItem>
               <SelectItem value="In Progress">In Progress</SelectItem>
               <SelectItem value="Resolved">Resolved</SelectItem>
             </SelectContent>
           </Select>
           
           <Select value={severityFilter} onValueChange={setSeverityFilter}>
             <SelectTrigger className="w-[130px]">
               <Filter className="w-3 h-3 mr-2" />
               <SelectValue placeholder="Severity" />
             </SelectTrigger>
             <SelectContent>
               <SelectItem value="all">All Severity</SelectItem>
               <SelectItem value="High">High+</SelectItem>
               <SelectItem value="Medium">Medium</SelectItem>
               <SelectItem value="Low">Low</SelectItem>
             </SelectContent>
           </Select>
        </div>
      </div>

      <div className="rounded-md border bg-white shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[40px]">
                <Checkbox 
                  checked={filteredThreats.length > 0 && selectedIds.size === filteredThreats.length}
                  onCheckedChange={toggleAll}
                />
              </TableHead>
              <TableHead className="cursor-pointer" onClick={() => handleSort('title')}>
                Threat <ArrowUpDown className="ml-1 h-3 w-3 inline" />
              </TableHead>
              <TableHead className="cursor-pointer" onClick={() => handleSort('risk_score')}>
                Severity <ArrowUpDown className="ml-1 h-3 w-3 inline" />
              </TableHead>
              <TableHead>Model</TableHead>
              <TableHead>STRIDE</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Integrations</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredThreats.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="h-24 text-center">
                  <div className="flex flex-col items-center justify-center text-slate-500">
                     <p>No threats found matching your filters.</p>
                     {(filterText || statusFilter !== 'all' || severityFilter !== 'all' || modelFilter !== 'all') && (
                       <Button variant="link" onClick={() => {
                         setFilterText('');
                         setStatusFilter('all');
                         setSeverityFilter('all');
                         setModelFilter('all');
                       }}>Clear filters</Button>
                     )}
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              filteredThreats.map((threat) => (
                <TableRow key={threat.id} className="group hover:bg-slate-50/50 transition-colors">
                  <TableCell>
                    <Checkbox 
                      checked={selectedIds.has(threat.id)}
                      onCheckedChange={() => toggleSelection(threat.id)}
                    />
                  </TableCell>
                  <TableCell className="font-medium max-w-[250px]">
                    <div className="flex flex-col">
                      <span className="truncate" title={threat.title}>{threat.title}</span>
                      <span className="text-[10px] text-slate-400 mt-0.5 font-normal truncate">ID: {threat.id.slice(0,8)}...</span>
                    </div>
                  </TableCell>
                  <TableCell>{getSeverityBadge(threat.risk_score)}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1.5 max-w-[150px]">
                       <LayoutGrid className="w-3 h-3 text-slate-400 shrink-0" />
                       <span className="text-sm text-slate-600 truncate" title={threat.model_name}>{threat.model_name}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                     <Badge variant="outline" className="font-normal text-xs text-slate-500 bg-white">
                        {threat.category || 'Unknown'}
                     </Badge>
                  </TableCell>
                  <TableCell>{getStatusBadge(threat.status)}</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      {threat.external_refs && Object.entries(threat.external_refs).map(([tool, data]) => (
                        <TooltipProvider key={tool}>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <a 
                                href={data.url} 
                                target="_blank" 
                                rel="noreferrer"
                                className="inline-flex items-center justify-center w-6 h-6 rounded bg-slate-100 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 border border-slate-200 transition-colors"
                              >
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="capitalize font-medium">{tool}</p>
                              <p className="text-xs opacity-80">{data.id}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      ))}
                      {(!threat.external_refs || Object.keys(threat.external_refs).length === 0) && <span className="text-xs text-slate-300">-</span>}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => onPushThreat([threat])}>
                          <Share2 className="mr-2 h-4 w-4" /> Push to External Tool
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => onCloseThreat(threat.id)} className="text-green-600 focus:text-green-700">
                          <CheckCircle2 className="mr-2 h-4 w-4" /> Mark as Resolved
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-slate-500">
                           <XCircle className="mr-2 h-4 w-4" /> Mark as False Positive
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      <div className="text-xs text-slate-500 flex justify-between items-center">
        <span>Showing {filteredThreats.length} of {threats.length} threats.</span>
        <span>Selection: {selectedIds.size}</span>
      </div>
    </div>
  );
};

export default RemediationPlanTable;
