
import React from 'react';
import { format, differenceInDays, addDays, startOfWeek, endOfWeek } from 'date-fns';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const RemediationTimeline = ({ plans }) => {
  // Determine date range for the timeline
  const today = new Date();
  const startDate = startOfWeek(addDays(today, -14)); // Start 2 weeks ago
  const endDate = endOfWeek(addDays(today, 28)); // End 4 weeks ahead
  const totalDays = differenceInDays(endDate, startDate) + 1;
  const days = Array.from({ length: totalDays }, (_, i) => addDays(startDate, i));

  const getStatusColor = (status) => {
    switch(status) {
      case 'Completed': return 'bg-green-500';
      case 'In Progress': return 'bg-blue-500';
      case 'Overdue': return 'bg-red-500';
      case 'On Hold': return 'bg-yellow-500';
      case 'Cancelled': return 'bg-slate-400';
      default: return 'bg-slate-300';
    }
  };

  const calculatePosition = (start, end) => {
    const planStart = start ? new Date(start) : today;
    const planEnd = end ? new Date(end) : addDays(today, 7);
    
    // Clamp to timeline view
    const viewStart = startDate;
    const viewEnd = endDate;

    const effectiveStart = planStart < viewStart ? viewStart : planStart;
    const effectiveEnd = planEnd > viewEnd ? viewEnd : planEnd;

    if (effectiveEnd < viewStart || effectiveStart > viewEnd) return null;

    const offsetDays = differenceInDays(effectiveStart, startDate);
    const durationDays = differenceInDays(effectiveEnd, effectiveStart) + 1;

    return {
      left: `${(offsetDays / totalDays) * 100}%`,
      width: `${(durationDays / totalDays) * 100}%`
    };
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader>
        <CardTitle>Remediation Roadmap</CardTitle>
      </CardHeader>
      <CardContent className="p-0 overflow-x-auto">
        <div className="min-w-[800px]">
          {/* Header Dates */}
          <div className="flex border-b border-slate-100 bg-slate-50">
            <div className="w-64 p-3 font-semibold text-xs text-slate-500 border-r shrink-0 sticky left-0 bg-slate-50 z-10">Task</div>
            <div className="flex-1 flex">
              {days.map((day, i) => (
                <div key={i} className={cn(
                  "flex-1 min-w-[30px] text-[10px] text-center p-1 border-r border-slate-100",
                  day.getDay() === 0 || day.getDay() === 6 ? "bg-slate-50" : "bg-white",
                  day.toDateString() === today.toDateString() && "bg-blue-50 font-bold text-blue-600"
                )}>
                  {format(day, 'dd')}
                  <div className="text-[8px] text-slate-400">{format(day, 'EEE')[0]}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Rows */}
          <div className="divide-y divide-slate-100">
            {plans.map(plan => {
              const pos = calculatePosition(plan.start_date, plan.target_date);
              
              return (
                <div key={plan.id} className="flex group hover:bg-slate-50/50 relative">
                  <div className="w-64 p-3 border-r shrink-0 sticky left-0 bg-white group-hover:bg-slate-50 z-10 flex items-center justify-between">
                    <div className="truncate pr-2">
                       <div className="font-medium text-sm truncate">{plan.description}</div>
                       <div className="text-xs text-slate-400 truncate">{plan.threat_assessment?.title || 'Unknown Threat'}</div>
                    </div>
                    <Avatar className="w-6 h-6 border">
                      <AvatarImage src={plan.owner?.avatar_url} />
                      <AvatarFallback className="text-[9px]">{plan.owner?.full_name?.substring(0,2)}</AvatarFallback>
                    </Avatar>
                  </div>
                  
                  <div className="flex-1 relative h-14 bg-[linear-gradient(90deg,transparent_29px,#f1f5f9_1px)] bg-[length:30px_100%]">
                     {/* Grid lines background simulation based on flex-1 width is tricky, using CSS grid is better but simpler relative positioning here */}
                     {pos && (
                       <TooltipProvider>
                         <Tooltip>
                           <TooltipTrigger asChild>
                             <div 
                                className={cn("absolute top-3 h-8 rounded-md shadow-sm border border-white/20 flex items-center px-2 cursor-pointer transition-all hover:brightness-105", getStatusColor(plan.status))}
                                style={{ left: pos.left, width: Math.max(parseFloat(pos.width), 2) + '%' }}
                             >
                                <span className="text-[10px] font-bold text-white truncate drop-shadow-md w-full">
                                  {plan.progress_percentage}%
                                </span>
                             </div>
                           </TooltipTrigger>
                           <TooltipContent>
                             <div className="text-xs">
                               <p className="font-bold">{plan.status}</p>
                               <p>Start: {plan.start_date}</p>
                               <p>Target: {plan.target_date}</p>
                             </div>
                           </TooltipContent>
                         </Tooltip>
                       </TooltipProvider>
                     )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RemediationTimeline;
