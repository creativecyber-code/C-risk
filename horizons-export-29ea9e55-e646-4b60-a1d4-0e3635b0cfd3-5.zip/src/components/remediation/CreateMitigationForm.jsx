
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { remediationService } from '@/services/remediationService';
import { supabase } from '@/lib/customSupabaseClient';

const CreateMitigationForm = ({ onSuccess, onCancel }) => {
  const [loading, setLoading] = useState(false);
  const [users, setUsers] = useState([]);
  const [formData, setFormData] = useState({
    description: '',
    mitigation_type: 'Mitigate',
    priority: 'Medium',
    status: 'Not Started',
    start_date: '',
    target_date: '',
    owner_id: ''
  });

  useEffect(() => {
    // Fetch potential owners (users in org)
    const fetchUsers = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      
      const { data: profile } = await supabase.from('user_profiles').select('org_id').eq('id', user.id).single();
      if (profile) {
        const { data } = await supabase.from('user_profiles').select('*').eq('org_id', profile.org_id);
        setUsers(data || []);
      }
    };
    fetchUsers();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await remediationService.createMitigationPlan(formData);
      onSuccess();
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label>Description / Title</Label>
        <Input 
          required 
          value={formData.description}
          onChange={(e) => setFormData({...formData, description: e.target.value})}
          placeholder="e.g. Implement MFA for Admin Portal"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Type</Label>
          <Select 
            value={formData.mitigation_type} 
            onValueChange={(v) => setFormData({...formData, mitigation_type: v})}
          >
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Avoid">Avoid</SelectItem>
              <SelectItem value="Mitigate">Mitigate</SelectItem>
              <SelectItem value="Transfer">Transfer</SelectItem>
              <SelectItem value="Accept">Accept</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Priority</Label>
          <Select 
            value={formData.priority} 
            onValueChange={(v) => setFormData({...formData, priority: v})}
          >
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Low">Low</SelectItem>
              <SelectItem value="Medium">Medium</SelectItem>
              <SelectItem value="High">High</SelectItem>
              <SelectItem value="Critical">Critical</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Start Date</Label>
          <Input 
            type="date"
            value={formData.start_date}
            onChange={(e) => setFormData({...formData, start_date: e.target.value})}
          />
        </div>
        <div className="space-y-2">
          <Label>Target Date</Label>
          <Input 
            type="date"
            value={formData.target_date}
            onChange={(e) => setFormData({...formData, target_date: e.target.value})}
          />
        </div>
      </div>

      <div className="space-y-2">
         <Label>Owner</Label>
         <Select 
            value={formData.owner_id} 
            onValueChange={(v) => setFormData({...formData, owner_id: v})}
          >
            <SelectTrigger><SelectValue placeholder="Select an owner" /></SelectTrigger>
            <SelectContent>
              {users.map(u => (
                <SelectItem key={u.id} value={u.id}>{u.full_name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        <Button type="submit" disabled={loading}>{loading ? 'Creating...' : 'Create Plan'}</Button>
      </div>
    </form>
  );
};

export default CreateMitigationForm;
