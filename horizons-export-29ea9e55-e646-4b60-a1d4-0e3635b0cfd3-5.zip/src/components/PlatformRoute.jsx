
import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2 } from 'lucide-react';

/**
 * PlatformRoute:
 * Protects routes meant exclusively for Platform Staff (Super Admins, Admins, Viewers).
 * Redirects unauthorized users to their appropriate dashboard or login.
 */
const PlatformRoute = ({ children }) => {
  const { user, isPlatformStaff, loading, userRole } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950">
        <div className="flex flex-col items-center gap-2 text-slate-400">
          <Loader2 className="h-8 w-8 animate-spin text-red-600" />
          <p className="text-sm font-medium tracking-wider uppercase">Verifying Clearance...</p>
        </div>
      </div>
    );
  }

  // 1. Not Authenticated -> Login
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  console.log('[PlatformRoute] Check:', { isPlatformStaff, userRole });

  // 2. Authenticated but NOT Platform Staff -> Redirect to Tenant Dashboard
  if (!isPlatformStaff) {
    console.warn('[PlatformRoute] Access Denied: User is not platform staff.');
    return <Navigate to="/app-dashboard" replace />;
  }

  // 3. Authorized Platform Staff
  return children;
};

export default PlatformRoute;
