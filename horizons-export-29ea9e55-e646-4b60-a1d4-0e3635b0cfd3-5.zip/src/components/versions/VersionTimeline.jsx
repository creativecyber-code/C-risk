
import React from 'react';
import { Clock, GitBranch, GitCommit, Tag, User } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const VersionTimeline = ({ versions, selectedVersion, onSelect, onCompareSelect, compareMode, selectedForCompare }) => {
  return (
    <div className="bg-white rounded-lg border h-full flex flex-col">
      <div className="p-4 border-b bg-slate-50">
        <h3 className="font-semibold text-slate-900 flex items-center gap-2">
          <Clock className="w-4 h-4" /> Version History
        </h3>
        <p className="text-xs text-slate-500 mt-1">
          {compareMode 
            ? "Select two versions to compare" 
            : "Select a version to view details or restore"}
        </p>
      </div>

      <ScrollArea className="flex-1 p-4">
        <div className="space-y-6 relative ml-2">
          {/* Vertical Line */}
          <div className="absolute left-[19px] top-2 bottom-2 w-0.5 bg-slate-200" />

          {versions.map((version, index) => {
            const isSelected = selectedVersion?.id === version.id;
            const isCompareSelected = selectedForCompare.includes(version.id);
            const isLatest = index === 0;

            return (
              <div key={version.id} className="relative pl-10 group">
                {/* Dot */}
                <div className={cn(
                  "absolute left-[13px] top-1.5 w-3.5 h-3.5 rounded-full border-2 z-10 transition-colors",
                  isLatest ? "bg-brand-500 border-brand-200" : "bg-white border-slate-300",
                  (isSelected || isCompareSelected) && "ring-2 ring-brand-200 border-brand-500"
                )} />

                <div 
                  onClick={() => compareMode ? onCompareSelect(version.id) : onSelect(version)}
                  className={cn(
                    "p-3 rounded-lg border transition-all cursor-pointer hover:shadow-sm",
                    isSelected ? "bg-brand-50 border-brand-200" : "bg-white border-slate-200 hover:bg-slate-50",
                    isCompareSelected && "ring-1 ring-brand-500 bg-brand-50/50"
                  )}
                >
                  <div className="flex justify-between items-start mb-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-bold text-slate-800">
                        {version.version_tag}
                      </span>
                      {isLatest && <Badge variant="secondary" className="text-[10px] h-5 px-1.5">Latest</Badge>}
                    </div>
                    <span className="text-xs text-slate-400 whitespace-nowrap">
                      {formatDistanceToNow(new Date(version.created_at), { addSuffix: true })}
                    </span>
                  </div>

                  <p className="text-sm text-slate-600 mb-2 line-clamp-2">
                    {version.description || "No description provided"}
                  </p>

                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center gap-1.5">
                      <Avatar className="w-5 h-5 border">
                        <AvatarImage src={version.created_by_profile?.avatar_url} />
                        <AvatarFallback className="text-[9px]">
                          {version.created_by_profile?.full_name?.substring(0, 2).toUpperCase() || 'U'}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-slate-500 truncate max-w-[100px]">
                        {version.created_by_profile?.full_name || 'Unknown'}
                      </span>
                    </div>
                    
                    {/* Stats mini-badge */}
                    <div className="flex gap-2 text-[10px] text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
                      <span title="Elements">{version.snapshot_data?.metadata?.elementCount || 0} El</span>
                      <span className="w-px bg-slate-300 h-3 self-center"></span>
                      <span title="Connections">{version.snapshot_data?.metadata?.connectionCount || 0} Conn</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
};

export default VersionTimeline;
