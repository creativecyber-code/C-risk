
import React from 'react';
import { ShieldAlert, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const AccessDenied = ({ reason = "Insufficient permissions" }) => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] bg-slate-50/50 p-6 rounded-xl border border-dashed border-slate-300">
       <div className="relative">
         <ShieldAlert className="w-20 h-20 text-red-100" />
         <Lock className="w-8 h-8 text-red-500 absolute bottom-0 right-0" />
       </div>
       
       <h2 className="mt-6 text-2xl font-bold text-slate-900">Access Denied</h2>
       <p className="mt-2 text-slate-500 max-w-md text-center">
         You do not have the necessary authorization to view this resource.
       </p>
       
       <div className="mt-4 px-4 py-2 bg-red-50 text-red-700 text-sm font-mono rounded border border-red-100">
         Reason: {reason}
       </div>

       <div className="mt-8 flex gap-4">
         <Button variant="outline" onClick={() => navigate(-1)}>Go Back</Button>
         <Button onClick={() => navigate('/dashboard')}>Dashboard</Button>
       </div>
    </div>
  );
};

export default AccessDenied;
