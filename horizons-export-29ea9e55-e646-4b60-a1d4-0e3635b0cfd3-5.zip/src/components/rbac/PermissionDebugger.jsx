
import React, { useState } from 'react';
import { Shield, ChevronDown, ChevronUp, Check, X, AlertTriangle } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { hasPermission, getRolePermissions } from '@/services/rbacService';
import { PERMISSIONS, PLATFORM_ROLES } from '@/lib/rbac_constants';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const PermissionDebugger = () => {
  const { user, profile } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  
  // Only show in development or if explicitly enabled
  // For this demo environment, we'll show it but collapsed
  
  if (!user) return null;

  const currentRole = profile?.role || 'Guest';
  const assignedPermissions = getRolePermissions(currentRole);
  const isPlatformAdmin = currentRole === PLATFORM_ROLES.PLATFORM_ADMIN;

  // Critical permissions we want to verify immediately
  const criticalChecks = [
    { label: 'Manage Tenants', perm: PERMISSIONS.MANAGE_TENANTS },
    { label: 'System Settings', perm: PERMISSIONS.MANAGE_PLATFORM_SETTINGS },
    { label: 'Platform Users', perm: PERMISSIONS.MANAGE_PLATFORM_USERS },
    { label: 'Platform Logs', perm: PERMISSIONS.VIEW_PLATFORM_LOGS },
  ];

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {!isOpen && (
        <Button 
          variant="outline" 
          size="sm" 
          className="bg-slate-900 text-white border-slate-700 shadow-lg gap-2"
          onClick={() => setIsOpen(true)}
        >
          <Shield className="w-4 h-4 text-emerald-400" />
          RBAC Debug
        </Button>
      )}

      {isOpen && (
        <Card className="w-96 shadow-2xl border-slate-700 bg-slate-900 text-slate-100 animate-in slide-in-from-bottom-5">
          <CardHeader className="p-4 border-b border-slate-800 flex flex-row items-center justify-between space-y-0">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-500" />
              <CardTitle className="text-sm font-bold">Permission Debugger</CardTitle>
            </div>
            <Button variant="ghost" size="icon" className="h-6 w-6 text-slate-400 hover:text-white" onClick={() => setIsOpen(false)}>
              <ChevronDown className="w-4 h-4" />
            </Button>
          </CardHeader>
          <CardContent className="p-4 space-y-4">
            
            {/* User Context */}
            <div className="bg-slate-800/50 p-3 rounded-md border border-slate-700">
              <div className="text-xs font-semibold text-slate-400 uppercase mb-1">Current Context</div>
              <div className="flex justify-between items-center text-sm">
                <span>Role:</span>
                <Badge variant={isPlatformAdmin ? "default" : "secondary"} className="bg-emerald-600">
                  {currentRole}
                </Badge>
              </div>
              <div className="flex justify-between items-center text-sm mt-1">
                <span>User ID:</span>
                <span className="font-mono text-xs text-slate-400 truncate w-24" title={user.id}>{user.id}</span>
              </div>
            </div>

            {/* Critical Checks */}
            <div>
              <div className="text-xs font-semibold text-slate-400 uppercase mb-2">Critical Permission Checks</div>
              <div className="space-y-2 bg-slate-800/30 p-2 rounded border border-slate-700/50">
                {criticalChecks.map((check) => {
                  const hasAccess = hasPermission(currentRole, check.perm);
                  return (
                    <div key={check.perm} className="flex items-center justify-between text-xs">
                      <span className="text-slate-300">{check.label}</span>
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-[10px] text-slate-500 hidden hover:block">{check.perm}</span>
                        {hasAccess ? (
                          <Badge variant="outline" className="border-green-500/50 text-green-400 bg-green-500/10 px-1 py-0 h-5">
                            <Check className="w-3 h-3 mr-1" /> Yes
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="border-red-500/50 text-red-400 bg-red-500/10 px-1 py-0 h-5">
                            <X className="w-3 h-3 mr-1" /> No
                          </Badge>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* All Assigned Permissions */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-semibold text-slate-400 uppercase">Assigned Capabilities</div>
                <Badge variant="secondary" className="text-[10px] h-5">{assignedPermissions.length} total</Badge>
              </div>
              <ScrollArea className="h-32 rounded-md border border-slate-700 bg-slate-950 p-2">
                {isPlatformAdmin ? (
                  <div className="flex flex-col items-center justify-center h-full text-center p-2 text-emerald-400">
                    <Shield className="w-6 h-6 mb-1 opacity-50" />
                    <span className="text-xs font-medium">Superuser Access</span>
                    <span className="text-[10px] text-slate-500">Bypasses explicit checks</span>
                  </div>
                ) : (
                  <div className="space-y-1">
                    {assignedPermissions.length > 0 ? assignedPermissions.map((p) => (
                      <div key={p} className="text-[10px] font-mono text-slate-300 flex items-center gap-2">
                        <div className="w-1 h-1 rounded-full bg-blue-500"></div>
                        {p}
                      </div>
                    )) : (
                       <div className="text-xs text-slate-500 italic">No permissions found</div>
                    )}
                  </div>
                )}
              </ScrollArea>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default PermissionDebugger;
