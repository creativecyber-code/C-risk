
import React from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const ROLE_HIERARCHY = {
  'Viewer': 1,
  'Auditor': 2,
  'Architect': 3,
  'Admin': 4
};

/**
 * Guard component to restrict access based on RBAC
 * @param {string} requiredRole - Minimum role required (Viewer, Auditor, Architect, Admin)
 */
const RoleGuard = ({ children, requiredRole = 'Viewer' }) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  
  // In a real app, role comes from user_profiles table via context.
  // Assuming user metadata has role for this implementation or default to Architect for demo.
  const userRole = user?.user_metadata?.role || 'Architect'; 

  const hasPermission = (ROLE_HIERARCHY[userRole] || 1) >= ROLE_HIERARCHY[requiredRole];

  if (!hasPermission) {
    return (
      <div className="flex flex-col items-center justify-center h-full min-h-[400px] p-8 text-center bg-slate-50 rounded-lg border border-slate-200">
        <ShieldAlert className="w-16 h-16 text-red-500 mb-4" />
        <h2 className="text-2xl font-bold text-slate-900">Access Denied</h2>
        <p className="text-slate-600 mt-2 max-w-md">
          You do not have permission to view this resource. 
          Required role: <span className="font-semibold">{requiredRole}</span>.
        </p>
        <Button className="mt-6" onClick={() => navigate('/dashboard')}>
          Return to Dashboard
        </Button>
      </div>
    );
  }

  return <>{children}</>;
};

export default RoleGuard;
