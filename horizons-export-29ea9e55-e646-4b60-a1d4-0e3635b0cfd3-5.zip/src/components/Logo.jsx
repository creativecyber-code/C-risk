
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { LOGO_URL, COMPANY_NAME } from '@/lib/constants';
import { ImageOff } from 'lucide-react';

// This is the sidebar logo component typically
const Logo = ({ className, imgClassName }) => {
  const [error, setError] = useState(false);

  return (
    <Link 
      to="/" 
      className={cn("flex items-center gap-3 hover:opacity-90 transition-opacity select-none group px-2", className)}
      aria-label={`${COMPANY_NAME} Home`}
    >
      <div className="relative flex-shrink-0">
        {!error ? (
           <img 
            src={LOGO_URL} 
            alt="Logo" 
            className={cn("h-8 w-auto object-contain transition-transform group-hover:scale-105", imgClassName)}
            onError={() => setError(true)}
          />
        ) : (
          <div className="h-8 w-8 bg-slate-100 rounded flex items-center justify-center border text-slate-400">
            <ImageOff className="h-4 w-4" />
          </div>
        )}
      </div>
      <span className="font-bold text-lg tracking-tight text-slate-900 truncate">
        {COMPANY_NAME}
      </span>
    </Link>
  );
};

export default Logo;
