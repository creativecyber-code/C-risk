
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Send, CheckCircle2, ShieldCheck } from 'lucide-react';
import { enquiryService } from '@/services/enquiryService';

const INDUSTRIES = [
  "Banking",
  "Insurance",
  "Fintech",
  "Regulatory Body",
  "Other"
];

const REGULATORY_BODIES = [
  "RBI (Reserve Bank of India)",
  "SEBI (Securities and Exchange Board of India)",
  "IRDAI (Insurance Regulatory and Development Authority)"
];

const PUBLIC_DOMAINS = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'live.com', 'icloud.com'];

const EnquiryForm = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    organization: '',
    email: '',
    phone: '',
    industry: '',
    regulatory_status: [],
    use_case: '',
    dpdp_consent: false
  });

  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    if (!formData.name) newErrors.name = "Name is required";
    if (!formData.organization) newErrors.organization = "Organization is required";
    if (!formData.industry) newErrors.industry = "Industry sector is required";
    
    // Email Validation
    if (!formData.email) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Invalid email format";
    } else {
      const domain = formData.email.split('@')[1];
      if (PUBLIC_DOMAINS.includes(domain.toLowerCase())) {
        newErrors.email = "Please use a valid work email address";
      }
    }

    // DPDP Consent Validation
    if (!formData.dpdp_consent) {
      newErrors.dpdp_consent = "You must agree to the data processing terms.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) {
      toast({
        title: "Validation Error",
        description: "Please check the form for errors.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    try {
      await enquiryService.submitEnquiry(formData);
      setIsSuccess(true);
      setFormData({
        name: '',
        organization: '',
        email: '',
        phone: '',
        industry: '',
        regulatory_status: [],
        use_case: '',
        dpdp_consent: false
      });
      toast({
        title: "Enquiry Submitted",
        description: "Thank you for your interest. Our team will contact you shortly.",
        className: "bg-green-600 text-white"
      });
    } catch (error) {
      console.error("Submission error:", error);
      toast({
        title: "Submission Failed",
        description: "Something went wrong. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCheckboxChange = (value) => {
    setFormData(prev => {
      const current = prev.regulatory_status;
      if (current.includes(value)) {
        return { ...prev, regulatory_status: current.filter(item => item !== value) };
      } else {
        return { ...prev, regulatory_status: [...current, value] };
      }
    });
  };

  if (isSuccess) {
    return (
      <Card className="max-w-2xl mx-auto border-green-100 bg-green-50/50 shadow-lg">
        <CardContent className="pt-6 flex flex-col items-center justify-center text-center p-12">
          <div className="h-16 w-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
            <CheckCircle2 className="h-8 w-8 text-green-600" />
          </div>
          <h3 className="text-2xl font-bold text-slate-900 mb-2">Request Received!</h3>
          <p className="text-slate-600 mb-6 max-w-md">
            We have received your enquiry. A C-RISK compliance specialist will review your requirements and reach out within 24 hours.
          </p>
          <Button onClick={() => setIsSuccess(false)} variant="outline" className="bg-white">
            Submit Another Request
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-3xl mx-auto border-t-4 border-t-blue-600 shadow-xl">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold">Request Enterprise Demo</CardTitle>
        <CardDescription>
          See how C-RISK automates compliance for your specific banking infrastructure.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name <span className="text-red-500">*</span></Label>
              <Input 
                id="name" 
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className={errors.name ? "border-red-500" : ""}
                placeholder="John Doe"
              />
              {errors.name && <p className="text-xs text-red-500">{errors.name}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="organization">Organization <span className="text-red-500">*</span></Label>
              <Input 
                id="organization" 
                value={formData.organization}
                onChange={(e) => setFormData({...formData, organization: e.target.value})}
                className={errors.organization ? "border-red-500" : ""}
                placeholder="Acme Financial Services"
              />
              {errors.organization && <p className="text-xs text-red-500">{errors.organization}</p>}
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="email">Work Email <span className="text-red-500">*</span></Label>
              <Input 
                id="email" 
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className={errors.email ? "border-red-500" : ""}
                placeholder="name@company.com"
              />
              {errors.email && <p className="text-xs text-red-500">{errors.email}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number <span className="text-slate-400 font-normal">(Optional)</span></Label>
              <Input 
                id="phone" 
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                placeholder="+91 98765 43210"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="industry">Industry Sector <span className="text-red-500">*</span></Label>
            <Select 
              value={formData.industry} 
              onValueChange={(val) => setFormData({...formData, industry: val})}
            >
              <SelectTrigger className={errors.industry ? "border-red-500" : ""}>
                <SelectValue placeholder="Select your sector" />
              </SelectTrigger>
              <SelectContent>
                {INDUSTRIES.map((ind) => (
                  <SelectItem key={ind} value={ind}>{ind}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.industry && <p className="text-xs text-red-500">{errors.industry}</p>}
          </div>

          <div className="space-y-3">
            <Label>Regulatory Requirements <span className="text-slate-400 font-normal">(Select all that apply)</span></Label>
            <div className="grid gap-2 border rounded-lg p-4 bg-slate-50/50">
              {REGULATORY_BODIES.map((body) => (
                <div key={body} className="flex items-center space-x-2">
                  <Checkbox 
                    id={body} 
                    checked={formData.regulatory_status.includes(body)}
                    onCheckedChange={() => handleCheckboxChange(body)}
                  />
                  <Label htmlFor={body} className="font-normal cursor-pointer text-slate-700">
                    {body}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="use_case">Primary Use Case / Objective</Label>
            <Textarea 
              id="use_case" 
              value={formData.use_case}
              onChange={(e) => setFormData({...formData, use_case: e.target.value})}
              placeholder="E.g., Automating DPIA for new loan origination system..."
              className="min-h-[100px]"
            />
          </div>

          <div className="space-y-4 pt-4 border-t">
            <div className={`flex items-start space-x-3 p-4 rounded-lg border ${errors.dpdp_consent ? 'border-red-200 bg-red-50' : 'border-blue-100 bg-blue-50/30'}`}>
              <Checkbox 
                id="dpdp_consent" 
                checked={formData.dpdp_consent}
                onCheckedChange={(checked) => setFormData({...formData, dpdp_consent: checked})}
                className="mt-1"
              />
              <div className="space-y-1">
                <Label htmlFor="dpdp_consent" className="font-medium cursor-pointer text-slate-900">
                  Data Privacy Consent <span className="text-red-500">*</span>
                </Label>
                <p className="text-xs text-slate-600 leading-relaxed">
                  I explicitly consent to the processing of my personal data provided herein by CreativeCyber as a Data Fiduciary for the purpose of product demonstration and communication, in accordance with the <strong>Digital Personal Data Protection Act, 2023</strong> and the <a href="/privacy-policy" className="text-blue-600 hover:underline" target="_blank">Privacy Policy</a>. I understand I can withdraw this consent at any time.
                </p>
              </div>
            </div>
            {errors.dpdp_consent && <p className="text-xs text-red-500 pl-1">{errors.dpdp_consent}</p>}
          </div>

          <Button type="submit" className="w-full bg-blue-900 hover:bg-blue-800 text-lg py-6" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Submitting...
              </>
            ) : (
              <>
                <Send className="mr-2 h-5 w-5" /> Submit Enquiry
              </>
            )}
          </Button>
          <p className="text-xs text-center text-slate-500 mt-4">
            By submitting this form, you acknowledge that you have read our Terms of Service.
          </p>
        </form>
      </CardContent>
    </Card>
  );
};

export default EnquiryForm;
