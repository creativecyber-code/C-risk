
import React, { useState, useEffect } from 'react';
import { 
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription 
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/components/ui/use-toast';
import { complianceService } from '@/services/complianceService';
import { COMPLIANCE_STANDARDS } from '@/data/complianceStandards';
import { Plus, Trash2, Shield, AlertTriangle, CheckCircle2, FileText, Link as LinkIcon, Upload, Download } from 'lucide-react';

const InternalControlDetails = ({ open, onOpenChange, control, orgId, onSave }) => {
    const [formData, setFormData] = useState({
        code: '', name: '', description: '', test_frequency: 'Annual', status: 'Draft', owner_id: ''
    });
    const [mappings, setMappings] = useState([]);
    const [risks, setRisks] = useState([]);
    const [auditHistory, setAuditHistory] = useState([]);
    const [evidence, setEvidence] = useState([]);
    const [users, setUsers] = useState([]);
    const [availableRisks, setAvailableRisks] = useState([]);
    
    // Form States
    const [newMapping, setNewMapping] = useState({ framework: '', controlId: '' });
    const [selectedRiskId, setSelectedRiskId] = useState('');
    const [testNote, setTestNote] = useState('');
    const [evidenceFile, setEvidenceFile] = useState(null);
    const [evidenceMeta, setEvidenceMeta] = useState({ title: '', type: 'Document' });
    const [uploading, setUploading] = useState(false);

    const { toast } = useToast();

    useEffect(() => {
        if (open) {
            loadUsers();
            if (control) {
                setFormData({
                    code: control.code,
                    name: control.name,
                    description: control.description || '',
                    test_frequency: control.test_frequency || 'Annual',
                    status: control.status || 'Draft',
                    owner_id: control.owner_id || ''
                });
                setMappings(control.mappings || []);
                setRisks(control.risks || []);
                loadHistory(control.id);
                loadEvidence(control.id);
                loadAvailableRisks();
            } else {
                setFormData({ code: '', name: '', description: '', test_frequency: 'Annual', status: 'Draft', owner_id: '' });
                setMappings([]);
                setRisks([]);
                setAuditHistory([]);
                setEvidence([]);
            }
        }
    }, [open, control]);

    const loadUsers = async () => {
        try {
            const data = await complianceService.getUsers(orgId);
            setUsers(data || []);
        } catch (e) { console.error(e); }
    };

    const loadHistory = async (id) => {
        const history = await complianceService.getControlHistory(id);
        setAuditHistory(history || []);
    };

    const loadEvidence = async (id) => {
        const data = await complianceService.getEvidence(id);
        setEvidence(data || []);
    };

    const loadAvailableRisks = async () => {
        const data = await complianceService.getAvailableRisks(orgId);
        setAvailableRisks(data || []);
    };

    const handleSubmit = async () => {
        if (!formData.code || !formData.name) {
            return toast({ title: "Validation Error", description: "Code and Name are required.", variant: "destructive" });
        }
        try {
            if (control) {
                await complianceService.updateInternalControl(control.id, formData);
                toast({ title: "Control updated" });
            } else {
                await complianceService.createInternalControl({ ...formData, org_id: orgId });
                toast({ title: "Control created" });
            }
            onSave();
            onOpenChange(false);
        } catch (e) {
            toast({ title: "Error saving control", variant: "destructive" });
        }
    };

    const handleAddMapping = async () => {
        if (!control) return toast({ title: "Save control first", variant: "destructive" });
        if (!newMapping.framework || !newMapping.controlId) return;
        
        try {
            await complianceService.addFrameworkMapping(control.id, newMapping.framework, newMapping.controlId);
            onSave(); // Refresh parent to get updated mappings
            // Optimistic update
            setMappings([...mappings, { id: 'temp', framework: newMapping.framework, framework_control_id: newMapping.controlId }]);
            setNewMapping({ framework: '', controlId: '' });
            toast({ title: "Mapping added" });
        } catch (e) {
            toast({ title: "Mapping failed", variant: "destructive" });
        }
    };

    const handleLinkRisk = async () => {
        if (!control || !selectedRiskId) return;
        try {
            await complianceService.linkRisk(control.id, selectedRiskId);
            onSave();
            setSelectedRiskId('');
            toast({ title: "Risk linked" });
        } catch (e) {
            toast({ title: "Link failed", variant: "destructive" });
        }
    };

    const handleLogTest = async (result) => {
        if (!control) return;
        try {
            await complianceService.logControlAudit({
                internal_control_id: control.id,
                result: result,
                audit_date: new Date().toISOString(),
                notes: testNote || `Manual testing result: ${result}`
            });
            toast({ title: "Test result logged" });
            setTestNote('');
            onSave(); 
            loadHistory(control.id);
        } catch (e) {
            toast({ title: "Logging failed", variant: "destructive" });
        }
    };

    const handleUploadEvidence = async () => {
        if (!control || !evidenceFile || !evidenceMeta.title) return;
        setUploading(true);
        try {
            await complianceService.uploadEvidence(evidenceFile, {
                ...evidenceMeta,
                control_id: control.id
            });
            toast({ title: "Evidence uploaded" });
            setEvidenceFile(null);
            setEvidenceMeta({ title: '', type: 'Document' });
            loadEvidence(control.id);
        } catch (e) {
            toast({ title: "Upload failed", description: e.message, variant: "destructive" });
        } finally {
            setUploading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl h-[85vh] flex flex-col p-0 gap-0">
                <DialogHeader className="p-6 pb-4 border-b">
                    <DialogTitle>{control ? 'Edit Control' : 'New Internal Control'}</DialogTitle>
                    <DialogDescription>Define your internal control, map to standards, and track effectiveness.</DialogDescription>
                </DialogHeader>
                
                <div className="flex-1 overflow-hidden flex flex-col">
                    <Tabs defaultValue="details" className="flex-1 flex flex-col overflow-hidden">
                        <div className="px-6 pt-4">
                            <TabsList className="w-full justify-start">
                                <TabsTrigger value="details">Details</TabsTrigger>
                                <TabsTrigger value="mappings" disabled={!control}>Framework Mapping</TabsTrigger>
                                <TabsTrigger value="risks" disabled={!control}>Risk Linking</TabsTrigger>
                                <TabsTrigger value="testing" disabled={!control}>Testing</TabsTrigger>
                                <TabsTrigger value="evidence" disabled={!control}>Evidence</TabsTrigger>
                            </TabsList>
                        </div>

                        <ScrollArea className="flex-1 p-6">
                            <TabsContent value="details" className="space-y-4 mt-0">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label>Control Code <span className="text-red-500">*</span></Label>
                                        <Input 
                                            value={formData.code} 
                                            onChange={e => setFormData({...formData, code: e.target.value})} 
                                            placeholder="e.g. AC-01"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Status</Label>
                                        <Select 
                                            value={formData.status} 
                                            onValueChange={v => setFormData({...formData, status: v})}
                                        >
                                            <SelectTrigger>
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="Draft">Draft</SelectItem>
                                                <SelectItem value="Not Tested">Not Tested</SelectItem>
                                                <SelectItem value="Effective">Effective</SelectItem>
                                                <SelectItem value="Partially Effective">Partially Effective</SelectItem>
                                                <SelectItem value="Ineffective">Ineffective</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <Label>Control Name <span className="text-red-500">*</span></Label>
                                    <Input 
                                        value={formData.name} 
                                        onChange={e => setFormData({...formData, name: e.target.value})} 
                                        placeholder="e.g. Password Complexity Policy"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Description</Label>
                                    <Textarea 
                                        value={formData.description} 
                                        onChange={e => setFormData({...formData, description: e.target.value})} 
                                        rows={4}
                                        placeholder="Describe the control implementation..."
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label>Owner</Label>
                                        <Select 
                                            value={formData.owner_id} 
                                            onValueChange={v => setFormData({...formData, owner_id: v})}
                                        >
                                            <SelectTrigger><SelectValue placeholder="Select Owner" /></SelectTrigger>
                                            <SelectContent>
                                                {users.map(u => (
                                                    <SelectItem key={u.id} value={u.id}>{u.full_name || u.email}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Test Frequency</Label>
                                        <Select 
                                            value={formData.test_frequency} 
                                            onValueChange={v => setFormData({...formData, test_frequency: v})}
                                        >
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="Continuous">Continuous</SelectItem>
                                                <SelectItem value="Monthly">Monthly</SelectItem>
                                                <SelectItem value="Quarterly">Quarterly</SelectItem>
                                                <SelectItem value="Annual">Annual</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                            </TabsContent>

                            <TabsContent value="mappings" className="space-y-6 mt-0">
                                <div className="flex gap-2 items-end p-4 bg-slate-50 rounded-lg border">
                                    <div className="flex-1 space-y-2">
                                        <Label>Framework</Label>
                                        <Select 
                                            value={newMapping.framework} 
                                            onValueChange={v => setNewMapping({ framework: v, controlId: '' })}
                                        >
                                            <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                                            <SelectContent>
                                                {Object.keys(COMPLIANCE_STANDARDS).map(k => (
                                                    <SelectItem key={k} value={k}>{COMPLIANCE_STANDARDS[k].name}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="flex-[2] space-y-2">
                                        <Label>Requirement / Control</Label>
                                        <Select 
                                            value={newMapping.controlId} 
                                            onValueChange={v => setNewMapping({ ...newMapping, controlId: v })}
                                            disabled={!newMapping.framework}
                                        >
                                            <SelectTrigger><SelectValue placeholder="Select Requirement..." /></SelectTrigger>
                                            <SelectContent>
                                                {newMapping.framework && COMPLIANCE_STANDARDS[newMapping.framework].controls.map(c => (
                                                    <SelectItem key={c.id} value={c.id}>
                                                        <span className="font-bold mr-2">{c.id}</span> {c.name}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <Button onClick={handleAddMapping} disabled={!newMapping.controlId}>
                                        <Plus className="w-4 h-4 mr-2" /> Map
                                    </Button>
                                </div>

                                <div className="space-y-2">
                                    <h4 className="text-sm font-medium">Active Mappings</h4>
                                    {mappings.length === 0 && <p className="text-sm text-slate-500 italic">No frameworks mapped yet.</p>}
                                    {mappings.map((m, idx) => (
                                        <div key={m.id || idx} className="flex items-center justify-between p-3 border rounded bg-white">
                                            <div className="flex items-center gap-3">
                                                <Badge variant="outline">{COMPLIANCE_STANDARDS[m.framework]?.name || m.framework}</Badge>
                                                <span className="font-mono text-sm font-bold">{m.framework_control_id}</span>
                                            </div>
                                            <Button variant="ghost" size="sm" className="text-red-500" onClick={async () => {
                                                if(m.id !== 'temp') {
                                                    await complianceService.removeFrameworkMapping(m.id);
                                                    onSave();
                                                }
                                            }}>
                                                <Trash2 className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    ))}
                                </div>
                            </TabsContent>

                            <TabsContent value="risks" className="space-y-6 mt-0">
                                <div className="flex gap-2 items-end p-4 bg-slate-50 rounded-lg border">
                                    <div className="flex-1 space-y-2">
                                        <Label>Select Risk to Link</Label>
                                        <Select value={selectedRiskId} onValueChange={setSelectedRiskId}>
                                            <SelectTrigger><SelectValue placeholder="Select a risk..." /></SelectTrigger>
                                            <SelectContent>
                                                {availableRisks.map(r => (
                                                    <SelectItem key={r.id} value={r.id}>
                                                        <span className="font-medium mr-2">[{r.risk_score}]</span> {r.title}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <Button onClick={handleLinkRisk} disabled={!selectedRiskId}>
                                        <LinkIcon className="w-4 h-4 mr-2" /> Link Risk
                                    </Button>
                                </div>

                                <div className="space-y-2">
                                    <h4 className="text-sm font-medium">Linked Risks</h4>
                                    {risks.length === 0 && <p className="text-sm text-slate-500 italic">No risks linked yet.</p>}
                                    {risks.map((r, idx) => (
                                        <div key={r.id || idx} className="flex items-center justify-between p-3 border rounded bg-white">
                                            <div className="flex items-center gap-3">
                                                <Badge variant={r.threat_assessment?.risk_score > 70 ? 'destructive' : 'secondary'}>
                                                    Score: {r.threat_assessment?.risk_score}
                                                </Badge>
                                                <span className="text-sm font-medium">{r.threat_assessment?.title}</span>
                                            </div>
                                            <Button variant="ghost" size="sm" className="text-red-500" onClick={async () => {
                                                await complianceService.unlinkRisk(r.id);
                                                onSave();
                                            }}>
                                                <Trash2 className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    ))}
                                </div>
                            </TabsContent>

                            <TabsContent value="testing" className="space-y-6 mt-0">
                                <div className="p-4 bg-slate-50 rounded-lg border space-y-4">
                                    <div className="space-y-2">
                                        <Label>Test Notes</Label>
                                        <Input 
                                            placeholder="Enter details about this test execution..." 
                                            value={testNote}
                                            onChange={e => setTestNote(e.target.value)}
                                        />
                                    </div>
                                    <div className="grid grid-cols-3 gap-4">
                                        <Button className="bg-green-600 hover:bg-green-700" onClick={() => handleLogTest('Pass')}>
                                            <CheckCircle2 className="w-4 h-4 mr-2" /> Pass
                                        </Button>
                                        <Button className="bg-amber-500 hover:bg-amber-600" onClick={() => handleLogTest('Partial')}>
                                            <AlertTriangle className="w-4 h-4 mr-2" /> Partial
                                        </Button>
                                        <Button className="bg-red-600 hover:bg-red-700" onClick={() => handleLogTest('Fail')}>
                                            <AlertTriangle className="w-4 h-4 mr-2" /> Fail
                                        </Button>
                                    </div>
                                </div>

                                <div className="space-y-4">
                                    <h4 className="font-semibold text-sm">Audit & Test History</h4>
                                    <div className="space-y-2">
                                        {auditHistory.map(audit => (
                                            <div key={audit.id} className="p-3 border rounded text-sm flex justify-between items-center bg-white">
                                                <div>
                                                    <div className="font-bold flex items-center gap-2">
                                                        {new Date(audit.audit_date).toLocaleDateString()}
                                                        <Badge variant={audit.result === 'Pass' ? 'default' : 'destructive'} className={audit.result === 'Pass' ? 'bg-green-600' : ''}>
                                                            {audit.result}
                                                        </Badge>
                                                    </div>
                                                    <div className="text-slate-500 mt-1">{audit.notes}</div>
                                                </div>
                                                <div className="text-xs text-slate-400">
                                                    by {audit.auditor?.full_name || 'Unknown'}
                                                </div>
                                            </div>
                                        ))}
                                        {auditHistory.length === 0 && <p className="text-slate-500 italic">No tests recorded.</p>}
                                    </div>
                                </div>
                            </TabsContent>

                            <TabsContent value="evidence" className="space-y-6 mt-0">
                                <div className="p-4 bg-slate-50 rounded-lg border space-y-4">
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <Label>Title</Label>
                                            <Input 
                                                placeholder="Evidence Title" 
                                                value={evidenceMeta.title}
                                                onChange={e => setEvidenceMeta({...evidenceMeta, title: e.target.value})}
                                            />
                                        </div>
                                        <div className="space-y-2">
                                            <Label>Type</Label>
                                            <Select 
                                                value={evidenceMeta.type} 
                                                onValueChange={v => setEvidenceMeta({...evidenceMeta, type: v})}
                                            >
                                                <SelectTrigger><SelectValue /></SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="Document">Document</SelectItem>
                                                    <SelectItem value="Screenshot">Screenshot</SelectItem>
                                                    <SelectItem value="Log">Log File</SelectItem>
                                                    <SelectItem value="Policy">Policy</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>File</Label>
                                        <Input type="file" onChange={e => setEvidenceFile(e.target.files[0])} />
                                    </div>
                                    <Button onClick={handleUploadEvidence} disabled={!evidenceFile || !evidenceMeta.title || uploading}>
                                        {uploading ? 'Uploading...' : <><Upload className="w-4 h-4 mr-2" /> Upload Evidence</>}
                                    </Button>
                                </div>

                                <div className="space-y-2">
                                    <h4 className="text-sm font-medium">Uploaded Evidence</h4>
                                    {evidence.length === 0 && <p className="text-sm text-slate-500 italic">No evidence uploaded.</p>}
                                    {evidence.map(item => (
                                        <div key={item.id} className="flex items-center justify-between p-3 border rounded bg-white">
                                            <div className="flex items-center gap-3">
                                                <FileText className="w-8 h-8 text-slate-400" />
                                                <div>
                                                    <div className="font-medium text-sm">{item.title}</div>
                                                    <div className="text-xs text-slate-500">
                                                        {item.type} • {new Date(item.created_at).toLocaleDateString()}
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="flex gap-2">
                                                <Button variant="outline" size="sm" asChild>
                                                    <a href={item.evidence_url} target="_blank" rel="noopener noreferrer">
                                                        <Download className="w-4 h-4" />
                                                    </a>
                                                </Button>
                                                <Button variant="ghost" size="sm" className="text-red-500" onClick={async () => {
                                                    await complianceService.deleteEvidence(item.id);
                                                    loadEvidence(control.id);
                                                }}>
                                                    <Trash2 className="w-4 h-4" />
                                                </Button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </TabsContent>
                        </ScrollArea>
                    </Tabs>
                </div>

                <DialogFooter className="p-4 border-t bg-slate-50">
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button onClick={handleSubmit}>Save Changes</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default InternalControlDetails;
