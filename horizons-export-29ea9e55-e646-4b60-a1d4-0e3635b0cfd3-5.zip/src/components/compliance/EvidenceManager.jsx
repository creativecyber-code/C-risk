
import React, { useState, useEffect } from 'react';
import { Upload, Link as LinkIcon, FileText, Trash2, ExternalLink, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { complianceService } from '@/services/complianceService';
import { useToast } from '@/components/ui/use-toast';

const EvidenceManager = ({ orgId, controlId, framework }) => {
  const [evidence, setEvidence] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    evidence_url: '',
    type: 'LINK'
  });

  const loadEvidence = async () => {
    try {
      const data = await complianceService.getEvidence(orgId, controlId);
      setEvidence(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEvidence();
  }, [controlId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await complianceService.addEvidence(orgId, {
        ...formData,
        control_id: controlId,
        framework
      });
      toast({ title: "Evidence Added" });
      setIsOpen(false);
      setFormData({ title: '', description: '', evidence_url: '', type: 'LINK' });
      loadEvidence();
    } catch (err) {
      toast({ title: "Failed to add evidence", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-semibold text-slate-900">Compliance Evidence ({evidence.length})</h4>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button size="sm" variant="outline" className="gap-2">
              <Plus className="w-3 h-3" /> Add Evidence
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Compliance Evidence</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 pt-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Title</label>
                <Input required value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="e.g. Audit Log Screenshot" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Type</label>
                <Select value={formData.type} onValueChange={v => setFormData({...formData, type: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="LINK">External Link</SelectItem>
                    <SelectItem value="DOCUMENT">Document Reference</SelectItem>
                    <SelectItem value="SCREENSHOT">Screenshot URL</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">URL / Location</label>
                <Input required value={formData.evidence_url} onChange={e => setFormData({...formData, evidence_url: e.target.value})} placeholder="https://..." />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Description</label>
                <Input value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
              </div>
              <Button type="submit" className="w-full">Save Evidence</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-2">
        {evidence.map(item => (
          <div key={item.id} className="flex items-center justify-between p-3 bg-slate-50 border rounded-lg text-sm">
             <div className="flex items-center gap-3">
               {item.type === 'LINK' ? <LinkIcon className="w-4 h-4 text-blue-500" /> : <FileText className="w-4 h-4 text-orange-500" />}
               <div>
                 <p className="font-medium text-slate-800">{item.title}</p>
                 <a href={item.evidence_url} target="_blank" rel="noreferrer" className="text-xs text-blue-600 hover:underline flex items-center gap-1">
                   View Resource <ExternalLink className="w-3 h-3" />
                 </a>
               </div>
             </div>
             <span className="text-xs text-slate-400">{new Date(item.created_at).toLocaleDateString()}</span>
          </div>
        ))}
        {evidence.length === 0 && <p className="text-xs text-slate-400 italic">No evidence uploaded yet.</p>}
      </div>
    </div>
  );
};

export default EvidenceManager;
