
import React, { useState, useEffect } from 'react';
import { Search, Plus, Filter, FileText, LayoutList, MoreHorizontal, PenSquare, Trash2, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { 
    DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import { complianceService } from '@/services/complianceService';
import InternalControlDetails from './InternalControlDetails';

const ControlLibrary = () => {
  const [controls, setControls] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  
  // Modal State
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [selectedControl, setSelectedControl] = useState(null);
  const [orgId, setOrgId] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    const init = async () => {
        try {
            const oid = await complianceService.getOrgId();
            setOrgId(oid);
            await loadControls(oid);
        } catch(e) {
            console.error("Init failed", e);
        }
    };
    init();
  }, []);

  const loadControls = async (oid = orgId) => {
    if (!oid) return;
    try {
      setLoading(true);
      const data = await complianceService.getInternalControls(oid);
      setControls(data || []);
    } catch (error) {
      console.error("Failed to load controls:", error);
      toast({
        title: "Error",
        description: "Could not load control library.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
      if(!window.confirm("Are you sure you want to delete this control? This action cannot be undone.")) return;
      try {
          await complianceService.deleteInternalControl(id);
          toast({ title: "Control deleted" });
          loadControls();
      } catch (e) {
          toast({ title: "Delete failed", variant: "destructive" });
      }
  };

  const handleEdit = (control) => {
      setSelectedControl(control);
      setIsDetailsOpen(true);
  };

  const handleCreate = () => {
      setSelectedControl(null);
      setIsDetailsOpen(true);
  };

  const filteredControls = controls.filter(c => {
      const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            c.code.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'ALL' || c.status === statusFilter;
      return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status) => {
      switch(status) {
          case 'Effective': return 'bg-green-100 text-green-700 border-green-200';
          case 'Partially Effective': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
          case 'Ineffective': return 'bg-red-100 text-red-700 border-red-200';
          case 'Not Tested': return 'bg-slate-100 text-slate-700 border-slate-200';
          default: return 'bg-slate-50 text-slate-500 border-slate-200';
      }
  };

  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-slate-800 flex items-center gap-2">
            Internal Control Registry
            <Badge variant="secondary" className="text-xs font-normal">{controls.length} Controls</Badge>
        </h2>
        <Button onClick={handleCreate} className="bg-brand-600 hover:bg-brand-700 text-white shadow-sm">
          <Plus className="w-4 h-4 mr-2" /> Add New Control
        </Button>
      </div>

      <div className="flex gap-4 items-center bg-white p-3 rounded-lg border shadow-sm">
        <div className="relative flex-grow max-w-lg">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <Input 
            placeholder="Search controls by code, name, or keywords..." 
            className="pl-10 border-slate-200"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="w-[200px]">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                    <Filter className="w-4 h-4 mr-2 text-slate-400" />
                    <SelectValue placeholder="Filter by Status" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="ALL">All Statuses</SelectItem>
                    <SelectItem value="Draft">Draft</SelectItem>
                    <SelectItem value="Not Tested">Not Tested</SelectItem>
                    <SelectItem value="Effective">Effective</SelectItem>
                    <SelectItem value="Ineffective">Ineffective</SelectItem>
                </SelectContent>
            </Select>
        </div>
      </div>

      {loading ? (
        <div className="flex-1 flex flex-col items-center justify-center min-h-[300px]">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-slate-200 border-t-brand-600 mb-4"></div>
            <p className="text-slate-500">Loading controls...</p>
        </div>
      ) : filteredControls.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center min-h-[400px] border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50">
          <div className="bg-white p-4 rounded-full shadow-sm mb-4">
            <LayoutList className="w-10 h-10 text-slate-300" />
          </div>
          <h3 className="text-lg font-medium text-slate-900 mb-1">No controls found</h3>
          <p className="text-slate-500 text-sm max-w-sm text-center mb-6">
            {searchTerm || statusFilter !== 'ALL' ? 'Try adjusting your filters.' : 'Create your first internal control to start tracking compliance.'}
          </p>
          {(searchTerm || statusFilter !== 'ALL') && (
              <Button variant="outline" onClick={() => {setSearchTerm(''); setStatusFilter('ALL');}}>Clear Filters</Button>
          )}
        </div>
      ) : (
        <div className="grid gap-3 pb-8">
          {filteredControls.map(control => (
            <Card key={control.id} className="hover:shadow-md transition-all duration-200 border-slate-200 group">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-start gap-4 flex-1">
                  <div className="bg-slate-50 border border-slate-200 p-2.5 rounded-lg text-slate-700 font-mono text-sm font-bold min-w-[90px] text-center flex flex-col justify-center">
                    {control.code}
                  </div>
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-3">
                        <h4 className="font-semibold text-slate-900 group-hover:text-brand-600 transition-colors cursor-pointer" onClick={() => handleEdit(control)}>
                            {control.name}
                        </h4>
                        <Badge className={`${getStatusColor(control.status)} font-medium`}>
                            {control.status}
                        </Badge>
                    </div>
                    <p className="text-sm text-slate-500 line-clamp-1 max-w-2xl">{control.description || "No description provided."}</p>
                    
                    <div className="flex items-center gap-4 mt-2 text-xs text-slate-400">
                       <span className="flex items-center gap-1">
                           <FileText className="w-3 h-3" /> {control.test_frequency} Test
                       </span>
                       {control.owner?.full_name && (
                           <span className="flex items-center gap-1">
                               User: {control.owner.full_name}
                           </span>
                       )}
                       {control.mappings && control.mappings.length > 0 && (
                           <span className="flex items-center gap-1 px-1.5 py-0.5 bg-slate-100 rounded text-slate-600 font-medium">
                               {control.mappings.length} Mappings
                           </span>
                       )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 pl-4 border-l border-slate-100 ml-4">
                  <div className="text-right hidden md:block">
                      <div className="text-xs text-slate-400">Last Tested</div>
                      <div className="text-sm font-medium text-slate-700">
                          {control.last_tested_at ? new Date(control.last_tested_at).toLocaleDateString() : 'Never'}
                      </div>
                  </div>
                  
                  <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-slate-600">
                              <MoreHorizontal className="w-4 h-4" />
                          </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEdit(control)}>
                              <PenSquare className="w-4 h-4 mr-2" /> Edit Control
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDelete(control.id)} className="text-red-600 hover:text-red-700 focus:text-red-700">
                              <Trash2 className="w-4 h-4 mr-2" /> Delete
                          </DropdownMenuItem>
                      </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {orgId && (
        <InternalControlDetails 
            open={isDetailsOpen} 
            onOpenChange={setIsDetailsOpen} 
            control={selectedControl} 
            orgId={orgId}
            onSave={() => loadControls(orgId)}
        />
      )}
    </div>
  );
};

export default ControlLibrary;
