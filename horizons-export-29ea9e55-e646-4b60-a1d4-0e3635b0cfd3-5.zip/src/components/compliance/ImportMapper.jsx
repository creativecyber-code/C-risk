
import React, { useState, useEffect } from 'react';
import { excelParserService } from '@/services/excelParserService';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Label } from '@/components/ui/label';
import { Loader2, ArrowRight, AlertTriangle, FileSpreadsheet, Check } from 'lucide-react';

const SYSTEM_FIELDS = [
  { id: 'section_ref', label: 'Reference / Section ID', required: true, description: 'e.g., Para 2.1, Section A' },
  { id: 'requirement_text', label: 'Obligation / Mandate', required: true, description: 'The raw regulatory text' },
  { id: 'suggested_control_name', label: 'Control Statement', required: true, description: 'Actionable control description' },
  { id: 'control_type', label: 'Control Type', required: false, description: 'Preventive, Detective, etc.' },
  { id: 'suggested_category', label: 'Category', required: false, description: 'Governance, Tech, etc.' },
  { id: 'risk_objective', label: 'Risk Objective', required: false, description: 'What risk does this address?' },
  { id: 'evidence_requirements', label: 'Evidence Required', required: false, description: 'Comma separated list' },
];

const ImportMapper = ({ file, onCancel, onComplete }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [parsedData, setParsedData] = useState(null);
  const [activeSheet, setActiveSheet] = useState('');
  const [mapping, setMapping] = useState({});
  const [validationError, setValidationError] = useState(null);
  const [headers, setHeaders] = useState([]);
  const [previewRows, setPreviewRows] = useState([]);

  useEffect(() => {
    const parse = async () => {
      try {
        const result = await excelParserService.parseFile(file);
        if (result.sheets.length === 0) throw new Error("No sheets found in file.");
        
        setParsedData(result);
        setActiveSheet(result.sheets[0]);
        setLoading(false);
      } catch (e) {
        setError(e.message);
        setLoading(false);
      }
    };
    parse();
  }, [file]);

  useEffect(() => {
    if (!parsedData || !activeSheet) return;

    const sheetData = parsedData.data[activeSheet];
    if (sheetData && sheetData.length > 0) {
      // Assume first row is headers
      const headerRow = sheetData[0];
      setHeaders(headerRow.map((h, i) => ({ index: i, label: h || `Column ${i + 1}` })));
      // Next 5 rows for preview
      setPreviewRows(sheetData.slice(1, 6));
      
      // Auto-map based on string similarity (simple)
      const newMapping = {};
      SYSTEM_FIELDS.forEach(field => {
        const match = headerRow.findIndex(h => 
          h && h.toLowerCase().includes(field.label.split(' ')[0].toLowerCase())
        );
        if (match !== -1) newMapping[field.id] = match.toString();
      });
      setMapping(newMapping);
    }
  }, [parsedData, activeSheet]);

  const handleMapChange = (fieldId, colIndex) => {
    setMapping(prev => ({ ...prev, [fieldId]: colIndex }));
    setValidationError(null);
  };

  const handleImport = () => {
    // 1. Check if Mapping is configured
    const { isValid, missing } = excelParserService.validateMapping(mapping);
    if (!isValid) {
      setValidationError(`Missing required column mappings: ${missing.map(m => SYSTEM_FIELDS.find(f => f.id === m).label).join(', ')}`);
      return;
    }

    // 2. Process data
    const sheetData = parsedData.data[activeSheet];
    if (!sheetData || sheetData.length <= 1) {
         setValidationError("The selected sheet appears to be empty.");
         return;
    }

    const dataRows = sheetData.slice(1); // Skip header
    
    // 3. Convert to structured objects and Validate EACH ROW
    const mappedData = dataRows.map(row => {
      const obj = {};
      Object.entries(mapping).forEach(([fieldId, colIndex]) => {
        if (colIndex !== undefined && colIndex !== null && colIndex !== 'ignore') {
          obj[fieldId] = row[parseInt(colIndex)];
        }
      });
      return obj;
    }).filter(obj => {
        // Strict Validation: Row must have ALL required fields to be considered valid
        // Optional fields can be missing, but Reference, Obligation, and Control are mandatory.
        return obj.section_ref && obj.requirement_text && obj.suggested_control_name;
    });

    if (mappedData.length === 0) {
        setValidationError("No valid rows found. Please ensure your Excel/CSV data contains values for all required columns (Reference, Obligation, Control Statement).");
        return;
    }

    onComplete(mappedData, activeSheet);
  };

  if (loading) {
    return (
      <Card className="w-full h-96 flex items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="w-10 h-10 animate-spin text-brand-600 mx-auto" />
          <p className="text-slate-500">Reading file structure...</p>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="w-full border-red-200 bg-red-50">
        <CardContent className="pt-6 text-center">
          <AlertTriangle className="w-10 h-10 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-red-700">Import Failed</h3>
          <p className="text-red-600 mb-4">{error}</p>
          <Button onClick={onCancel} variant="outline" className="border-red-200 hover:bg-red-100">Try Again</Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full flex flex-col h-[700px]">
      <CardHeader className="border-b pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-green-100 rounded-lg">
            <FileSpreadsheet className="w-6 h-6 text-green-700" />
          </div>
          <div>
            <CardTitle>Map Columns</CardTitle>
            <CardDescription>
              Match columns from <strong>{file.name}</strong> to RegParser fields.
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 overflow-hidden flex flex-col p-0">
        {/* Sheet Selector */}
        {parsedData?.sheets.length > 1 && (
            <div className="px-6 py-2 bg-slate-50 border-b">
                <Tabs value={activeSheet} onValueChange={setActiveSheet}>
                    <TabsList>
                        {parsedData.sheets.map(sheet => (
                            <TabsTrigger key={sheet} value={sheet}>{sheet}</TabsTrigger>
                        ))}
                    </TabsList>
                </Tabs>
            </div>
        )}

        <div className="flex flex-1 overflow-hidden">
             {/* Left: Mapping Controls */}
            <div className="w-1/3 border-r overflow-y-auto p-6 space-y-6 bg-slate-50/50">
                <div className="space-y-4">
                    {SYSTEM_FIELDS.map(field => (
                        <div key={field.id} className="space-y-1.5">
                            <div className="flex justify-between">
                                <Label className={`text-sm ${field.required ? 'font-semibold text-slate-800' : 'text-slate-600'}`}>
                                    {field.label} {field.required && <span className="text-red-500">*</span>}
                                </Label>
                                {mapping[field.id] && <Check className="w-4 h-4 text-green-600" />}
                            </div>
                            <Select 
                                value={mapping[field.id] || ''} 
                                onValueChange={(val) => handleMapChange(field.id, val)}
                            >
                                <SelectTrigger className="bg-white">
                                    <SelectValue placeholder="Select Column" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="ignore" className="text-slate-400 italic">-- Ignore --</SelectItem>
                                    {headers.map(h => (
                                        <SelectItem key={h.index} value={h.index.toString()}>
                                            {h.label}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            <p className="text-[10px] text-slate-500">{field.description}</p>
                        </div>
                    ))}
                </div>
            </div>

            {/* Right: Preview */}
            <div className="w-2/3 overflow-hidden flex flex-col">
                <div className="p-4 bg-slate-100 border-b text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    Data Preview (First 5 Rows)
                </div>
                <div className="flex-1 overflow-auto p-4">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                {headers.map(h => (
                                    <TableHead key={h.index} className="whitespace-nowrap min-w-[150px]">
                                        {h.label}
                                        {Object.values(mapping).includes(h.index.toString()) && (
                                            <div className="mt-1">
                                                <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-brand-100 text-brand-800">
                                                    Mapped
                                                </span>
                                            </div>
                                        )}
                                    </TableHead>
                                ))}
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {previewRows.map((row, idx) => (
                                <TableRow key={idx}>
                                    {headers.map(h => (
                                        <TableCell key={h.index} className="whitespace-nowrap max-w-[200px] truncate text-xs">
                                            {row[h.index]}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
            </div>
        </div>
      </CardContent>

      <CardFooter className="border-t p-4 flex justify-between bg-slate-50">
        <div className="flex items-center gap-2">
            {validationError && (
                <Alert variant="destructive" className="py-2 h-auto max-w-sm">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle className="ml-2 text-sm">{validationError}</AlertTitle>
                </Alert>
            )}
        </div>
        <div className="flex gap-3">
            <Button variant="ghost" onClick={onCancel}>Cancel</Button>
            <Button onClick={handleImport} className="bg-green-600 hover:bg-green-700">
                <FileSpreadsheet className="w-4 h-4 mr-2" />
                Import Data
            </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default ImportMapper;
