
import React, { useState } from 'react';
import { Check, X, AlertCircle, Clock, Loader2, Link2, Paperclip } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { complianceService } from '@/services/complianceService';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import EvidenceManager from './EvidenceManager';
import ControlMapping from './ControlMapping';
import { Badge } from '@/components/ui/badge';

const STATUS_OPTIONS = [
  { value: 'NOT_IMPLEMENTED', label: 'Not Implemented', color: 'text-red-600' },
  { value: 'PLANNED', label: 'Planned', color: 'text-slate-500' },
  { value: 'IMPLEMENTED', label: 'Implemented', color: 'text-green-600' },
  { value: 'OPTIMIZED', label: 'Optimized', color: 'text-purple-600' },
  { value: 'NON_COMPLIANT', label: 'Non-Compliant', color: 'text-red-700 font-bold' },
];

const FrameworkDetails = ({ frameworkKey, data, orgId, onUpdate, threats }) => {
  const { toast } = useToast();
  const [updating, setUpdating] = useState(null);

  const handleStatusChange = async (controlId, newStatus) => {
    setUpdating(controlId);
    try {
      await complianceService.updateComplianceStatus(orgId, frameworkKey, controlId, newStatus, 'Status updated manually via dashboard');
      await onUpdate();
      toast({ title: "Status Updated", description: "Compliance record saved." });
    } catch (error) {
      toast({ title: "Update Failed", variant: "destructive" });
    } finally {
      setUpdating(null);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-slate-50 to-white border-none shadow-sm">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded bg-brand-100 flex items-center justify-center text-brand-700 font-bold text-xl shadow-sm">
                {frameworkKey.substring(0,2)}
            </div>
            <div>
              <CardTitle className="text-xl">{data.name}</CardTitle>
              <CardDescription>{data.description}</CardDescription>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-4">
        {data.controls.map((control) => (
          <Accordion type="single" collapsible key={control.id} className="bg-white border rounded-lg shadow-sm">
            <AccordionItem value={control.id} className="border-0">
               <div className="flex flex-col md:flex-row items-center p-4 gap-4">
                  <div className={`w-2 h-12 rounded-full flex-shrink-0 ${
                      control.status === 'IMPLEMENTED' || control.status === 'OPTIMIZED' ? 'bg-green-500' : 
                      control.status === 'PLANNED' ? 'bg-amber-400' : 'bg-red-500'
                  }`} />
                  
                  <div className="flex-1 space-y-1 w-full">
                     <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs font-bold bg-slate-100 text-slate-600 px-2 py-1 rounded">
                          {control.id}
                        </span>
                        <Badge variant="outline">{control.category}</Badge>
                        {control.mappedThreats > 0 && (
                            <Badge className="bg-indigo-50 text-indigo-700 border-indigo-200 gap-1">
                                <Link2 className="w-3 h-3" /> {control.mappedThreats} Threats
                            </Badge>
                        )}
                        {control.evidenceCount > 0 && (
                            <Badge className="bg-green-50 text-green-700 border-green-200 gap-1">
                                <Paperclip className="w-3 h-3" /> {control.evidenceCount} Evidence
                            </Badge>
                        )}
                     </div>
                     <h4 className="font-bold text-slate-900">{control.name}</h4>
                  </div>

                  <div className="w-full md:w-48 flex-shrink-0 z-10">
                    <Select 
                      value={control.status} 
                      onValueChange={(val) => handleStatusChange(control.id, val)}
                      disabled={updating === control.id}
                    >
                      <SelectTrigger className={`w-full h-9 text-xs font-medium border-slate-200 ${STATUS_OPTIONS.find(o => o.value === control.status)?.color}`}>
                         {updating === control.id && <Loader2 className="w-3 h-3 animate-spin mr-2" />}
                         <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {STATUS_OPTIONS.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            <div className="flex items-center gap-2">
                               <div className={`w-2 h-2 rounded-full ${option.color.replace('text-', 'bg-')}`} />
                               {option.label}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <AccordionTrigger className="p-2 hover:no-underline" />
               </div>

               <AccordionContent className="px-6 pb-6 pt-0">
                   <div className="pt-4 border-t grid grid-cols-1 lg:grid-cols-2 gap-8">
                      <div className="space-y-4">
                          <p className="text-sm text-slate-600">{control.description}</p>
                          <EvidenceManager 
                             orgId={orgId} 
                             controlId={control.id} 
                             framework={frameworkKey} 
                          />
                      </div>
                      <div className="space-y-4 border-l pl-0 lg:pl-8 border-slate-100">
                          <ControlMapping 
                             controlId={control.id} 
                             framework={frameworkKey} 
                             availableThreats={threats} 
                          />
                      </div>
                   </div>
               </AccordionContent>
            </AccordionItem>
          </Accordion>
        ))}
      </div>
    </div>
  );
};

export default FrameworkDetails;
