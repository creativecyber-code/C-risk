
import React, { useState } from 'react';
import { Check, X, ArrowRight, FileText, Shield, Target, FileCheck, Layers, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/components/ui/use-toast';
import { regParserService } from '@/services/regParserService';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const ExtractionReview = ({ extracts, onUpdate, docId }) => {
  const { toast } = useToast();
  const [processing, setProcessing] = useState(false);

  const handleApprove = async (id) => {
    try {
      const result = await regParserService.approveExtract(id);
      toast({
        title: "Control Generated",
        description: `Created control and mapped to ${result.mappedThreatsCount} threats automatically.`
      });
      onUpdate();
    } catch (e) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const handleApproveAll = async () => {
    setProcessing(true);
    try {
        const count = await regParserService.approveAllExtracts(docId);
        toast({ title: "Batch Approval Complete", description: `Approved and generated ${count} controls.` });
        onUpdate();
    } catch (e) {
        toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
        setProcessing(false);
    }
  };

  const getCategoryColor = (cat) => {
      switch(cat) {
          case 'Technology': return 'bg-blue-100 text-blue-700 border-blue-200';
          case 'Governance': return 'bg-purple-100 text-purple-700 border-purple-200';
          case 'Operational': return 'bg-orange-100 text-orange-700 border-orange-200';
          case 'Reporting & Disclosure': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
          default: return 'bg-slate-100 text-slate-700 border-slate-200';
      }
  };

  const getTypeIcon = (type) => {
      switch(type) {
          case 'Preventive': return <Shield className="w-3 h-3 mr-1" />;
          case 'Detective': return <Eye className="w-3 h-3 mr-1" />;
          case 'Corrective': return <Layers className="w-3 h-3 mr-1" />;
          default: return <FileText className="w-3 h-3 mr-1" />;
      }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between bg-slate-50 p-4 rounded-lg border">
        <div>
            <h3 className="text-lg font-semibold text-slate-900">Extraction Analysis Report</h3>
            <p className="text-sm text-slate-500">
                {extracts.length} actionable requirements identified from regulatory text.
            </p>
        </div>
        <div className="flex gap-2">
            <div className="flex flex-col items-end mr-4">
                <span className="text-xs text-slate-500 uppercase font-bold">Completeness</span>
                <span className="text-sm font-mono font-bold text-green-600">98.4%</span>
            </div>
            {extracts.some(e => e.status === 'PENDING') && (
                <Button onClick={handleApproveAll} disabled={processing} className="bg-indigo-600 hover:bg-indigo-700">
                    {processing ? 'Processing...' : 'Approve All Pending'}
                </Button>
            )}
        </div>
      </div>

      <ScrollArea className="h-[500px] pr-4">
        <div className="space-y-4">
          {extracts.map((extract) => (
            <Card key={extract.id} className={`overflow-hidden transition-all ${extract.status === 'APPROVED' ? 'opacity-60 border-slate-200 bg-slate-50/50' : 'border-indigo-100 shadow-sm hover:shadow-md'}`}>
              <div className={`h-1 w-full ${extract.status === 'APPROVED' ? 'bg-green-500' : 'bg-indigo-500'}`} />
              <CardContent className="p-5">
                {/* Header Section */}
                <div className="flex justify-between items-start mb-4">
                    <div className="flex flex-wrap gap-2 items-center">
                        <Badge variant="outline" className="font-mono">{extract.section_ref}</Badge>
                        <Badge className={getCategoryColor(extract.suggested_category)}>
                            {extract.suggested_category || 'General'}
                        </Badge>
                        <Badge variant="secondary" className="flex items-center">
                            {getTypeIcon(extract.control_type)} {extract.control_type || 'Control'}
                        </Badge>
                        <Badge variant="outline" className="border-slate-200 text-slate-500">
                            {Math.round(extract.confidence_score * 100)}% Match
                        </Badge>
                    </div>
                    {extract.status === 'PENDING' ? (
                         <div className="flex gap-2">
                             <TooltipProvider>
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <Button size="icon" variant="ghost" className="h-8 w-8 text-green-600 hover:text-green-700 hover:bg-green-50" onClick={() => handleApprove(extract.id)}>
                                            <Check className="w-5 h-5" />
                                        </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>Approve & Generate Control</TooltipContent>
                                </Tooltip>
                             </TooltipProvider>
                             <Button size="icon" variant="ghost" className="h-8 w-8 text-red-400 hover:text-red-600 hover:bg-red-50">
                                <X className="w-5 h-5" />
                             </Button>
                         </div>
                    ) : (
                        <Badge className="bg-green-100 text-green-800 border-green-200">
                            <Check className="w-3 h-3 mr-1"/> Approved
                        </Badge>
                    )}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Left: Source & Obligation */}
                    <div className="space-y-3">
                        <div className="space-y-1">
                            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Original Mandate</span>
                            <p className="text-sm text-slate-600 bg-slate-100/50 p-3 rounded-md border border-slate-100 italic font-serif leading-relaxed">
                                "{extract.original_obligation_text || extract.requirement_text}"
                            </p>
                        </div>
                        
                        {extract.conditionality && (
                             <div className="flex items-start gap-2 text-xs text-amber-700 bg-amber-50 p-2 rounded border border-amber-100">
                                <AlertTriangleIcon className="w-4 h-4 shrink-0 mt-0.5" />
                                <span>Condition: {extract.conditionality}</span>
                             </div>
                        )}
                    </div>

                    {/* Right: Transformed Control */}
                    <div className="space-y-3 relative">
                        <div className="absolute -left-3 top-8 bottom-0 w-px bg-slate-200 lg:block hidden"></div>
                        
                        <div className="space-y-1">
                            <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider flex items-center gap-1">
                                <ArrowRight className="w-3 h-3" /> Control Statement
                            </span>
                            <p className="text-sm font-medium text-slate-900 leading-relaxed">
                                {extract.suggested_control_name}
                            </p>
                            <div className="flex items-center gap-2 mt-1">
                                <code className="text-[10px] bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200 text-slate-500">
                                    {extract.suggested_control_code}
                                </code>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3 mt-2">
                             <div className="bg-slate-50 p-2 rounded border border-slate-100">
                                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 mb-1">
                                    <Target className="w-3 h-3 text-red-500" /> Risk Objective
                                </div>
                                <p className="text-xs text-slate-600 leading-snug">
                                    {extract.risk_objective || "Mitigate non-compliance risk."}
                                </p>
                             </div>
                             <div className="bg-slate-50 p-2 rounded border border-slate-100">
                                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 mb-1">
                                    <FileCheck className="w-3 h-3 text-blue-500" /> Evidence
                                </div>
                                <ul className="text-xs text-slate-600 list-disc list-inside">
                                    {Array.isArray(extract.evidence_requirements) 
                                        ? extract.evidence_requirements.map((ev, i) => <li key={i}>{ev}</li>)
                                        : <li>{extract.evidence_requirements || "Audit Trail"}</li>
                                    }
                                </ul>
                             </div>
                        </div>
                    </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

// Helper for conditional rendering icon
const AlertTriangleIcon = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" x2="12" y1="9" y2="13"/><line x1="12" x2="12.01" y1="17" y2="17"/></svg>
);

export default ExtractionReview;
