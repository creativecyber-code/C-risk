
import React, { useState, useEffect } from 'react';
import { Link2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { complianceService } from '@/services/complianceService';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';

const ControlMapping = ({ controlId, framework, availableThreats }) => {
  const [mappings, setMappings] = useState([]);
  const [selectedThreat, setSelectedThreat] = useState('');
  const { toast } = useToast();

  const loadMappings = async () => {
    const data = await complianceService.getMappings(controlId);
    setMappings(data);
  };

  useEffect(() => {
    loadMappings();
  }, [controlId]);

  const handleAdd = async () => {
    if (!selectedThreat) return;
    try {
      await complianceService.addMapping(selectedThreat, controlId, framework);
      setSelectedThreat('');
      loadMappings();
      toast({ title: "Threat mapped successfully" });
    } catch (e) {
      toast({ title: "Mapping failed", description: e.message, variant: "destructive" });
    }
  };

  const handleRemove = async (id) => {
    try {
      await complianceService.removeMapping(id);
      loadMappings();
    } catch (e) {
      toast({ title: "Removal failed", variant: "destructive" });
    }
  };

  // Filter out already mapped
  const unmappedThreats = availableThreats.filter(t => !mappings.find(m => m.threat_id === t.id));

  return (
    <div className="space-y-4">
       <h4 className="text-sm font-semibold text-slate-900">Threat Mappings</h4>
       
       <div className="flex gap-2">
         <Select value={selectedThreat} onValueChange={setSelectedThreat}>
           <SelectTrigger className="w-full text-xs">
             <SelectValue placeholder="Select Threat to Link..." />
           </SelectTrigger>
           <SelectContent>
             {unmappedThreats.map(t => (
               <SelectItem key={t.id} value={t.id}>{t.title} (Risk: {t.risk_score})</SelectItem>
             ))}
           </SelectContent>
         </Select>
         <Button size="sm" onClick={handleAdd} disabled={!selectedThreat}>Link</Button>
       </div>

       <div className="flex flex-wrap gap-2">
         {mappings.map(m => (
           <Badge key={m.id} variant="secondary" className="pl-2 pr-1 py-1 gap-2 flex items-center">
             <Link2 className="w-3 h-3 text-slate-400" />
             <span className="max-w-[150px] truncate">{m.threat_assessments?.title}</span>
             <button onClick={() => handleRemove(m.id)} className="hover:text-red-500 rounded-full p-0.5"><X className="w-3 h-3" /></button>
           </Badge>
         ))}
         {mappings.length === 0 && <p className="text-xs text-slate-400 italic">No threats mapped to this control.</p>}
       </div>
    </div>
  );
};

export default ControlMapping;
