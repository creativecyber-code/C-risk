
import React, { useState } from 'react';
import { Search, Book, ShieldAlert, FileText, Lock } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { BANKING_THREAT_LIBRARY, getThreatsByCategory, searchThreats } from '@/data/bankingThreatLibrary';

const ThreatLibraryPanel = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const categories = getThreatsByCategory();
  const isSearching = searchQuery.length > 0;
  const filteredThreats = isSearching ? searchThreats(searchQuery) : [];

  const getRiskColor = (risk) => {
    switch(risk.toLowerCase()) {
      case 'critical': return 'bg-red-950 text-red-400 border-red-900';
      case 'high': return 'bg-red-900/30 text-red-300 border-red-800';
      case 'medium': return 'bg-yellow-900/30 text-yellow-300 border-yellow-800';
      default: return 'bg-blue-900/30 text-blue-300 border-blue-800';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full justify-start gap-3 bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700">
          <Book className="w-4 h-4 text-purple-400" />
          Banking Threat Library
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-2xl bg-slate-900 border-slate-700 text-slate-100 h-[80vh] flex flex-col p-0 gap-0">
        <DialogHeader className="p-6 border-b border-slate-800">
          <DialogTitle className="flex items-center gap-2 text-xl">
            <ShieldAlert className="w-6 h-6 text-purple-400" />
            Banking Threat Library (STRIDE)
          </DialogTitle>
          <div className="relative mt-4">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              placeholder="Search threats by name, category, or description..."
              className="w-full bg-slate-800 border border-slate-700 rounded-md pl-9 pr-4 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-purple-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </DialogHeader>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {isSearching ? (
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-slate-400">Search Results ({filteredThreats.length})</h3>
              {filteredThreats.length > 0 ? (
                filteredThreats.map(threat => (
                  <ThreatCardItem key={threat.id} threat={threat} getRiskColor={getRiskColor} />
                ))
              ) : (
                <p className="text-center text-slate-500 py-8">No threats found matching your query.</p>
              )}
            </div>
          ) : (
            Object.entries(categories).map(([category, threats]) => (
              <div key={category} className="space-y-3">
                <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
                  {category}
                </h3>
                <div className="grid grid-cols-1 gap-3">
                  {threats.map(threat => (
                    <ThreatCardItem key={threat.id} threat={threat} getRiskColor={getRiskColor} />
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

const ThreatCardItem = ({ threat, getRiskColor }) => (
  <div className="bg-slate-800/50 border border-slate-700/50 rounded-lg p-4 hover:bg-slate-800 transition-colors">
    <div className="flex justify-between items-start mb-2">
      <div className="flex items-center gap-2">
        <span className={`text-xs px-2 py-0.5 rounded border ${getRiskColor(threat.risk)}`}>
          {threat.risk}
        </span>
        <span className="text-xs px-2 py-0.5 rounded border bg-slate-700 text-slate-300 border-slate-600">
          {threat.stride}
        </span>
      </div>
      <span className="text-xs text-slate-500 font-mono">{threat.id}</span>
    </div>
    
    <h4 className="font-semibold text-slate-200 mb-1">{threat.title}</h4>
    <p className="text-sm text-slate-400 mb-3">{threat.description}</p>
    
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
      <div className="bg-slate-900/50 p-2 rounded border border-slate-700/30">
        <div className="flex items-center gap-1.5 text-blue-400 mb-1 font-medium">
          <FileText className="w-3 h-3" /> Compliance Impact
        </div>
        <span className="text-slate-400">{threat.compliance}</span>
      </div>
      <div className="bg-slate-900/50 p-2 rounded border border-slate-700/30">
        <div className="flex items-center gap-1.5 text-green-400 mb-1 font-medium">
          <Lock className="w-3 h-3" /> Mitigation
        </div>
        <span className="text-slate-400">{threat.mitigation}</span>
      </div>
    </div>
  </div>
);

export default ThreatLibraryPanel;
