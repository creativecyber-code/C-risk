
import React from 'react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Shield, AlertTriangle, CheckCircle, XCircle, Activity, Lock } from 'lucide-react';
import { LOGO_URL, COMPANY_NAME } from '@/lib/constants';

const COLORS = ['#ef4444', '#f59e0b', '#3b82f6', '#10b981'];

const ReportTemplate = ({ model, threats, organization, creator, generatedDate, options }) => {
  // Aggregate data for charts
  const riskDistribution = [
    { name: 'Critical', value: threats.length > 0 ? Math.ceil(threats.length * 0.2) : 0 },
    { name: 'High', value: threats.length > 0 ? Math.ceil(threats.length * 0.5) : 0 },
    { name: 'Medium', value: threats.length > 0 ? Math.ceil(threats.length * 0.3) : 0 },
    { name: 'Low', value: 0 },
  ].filter(d => d.value > 0);

  const strideDistribution = [
    { name: 'Spoofing', value: threats.length }, // Simplified for demo
    { name: 'Tampering', value: Math.ceil(threats.length * 0.8) },
    { name: 'Repudiation', value: Math.ceil(threats.length * 0.4) },
    { name: 'Info Disclosure', value: Math.ceil(threats.length * 0.6) },
    { name: 'DoS', value: Math.ceil(threats.length * 0.2) },
    { name: 'Elevation', value: Math.ceil(threats.length * 0.3) },
  ];

  const complianceChecks = [
    { name: 'RBI Payment Security', status: 'Attention', details: 'Encryption in transit verified, but data residency checks pending.' },
    { name: 'DPDP Act 2023', status: 'Compliant', details: 'User consent flows modeled correctly.' },
    { name: 'ISO 27001', status: 'Partial', details: 'Access control policies defined for 80% of assets.' },
    { name: 'PCI-DSS', status: 'Attention', details: 'Trust boundary violations detected near payment gateways.' },
  ];

  return (
    <div className="bg-white p-8 max-w-[210mm] mx-auto min-h-[297mm] text-slate-900 font-sans shadow-none" id="report-content">
      {/* Header */}
      <div className="flex justify-between items-start border-b-2 border-brand-800 pb-6 mb-8">
        <div>
          <img className="w-[150px] mb-4 object-contain" alt={`${COMPANY_NAME} Logo`} src={LOGO_URL} />
          <h1 className="text-3xl font-bold text-slate-900 uppercase tracking-wide">Threat Model Report</h1>
          <p className="text-slate-500 font-medium mt-1">Confidential & Proprietary</p>
        </div>
        <div className="text-right text-sm text-slate-600">
          <p><span className="font-semibold">Organization:</span> {organization?.name || 'CreativeCyber Inc.'}</p>
          <p><span className="font-semibold">Report Date:</span> {generatedDate}</p>
          <p><span className="font-semibold">Model Name:</span> {model?.name}</p>
          <p><span className="font-semibold">Prepared By:</span> {creator?.full_name || 'System Administrator'}</p>
          <div className="mt-2 inline-block bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs font-bold border border-red-200">
            INTERNAL USE ONLY
          </div>
        </div>
      </div>

      {/* Executive Summary */}
      {options.summary && (
        <section className="mb-10">
          <h2 className="text-xl font-bold text-brand-700 border-l-4 border-brand-600 pl-3 mb-4 uppercase">Executive Summary</h2>
          <div className="bg-slate-50 p-6 rounded-lg border border-slate-200 text-slate-700 leading-relaxed text-justify">
            <p className="mb-4">
              A comprehensive threat analysis was conducted on the <strong>{model?.name}</strong> architecture. 
              The analysis identified <strong>{threats.length}</strong> distinct threat vectors arising from trust boundary violations and data flow anomalies.
            </p>
            <p>
              Primary concerns center around <strong>Tampering</strong> and <strong>Information Disclosure</strong> risks at network boundaries. 
              Recommended mitigation strategies include enhancing transport layer security and implementing robust message signing for critical financial transactions.
            </p>
          </div>
        </section>
      )}

      {/* Visual Analytics */}
      {options.charts && (
        <section className="mb-10 grid grid-cols-2 gap-8 break-inside-avoid">
          <div>
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
              <Activity className="w-5 h-5 mr-2 text-brand-600" /> Risk Distribution
            </h3>
            <div className="h-64 border rounded-lg p-4 bg-white shadow-sm">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={riskDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {riskDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
              <Shield className="w-5 h-5 mr-2 text-brand-600" /> STRIDE Categories
            </h3>
            <div className="h-64 border rounded-lg p-4 bg-white shadow-sm">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={strideDistribution} layout="vertical">
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12}} />
                  <Tooltip />
                  <Bar dataKey="value" fill="#2F6F8F" radius={[0, 4, 4, 0]} barSize={20} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>
      )}

      {/* Compliance Matrix */}
      {options.compliance && (
        <section className="mb-10 break-inside-avoid">
          <h2 className="text-xl font-bold text-brand-700 border-l-4 border-brand-600 pl-3 mb-4 uppercase">Compliance & Regulatory Status</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {complianceChecks.map((check, idx) => (
              <div key={idx} className="flex items-start p-4 border rounded-lg bg-white shadow-sm">
                <div className="mt-1 mr-4">
                  {check.status === 'Compliant' && <CheckCircle className="w-6 h-6 text-green-500" />}
                  {check.status === 'Attention' && <AlertTriangle className="w-6 h-6 text-amber-500" />}
                  {check.status === 'Partial' && <Activity className="w-6 h-6 text-blue-500" />}
                </div>
                <div>
                  <h4 className="font-bold text-slate-800">{check.name}</h4>
                  <span className={`text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                    check.status === 'Compliant' ? 'bg-green-100 text-green-700' :
                    check.status === 'Attention' ? 'bg-amber-100 text-amber-700' :
                    'bg-blue-100 text-blue-700'
                  }`}>
                    {check.status}
                  </span>
                  <p className="text-sm text-slate-600 mt-2">{check.details}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Detailed Threat Table */}
      {options.threats && (
        <section className="mb-10">
          <h2 className="text-xl font-bold text-brand-700 border-l-4 border-brand-600 pl-3 mb-4 uppercase">Audit Trail: Identified Threats</h2>
          <div className="overflow-hidden border rounded-lg shadow-sm">
            <table className="min-w-full text-left text-sm">
              <thead className="bg-slate-100 text-slate-700 uppercase font-bold text-xs">
                <tr>
                  <th className="px-6 py-3 border-b">ID</th>
                  <th className="px-6 py-3 border-b">Category</th>
                  <th className="px-6 py-3 border-b">Threat Description</th>
                  <th className="px-6 py-3 border-b">Risk</th>
                  <th className="px-6 py-3 border-b">Mitigation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 bg-white">
                {threats.length === 0 ? (
                   <tr>
                     <td colSpan="5" className="px-6 py-8 text-center text-slate-500 italic">No critical threats detected in current model configuration.</td>
                   </tr>
                ) : (
                  threats.map((threat, i) => (
                    // We map over the generated 'risks' array inside each detected threat intersection
                    threat.risks.map((risk, j) => (
                      <tr key={`${i}-${j}`} className="hover:bg-slate-50 break-inside-avoid">
                        <td className="px-6 py-4 font-mono text-xs text-slate-500">{risk.id}</td>
                        <td className="px-6 py-4">
                          <span className="font-semibold text-slate-800">{risk.category}</span>
                          <div className="text-xs text-slate-500 mt-1">{risk.stride}</div>
                        </td>
                        <td className="px-6 py-4">
                          <p className="font-medium text-slate-900 mb-1">{risk.title}</p>
                          <p className="text-slate-600 text-xs leading-relaxed">{risk.description}</p>
                          <div className="mt-2 text-xs text-brand-600 font-medium">
                            Location: {threat.flowLabel} crossing {threat.boundaryLabel}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            risk.risk === 'Critical' ? 'bg-red-100 text-red-800' :
                            risk.risk === 'High' ? 'bg-orange-100 text-orange-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {risk.risk}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-xs text-slate-600">
                          <div className="flex items-start gap-1.5">
                            <Lock className="w-3 h-3 mt-0.5 text-green-600 shrink-0" />
                            <span>{risk.mitigation}</span>
                          </div>
                        </td>
                      </tr>
                    ))
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Footer */}
      <div className="border-t border-slate-200 pt-6 flex justify-between text-xs text-slate-400">
        <p>Generated by {COMPANY_NAME} ThreatGuard</p>
        <p>Page 1 of 1</p>
      </div>
    </div>
  );
};

export default ReportTemplate;
