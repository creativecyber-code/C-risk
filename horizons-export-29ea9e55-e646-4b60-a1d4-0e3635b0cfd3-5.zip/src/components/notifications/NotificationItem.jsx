
import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import { AlertTriangle, Info, CheckCircle2, Zap, Users, ShieldAlert } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const NotificationItem = ({ notification, onRead, compact = false }) => {
  const isCritical = notification.severity === 'Critical';
  const isHigh = notification.severity === 'High';

  const getIcon = () => {
    switch (notification.type) {
      case 'THREAT': return <ShieldAlert className="w-4 h-4" />;
      case 'RISK': return <AlertTriangle className="w-4 h-4" />;
      case 'COMPLIANCE': return <CheckCircle2 className="w-4 h-4" />;
      case 'INTEGRATION': return <Zap className="w-4 h-4" />;
      case 'TEAM': return <Users className="w-4 h-4" />;
      default: return <Info className="w-4 h-4" />;
    }
  };

  const getColor = () => {
    switch (notification.severity) {
      case 'Critical': return 'text-red-600 bg-red-100';
      case 'High': return 'text-orange-600 bg-orange-100';
      case 'Medium': return 'text-yellow-600 bg-yellow-100';
      case 'Low': return 'text-green-600 bg-green-100';
      default: return 'text-blue-600 bg-blue-100';
    }
  };

  return (
    <div className={cn(
      "relative flex gap-3 p-4 transition-colors hover:bg-slate-50 border-b border-slate-100 last:border-0",
      !notification.is_read && "bg-slate-50/50"
    )}>
      {!notification.is_read && (
        <span className="absolute top-4 right-4 w-2 h-2 rounded-full bg-blue-500" />
      )}
      
      <div className={cn("flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center mt-1", getColor())}>
        {getIcon()}
      </div>

      <div className="flex-1 space-y-1">
        <div className="flex items-start justify-between pr-4">
          <p className={cn("text-sm font-medium leading-none", !notification.is_read ? "text-slate-900" : "text-slate-600")}>
            {notification.title}
          </p>
        </div>
        
        <p className="text-sm text-slate-500 line-clamp-2">
          {notification.message}
        </p>

        <div className="flex items-center gap-2 mt-2">
          <span className="text-xs text-slate-400">
            {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true })}
          </span>
          <Badge variant="outline" className={cn("text-[10px] h-5 px-1.5", getColor(), "bg-transparent border-current opacity-70")}>
            {notification.severity}
          </Badge>
          
          {notification.link && !compact && (
            <Button variant="link" size="sm" className="h-auto p-0 text-xs ml-auto" asChild>
              <a href={notification.link}>View Details</a>
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default NotificationItem;
