
import React, { useEffect, useState } from 'react';
import { Bell, Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { notificationService } from '@/services/notificationService';
import NotificationItem from './NotificationItem';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const NotificationCenter = () => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();

  const fetchNotifications = async () => {
    if (!user?.id) return;

    try {
      // Pass user.id first, then the limit
      const data = await notificationService.getNotifications(user.id, 5);
      const count = await notificationService.getUnreadCount(user.id);
      setNotifications(data || []);
      setUnreadCount(count || 0);
    } catch (error) {
      console.error("Error fetching notifications", error);
    }
  };

  useEffect(() => {
    if (user?.id) {
      fetchNotifications();

      // Subscribe to realtime changes for this specific user
      const channel = supabase
        .channel(`public:notifications:${user.id}`)
        .on('postgres_changes', 
          { 
            event: 'INSERT', 
            schema: 'public', 
            table: 'notifications',
            filter: `user_id=eq.${user.id}` 
          }, 
          (payload) => {
            fetchNotifications();
            
            // Immediate Toast for critical items
            if (['Critical', 'High'].includes(payload.new.severity)) {
              toast({
                title: payload.new.title,
                description: payload.new.message,
                variant: payload.new.severity === 'Critical' ? 'destructive' : 'default',
              });
            }
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [user?.id, toast]);

  const handleMarkAllRead = async () => {
    if (!user?.id) return;
    await notificationService.markAllAsRead(user.id);
    fetchNotifications();
  };

  const handleViewHistory = () => {
    setIsOpen(false);
    navigate('/dashboard/notifications');
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative text-slate-500 hover:text-slate-900">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-red-600 ring-2 ring-white animate-pulse" />
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="flex items-center justify-between px-4 py-3 border-b bg-slate-50/50">
          <h4 className="font-semibold text-sm">Notifications</h4>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" className="h-auto p-1 text-xs text-blue-600 hover:text-blue-700" onClick={handleMarkAllRead}>
              <Check className="w-3 h-3 mr-1" /> Mark all read
            </Button>
          )}
        </div>
        <ScrollArea className="h-[300px]">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full p-4 text-center">
              <Bell className="w-8 h-8 text-slate-200 mb-2" />
              <p className="text-sm text-slate-500">No recent notifications</p>
            </div>
          ) : (
            notifications.map(n => (
              <NotificationItem 
                key={n.id} 
                notification={n} 
                compact={true} 
              />
            ))
          )}
        </ScrollArea>
        <div className="p-2 border-t bg-slate-50/50">
          <Button variant="outline" className="w-full text-xs h-8" onClick={handleViewHistory}>
            View All History
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default NotificationCenter;
