
import React, { useState, useEffect } from 'react';
import { adminService } from '@/services/adminService';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { Edit2, Plus, Check } from 'lucide-react';

const PricingManagement = () => {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingPlan, setEditingPlan] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    loadPlans();
  }, []);

  const loadPlans = async () => {
    try {
      const data = await adminService.getSubscriptionPlans();
      setPlans(data);
    } catch (error) {
      toast({ title: "Failed to load plans", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      if (editingPlan.id) {
        await adminService.updateSubscriptionPlan(editingPlan.id, editingPlan);
        toast({ title: "Plan updated successfully" });
      } else {
        await adminService.createSubscriptionPlan(editingPlan);
        toast({ title: "Plan created successfully" });
      }
      setEditingPlan(null);
      loadPlans();
    } catch (error) {
      toast({ title: "Operation failed", description: error.message, variant: "destructive" });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Subscription Plans</h2>
          <p className="text-muted-foreground">Manage pricing tiers and feature sets.</p>
        </div>
        <Button onClick={() => setEditingPlan({ name: '', price_monthly: 0, features: [], limits: {} })}>
          <Plus className="mr-2 h-4 w-4" /> Create Plan
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {plans.map((plan) => (
          <Card key={plan.id} className="flex flex-col relative overflow-hidden">
             {!plan.is_active && (
               <div className="absolute top-0 right-0 bg-slate-100 px-3 py-1 text-xs font-mono rounded-bl">Inactive</div>
             )}
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                {plan.name}
                <span className="text-xl font-bold">${plan.price_monthly}<span className="text-sm font-normal text-muted-foreground">/mo</span></span>
              </CardTitle>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow space-y-4">
               <div className="text-sm font-medium">Features:</div>
               <ul className="space-y-2 text-sm text-muted-foreground">
                 {(Array.isArray(plan.features) ? plan.features : []).map((f, i) => (
                   <li key={i} className="flex items-start">
                     <Check className="mr-2 h-4 w-4 text-green-500 shrink-0 mt-0.5" />
                     {f}
                   </li>
                 ))}
               </ul>
               <div className="pt-4 border-t">
                 <div className="text-sm font-medium mb-2">Limits:</div>
                 <div className="grid grid-cols-2 gap-2 text-sm">
                   <div className="bg-slate-50 p-2 rounded">
                     <span className="text-muted-foreground block text-xs">Users</span>
                     <span className="font-semibold">{plan.limits?.users === -1 ? 'Unlimited' : plan.limits?.users || 0}</span>
                   </div>
                   <div className="bg-slate-50 p-2 rounded">
                     <span className="text-muted-foreground block text-xs">Projects</span>
                     <span className="font-semibold">{plan.limits?.projects === -1 ? 'Unlimited' : plan.limits?.projects || 0}</span>
                   </div>
                 </div>
               </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={() => setEditingPlan(plan)}>
                <Edit2 className="mr-2 h-4 w-4" /> Edit Plan
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <Dialog open={!!editingPlan} onOpenChange={(open) => !open && setEditingPlan(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingPlan?.id ? 'Edit Plan' : 'Create New Plan'}</DialogTitle>
          </DialogHeader>
          {editingPlan && (
            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Plan Name</Label>
                  <Input 
                    value={editingPlan.name} 
                    onChange={e => setEditingPlan({...editingPlan, name: e.target.value})} 
                    required 
                  />
                </div>
                <div className="space-y-2">
                   <Label>Monthly Price ($)</Label>
                   <Input 
                     type="number" 
                     value={editingPlan.price_monthly} 
                     onChange={e => setEditingPlan({...editingPlan, price_monthly: e.target.value})} 
                     required 
                   />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Input 
                  value={editingPlan.description} 
                  onChange={e => setEditingPlan({...editingPlan, description: e.target.value})} 
                />
              </div>
              
              <div className="space-y-2">
                <Label>Features (JSON Array)</Label>
                <Textarea 
                  className="font-mono text-xs"
                  value={JSON.stringify(editingPlan.features, null, 2)}
                  onChange={e => {
                    try {
                      const parsed = JSON.parse(e.target.value);
                      setEditingPlan({...editingPlan, features: parsed});
                    } catch (err) {
                      // Allow typing, validate on submit strictly if needed
                    }
                  }}
                />
                <p className="text-xs text-muted-foreground">Enter as ["Feature 1", "Feature 2"]</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                 <div className="space-y-2">
                   <Label>User Limit (-1 for unlim.)</Label>
                   <Input 
                     type="number"
                     value={editingPlan.limits?.users ?? 5}
                     onChange={e => setEditingPlan({
                       ...editingPlan, 
                       limits: { ...editingPlan.limits, users: parseInt(e.target.value) }
                     })}
                   />
                 </div>
                 <div className="space-y-2">
                   <Label>Project Limit (-1 for unlim.)</Label>
                   <Input 
                     type="number"
                     value={editingPlan.limits?.projects ?? 3}
                     onChange={e => setEditingPlan({
                       ...editingPlan, 
                       limits: { ...editingPlan.limits, projects: parseInt(e.target.value) }
                     })}
                   />
                 </div>
              </div>

              <div className="flex items-center space-x-2 pt-2">
                <Switch 
                  checked={editingPlan.is_active !== false}
                  onCheckedChange={c => setEditingPlan({...editingPlan, is_active: c})}
                />
                <Label>Active (Visible to users)</Label>
              </div>

              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setEditingPlan(null)}>Cancel</Button>
                <Button type="submit">Save Plan</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PricingManagement;
