
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Download, Trash2, Search, Eye, FileText, Calendar, Building, Mail, Phone, Briefcase, ShieldCheck } from 'lucide-react';
import { enquiryService } from '@/services/enquiryService';
import * as XLSX from 'xlsx';

const EnquiryManagement = () => {
  const [enquiries, setEnquiries] = useState([]);
  const [filteredEnquiries, setFilteredEnquiries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEnquiry, setSelectedEnquiry] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    loadEnquiries();
  }, []);

  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredEnquiries(enquiries);
    } else {
      const lowerTerm = searchTerm.toLowerCase();
      const filtered = enquiries.filter(
        (e) => 
          e.name.toLowerCase().includes(lowerTerm) ||
          e.organization.toLowerCase().includes(lowerTerm) ||
          e.email.toLowerCase().includes(lowerTerm)
      );
      setFilteredEnquiries(filtered);
    }
  }, [searchTerm, enquiries]);

  const loadEnquiries = async () => {
    setLoading(true);
    try {
      const data = await enquiryService.getAllEnquiries();
      setEnquiries(data);
      setFilteredEnquiries(data);
    } catch (error) {
      console.error("Failed to load enquiries", error);
      toast({
        title: "Error",
        description: "Could not load enquiries. Ensure you have admin permissions.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id, e) => {
    e.stopPropagation(); // Prevent row click
    // eslint-disable-next-line no-restricted-globals
    if (!window.confirm("Are you sure you want to delete this enquiry? This action cannot be undone.")) return;

    try {
      await enquiryService.deleteEnquiry(id);
      toast({ title: "Enquiry deleted successfully" });
      loadEnquiries(); // Refresh list
      if (selectedEnquiry?.id === id) setSelectedEnquiry(null);
    } catch (error) {
      toast({ title: "Delete Failed", description: error.message, variant: "destructive" });
    }
  };

  const handleExport = () => {
    const worksheet = XLSX.utils.json_to_sheet(enquiries.map(e => ({
      Date: new Date(e.created_at).toLocaleDateString(),
      Name: e.name,
      Organization: e.organization,
      Email: e.email,
      Phone: e.phone || 'N/A',
      Industry: e.industry,
      Regulatory_Needs: Array.isArray(e.regulatory_status) ? e.regulatory_status.join(', ') : '',
      Use_Case: e.use_case,
      DPDP_Consent: e.dpdp_consent ? 'Yes' : 'No'
    })));

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Enquiries");
    XLSX.writeFile(workbook, `C-RISK_Enquiries_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const DetailsView = ({ enquiry }) => {
    if (!enquiry) return null;
    return (
      <ScrollArea className="h-[60vh] pr-4">
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4 text-sm">
             <div>
               <p className="text-muted-foreground mb-1 flex items-center gap-1"><Calendar className="w-3 h-3"/> Date Received</p>
               <p className="font-medium">{new Date(enquiry.created_at).toLocaleString()}</p>
             </div>
             <div>
               <p className="text-muted-foreground mb-1 flex items-center gap-1"><Briefcase className="w-3 h-3"/> Industry</p>
               <Badge variant="outline">{enquiry.industry}</Badge>
             </div>
          </div>

          <div className="flex items-center gap-2 p-3 bg-green-50 text-green-800 border border-green-200 rounded-md">
            <ShieldCheck className="w-5 h-5" />
            <div className="text-sm">
              <span className="font-semibold">DPDP Consent:</span> {enquiry.dpdp_consent ? 'Granted (Verified)' : 'Not Recorded'}
            </div>
          </div>

          <div className="space-y-4 border rounded-lg p-4 bg-slate-50">
            <h4 className="font-semibold text-slate-900 border-b pb-2">Contact Information</h4>
            <div className="grid gap-3">
              <div>
                <p className="text-xs text-muted-foreground">Name</p>
                <p className="font-medium">{enquiry.name}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Organization</p>
                <div className="flex items-center gap-2">
                  <Building className="w-4 h-4 text-slate-400" />
                  <p className="font-medium">{enquiry.organization}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                   <p className="text-xs text-muted-foreground">Email</p>
                   <div className="flex items-center gap-2">
                     <Mail className="w-4 h-4 text-slate-400" />
                     <a href={`mailto:${enquiry.email}`} className="text-blue-600 hover:underline">{enquiry.email}</a>
                   </div>
                </div>
                <div>
                   <p className="text-xs text-muted-foreground">Phone</p>
                   <div className="flex items-center gap-2">
                     <Phone className="w-4 h-4 text-slate-400" />
                     <p>{enquiry.phone || 'N/A'}</p>
                   </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-semibold text-slate-900">Regulatory Focus</h4>
            <div className="flex flex-wrap gap-2">
              {enquiry.regulatory_status && enquiry.regulatory_status.length > 0 ? (
                enquiry.regulatory_status.map((reg, idx) => (
                  <Badge key={idx} variant="secondary" className="bg-blue-100 text-blue-800 border-blue-200">
                    {reg}
                  </Badge>
                ))
              ) : (
                <span className="text-sm text-muted-foreground italic">None specified</span>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-semibold text-slate-900">Use Case / Objective</h4>
            <div className="p-4 rounded-lg border bg-white text-sm leading-relaxed whitespace-pre-wrap">
              {enquiry.use_case || "No details provided."}
            </div>
          </div>
        </div>
      </ScrollArea>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Enquiries</h2>
          <p className="text-muted-foreground">Manage incoming enterprise demo requests.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={handleExport} disabled={enquiries.length === 0}>
            <Download className="mr-2 h-4 w-4" /> Export CSV
          </Button>
        </div>
      </div>

      <div className="flex items-center py-4">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search enquiries..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8"
          />
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Organization</TableHead>
                <TableHead>Industry</TableHead>
                <TableHead>Work Email</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">
                    <Loader2 className="h-6 w-6 animate-spin mx-auto text-slate-400" />
                  </TableCell>
                </TableRow>
              ) : filteredEnquiries.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                    No enquiries found.
                  </TableCell>
                </TableRow>
              ) : (
                filteredEnquiries.map((item) => (
                  <TableRow key={item.id} className="cursor-pointer hover:bg-slate-50">
                    <TableCell className="font-medium">
                      {new Date(item.created_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell>{item.name}</TableCell>
                    <TableCell>{item.organization}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{item.industry}</Badge>
                    </TableCell>
                    <TableCell>{item.email}</TableCell>
                    <TableCell className="text-right">
                       <div className="flex items-center justify-end gap-2">
                         <Dialog>
                           <DialogTrigger asChild>
                             <Button size="icon" variant="ghost" onClick={() => setSelectedEnquiry(item)}>
                               <Eye className="h-4 w-4 text-blue-600" />
                             </Button>
                           </DialogTrigger>
                           <DialogContent className="max-w-xl">
                             <DialogHeader>
                               <DialogTitle>Enquiry Details</DialogTitle>
                               <DialogDescription>Submitted on {new Date(item.created_at).toLocaleString()}</DialogDescription>
                             </DialogHeader>
                             <DetailsView enquiry={item} />
                             <DialogFooter>
                                <Button variant="destructive" onClick={(e) => {
                                  // Close dialog logic handled by state change or wrapping component if needed
                                  // For simplicity in this structure, we just call delete
                                  handleDelete(item.id, e);
                                }}>Delete Enquiry</Button>
                             </DialogFooter>
                           </DialogContent>
                         </Dialog>

                         <Button size="icon" variant="ghost" onClick={(e) => handleDelete(item.id, e)}>
                           <Trash2 className="h-4 w-4 text-red-500" />
                         </Button>
                       </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default EnquiryManagement;
