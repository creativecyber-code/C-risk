
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Check, X, HelpCircle } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { accessControlService } from '@/services/accessControlService';

const PermissionMatrix = ({ orgId }) => {
  const [permissions, setPermissions] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPermissions();
  }, []);

  const loadPermissions = async () => {
    try {
      const data = await accessControlService.getPermissionsMatrix();
      setPermissions(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const roles = ['Admin', 'Architect', 'Auditor', 'Viewer'];
  const permissionKeys = [
    { key: 'models:create', label: 'Create Models', desc: 'Create new threat models from scratch or templates' },
    { key: 'models:delete', label: 'Delete Models', desc: 'Permanently remove threat models' },
    { key: 'users:manage', label: 'Manage Users', desc: 'Invite, edit, and remove users' },
    { key: 'settings:edit', label: 'Edit Settings', desc: 'Modify organization settings and security policies' },
    { key: 'billing:manage', label: 'Manage Billing', desc: 'Access invoices and subscription settings' },
    { key: 'audit:view', label: 'View Audit Logs', desc: 'Access system activity history' },
  ];

  if (loading) return <div className="p-8 text-center">Loading permissions...</div>;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Role Permissions</CardTitle>
        <CardDescription>Overview of access levels for each system role.</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[300px]">Permission</TableHead>
              {roles.map(role => (
                <TableHead key={role} className="text-center">{role}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {permissionKeys.map((perm) => (
              <TableRow key={perm.key}>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{perm.label}</span>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger>
                          <HelpCircle className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>{perm.desc}</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </TableCell>
                {roles.map(role => {
                  const hasPerm = permissions[role]?.[perm.key];
                  return (
                    <TableCell key={`${role}-${perm.key}`} className="text-center">
                      <div className="flex justify-center">
                        {hasPerm ? (
                          <div className="rounded-full bg-green-100 p-1">
                            <Check className="h-4 w-4 text-green-600" />
                          </div>
                        ) : (
                          <div className="rounded-full bg-slate-100 p-1">
                            <X className="h-4 w-4 text-slate-400" />
                          </div>
                        )}
                      </div>
                    </TableCell>
                  );
                })}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default PermissionMatrix;
