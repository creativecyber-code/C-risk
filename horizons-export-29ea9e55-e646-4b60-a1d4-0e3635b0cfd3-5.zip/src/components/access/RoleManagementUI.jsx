
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { TENANT_ROLES, ROLE_PERMISSIONS, PERMISSIONS } from '@/lib/rbac_constants';
import { Shield, Plus, Save, Trash2 } from 'lucide-react';

const RoleManagementUI = ({ orgId }) => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('standard');
  const [customRoles, setCustomRoles] = useState([]);
  const [newRoleName, setNewRoleName] = useState('');
  const [selectedPermissions, setSelectedPermissions] = useState({});

  useEffect(() => {
    if (orgId) fetchCustomRoles();
  }, [orgId]);

  const fetchCustomRoles = async () => {
    const { data } = await supabase.from('roles').select('*').eq('org_id', orgId);
    if (data) setCustomRoles(data);
  };

  const handleCreateRole = async () => {
    if (!newRoleName.trim()) return;
    
    const { data, error } = await supabase.from('roles').insert({
      org_id: orgId,
      name: newRoleName,
      description: 'Custom Role',
      is_system_role: false
    }).select().single();

    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      setCustomRoles([...customRoles, data]);
      setNewRoleName('');
      toast({ title: "Role Created", description: `Role ${newRoleName} added.` });
    }
  };

  // Group permissions by category for UI
  const groupedPermissions = Object.entries(PERMISSIONS).reduce((acc, [key, value]) => {
    const category = value.split(':')[0].toUpperCase();
    if (!acc[category]) acc[category] = [];
    acc[category].push({ key, value });
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
           <h3 className="text-lg font-medium">Role Management</h3>
           <p className="text-sm text-muted-foreground">Define what each role can do within your organization.</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="standard">Standard Roles</TabsTrigger>
          <TabsTrigger value="custom">Custom Roles</TabsTrigger>
        </TabsList>

        <TabsContent value="standard" className="space-y-4">
           <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
             {Object.entries(TENANT_ROLES).map(([key, roleName]) => (
               <Card key={key}>
                 <CardHeader className="pb-2">
                   <div className="flex justify-between">
                      <CardTitle className="text-base">{roleName}</CardTitle>
                      <Badge variant="secondary">System</Badge>
                   </div>
                 </CardHeader>
                 <CardContent>
                   <div className="text-sm text-slate-500 mb-4">
                     {ROLE_PERMISSIONS[roleName] 
                       ? `${ROLE_PERMISSIONS[roleName].length} permissions assigned.` 
                       : 'Restricted access.'}
                   </div>
                   <div className="flex flex-wrap gap-1">
                      {(ROLE_PERMISSIONS[roleName] || []).slice(0, 3).map(p => (
                        <Badge key={p} variant="outline" className="text-[10px]">{p.split(':').pop()}</Badge>
                      ))}
                      {(ROLE_PERMISSIONS[roleName] || []).length > 3 && (
                        <Badge variant="outline" className="text-[10px]">+{(ROLE_PERMISSIONS[roleName] || []).length - 3} more</Badge>
                      )}
                   </div>
                 </CardContent>
               </Card>
             ))}
           </div>
        </TabsContent>

        <TabsContent value="custom" className="space-y-4">
           <div className="flex gap-4 items-end bg-slate-50 p-4 rounded-lg border">
             <div className="space-y-2 flex-1">
               <label className="text-sm font-medium">New Role Name</label>
               <Input 
                 placeholder="e.g. Junior Analyst" 
                 value={newRoleName}
                 onChange={e => setNewRoleName(e.target.value)}
               />
             </div>
             <Button onClick={handleCreateRole}><Plus className="w-4 h-4 mr-2" /> Create Role</Button>
           </div>

           {customRoles.length === 0 ? (
             <div className="text-center py-8 text-slate-500 border-2 border-dashed rounded-lg">
               No custom roles defined.
             </div>
           ) : (
             <div className="space-y-4">
                {customRoles.map(role => (
                  <Card key={role.id}>
                    <CardHeader className="pb-2 flex flex-row items-center justify-between">
                       <CardTitle className="text-base">{role.name}</CardTitle>
                       <Button variant="ghost" size="sm" className="text-red-500"><Trash2 className="w-4 h-4" /></Button>
                    </CardHeader>
                    <CardContent>
                       <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          {Object.entries(groupedPermissions).map(([category, perms]) => (
                             <div key={category} className="space-y-2">
                                <h5 className="text-xs font-bold text-slate-400">{category}</h5>
                                {perms.map(p => (
                                  <div key={p.value} className="flex items-center space-x-2">
                                     <Checkbox id={`${role.id}-${p.value}`} />
                                     <label htmlFor={`${role.id}-${p.value}`} className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                       {p.value.split(':').pop()}
                                     </label>
                                  </div>
                                ))}
                             </div>
                          ))}
                       </div>
                    </CardContent>
                  </Card>
                ))}
             </div>
           )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default RoleManagementUI;
