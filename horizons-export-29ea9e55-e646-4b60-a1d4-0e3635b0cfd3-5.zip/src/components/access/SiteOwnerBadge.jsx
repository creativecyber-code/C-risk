
import React from 'react';
import { Crown } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const SiteOwnerBadge = () => {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge variant="default" className="bg-amber-500 hover:bg-amber-600 border-amber-600 flex gap-1 items-center px-2 py-1">
            <Crown className="h-3 w-3 text-white" />
            <span className="text-xs font-semibold text-white">Site Owner</span>
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <p>You have full system control</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default SiteOwnerBadge;
