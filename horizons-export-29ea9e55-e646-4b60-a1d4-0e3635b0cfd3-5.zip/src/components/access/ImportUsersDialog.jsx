
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { accessControlService } from '@/services/accessControlService';
import { Download } from 'lucide-react';

const ImportUsersDialog = ({ open, onOpenChange, orgId, onSuccess }) => {
  const { toast } = useToast();
  const [csvContent, setCsvContent] = useState('');
  const [loading, setLoading] = useState(false);

  const handleImport = async () => {
    if (!csvContent.trim()) return;
    setLoading(true);

    try {
      // Basic CSV parser
      const lines = csvContent.trim().split('\n');
      const users = lines.map(line => {
        const [email, fullName, role] = line.split(',').map(s => s.trim());
        return { email, fullName, role: role || 'Viewer' };
      }).filter(u => u.email && u.email.includes('@')); // Basic validation

      if (users.length === 0) {
        throw new Error("No valid users found in CSV content");
      }

      const result = await accessControlService.bulkImportUsers(users, orgId);
      
      toast({
        title: "Import Complete",
        description: `Successfully imported ${result.success} users. ${result.failed} failed.`,
        variant: result.failed > 0 ? "warning" : "default"
      });

      if (result.success > 0) {
        onSuccess?.();
        onOpenChange(false);
        setCsvContent('');
      }
    } catch (error) {
      toast({
        title: "Import Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadTemplate = () => {
    const template = "email,full_name,role\njohn@example.com,John Doe,Viewer\njane@example.com,Jane Smith,Architect";
    const blob = new Blob([template], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = "user_import_template.csv";
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Bulk Import Users</DialogTitle>
          <DialogDescription>
            Paste CSV content below. Format: email, full_name, role.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="flex justify-end">
            <Button variant="outline" size="sm" onClick={handleDownloadTemplate}>
              <Download className="mr-2 h-4 w-4" /> Download Template
            </Button>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="csv">CSV Content</Label>
            <Textarea
              id="csv"
              placeholder="john@example.com, John Doe, Viewer"
              className="h-[200px] font-mono text-sm"
              value={csvContent}
              onChange={(e) => setCsvContent(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleImport} disabled={loading || !csvContent.trim()}>
            {loading ? 'Importing...' : 'Import Users'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ImportUsersDialog;
