
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { accessControlService } from '@/services/accessControlService';
import { emailService } from '@/services/emailService';
import { supabase } from '@/lib/customSupabaseClient';

const UserDialog = ({ open, onOpenChange, orgId, userToEdit, onSuccess }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    fullName: '',
    role: 'Viewer'
  });

  useEffect(() => {
    if (userToEdit) {
      setFormData({
        email: userToEdit.email || '',
        fullName: userToEdit.full_name || '',
        role: userToEdit.role || 'Viewer'
      });
    } else {
      setFormData({
        email: '',
        fullName: '',
        role: 'Viewer'
      });
    }
  }, [userToEdit, open]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (userToEdit) {
        // Update existing user logic
        await accessControlService.updateUser(userToEdit.id, {
          role: formData.role,
          full_name: formData.fullName
        }, orgId);
        toast({ title: "User updated successfully" });
      } else {
        // --- NEW INVITATION LOGIC ---
        
        // 1. Fetch Org Name for the email
        const { data: org } = await supabase.from('organizations').select('name').eq('id', orgId).single();
        const orgName = org?.name || 'Organization';

        // 2. Send Invitation via EmailService
        const result = await emailService.sendInvitation(
          formData.email,
          formData.role,
          orgName,
          orgId
        );

        if (!result.success) throw result.error;

        toast({ 
          title: "Invitation Sent", 
          description: `Email sent to ${formData.email}` 
        });
      }
      
      onSuccess?.();
      onOpenChange(false);
    } catch (error) {
      console.error(error);
      toast({ 
        title: "Operation failed", 
        description: error.message || "Could not complete request", 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{userToEdit ? 'Edit User' : 'Invite User'}</DialogTitle>
          <DialogDescription>
            {userToEdit 
              ? 'Update user details and role assignment.' 
              : 'Send an email invitation to join the organization.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Full Name {userToEdit ? '' : '(Optional)'}</Label>
            <Input
              id="name"
              value={formData.fullName}
              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
              placeholder="John Doe"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="john@company.com"
              required
              disabled={!!userToEdit} 
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="role">Role</Label>
            <Select 
              value={formData.role} 
              onValueChange={(val) => setFormData({ ...formData, role: val })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Admin">Admin</SelectItem>
                <SelectItem value="Architect">Architect</SelectItem>
                <SelectItem value="Auditor">Auditor</SelectItem>
                <SelectItem value="Viewer">Viewer</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-[0.8rem] text-muted-foreground">
              {formData.role === 'Admin' ? 'Full access to all settings and data.' : 
               formData.role === 'Viewer' ? 'Read-only access to published models.' : 'Standard access level.'}
            </p>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Processing...' : (userToEdit ? 'Save Changes' : 'Send Invitation')}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default UserDialog;
