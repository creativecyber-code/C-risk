
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { supabase } from '@/lib/customSupabaseClient';
import { Loader2, Database, ShieldAlert, RefreshCw } from 'lucide-react';
import { demoCredentials } from '@/data/demoCredentials';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

// Maps Organization Names to the UUIDs
const ORG_MAP = {
  "HDFC Bank Ltd": "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11",
  "ICICI Bank Ltd": "b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22",
  "Axis Bank Ltd": "c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a33"
};

const DatabaseSeeder = () => {
  const [loading, setLoading] = useState(false);
  const [logs, setLogs] = useState([]);
  const [success, setSuccess] = useState(false);

  const addLog = (msg, type = 'info') => {
    setLogs(prev => [...prev, { msg, type, time: new Date().toLocaleTimeString() }]);
  };

  const seedUsers = async () => {
    setLoading(true);
    setLogs([]);
    setSuccess(false);
    addLog("Starting ADMIN Reset Process...", 'info');
    addLog("Target Password: P@ssw0rd@123", 'info');

    try {
      // Flatten users list for the API
      const allUsers = [];
      demoCredentials.forEach(org => {
        const orgId = ORG_MAP[org.org];
        org.users.forEach(user => {
          allUsers.push({
            ...user,
            orgId
          });
        });
      });

      addLog(`Sending ${allUsers.length} users to Admin API for processing...`, 'info');

      // Call the Edge Function
      const { data, error } = await supabase.functions.invoke('admin-reset-users', {
        body: { users: allUsers }
      });

      if (error) throw error;

      if (data.results) {
        let errorCount = 0;
        data.results.forEach(res => {
          if (res.status === 'error') {
            addLog(`❌ Failed ${res.email}: ${res.error}`, 'error');
            errorCount++;
          } else if (res.status === 'updated') {
             addLog(`✅ Updated Password: ${res.email}`, 'success');
          } else {
             addLog(`✅ Created Fresh: ${res.email}`, 'success');
          }
        });

        if (errorCount === 0) {
            setSuccess(true);
            addLog("🎉 All users processed successfully!", 'success');
            addLog("You can now login with P@ssw0rd@123", 'success');
        } else {
            addLog(`⚠️ Completed with ${errorCount} errors.`, 'warning');
        }
      }

    } catch (err) {
      addLog(`CRITICAL API ERROR: ${err.message}`, 'error');
      addLog("Falling back to client-side seeding (less reliable)...", 'warning');
      await fallbackClientSideSeed();
    } finally {
      setLoading(false);
    }
  };

  // Fallback if Edge Function fails (e.g. locally without proper setup)
  const fallbackClientSideSeed = async () => {
     for (const org of demoCredentials) {
        const orgId = ORG_MAP[org.org];
        for (const user of org.users) {
           try {
              const { data, error } = await supabase.auth.signUp({
                 email: user.email,
                 password: user.password,
                 options: {
                    data: { full_name: user.name, org_id: orgId, role: user.role }
                 }
              });
              
              if (error) {
                 addLog(`Client-side Error ${user.email}: ${error.message}`, 'error');
              } else {
                 addLog(`Client-side Success (Check Email): ${user.email}`, 'success');
                 // Try to insert profile immediately
                 if (data.user) {
                    await supabase.from('user_profiles').upsert({
                        id: data.user.id,
                        email: user.email,
                        full_name: user.name,
                        role: user.role.split(' / ')[0],
                        org_id: orgId,
                        created_at: new Date().toISOString()
                    });
                 }
              }
           } catch (e) {
              addLog(`Client-side Crash ${user.email}: ${e.message}`, 'error');
           }
        }
     }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto mt-4 border-red-200 bg-red-50/50 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-red-900">
          <ShieldAlert className="h-5 w-5" />
          Admin Account Repair Tool
        </CardTitle>
        <CardDescription className="text-red-800">
          Use this to forcefuly reset all demo accounts to default state.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {success && (
             <Alert className="mb-4 bg-green-50 border-green-200 text-green-800">
                <ShieldAlert className="h-4 w-4" />
                <AlertTitle>Success!</AlertTitle>
                <AlertDescription>
                   All accounts repaired. Passwords reset to <b>P@ssw0rd@123</b>.
                </AlertDescription>
             </Alert>
        )}

        <Button 
          onClick={seedUsers} 
          disabled={loading}
          variant="destructive"
          className="w-full mb-4 bg-red-600 hover:bg-red-700"
        >
          {loading ? (
            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Repairing Accounts...</>
          ) : (
            <><RefreshCw className="mr-2 h-4 w-4" /> Reset All Users to P@ssw0rd@123</>
          )}
        </Button>

        <div className="bg-slate-950 rounded-lg p-4 h-48 overflow-y-auto font-mono text-[10px] leading-tight shadow-inner">
          {logs.length === 0 ? (
            <span className="text-slate-500 italic">Waiting to start repair process...</span>
          ) : (
            logs.map((log, i) => (
              <div key={i} className={`mb-1 flex items-start gap-2 ${
                log.type === 'error' ? 'text-red-400 font-bold' : 
                log.type === 'success' ? 'text-emerald-400 font-bold' : 
                log.type === 'warning' ? 'text-yellow-400' : 'text-slate-300'
              }`}>
                <span className="opacity-30 select-none">[{log.time}]</span>
                <span>{log.msg}</span>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default DatabaseSeeder;
