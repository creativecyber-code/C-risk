
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';
import { 
  Loader2, 
  Plus, 
  Trash2, 
  Edit2, 
  Copy, 
  CheckCircle, 
  AlertCircle, 
  Globe, 
  RefreshCw,
  Info
} from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';

const DEFAULT_RECORDS = [
  { type: 'TXT', name: '@', value: 'v=spf1 include:_spf.mail.hostinger.com ~all', status: 'pending' },
  { type: 'CNAME', name: 'creativecyber._domainkey', value: 'dkim.mail.hostinger.com', status: 'pending' },
  { type: 'MX', name: '@', value: 'mx1.hostinger.com', priority: 5, status: 'pending' },
  { type: 'MX', name: '@', value: 'mx2.hostinger.com', priority: 10, status: 'pending' },
];

const DNSSettings = ({ orgId }) => {
  const { toast } = useToast();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [verifying, setVerifying] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [recordToDelete, setRecordToDelete] = useState(null);
  const [newRecord, setNewRecord] = useState({ type: 'TXT', name: '', value: '', priority: '', ttl: 3600 });
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    if (orgId) loadRecords();
  }, [orgId]);

  const loadRecords = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('dns_records')
        .select('*')
        .eq('org_id', orgId)
        .order('type');

      if (error) throw error;
      
      if (!data || data.length === 0) {
        setRecords([]);
      } else {
        setRecords(data);
      }
    } catch (error) {
      console.error('Error loading DNS records:', error);
      toast({ variant: "destructive", title: "Failed to load DNS records" });
    } finally {
      setLoading(false);
    }
  };

  const loadDefaults = async () => {
    try {
      setLoading(true);
      const inserts = DEFAULT_RECORDS.map(rec => ({
        ...rec,
        org_id: orgId,
        ttl: 3600
      }));
      
      const { data, error } = await supabase.from('dns_records').insert(inserts).select();
      if (error) throw error;
      
      setRecords(data);
      
      await supabase.from('app_audit_logs').insert({
        org_id: orgId,
        action: 'DNS_DEFAULTS_LOADED',
        details: { domain: 'creativecyber.in', count: inserts.length },
        status: 'success'
      });
      
      toast({ title: "Default records loaded", description: "Standard Hostinger configuration applied." });
    } catch (error) {
      console.error('Error loading defaults:', error);
      toast({ variant: "destructive", title: "Failed to load defaults" });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveRecord = async () => {
    if (!newRecord.name || !newRecord.value) {
      toast({ variant: "destructive", title: "Missing fields", description: "Name and Value are required." });
      return;
    }

    try {
      let result;
      if (editingId) {
        result = await supabase
          .from('dns_records')
          .update({ ...newRecord, updated_at: new Date().toISOString() })
          .eq('id', editingId)
          .select();
      } else {
        result = await supabase
          .from('dns_records')
          .insert({ 
            ...newRecord, 
            org_id: orgId,
            status: 'pending' 
          })
          .select();
      }

      if (result.error) throw result.error;

      await supabase.from('app_audit_logs').insert({
        org_id: orgId,
        action: editingId ? 'DNS_RECORD_UPDATED' : 'DNS_RECORD_CREATED',
        details: { record: newRecord },
        status: 'success'
      });

      toast({ 
        title: editingId ? "Record Updated" : "Record Added", 
        description: `${newRecord.type} record saved successfully.` 
      });
      
      setIsAddDialogOpen(false);
      setNewRecord({ type: 'TXT', name: '', value: '', priority: '', ttl: 3600 });
      setEditingId(null);
      loadRecords();
    } catch (error) {
      console.error('Error saving record:', error);
      toast({ variant: "destructive", title: "Failed to save record", description: error.message });
    }
  };

  const handleDeleteClick = (id) => {
    setRecordToDelete(id);
    setDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!recordToDelete) return;
    
    try {
      const { error } = await supabase.from('dns_records').delete().eq('id', recordToDelete);
      if (error) throw error;

      await supabase.from('app_audit_logs').insert({
        org_id: orgId,
        action: 'DNS_RECORD_DELETED',
        details: { record_id: recordToDelete },
        status: 'success'
      });

      toast({ title: "Record Deleted" });
      setDeleteDialogOpen(false);
      setRecordToDelete(null);
      loadRecords();
    } catch (error) {
      console.error('Error deleting record:', error);
      toast({ variant: "destructive", title: "Failed to delete record" });
    }
  };

  const handleVerify = async () => {
    setVerifying(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const updates = records.map(async (rec) => {
        const isLikelyValid = rec.value.includes('hostinger') || rec.value.includes('spf');
        const newStatus = isLikelyValid ? 'verified' : 'failed';
        
        await supabase
          .from('dns_records')
          .update({ 
            status: newStatus, 
            last_verified_at: new Date().toISOString() 
          })
          .eq('id', rec.id);
          
        return { ...rec, status: newStatus, last_verified_at: new Date().toISOString() };
      });

      await Promise.all(updates);
      
      await supabase.from('app_audit_logs').insert({
        org_id: orgId,
        action: 'DNS_VERIFICATION_RUN',
        status: 'success'
      });

      toast({ title: "Verification Complete", description: "DNS records status updated." });
      loadRecords();
    } catch (error) {
      console.error('Verification failed:', error);
      toast({ variant: "destructive", title: "Verification Failed" });
    } finally {
      setVerifying(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied!", description: "Value copied to clipboard." });
  };

  const exportRecords = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Type,Name,Value,Priority,TTL,Status\n"
      + records.map(e => `${e.type},${e.name},${e.value},${e.priority || ''},${e.ttl},${e.status}`).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "dns_records_creativecyber.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const openEdit = (record) => {
    setNewRecord({
      type: record.type,
      name: record.name,
      value: record.value,
      priority: record.priority || '',
      ttl: record.ttl
    });
    setEditingId(record.id);
    setIsAddDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>DNS Configuration</CardTitle>
              <CardDescription>Manage DNS records for <strong>creativecyber.in</strong> to ensure email deliverability and domain verification.</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleVerify} disabled={verifying}>
                {verifying ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
                Verify Records
              </Button>
              <Button variant="outline" onClick={exportRecords}>
                Export CSV
              </Button>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button onClick={() => { setEditingId(null); setNewRecord({ type: 'TXT', name: '', value: '', priority: '', ttl: 3600 }); }}>
                    <Plus className="mr-2 h-4 w-4" /> Add Record
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{editingId ? 'Edit DNS Record' : 'Add DNS Record'}</DialogTitle>
                    <DialogDescription>
                      Add a new record to your zone file. Changes may take up to 48 hours to propagate.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right">Type</Label>
                      <Select 
                        value={newRecord.type} 
                        onValueChange={(val) => setNewRecord({...newRecord, type: val})}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="A">A</SelectItem>
                          <SelectItem value="CNAME">CNAME</SelectItem>
                          <SelectItem value="MX">MX</SelectItem>
                          <SelectItem value="TXT">TXT</SelectItem>
                          <SelectItem value="SPF">SPF</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right">Name</Label>
                      <Input 
                        value={newRecord.name} 
                        onChange={(e) => setNewRecord({...newRecord, name: e.target.value})}
                        className="col-span-3" 
                        placeholder="@ for root"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right">Value</Label>
                      <Input 
                        value={newRecord.value} 
                        onChange={(e) => setNewRecord({...newRecord, value: e.target.value})}
                        className="col-span-3" 
                        placeholder="IP address or domain"
                      />
                    </div>
                    {newRecord.type === 'MX' && (
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label className="text-right">Priority</Label>
                        <Input 
                          type="number"
                          value={newRecord.priority} 
                          onChange={(e) => setNewRecord({...newRecord, priority: e.target.value})}
                          className="col-span-3" 
                          placeholder="10"
                        />
                      </div>
                    )}
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right">TTL</Label>
                      <Input 
                        type="number"
                        value={newRecord.ttl} 
                        onChange={(e) => setNewRecord({...newRecord, ttl: e.target.value})}
                        className="col-span-3" 
                        placeholder="3600"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button onClick={handleSaveRecord}>Save Changes</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-muted-foreground">Loading DNS records...</div>
          ) : records.length === 0 ? (
            <div className="text-center py-12 border-2 border-dashed rounded-lg">
              <Globe className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No DNS Records Found</h3>
              <p className="text-muted-foreground mb-6">Start by adding standard records for creativecyber.in</p>
              <Button onClick={loadDefaults}>Load Default Hostinger Records</Button>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[80px]">Type</TableHead>
                    <TableHead className="w-[150px]">Name</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead className="w-[80px]">Priority</TableHead>
                    <TableHead className="w-[100px]">TTL</TableHead>
                    <TableHead className="w-[120px]">Status</TableHead>
                    <TableHead className="w-[100px] text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {records.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>
                        <Badge variant="outline">{record.type}</Badge>
                      </TableCell>
                      <TableCell className="font-mono text-sm">{record.name}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 max-w-[300px] md:max-w-[400px]">
                          <span className="truncate font-mono text-sm" title={record.value}>{record.value}</span>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6 shrink-0" 
                            onClick={() => copyToClipboard(record.value)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell>{record.priority || '-'}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">{record.ttl}</TableCell>
                      <TableCell>
                        {record.status === 'verified' ? (
                          <div className="flex items-center text-green-600 text-xs font-medium">
                            <CheckCircle className="mr-1 h-3 w-3" /> Verified
                          </div>
                        ) : record.status === 'failed' ? (
                          <div className="flex items-center text-red-500 text-xs font-medium">
                            <AlertCircle className="mr-1 h-3 w-3" /> Failed
                          </div>
                        ) : (
                          <div className="flex items-center text-yellow-600 text-xs font-medium">
                            <RefreshCw className="mr-1 h-3 w-3 animate-spin" /> Pending
                          </div>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(record)}>
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => handleDeleteClick(record.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        <CardFooter className="bg-slate-50 border-t px-6 py-4">
          <div className="flex items-start gap-2 text-sm text-muted-foreground w-full">
            <Info className="h-4 w-4 mt-0.5 shrink-0 text-blue-500" />
            <div>
              <p className="font-medium text-slate-700">Propagation Status</p>
              <p>DNS changes can take up to 48 hours to propagate globally. Use the verify button to check the current status of your records.</p>
            </div>
          </div>
        </CardFooter>
      </Card>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete DNS Record</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this DNS record? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex gap-3 justify-end">
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
      
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Verification Checklist</CardTitle>
            <CardDescription>Required records for full domain functionality</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
             <div className="flex items-center justify-between border-b pb-2">
                <div className="space-y-1">
                  <span className="font-medium flex items-center gap-2">SPF Record <Badge variant="secondary" className="text-[10px]">Security</Badge></span>
                  <p className="text-xs text-muted-foreground">Prevents email spoofing by listing authorized IPs.</p>
                </div>
                {records.some(r => r.type === 'TXT' && r.value.includes('spf')) ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-yellow-500" />
                )}
             </div>
             <div className="flex items-center justify-between border-b pb-2">
                <div className="space-y-1">
                  <span className="font-medium flex items-center gap-2">DKIM Record <Badge variant="secondary" className="text-[10px]">Authenticity</Badge></span>
                  <p className="text-xs text-muted-foreground">Cryptographic signature verifying email origin.</p>
                </div>
                {records.some(r => r.value.includes('dkim')) ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-yellow-500" />
                )}
             </div>
             <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <span className="font-medium flex items-center gap-2">MX Records <Badge variant="secondary" className="text-[10px]">Delivery</Badge></span>
                  <p className="text-xs text-muted-foreground">Directs incoming email to mail servers.</p>
                </div>
                {records.some(r => r.type === 'MX') ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-yellow-500" />
                )}
             </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Configuration Guide</CardTitle>
            <CardDescription>How to update your registrar settings</CardDescription>
          </CardHeader>
          <CardContent>
            <ol className="list-decimal list-inside space-y-3 text-sm text-slate-700">
              <li>Log in to your domain registrar's dashboard (e.g., Hostinger, GoDaddy).</li>
              <li>Navigate to the <strong>DNS Zone Editor</strong> or <strong>DNS Management</strong> section.</li>
              <li>Locate the option to <strong>Add New Record</strong>.</li>
              <li>Copy the values from the table above for each missing record type (SPF, DKIM, MX).</li>
              <li>Paste the values into your registrar's form fields. Note: For "Name", some registrars require "@" while others require leaving it blank for the root domain.</li>
              <li>Save your changes and return here to click <strong>Verify Records</strong>.</li>
            </ol>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DNSSettings;
