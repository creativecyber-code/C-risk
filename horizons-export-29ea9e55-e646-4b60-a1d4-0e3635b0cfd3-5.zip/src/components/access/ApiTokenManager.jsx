
import React, { useState, useEffect } from 'react';
import { Key, Copy, Trash2, Eye, EyeOff, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/components/ui/use-toast';
import { accessControlService } from '@/services/accessControlService';

const ApiTokenManager = () => {
  const [tokens, setTokens] = useState([]);
  const [newTokenName, setNewTokenName] = useState('');
  const [generatedToken, setGeneratedToken] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadTokens();
  }, []);

  const loadTokens = async () => {
    try {
      const data = await accessControlService.getApiTokens();
      setTokens(data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreate = async () => {
    try {
      // Default scopes for demo
      const scopes = ['threat_models:read', 'analytics:view']; 
      const res = await accessControlService.generateApiToken(newTokenName, scopes);
      setGeneratedToken(res.tokenRaw);
      setNewTokenName('');
      loadTokens();
    } catch (e) {
      toast({ title: "Failed to create token", variant: "destructive" });
    }
  };

  const handleRevoke = async (id) => {
    try {
      await accessControlService.revokeToken(id);
      loadTokens();
      toast({ title: "Token revoked" });
    } catch (e) {
      toast({ title: "Failed to revoke", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-medium">API Access Tokens</h3>
          <p className="text-sm text-slate-500">Manage tokens for external integrations and CI/CD.</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="w-4 h-4 mr-2" /> Generate Token</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New API Token</DialogTitle>
            </DialogHeader>
            
            {!generatedToken ? (
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Token Name</Label>
                  <Input 
                    placeholder="e.g. Jenkins CI Pipeline" 
                    value={newTokenName}
                    onChange={e => setNewTokenName(e.target.value)}
                  />
                </div>
                <div className="text-sm text-slate-500 bg-slate-50 p-3 rounded">
                  <p>Scopes (Hardcoded for demo):</p>
                  <ul className="list-disc pl-5 mt-1">
                    <li>threat_models:read</li>
                    <li>analytics:view</li>
                  </ul>
                </div>
              </div>
            ) : (
              <div className="space-y-4 py-4">
                <div className="bg-green-50 border border-green-200 p-4 rounded-lg text-center">
                  <p className="text-sm text-green-800 mb-2 font-medium">Token Generated Successfully!</p>
                  <div className="flex items-center gap-2 bg-white p-2 border rounded">
                     <code className="text-xs font-mono break-all text-slate-600">{generatedToken}</code>
                     <Button variant="ghost" size="sm" onClick={() => navigator.clipboard.writeText(generatedToken)}>
                       <Copy className="w-4 h-4" />
                     </Button>
                  </div>
                  <p className="text-xs text-red-500 mt-2">
                    Copy this now. You won't be able to see it again!
                  </p>
                </div>
              </div>
            )}

            <DialogFooter>
              {!generatedToken ? (
                 <Button onClick={handleCreate} disabled={!newTokenName}>Generate</Button>
              ) : (
                 <Button onClick={() => { setIsDialogOpen(false); setGeneratedToken(null); }}>Done</Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {tokens.length === 0 && <p className="text-slate-500 text-sm italic">No active tokens found.</p>}
        {tokens.map(token => (
          <Card key={token.id} className="flex items-center justify-between p-4">
             <div className="flex items-center gap-4">
               <div className="p-2 bg-slate-100 rounded-lg">
                 <Key className="w-5 h-5 text-slate-600" />
               </div>
               <div>
                 <div className="font-medium">{token.name}</div>
                 <div className="text-xs text-slate-500 flex gap-2">
                   <span>Created: {new Date(token.created_at).toLocaleDateString()}</span>
                   <span>•</span>
                   <span>Expires: {new Date(token.expires_at).toLocaleDateString()}</span>
                 </div>
               </div>
             </div>
             <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-700 hover:bg-red-50" onClick={() => handleRevoke(token.id)}>
               <Trash2 className="w-4 h-4" />
             </Button>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ApiTokenManager;
