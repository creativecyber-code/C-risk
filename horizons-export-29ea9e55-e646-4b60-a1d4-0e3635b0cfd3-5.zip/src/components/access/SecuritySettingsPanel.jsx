
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import EmailConfiguration from './EmailConfiguration';
import SecuritySettings from './SecuritySettings';

const SecuritySettingsPanel = ({ orgId }) => {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Authentication & Security</CardTitle>
          <CardDescription>Manage how your users log in and access the platform.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
           {/* Replaced the static placeholder with the full functional component */}
           <div className="p-6 pt-0">
             <SecuritySettings orgId={orgId} />
           </div>
        </CardContent>
      </Card>

      {/* Integrate the Email Logs/Config here as part of system settings */}
      <EmailConfiguration orgId={orgId} />
    </div>
  );
};

export default SecuritySettingsPanel;
