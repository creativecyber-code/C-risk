
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { accessControlService } from '@/services/accessControlService';
import { Loader2 } from 'lucide-react';

const OrgSettingsPanel = ({ orgId }) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    industry: '',
    primary_color: '#4f46e5',
    logo_url: ''
  });
  const [currentSettings, setCurrentSettings] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [fetchError, setFetchError] = useState(null);

  useEffect(() => {
    if (orgId) {
      loadData();
    }
  }, [orgId]);

  const loadData = async () => {
    setLoading(true);
    setFetchError(null);
    try {
      const data = await accessControlService.getOrgSettings(orgId);
      if (data) {
        setCurrentSettings(data.settings || {});
        setFormData({
          name: data.name || '',
          industry: data.industry || data.settings?.industry || 'Technology',
          primary_color: data.settings?.theme?.primary_color || '#4f46e5',
          logo_url: data.logo_url || ''
        });
      } else {
        setFetchError("Organization details could not be found.");
      }
    } catch (e) {
      console.error(e);
      setFetchError("Failed to load organization settings. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // We update both the top-level industry column (now that it exists)
      // and the settings JSON for backward compatibility/redundancy if needed.
      await accessControlService.updateOrgSettings(orgId, {
        name: formData.name,
        industry: formData.industry,
        logo_url: formData.logo_url,
        settings: {
          ...currentSettings,
          industry: formData.industry, // Keep in sync
          theme: { 
            ...(currentSettings.theme || {}),
            primary_color: formData.primary_color 
          }
        }
      });
      
      document.documentElement.style.setProperty('--primary', formData.primary_color);
      
      toast({ title: "Organization settings updated successfully" });
    } catch (e) {
      console.error("Update failed:", e);
      toast({ title: "Update failed", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
           <CardTitle>Organization Profile</CardTitle>
           <CardDescription>Loading details...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center py-8">
           <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  if (fetchError) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-red-500 mb-4">{fetchError}</div>
          <Button variant="outline" onClick={loadData}>Retry</Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Organization Profile & Branding</CardTitle>
        <CardDescription>Customize your tenant appearance and details.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-2">
          <Label htmlFor="orgName">Organization Name</Label>
          <Input 
            id="orgName" 
            value={formData.name} 
            onChange={(e) => setFormData({...formData, name: e.target.value})}
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="industry">Industry</Label>
          <Select 
            value={formData.industry}
            onValueChange={(val) => setFormData({...formData, industry: val})}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select industry" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Technology">Technology</SelectItem>
              <SelectItem value="Finance">Finance</SelectItem>
              <SelectItem value="Healthcare">Healthcare</SelectItem>
              <SelectItem value="Retail">Retail</SelectItem>
              <SelectItem value="Manufacturing">Manufacturing</SelectItem>
              <SelectItem value="Energy">Energy</SelectItem>
              <SelectItem value="Government">Government</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
           <div className="space-y-2">
             <Label>Brand Color</Label>
             <div className="flex gap-2">
               <Input 
                 type="color" 
                 value={formData.primary_color}
                 className="w-12 h-10 p-1 cursor-pointer"
                 onChange={(e) => setFormData({...formData, primary_color: e.target.value})}
               />
               <Input 
                 value={formData.primary_color}
                 onChange={(e) => setFormData({...formData, primary_color: e.target.value})}
                 className="uppercase font-mono"
                 placeholder="#000000"
               />
             </div>
           </div>
           <div className="space-y-2">
             <Label>Logo URL</Label>
             <Input 
               value={formData.logo_url}
               onChange={(e) => setFormData({...formData, logo_url: e.target.value})}
               placeholder="https://example.com/logo.png"
             />
           </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <div className="text-xs text-muted-foreground">
          Organization ID: <span className="font-mono">{orgId}</span>
        </div>
        <Button onClick={handleSave} disabled={saving}>
          {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {saving ? 'Saving...' : 'Save Changes'}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default OrgSettingsPanel;
