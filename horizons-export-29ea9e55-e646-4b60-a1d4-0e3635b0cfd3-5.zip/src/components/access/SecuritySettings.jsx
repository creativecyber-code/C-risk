
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Shield, Lock, Fingerprint, CheckCircle, AlertTriangle, Key, ExternalLink } from 'lucide-react';
import { securityConfigService } from '@/services/securityConfigService';
import { auditService } from '@/services/auditService';

const SecuritySettings = ({ orgId }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testingSSO, setTestingSSO] = useState(false);
  const [settings, setSettings] = useState({
    sso_enabled: false,
    sso_provider: '',
    sso_config: {
      client_id: '',
      client_secret: '',
      redirect_uri: window.location.origin + '/auth/callback',
      metadata_url: '' // For SAML
    },
    mfa_enabled: false,
    mfa_methods: ['totp'],
    mfa_enforcement: 'optional'
  });

  useEffect(() => {
    if (orgId) loadSettings();
  }, [orgId]);

  const loadSettings = async () => {
    try {
      setLoading(true);
      const data = await securityConfigService.getSettings(orgId);
      // Merge with defaults to ensure all fields exist
      setSettings(prev => ({
        ...prev,
        ...data,
        sso_config: { ...prev.sso_config, ...(data.sso_config || {}) }
      }));
    } catch (error) {
      console.error(error);
      toast({ title: "Failed to load security settings", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      
      // Validation for MFA
      if (settings.mfa_enabled && settings.mfa_methods.length === 0) {
        throw new Error("At least one MFA method must be selected when MFA is enabled.");
      }

      // Validation for SSO
      if (settings.sso_enabled) {
        if (!settings.sso_provider) throw new Error("Please select an SSO provider.");
        if (settings.sso_provider !== 'saml' && (!settings.sso_config.client_id || !settings.sso_config.client_secret)) {
          throw new Error("Client ID and Secret are required for OAuth providers.");
        }
      }

      await securityConfigService.saveSettings(orgId, settings);
      
      await auditService.logAction('SECURITY_SETTINGS_UPDATE', 'security_settings', {
        org_id: orgId,
        changes: {
          sso_enabled: settings.sso_enabled,
          mfa_enabled: settings.mfa_enabled
        }
      });

      toast({ title: "Security settings saved", description: "Your changes have been applied successfully." });
    } catch (error) {
      toast({ title: "Failed to save settings", description: error.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleTestSSO = async () => {
    try {
      setTestingSSO(true);
      await securityConfigService.testSSOConnection(settings.sso_provider, settings.sso_config);
      toast({ title: "Connection Successful", description: `Successfully connected to ${settings.sso_provider} configuration.` });
    } catch (error) {
      toast({ title: "Connection Failed", description: error.message, variant: "destructive" });
    } finally {
      setTestingSSO(false);
    }
  };

  const toggleMfaMethod = (method) => {
    setSettings(prev => {
      const methods = prev.mfa_methods.includes(method)
        ? prev.mfa_methods.filter(m => m !== method)
        : [...prev.mfa_methods, method];
      return { ...prev, mfa_methods: methods };
    });
  };

  if (loading) {
    return <div className="flex justify-center p-8"><Loader2 className="animate-spin" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2">
        {/* Status Dashboard */}
        <Card className="md:col-span-2 bg-slate-50 border-slate-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Shield className="h-5 w-5 text-brand-600" />
              Security Status Dashboard
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center gap-3 bg-white p-3 rounded border">
                <div className={`p-2 rounded-full ${settings.sso_enabled ? 'bg-green-100 text-green-600' : 'bg-slate-100 text-slate-400'}`}>
                  <Lock className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium text-sm">Single Sign-On</p>
                  <p className="text-xs text-muted-foreground">{settings.sso_enabled ? 'Active' : 'Disabled'}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 bg-white p-3 rounded border">
                <div className={`p-2 rounded-full ${settings.mfa_enabled ? 'bg-green-100 text-green-600' : 'bg-slate-100 text-slate-400'}`}>
                  <Fingerprint className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium text-sm">Multi-Factor Auth</p>
                  <p className="text-xs text-muted-foreground">
                    {settings.mfa_enabled ? (settings.mfa_enforcement === 'required_all' ? 'Enforced for All' : 'Enabled') : 'Disabled'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3 bg-white p-3 rounded border">
                <div className="p-2 rounded-full bg-blue-100 text-blue-600">
                  <CheckCircle className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium text-sm">Audit Logging</p>
                  <p className="text-xs text-muted-foreground">Always Active</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SSO Configuration */}
        <Card className="md:col-span-1">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle>Single Sign-On (SSO)</CardTitle>
                <CardDescription>Allow users to log in with their corporate credentials.</CardDescription>
              </div>
              <Switch 
                checked={settings.sso_enabled}
                onCheckedChange={(checked) => setSettings({...settings, sso_enabled: checked})}
              />
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className={`space-y-4 ${!settings.sso_enabled ? 'opacity-50 pointer-events-none' : ''}`}>
              <div className="space-y-2">
                <Label>Identity Provider</Label>
                <Select 
                  value={settings.sso_provider} 
                  onValueChange={(val) => setSettings({...settings, sso_provider: val})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="google">Google Workspace</SelectItem>
                    <SelectItem value="microsoft">Microsoft Azure AD</SelectItem>
                    <SelectItem value="github">GitHub Organization</SelectItem>
                    <SelectItem value="saml">Custom SAML 2.0</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {settings.sso_provider === 'saml' ? (
                <div className="space-y-2">
                  <Label>Metadata URL</Label>
                  <Input 
                    placeholder="https://idp.example.com/metadata"
                    value={settings.sso_config.metadata_url || ''}
                    onChange={(e) => setSettings({
                      ...settings, 
                      sso_config: { ...settings.sso_config, metadata_url: e.target.value }
                    })}
                  />
                </div>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label>Client ID</Label>
                    <Input 
                      type="text" 
                      placeholder="Enter Client ID"
                      value={settings.sso_config.client_id}
                      onChange={(e) => setSettings({
                        ...settings, 
                        sso_config: { ...settings.sso_config, client_id: e.target.value }
                      })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Client Secret</Label>
                    <Input 
                      type="password" 
                      placeholder="Enter Client Secret"
                      value={settings.sso_config.client_secret}
                      onChange={(e) => setSettings({
                        ...settings, 
                        sso_config: { ...settings.sso_config, client_secret: e.target.value }
                      })}
                    />
                  </div>
                </>
              )}

              <div className="space-y-2">
                <Label>Redirect URI</Label>
                <div className="flex gap-2">
                  <Input readOnly value={settings.sso_config.redirect_uri} className="bg-slate-50 font-mono text-xs" />
                  <Button variant="outline" size="icon" onClick={() => {
                    navigator.clipboard.writeText(settings.sso_config.redirect_uri);
                    toast({ title: "Copied to clipboard" });
                  }}>
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">Register this URI in your IDP settings.</p>
              </div>

              <Button 
                variant="outline" 
                className="w-full" 
                onClick={handleTestSSO}
                disabled={testingSSO || !settings.sso_provider}
              >
                {testingSSO ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Shield className="h-4 w-4 mr-2" />}
                Test SSO Configuration
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* MFA Configuration */}
        <Card className="md:col-span-1">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle>Multi-Factor Auth (MFA)</CardTitle>
                <CardDescription>Add an extra layer of security for user logins.</CardDescription>
              </div>
              <Switch 
                checked={settings.mfa_enabled}
                onCheckedChange={(checked) => setSettings({...settings, mfa_enabled: checked})}
              />
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className={`space-y-6 ${!settings.mfa_enabled ? 'opacity-50 pointer-events-none' : ''}`}>
              
              <div className="space-y-3">
                <Label>Allowed Methods</Label>
                <div className="grid gap-2">
                  <div className="flex items-center space-x-2 border p-3 rounded-md">
                    <Checkbox 
                      id="mfa_totp" 
                      checked={settings.mfa_methods.includes('totp')}
                      onCheckedChange={() => toggleMfaMethod('totp')}
                    />
                    <Label htmlFor="mfa_totp" className="flex-1 cursor-pointer">
                      Authenticator App (TOTP)
                      <p className="text-xs text-muted-foreground font-normal">Google Auth, Authy, etc.</p>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 border p-3 rounded-md">
                    <Checkbox 
                      id="mfa_sms" 
                      checked={settings.mfa_methods.includes('sms')}
                      onCheckedChange={() => toggleMfaMethod('sms')}
                    />
                    <Label htmlFor="mfa_sms" className="flex-1 cursor-pointer">
                      SMS Text Message
                      <p className="text-xs text-muted-foreground font-normal">Requires phone number.</p>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 border p-3 rounded-md">
                    <Checkbox 
                      id="mfa_email" 
                      checked={settings.mfa_methods.includes('email')}
                      onCheckedChange={() => toggleMfaMethod('email')}
                    />
                    <Label htmlFor="mfa_email" className="flex-1 cursor-pointer">
                      Email Verification
                      <p className="text-xs text-muted-foreground font-normal">Code sent to login email.</p>
                    </Label>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Enforcement Policy</Label>
                <Select 
                  value={settings.mfa_enforcement}
                  onValueChange={(val) => setSettings({...settings, mfa_enforcement: val})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Policy" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="optional">Optional (User Choice)</SelectItem>
                    <SelectItem value="required_admins">Required for Admins & Owners</SelectItem>
                    <SelectItem value="required_all">Required for Everyone</SelectItem>
                  </SelectContent>
                </Select>
                {settings.mfa_enforcement === 'required_all' && (
                  <Alert className="mt-2 bg-amber-50 border-amber-200">
                    <AlertTriangle className="h-4 w-4 text-amber-600" />
                    <AlertTitle className="text-amber-800 text-xs font-bold">Warning</AlertTitle>
                    <AlertDescription className="text-amber-700 text-xs">
                      Users without MFA configured will be forced to set it up on next login.
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-between items-center bg-slate-50 p-4 rounded-lg border">
        <div className="text-sm text-muted-foreground">
          <p className="font-medium text-slate-900">Need Help?</p>
          View the <a href="#" className="text-brand-600 underline">Security Configuration Guide</a> for detailed instructions.
        </div>
        <Button size="lg" onClick={handleSave} disabled={saving}>
          {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Save Security Changes
        </Button>
      </div>
    </div>
  );
};

export default SecuritySettings;
