
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Download, Search, Filter, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';

const AuditLogViewer = ({ orgId }) => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    fetchLogs();
  }, [orgId]);

  const fetchLogs = async () => {
    setLoading(true);
    try {
      // Check if we are in mock mode
      const isMockMode = localStorage.getItem('mock_session_user');
      
      if (isMockMode) {
        // In mock mode, we can't query the real DB with a fake token
        // So we return mock data immediately
        setLogs(getMockLogs());
        setLoading(false);
        return;
      }

      // Try to fetch real logs first
      const { data, error } = await supabase
        .from('app_audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      if (data && data.length > 0) {
        setLogs(data);
      } else {
        // Fallback to mock if empty (just for demo continuity if DB is fresh)
        setLogs(getMockLogs());
      }
    } catch (e) {
      console.error("Failed to fetch audit logs:", e);
      setLogs(getMockLogs());
    } finally {
      setLoading(false);
    }
  };

  const getMockLogs = () => [
    { id: 1, action: 'ROLE_ASSIGNMENT', user_id: 'System', target_resource: 'venukailas@creativecyber.in', details: { role: 'Platform Admin' }, created_at: new Date().toISOString() },
    { id: 2, action: 'ROLE_ASSIGNMENT', user_id: 'System', target_resource: 'venu_kailas@yahoo.com', details: { role: 'Tenant Admin' }, created_at: new Date().toISOString() },
  ];

  const handleExport = () => {
    const csv = [
        ['ID', 'Timestamp', 'Action', 'Target', 'Details'],
        ...logs.map(l => [
          l.id, 
          l.created_at, 
          l.action, 
          l.target_resource, 
          JSON.stringify(l.details || {})
        ])
    ].map(e => e.join(',')).join('\n');
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit_logs_${new Date().toISOString()}.csv`;
    a.click();
  };

  const filteredLogs = logs.filter(l => 
    JSON.stringify(l).toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
           <CardTitle>Audit & Compliance Logs</CardTitle>
           <CardDescription>Track all sensitive actions within the tenant.</CardDescription>
        </div>
        <Button variant="outline" onClick={handleExport}>
           <Download className="w-4 h-4 mr-2" /> Export CSV
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
           <div className="relative flex-1">
             <Search className="absolute left-2 top-2.5 h-4 w-4 text-slate-400" />
             <Input placeholder="Search logs..." className="pl-8" value={filter} onChange={e => setFilter(e.target.value)} />
           </div>
           <Button variant="outline" onClick={fetchLogs}><Filter className="w-4 h-4 mr-2" /> Refresh</Button>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Timestamp</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Target</TableHead>
                <TableHead>Details</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin mx-auto text-slate-400" />
                  </TableCell>
                </TableRow>
              ) : filteredLogs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-8 text-slate-500">
                    No logs found matching your criteria.
                  </TableCell>
                </TableRow>
              ) : (
                filteredLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell className="font-mono text-xs text-slate-500">
                      {new Date(log.created_at).toLocaleString()}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={
                        log.action === 'ROLE_ASSIGNMENT' ? 'bg-blue-50 text-blue-700 border-blue-200' : 
                        log.action === 'IMPERSONATE' ? 'bg-amber-50 text-amber-700 border-amber-200' : ''
                      }>
                        {log.action}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm font-medium">{log.target_resource}</TableCell>
                    <TableCell className="text-sm text-slate-500 truncate max-w-[300px]">
                      {typeof log.details === 'object' ? JSON.stringify(log.details) : log.details}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default AuditLogViewer;
