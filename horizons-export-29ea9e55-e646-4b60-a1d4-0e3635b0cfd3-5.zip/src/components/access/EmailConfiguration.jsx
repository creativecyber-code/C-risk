
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Mail, Save, RefreshCw } from 'lucide-react';
import { notificationService } from '@/services/notificationService';

const EmailConfiguration = ({ orgId }) => {
  const [config, setConfig] = useState({
    smtp_host: '',
    smtp_port: '465',
    smtp_user: '',
    smtp_pass: '',
    sender_email: '',
    sender_name: '',
    use_custom_smtp: false
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [resetting, setResetting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (orgId) {
      loadConfig();
    }
  }, [orgId]);

  const loadConfig = async () => {
    setLoading(true);
    try {
      // Safely timeout if loading takes too long
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Timeout')), 8000)
      );
      
      const loadPromise = notificationService.getEmailConfig(orgId);
      const data = await Promise.race([loadPromise, timeoutPromise]);
      
      if (data) {
        // Ensure defaults if data is partial
        setConfig(prev => ({ ...prev, ...data }));
      }
    } catch (error) {
      console.error('Error loading email config:', error);
      toast({ 
        title: "Error loading configuration", 
        description: "Could not fetch current email settings.", 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
      setResetting(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Explicitly calling updateEmailConnection as requested
      await notificationService.updateEmailConnection(orgId, config);
      toast({ title: "Configuration saved successfully" });
    } catch (error) {
      console.error("Save error:", error);
      toast({ 
        title: "Failed to save configuration", 
        description: error.message || "An unexpected error occurred.", 
        variant: "destructive" 
      });
    } finally {
      setSaving(false);
    }
  };

  const handleTestConnection = async () => {
    setTesting(true);
    try {
      const result = await notificationService.testSmtpConnection(config);
      if (result.success) {
        toast({ title: "Connection Successful", className: "bg-green-600 text-white" });
      } else {
        throw new Error(result.message);
      }
    } catch (error) {
      toast({ 
        title: "Connection Failed", 
        description: error.message || "Could not connect to SMTP server", 
        variant: "destructive" 
      });
    } finally {
      setTesting(false);
    }
  };
  
  const handleReset = () => {
    setResetting(true);
    loadConfig(); // Reload original data
  };

  if (loading && !resetting) {
    return (
      <Card>
        <CardContent className="p-8 flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Mail className="h-5 w-5" />
          Email Service Settings
        </CardTitle>
        <CardDescription>Configure custom SMTP settings for system notifications</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between space-x-2 border p-4 rounded-lg">
          <div className="space-y-0.5">
            <Label className="text-base">Use Custom SMTP</Label>
            <p className="text-sm text-muted-foreground">
              Send emails using your own mail server instead of the system default
            </p>
          </div>
          <Switch 
            checked={config.use_custom_smtp}
            onCheckedChange={(checked) => setConfig(prev => ({ ...prev, use_custom_smtp: checked }))}
          />
        </div>

        {config.use_custom_smtp && (
          <div className="grid gap-6 animate-in fade-in slide-in-from-top-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>SMTP Host</Label>
                <Input 
                  placeholder="smtp.example.com" 
                  value={config.smtp_host}
                  onChange={(e) => setConfig(prev => ({ ...prev, smtp_host: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label>SMTP Port</Label>
                <Input 
                  placeholder="465" 
                  value={config.smtp_port}
                  onChange={(e) => setConfig(prev => ({ ...prev, smtp_port: e.target.value }))}
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Username</Label>
                <Input 
                  placeholder="postmaster@example.com" 
                  value={config.smtp_user}
                  onChange={(e) => setConfig(prev => ({ ...prev, smtp_user: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label>Password</Label>
                <Input 
                  type="password"
                  placeholder="••••••••••••" 
                  value={config.smtp_pass}
                  onChange={(e) => setConfig(prev => ({ ...prev, smtp_pass: e.target.value }))}
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Sender Name</Label>
                <Input 
                  placeholder="Security Team" 
                  value={config.sender_name}
                  onChange={(e) => setConfig(prev => ({ ...prev, sender_name: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label>Sender Email</Label>
                <Input 
                  placeholder="noreply@example.com" 
                  value={config.sender_email}
                  onChange={(e) => setConfig(prev => ({ ...prev, sender_email: e.target.value }))}
                />
              </div>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between bg-slate-50 p-6">
        <Button 
          variant="outline" 
          onClick={handleReset}
          disabled={resetting || saving}
        >
          <RefreshCw className={`mr-2 h-4 w-4 ${resetting ? 'animate-spin' : ''}`} />
          Reset Changes
        </Button>
        <div className="flex gap-2">
          {config.use_custom_smtp && (
            <Button 
              variant="secondary" 
              onClick={handleTestConnection}
              disabled={testing || saving}
            >
              {testing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Mail className="mr-2 h-4 w-4" />}
              Test Connection
            </Button>
          )}
          <Button onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            Save Configuration
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default EmailConfiguration;
