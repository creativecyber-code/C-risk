
import React, { useState } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger
} from "@/components/ui/dialog";
import { UserCog, AlertTriangle, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { adminService } from '@/services/adminService';
import { rbacService } from '@/services/rbacService';

const ImpersonationControl = () => {
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const [targetEmail, setTargetEmail] = useState('');
  const [reason, setReason] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  // Guard: Only Platform Admins or Support Tier 3 can see this
  const canImpersonate = rbacService.hasPermission(profile?.role, 'platform:users:manage') || 
                         profile?.role === 'Platform Admin';

  if (!canImpersonate) return null;

  const handleImpersonate = async () => {
    if (!targetEmail || !reason) {
        toast({ title: "Missing Information", description: "Email and Reason are required.", variant: "destructive" });
        return;
    }

    setIsLoading(true);
    try {
        // Log the attempt first
        await rbacService.logAccessCheck(user.id, 'IMPERSONATE', targetEmail, true, reason);
        
        // This is a simulation since actual auth session swapping requires backend edge function support
        // usually involving minting a new JWT for the target user.
        await new Promise(resolve => setTimeout(resolve, 1500));

        toast({ 
            title: "Impersonation Session Started", 
            description: `You are now viewing the dashboard as ${targetEmail}. Audit log ID: ${crypto.randomUUID()}`,
            className: "bg-amber-100 border-amber-200 text-amber-900"
        });
        setIsOpen(false);
    } catch (e) {
        toast({ title: "Failed", description: e.message, variant: "destructive" });
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="border-amber-200 bg-amber-50 hover:bg-amber-100 text-amber-700">
           <UserCog className="w-4 h-4 mr-2" /> Support Impersonation
        </Button>
      </DialogTrigger>
      <DialogContent className="border-amber-200">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-amber-700">
             <AlertTriangle className="w-5 h-5" /> Impersonate User
          </DialogTitle>
          <DialogDescription>
            This action allows you to sign in as another user to troubleshoot issues. 
            <strong>All actions performed will be logged and attributed to your admin account.</strong>
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
           <div className="space-y-2">
             <label className="text-sm font-medium">Target User Email</label>
             <Input 
                placeholder="user@customer.com" 
                value={targetEmail}
                onChange={e => setTargetEmail(e.target.value)}
             />
           </div>
           <div className="space-y-2">
             <label className="text-sm font-medium">Reason for Access</label>
             <Input 
                placeholder="Ticket #1234 - Cannot access reports" 
                value={reason}
                onChange={e => setReason(e.target.value)}
             />
           </div>
        </div>

        <DialogFooter>
           <Button variant="ghost" onClick={() => setIsOpen(false)}>Cancel</Button>
           <Button 
             className="bg-amber-600 hover:bg-amber-700 text-white" 
             onClick={handleImpersonate}
             disabled={isLoading}
           >
             {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
             Start Session
           </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ImpersonationControl;
