
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, X } from 'lucide-react';
import { ATTRIBUTES } from '@/lib/rbac_constants';

const AttributeAssignmentUI = ({ userAttributes = {}, onChange }) => {
  const [newVal, setNewVal] = useState('');
  const [activeAttr, setActiveAttr] = useState(ATTRIBUTES.BUSINESS_UNIT);

  const handleAdd = () => {
    if (!newVal) return;
    const currentList = userAttributes[activeAttr] || [];
    if (!currentList.includes(newVal)) {
        onChange(activeAttr, [...currentList, newVal]);
    }
    setNewVal('');
  };

  const handleRemove = (attr, val) => {
    const currentList = userAttributes[attr] || [];
    onChange(attr, currentList.filter(v => v !== val));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm font-medium">ABAC Attributes (Scope)</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
         <div className="flex gap-2 border-b pb-2">
            {Object.values(ATTRIBUTES).map(attr => (
                <Button 
                  key={attr} 
                  variant={activeAttr === attr ? 'default' : 'ghost'} 
                  size="sm"
                  onClick={() => setActiveAttr(attr)}
                  className="capitalize"
                >
                  {attr.replace('_', ' ')}
                </Button>
            ))}
         </div>

         <div className="space-y-3">
             <div className="flex gap-2">
                <Input 
                  placeholder={`Add ${activeAttr.replace('_', ' ')} scope...`}
                  value={newVal}
                  onChange={e => setNewVal(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleAdd()}
                />
                <Button size="sm" onClick={handleAdd}><Plus className="w-4 h-4" /></Button>
             </div>

             <div className="flex flex-wrap gap-2 min-h-[40px]">
                {(userAttributes[activeAttr] || []).map(val => (
                   <Badge key={val} variant="secondary" className="flex items-center gap-1 pl-2 pr-1">
                      {val}
                      <Button variant="ghost" size="icon" className="h-4 w-4 p-0 ml-1 rounded-full hover:bg-slate-200" onClick={() => handleRemove(activeAttr, val)}>
                         <X className="w-3 h-3" />
                      </Button>
                   </Badge>
                ))}
                {(userAttributes[activeAttr] || []).length === 0 && (
                    <span className="text-sm text-slate-400 italic">No specific scope assigned (Global)</span>
                )}
             </div>
         </div>
      </CardContent>
    </Card>
  );
};

export default AttributeAssignmentUI;
