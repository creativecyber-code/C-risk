
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Mail, CheckCircle, AlertTriangle, Send, RotateCcw } from 'lucide-react';
import { accessControlService } from '@/services/accessControlService';
import { emailService } from '@/services/emailService';

const EmailSenderSettings = ({ orgId }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [sendingTest, setSendingTest] = useState(false);
  
  const [formData, setFormData] = useState({
    sender_name: emailService.DEFAULT_SENDER.name,
    sender_email: emailService.DEFAULT_SENDER.email
  });
  
  const [testEmail, setTestEmail] = useState('');

  useEffect(() => {
    if (orgId) loadSettings();
  }, [orgId]);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const data = await accessControlService.getOrgSettings(orgId);
      if (data?.settings?.email) {
        setFormData({
          sender_name: data.settings.email.sender_name || emailService.DEFAULT_SENDER.name,
          sender_email: data.settings.email.sender_email || emailService.DEFAULT_SENDER.email
        });
      } else {
        // Explicitly set defaults if nothing exists
        setFormData(emailService.DEFAULT_SENDER);
      }
    } catch (e) {
      console.error(e);
      toast({ title: "Failed to load email settings", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const current = await accessControlService.getOrgSettings(orgId);
      const newSettings = {
        ...(current.settings || {}),
        email: formData
      };

      await accessControlService.updateOrgSettings(orgId, { settings: newSettings });
      toast({ title: "Email settings updated successfully" });
    } catch (e) {
      toast({ title: "Update failed", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleReset = async () => {
    if (!window.confirm("Are you sure you want to reset email settings to Hostinger defaults?")) return;
    
    setResetting(true);
    try {
      const current = await accessControlService.getOrgSettings(orgId);
      // Remove specific email settings to fallback to system defaults
      const newSettings = { ...(current.settings || {}) };
      delete newSettings.email;

      await accessControlService.updateOrgSettings(orgId, { settings: newSettings });
      
      // Update UI state
      setFormData(emailService.DEFAULT_SENDER);
      
      toast({ 
        title: "Settings Reset", 
        description: "Email configuration has been reset to Hostinger defaults." 
      });
    } catch (e) {
      toast({ title: "Reset failed", description: e.message, variant: "destructive" });
    } finally {
      setResetting(false);
    }
  };

  const handleSendTest = async () => {
    if (!testEmail) {
      toast({ title: "Please enter a test email address", variant: "destructive" });
      return;
    }
    setSendingTest(true);
    try {
      await emailService.sendTestEmail(testEmail, orgId);
      toast({ title: "Test email sent!", description: `Check ${testEmail} inbox.` });
    } catch (e) {
      toast({ title: "Failed to send test email", description: e.message, variant: "destructive" });
    } finally {
      setSendingTest(false);
    }
  };

  if (loading) {
    return <div className="p-8 flex justify-center"><Loader2 className="animate-spin" /></div>;
  }

  return (
    <div className="grid gap-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>Email Sender Configuration</CardTitle>
              <CardDescription>
                Customize how system emails appear to your users. 
              </CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={handleReset} disabled={resetting || saving}>
              {resetting ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCcw className="h-4 w-4 mr-2" />}
              Reset Defaults
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="senderName">Sender Name</Label>
              <Input
                id="senderName"
                value={formData.sender_name}
                onChange={(e) => setFormData({ ...formData, sender_name: e.target.value })}
                placeholder={emailService.DEFAULT_SENDER.name}
              />
              <p className="text-xs text-muted-foreground">Default: {emailService.DEFAULT_SENDER.name}</p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="senderEmail">Sender Email Address</Label>
              <Input
                id="senderEmail"
                type="email"
                value={formData.sender_email}
                onChange={(e) => setFormData({ ...formData, sender_email: e.target.value })}
                placeholder={emailService.DEFAULT_SENDER.email}
              />
              <p className="text-xs text-muted-foreground">Default: {emailService.DEFAULT_SENDER.email}</p>
            </div>
          </div>

          <Alert className="bg-slate-50 border-slate-200">
            <CheckCircle className="h-4 w-4 text-slate-600" />
            <AlertTitle className="text-slate-800">Hostinger SMTP Defaults</AlertTitle>
            <AlertDescription className="text-slate-700 text-sm mt-2">
              <div className="grid grid-cols-2 gap-x-8 gap-y-1">
                <span>SMTP Server:</span>
                <span className="font-mono">smtp.hostinger.com</span>
                
                <span>Encryption:</span>
                <span className="font-mono">SSL/TLS (Port 465)</span>
                
                <span>Alternative:</span>
                <span className="font-mono">STARTTLS (Port 587)</span>
              </div>
            </AlertDescription>
          </Alert>
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <div className="flex gap-2 w-full max-w-sm">
            <Input 
              placeholder="Test email address" 
              value={testEmail}
              onChange={(e) => setTestEmail(e.target.value)}
              className="h-9"
            />
            <Button size="sm" variant="outline" onClick={handleSendTest} disabled={sendingTest}>
               {sendingTest ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </div>
          <Button onClick={handleSave} disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Save Changes
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default EmailSenderSettings;
