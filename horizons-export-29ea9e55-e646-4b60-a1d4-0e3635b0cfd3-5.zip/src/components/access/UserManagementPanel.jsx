
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { MoreHorizontal, Plus, Shield, UserX, Mail, RefreshCw, AlertCircle, Trash2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { accessControlService } from '@/services/accessControlService';
import { supabase } from '@/lib/customSupabaseClient';
import UserDialog from '@/components/access/UserDialog';
import ImportUsersDialog from '@/components/access/ImportUsersDialog';
import AttributeAssignmentUI from '@/components/access/AttributeAssignmentUI';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

const UserManagementPanel = ({ orgId }) => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isAttributeOpen, setIsAttributeOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [userAttributes, setUserAttributes] = useState({}); // Local state for edit
  const { toast } = useToast();

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const data = await accessControlService.getOrgUsers(orgId);
      // Mock attributes for demo
      const enhancedData = data.map(u => ({ 
        ...u, 
        attributes: u.attributes || { business_unit: ['Engineering'], geography: ['US'] } 
      }));
      setUsers(enhancedData);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (orgId) fetchUsers();
  }, [orgId]);

  const handleAttributeSave = async () => {
     // Save logic here (mocked)
     toast({ title: "Attributes Updated", description: "ABAC Scope has been saved." });
     setIsAttributeOpen(false);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>User Management</CardTitle>
          <CardDescription>Manage users, roles, and ABAC attributes.</CardDescription>
        </div>
        <div className="flex gap-2">
          <Button size="sm" onClick={() => { setSelectedUser(null); setIsDialogOpen(true); }}>
            <Plus className="mr-2 h-4 w-4" /> Add User
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Role (RBAC)</TableHead>
              <TableHead>Scope (ABAC)</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.map(user => (
              <TableRow key={user.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                     <Avatar className="h-8 w-8"><AvatarFallback>{user.full_name?.[0]}</AvatarFallback></Avatar>
                     <div>
                        <div className="font-medium">{user.full_name}</div>
                        <div className="text-xs text-muted-foreground">{user.email}</div>
                     </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{user.role}</Badge>
                </TableCell>
                <TableCell>
                   <div className="flex gap-1 flex-wrap">
                     {user.attributes?.business_unit?.map(u => <Badge key={u} variant="secondary" className="text-[10px]">{u}</Badge>)}
                     {user.attributes?.geography?.map(g => <Badge key={g} variant="secondary" className="text-[10px]">{g}</Badge>)}
                   </div>
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                     <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon"><MoreHorizontal className="w-4 h-4" /></Button>
                     </DropdownMenuTrigger>
                     <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => { setSelectedUser(user); setIsDialogOpen(true); }}>Edit Role</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => { setSelectedUser(user); setUserAttributes(user.attributes); setIsAttributeOpen(true); }}>
                           Manage Attributes (ABAC)
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-red-600">Remove User</DropdownMenuItem>
                     </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        <UserDialog 
          open={isDialogOpen} 
          onOpenChange={setIsDialogOpen} 
          orgId={orgId}
          userToEdit={selectedUser}
          onSuccess={fetchUsers}
        />

        <Dialog open={isAttributeOpen} onOpenChange={setIsAttributeOpen}>
           <DialogContent>
              <DialogHeader>
                 <DialogTitle>Manage User Attributes</DialogTitle>
              </DialogHeader>
              <AttributeAssignmentUI 
                 userAttributes={userAttributes} 
                 onChange={(attr, val) => setUserAttributes({...userAttributes, [attr]: val})} 
              />
              <Button onClick={handleAttributeSave}>Save Attributes</Button>
           </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default UserManagementPanel;
