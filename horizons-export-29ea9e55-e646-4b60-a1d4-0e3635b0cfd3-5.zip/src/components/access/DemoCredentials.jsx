
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Copy, Check, Users } from 'lucide-react';
import { demoCredentials } from '@/data/demoCredentials';
import { useToast } from '@/components/ui/use-toast';

const DemoCredentials = () => {
  const { toast } = useToast();
  const [copied, setCopied] = React.useState(null);

  const copyToClipboard = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    toast({ title: "Copied to clipboard", duration: 1500 });
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <Card className="w-full border-2 border-indigo-100 bg-white/50 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <div className="bg-indigo-100 p-2 rounded-lg">
            <Users className="h-5 w-5 text-indigo-600" />
          </div>
          <div>
            <CardTitle className="text-lg text-slate-800">Demo Access</CardTitle>
            <CardDescription>Pre-seeded accounts for testing</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue={demoCredentials[0].org} className="w-full">
          <TabsList className="w-full grid grid-cols-3 mb-4">
            {demoCredentials.map(org => (
              <TabsTrigger key={org.org} value={org.org} className="text-xs sm:text-sm">
                {org.org.split(' ')[0]}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {demoCredentials.map((org) => (
            <TabsContent key={org.org} value={org.org} className="space-y-3">
              {org.users.map((user, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-lg hover:border-indigo-300 transition-colors group">
                  <div className="flex flex-col min-w-0 mr-2">
                    <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider mb-0.5">{user.role}</span>
                    <span className="font-medium text-slate-800 text-sm truncate">{user.name}</span>
                    <span className="text-xs text-slate-500 truncate">{user.email}</span>
                  </div>
                  <div className="flex flex-col gap-1 shrink-0">
                     <Button 
                       variant="ghost" 
                       size="sm" 
                       className="h-7 px-2 text-xs hover:bg-indigo-50 hover:text-indigo-700"
                       onClick={() => copyToClipboard(user.email, `${org.org}-${idx}-email`)}
                     >
                       {copied === `${org.org}-${idx}-email` ? <Check className="h-3 w-3 mr-1" /> : <Copy className="h-3 w-3 mr-1" />}
                       Email
                     </Button>
                     <Button 
                       variant="ghost" 
                       size="sm" 
                       className="h-7 px-2 text-xs hover:bg-indigo-50 hover:text-indigo-700"
                       onClick={() => copyToClipboard(user.password, `${org.org}-${idx}-pass`)}
                     >
                       {copied === `${org.org}-${idx}-pass` ? <Check className="h-3 w-3 mr-1" /> : <Copy className="h-3 w-3 mr-1" />}
                       Pass
                     </Button>
                  </div>
                </div>
              ))}
              <div className="text-center mt-2">
                 <span className="text-xs text-slate-500 bg-slate-100 px-2 py-1 rounded border border-slate-200 font-mono">
                   Password: P@ssw0rd@123
                 </span>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default DemoCredentials;
