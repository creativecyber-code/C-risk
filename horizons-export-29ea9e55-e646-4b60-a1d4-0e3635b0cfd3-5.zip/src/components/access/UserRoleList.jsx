
import React, { useState } from 'react';
import { MoreVertical, ShieldAlert, UserCog, History } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const UserRoleList = ({ users, roles, onAssignRole, onDeactivate }) => {
  return (
    <div className="space-y-4">
      {users.map(user => (
        <div key={user.id} className="flex items-center justify-between p-4 bg-white border rounded-lg hover:shadow-sm transition-all">
          <div className="flex items-center gap-4">
            <Avatar className="h-10 w-10 border">
              <AvatarImage src={user.avatar_url} />
              <AvatarFallback className="bg-brand-50 text-brand-700">
                {user.full_name?.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="font-medium text-slate-900">{user.full_name}</div>
              <div className="text-sm text-slate-500">{user.email}</div>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex flex-col items-end gap-1">
              <span className="text-xs text-slate-400 uppercase font-semibold">Current Role</span>
              <Select 
                defaultValue={user.role || "Analyst"} 
                onValueChange={(val) => onAssignRole(user.id, val)}
              >
                <SelectTrigger className="w-[180px] h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {roles.map(r => (
                    <SelectItem key={r.id} value={r.name}>
                       <div className="flex items-center gap-2">
                         {r.name === 'Admin' && <ShieldAlert className="w-3 h-3 text-red-500" />}
                         {r.name}
                       </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical className="w-4 h-4 text-slate-500" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>User Actions</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => {}}>
                  <UserCog className="w-4 h-4 mr-2" /> Manage Access
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => {}}>
                  <History className="w-4 h-4 mr-2" /> View Audit Log
                </DropdownMenuItem>
                <DropdownMenuItem className="text-red-600 focus:text-red-600" onClick={() => onDeactivate(user.id)}>
                  Deactivate User
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      ))}
    </div>
  );
};

export default UserRoleList;
