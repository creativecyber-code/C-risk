
import React, { useCallback, useState, useRef, useEffect } from 'react';
import ReactFlow, { 
  addEdge, 
  Background, 
  Controls, 
  MiniMap, 
  useNodesState, 
  useEdgesState,
  Panel
} from 'reactflow';
import 'reactflow/dist/style.css';
import { ProcessNode, StoreNode, InteractorNode, TrustBoundaryNode } from './canvas/CustomNodes';
import { Button } from '@/components/ui/button';
import { Plus, Download, ShieldCheck, Save, Loader2 } from 'lucide-react';
import { auditService } from '@/services/auditService';
import { autoStrideService } from '@/services/autoStrideService';
import { useToast } from '@/components/ui/use-toast';
import { generateCISOReport } from '@/utils/pdfReportGenerator';

const nodeTypes = {
  process: ProcessNode,
  store: StoreNode,
  interactor: InteractorNode,
  trustBoundary: TrustBoundaryNode
};

const ThreatModelingCanvas = ({ initialNodes = [], initialEdges = [], onSave, modelInfo }) => {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [analyzing, setAnalyzing] = useState(false);
  const { toast } = useToast();
  const reactFlowWrapper = useRef(null);

  const onConnect = useCallback((params) => {
    setEdges((eds) => addEdge({ ...params, animated: true, type: 'smoothstep' }, eds));
    auditService.logAction('DIAGRAM_CONNECT', modelInfo?.name, { source: params.source, target: params.target });
  }, [setEdges, modelInfo]);

  const addNode = (type) => {
    const id = `${type}-${Date.now()}`;
    const newNode = {
      id,
      type,
      position: { x: Math.random() * 400, y: Math.random() * 400 },
      data: { label: `New ${type}` },
      // Boundary nodes need specific style/size handling in a real app (Resizing), 
      // here we default them large for containment demo
      style: type === 'trustBoundary' ? { width: 300, height: 300, zIndex: -1 } : {}
    };
    setNodes((nds) => [...nds, newNode]);
    auditService.logAction('NODE_ADD', modelInfo?.name, { type });
  };

  const handleRunAutoStride = () => {
    setAnalyzing(true);
    setTimeout(() => {
        const threats = autoStrideService.analyze(nodes, edges);
        setAnalyzing(false);
        toast({
            title: "Auto-STRIDE Complete",
            description: `Detected ${threats.length} potential threats based on trust boundaries.`,
        });
        // In a real app, we would emit these threats to the parent or save them
    }, 1000);
  };

  const handleExportReport = async () => {
    // Generate dummy threats if none provided for demo
    const threats = autoStrideService.analyze(nodes, edges); 
    await generateCISOReport(modelInfo || { name: 'Current Model' }, threats, 'threat-canvas-container');
    toast({ title: "Report Generated", description: "CISO PDF report has been downloaded." });
  };

  return (
    <div className="h-[75vh] w-full border rounded-lg bg-slate-50 relative" id="threat-canvas-container" ref={reactFlowWrapper}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        nodeTypes={nodeTypes}
        fitView
        attributionPosition="bottom-right"
      >
        <Background gap={16} color="#e2e8f0" />
        <Controls />
        <MiniMap nodeColor={(n) => {
            if (n.type === 'trustBoundary') return '#fecaca';
            if (n.type === 'store') return '#bbf7d0';
            return '#ddd';
        }} />

        <Panel position="top-left" className="bg-white p-2 rounded shadow-lg border border-slate-200 flex flex-col gap-2">
           <div className="text-xs font-bold text-slate-500 uppercase mb-1">Toolbox</div>
           <Button variant="outline" size="sm" onClick={() => addNode('process')} className="justify-start gap-2">
             <div className="w-3 h-3 rounded-full border border-slate-500" /> Process
           </Button>
           <Button variant="outline" size="sm" onClick={() => addNode('store')} className="justify-start gap-2">
             <div className="w-3 h-2 border-y border-slate-500" /> Store
           </Button>
           <Button variant="outline" size="sm" onClick={() => addNode('interactor')} className="justify-start gap-2">
             <div className="w-3 h-3 border border-slate-500 rounded-sm" /> Interactor
           </Button>
           <Button variant="outline" size="sm" onClick={() => addNode('trustBoundary')} className="justify-start gap-2 text-red-600 border-red-100 bg-red-50 hover:bg-red-100">
             <div className="w-3 h-3 border border-dashed border-red-500" /> Trust Boundary
           </Button>
        </Panel>

        <Panel position="top-right" className="flex gap-2">
           <Button onClick={handleRunAutoStride} disabled={analyzing} className="bg-indigo-600 hover:bg-indigo-700">
             {analyzing ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <ShieldCheck className="w-4 h-4 mr-2" />}
             Auto-STRIDE
           </Button>
           <Button variant="outline" onClick={handleExportReport} className="bg-white">
             <Download className="w-4 h-4 mr-2" /> CISO Report
           </Button>
           <Button onClick={() => onSave && onSave(nodes, edges)} variant="secondary">
             <Save className="w-4 h-4 mr-2" /> Save
           </Button>
        </Panel>
      </ReactFlow>
    </div>
  );
};

export default ThreatModelingCanvas;
