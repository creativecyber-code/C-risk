
import React from 'react';
import { render } from '@testing-library/react';
import { vi } from 'vitest';
import { HelmetProvider } from 'react-helmet-async';
import { BrowserRouter } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';

// Auth Mock Context
export const AuthContextMock = React.createContext(null);

export const MockAuthProvider = ({ children, user = { id: 'test-user', email: 'test@example.com', user_metadata: { org_id: 'org-123' } } }) => {
  return (
    <AuthContextMock.Provider value={{ user, signIn: vi.fn(), signOut: vi.fn() }}>
      {children}
    </AuthContextMock.Provider>
  );
};

// Custom render function that wraps components in necessary providers
export const renderWithProviders = (ui, { user, ...options } = {}) => {
  const Wrapper = ({ children }) => (
    <HelmetProvider>
      <MockAuthProvider user={user}>
        <BrowserRouter>
          {children}
          <Toaster />
        </BrowserRouter>
      </MockAuthProvider>
    </HelmetProvider>
  );

  return render(ui, { wrapper: Wrapper, ...options });
};

// Helper for waiting
export const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
