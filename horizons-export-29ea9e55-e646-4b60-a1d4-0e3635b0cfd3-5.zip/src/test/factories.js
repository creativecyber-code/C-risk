
// Test Data Factories (Requirement 19)

export const appFactory = (overrides = {}) => ({
  id: 'app-' + Math.random().toString(36).substr(2, 9),
  org_id: 'org-123',
  name: 'Test Application',
  business_unit: 'Engineering',
  type: 'Digital',
  inherent_risk_level: 'Low',
  inherent_risk_score: 1.5,
  data_classification: {
    pii: false,
    spi: false,
    pci: false,
    financial: false
  },
  regulations: [],
  status: 'Approved',
  ...overrides
});

export const assessmentFactory = (overrides = {}) => ({
  id: 'assess-' + Math.random().toString(36).substr(2, 9),
  application_id: 'app-123',
  confidentiality_score: 1,
  integrity_score: 1,
  availability_score: 1,
  regulatory_impact: 1,
  operational_impact: 1,
  financial_impact: 1,
  fair_ale_estimate: 50000,
  ...overrides
});

export const userProfileFactory = (overrides = {}) => ({
  id: 'user-123',
  org_id: 'org-123',
  email: 'tester@example.com',
  full_name: 'Test User',
  role: 'Admin',
  ...overrides
});
