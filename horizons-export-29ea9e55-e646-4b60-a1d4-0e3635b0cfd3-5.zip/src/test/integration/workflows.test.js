
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { supabase } from '@/lib/customSupabaseClient';
import { businessInitService } from '@/services/businessInitService';
import { remediationService } from '@/services/remediationService';
import { auditService } from '@/services/auditService';

// Test Suites 1, 9, 11, 13, 16, 18
describe('Integration Workflows', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Security & Data Isolation (Requirement 1, 18)', () => {
    it('should enforce org_id in all queries', async () => {
      // This test inspects the calls made to Supabase mock to ensure org_id is always present
      const mockSelect = vi.fn().mockReturnThis();
      const mockEq = vi.fn().mockReturnThis(); // .eq()
      const mockOrder = vi.fn().mockResolvedValue({ data: [], error: null });

      supabase.from.mockReturnValue({
        select: mockSelect,
        eq: mockEq,
        order: mockOrder
      });

      const targetOrgId = 'org-secure-123';
      await businessInitService.getApplications(targetOrgId);

      // Verify strict isolation
      expect(mockEq).toHaveBeenCalledWith('org_id', targetOrgId);
    });
  });

  describe('Audit Trail (Requirement 9, 11)', () => {
    it('should log actions when critical changes occur', async () => {
      const insertSpy = vi.fn();
      supabase.from.mockImplementation((table) => {
        if (table === 'app_audit_logs') return { insert: insertSpy };
        if (table === 'user_profiles') return { select: vi.fn().mockReturnThis(), eq: vi.fn().mockReturnThis(), single: vi.fn().mockResolvedValue({ data: { org_id: 'org-1' } }) };
        return { insert: vi.fn() };
      });

      await auditService.logAction('TEST_ACTION', 'Resource-1');

      expect(insertSpy).toHaveBeenCalledWith(expect.objectContaining({
        action: 'TEST_ACTION',
        target_resource: 'Resource-1',
        org_id: 'org-1'
      }));
    });
  });

  describe('RFP-Ready Export Logic (Requirement 15)', () => {
    it('should gather all mitigation plans for export', async () => {
       const mockPlans = [
         { id: 1, title: 'Encryption', status: 'Completed' },
         { id: 2, title: 'MFA', status: 'Pending' }
       ];
       
       const mockSelect = vi.fn().mockReturnThis();
       const mockEq = vi.fn().mockResolvedValue({ data: mockPlans, error: null });
       
       supabase.from.mockReturnValue({
         select: mockSelect,
         eq: mockEq
       });
       
       const plans = await remediationService.getMitigationPlans();
       
       // Verify we can retrieve data needed for CSV/PDF export
       expect(plans).toHaveLength(2);
       expect(plans[0].title).toBe('Encryption');
    });
  });
});
