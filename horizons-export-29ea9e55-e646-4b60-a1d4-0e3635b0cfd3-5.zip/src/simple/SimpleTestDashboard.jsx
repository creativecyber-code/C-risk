
import React from 'react';

// Static test dashboard for reliability
const SimpleTestDashboard = () => {
  const tests = [
    { name: 'Auth Service Login', status: 'PASS', duration: '120ms' },
    { name: 'Role Based Access Control', status: 'PASS', duration: '45ms' },
    { name: 'Data Encryption', status: 'PASS', duration: '210ms' },
    { name: 'Input Validation', status: 'FAIL', duration: '85ms', error: 'SQL Injection detected in payload' },
    { name: 'Session Timeout', status: 'PASS', duration: '1005ms' },
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">System Health & Test Status</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
           <div className="text-sm text-green-800 font-medium">Passing Tests</div>
           <div className="text-3xl font-bold text-green-700">80%</div>
        </div>
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
           <div className="text-sm text-red-800 font-medium">Failed Tests</div>
           <div className="text-3xl font-bold text-red-700">1</div>
        </div>
        <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
           <div className="text-sm text-gray-800 font-medium">Total Duration</div>
           <div className="text-3xl font-bold text-gray-700">1.4s</div>
        </div>
      </div>

      <div className="bg-white border rounded-lg overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-100 text-gray-700 border-b">
             <tr>
               <th className="px-4 py-3">Test Case</th>
               <th className="px-4 py-3">Status</th>
               <th className="px-4 py-3">Duration</th>
               <th className="px-4 py-3">Details</th>
             </tr>
          </thead>
          <tbody className="divide-y">
            {tests.map((test, index) => (
              <tr key={index}>
                <td className="px-4 py-3 font-medium">{test.name}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                    test.status === 'PASS' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {test.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-gray-500 font-mono">{test.duration}</td>
                <td className="px-4 py-3 text-red-600 text-xs">
                   {test.error || '-'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SimpleTestDashboard;
