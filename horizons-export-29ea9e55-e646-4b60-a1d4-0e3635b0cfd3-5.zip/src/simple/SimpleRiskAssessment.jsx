
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { mockDataService } from '@/services/mockDataService';

const SimpleRiskAssessment = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [app, setApp] = useState(null);
  
  const [scores, setScores] = useState({
    confidentiality: 1,
    integrity: 1,
    availability: 1
  });

  useEffect(() => {
    const apps = mockDataService.getApplications();
    const found = apps.find(a => a.id === id);
    if (found) {
      setApp(found);
      const existing = mockDataService.getRiskForApp(id);
      if (existing) {
        setScores({
          confidentiality: existing.confidentiality,
          integrity: existing.integrity,
          availability: existing.availability
        });
      }
    } else {
      navigate('/initiation');
    }
  }, [id, navigate]);

  const handleScoreChange = (e) => {
    setScores({ ...scores, [e.target.name]: parseInt(e.target.value) });
  };

  const calculateRisk = () => {
    const total = scores.confidentiality + scores.integrity + scores.availability;
    // Simple logic: Max possible is 15.
    // > 12 Critical, > 9 High, > 6 Medium, <= 6 Low
    let level = 'Low';
    if (total > 12) level = 'Critical';
    else if (total > 9) level = 'High';
    else if (total > 6) level = 'Medium';
    
    return { total, level };
  };

  const handleSave = () => {
    const { total, level } = calculateRisk();
    mockDataService.saveRiskAssessment({
      appId: id,
      ...scores,
      score: total,
      level
    });
    alert('Risk Assessment Saved!');
    navigate('/initiation');
  };

  if (!app) return <div>Loading...</div>;

  const { total, level } = calculateRisk();

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6 border-b pb-4 flex justify-between items-start">
        <div>
           <h2 className="text-2xl font-bold text-gray-900">Inherent Risk Assessment</h2>
           <p className="text-gray-500">Evaluating: <span className="font-semibold text-gray-800">{app.name}</span></p>
        </div>
        <div className="text-right">
           <div className="text-sm text-gray-500">Current Score</div>
           <div className={`text-2xl font-bold ${
             level === 'Critical' ? 'text-red-600' : 
             level === 'High' ? 'text-orange-500' : 
             level === 'Medium' ? 'text-yellow-600' : 'text-green-600'
           }`}>
             {level} ({total})
           </div>
        </div>
      </div>

      <div className="space-y-8">
        {/* CIA Triad Inputs */}
        {['confidentiality', 'integrity', 'availability'].map((factor) => (
          <div key={factor} className="bg-white p-4 border rounded-lg shadow-sm">
            <h3 className="text-lg font-semibold capitalize mb-2 text-gray-800">{factor}</h3>
            <p className="text-sm text-gray-500 mb-4">Rate the impact if {factor} is compromised (1 = Low, 5 = Critical).</p>
            
            <div className="flex items-center gap-4">
              <input 
                type="range" 
                name={factor} 
                min="1" 
                max="5" 
                value={scores[factor]} 
                onChange={handleScoreChange}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-xl font-bold text-blue-600 w-12 text-center">{scores[factor]}</span>
            </div>
            
            <div className="flex justify-between text-xs text-gray-400 mt-2">
               <span>Negligible (1)</span>
               <span>Catastrophic (5)</span>
            </div>
          </div>
        ))}

        <div className="flex justify-end gap-3 pt-6 border-t">
           <button 
             onClick={() => navigate('/initiation')}
             className="px-4 py-2 bg-white border border-gray-300 rounded text-gray-700 hover:bg-gray-50 font-medium"
           >
             Cancel
           </button>
           <button 
             onClick={handleSave}
             className="px-8 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium shadow-sm"
           >
             Save Assessment
           </button>
        </div>
      </div>
    </div>
  );
};

export default SimpleRiskAssessment;
