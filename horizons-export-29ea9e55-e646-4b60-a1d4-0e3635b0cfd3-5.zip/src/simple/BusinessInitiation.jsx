
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { mockDataService } from '@/services/mockDataService';

const BusinessInitiation = () => {
  const [apps, setApps] = useState([]);

  useEffect(() => {
    mockDataService.init();
    setApps(mockDataService.getApplications());
  }, []);

  const getRiskLabel = (appId) => {
    const risk = mockDataService.getRiskForApp(appId);
    if (!risk) return <span className="text-gray-400 italic">Not Assessed</span>;
    
    const colors = {
      'Critical': 'bg-red-100 text-red-800',
      'High': 'bg-orange-100 text-orange-800',
      'Medium': 'bg-yellow-100 text-yellow-800',
      'Low': 'bg-green-100 text-green-800'
    };
    
    return (
      <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${colors[risk.level] || 'bg-gray-100'}`}>
        {risk.level} ({risk.score})
      </span>
    );
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
           <h2 className="text-2xl font-bold text-gray-900">Module 1: Business Initiation</h2>
           <p className="text-gray-500 mt-1">Manage business applications and inherent risk assessments.</p>
        </div>
        <Link 
          to="/initiation/new" 
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium shadow-sm"
        >
          Add Application
        </Link>
      </div>

      <div className="overflow-x-auto border rounded-lg">
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 text-gray-700 border-b">
            <tr>
              <th className="px-4 py-3 font-semibold">Application Name</th>
              <th className="px-4 py-3 font-semibold">Owner</th>
              <th className="px-4 py-3 font-semibold">Status</th>
              <th className="px-4 py-3 font-semibold">Risk Level</th>
              <th className="px-4 py-3 font-semibold text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {apps.length === 0 ? (
              <tr>
                <td colSpan="5" className="px-4 py-8 text-center text-gray-500">
                  No applications found. Create one to get started.
                </td>
              </tr>
            ) : (
              apps.map((app) => (
                <tr key={app.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 font-medium text-gray-900">{app.name}</td>
                  <td className="px-4 py-3 text-gray-600">{app.owner}</td>
                  <td className="px-4 py-3">
                    <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs border border-slate-200">
                      {app.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {getRiskLabel(app.id)}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Link 
                      to={`/initiation/risk/${app.id}`} 
                      className="text-blue-600 hover:text-blue-800 font-medium hover:underline"
                    >
                      Assess Risk
                    </Link>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default BusinessInitiation;
