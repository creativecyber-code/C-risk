
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { mockDataService } from '@/services/mockDataService';

const SimpleDashboard = () => {
  const [stats, setStats] = useState({ totalApps: 0, highRisk: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate slight loading for realism
    setTimeout(() => {
      const apps = mockDataService.getApplications();
      const risks = JSON.parse(localStorage.getItem('c_risk_simple_risks') || '[]');
      
      const highRiskCount = risks.filter(r => r.level === 'High' || r.level === 'Critical').length;
      
      setStats({
        totalApps: apps.length,
        highRisk: highRiskCount
      });
      setLoading(false);
    }, 300);
  }, []);

  if (loading) {
    return <div className="p-10 text-center text-gray-500">Loading dashboard data...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center border-b pb-4">
        <h2 className="text-2xl font-bold text-gray-800">Executive Overview</h2>
        <button 
          onClick={() => {
            const data = mockDataService.exportData();
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'c-risk-lite-export.json';
            a.click();
          }}
          className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded text-sm font-medium border"
        >
          Export Data JSON
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-blue-50 border border-blue-100 p-6 rounded-lg text-center">
          <div className="text-4xl font-bold text-blue-600 mb-1">{stats.totalApps}</div>
          <div className="text-sm text-blue-800 font-medium uppercase tracking-wide">Total Applications</div>
        </div>
        
        <div className="bg-red-50 border border-red-100 p-6 rounded-lg text-center">
          <div className="text-4xl font-bold text-red-600 mb-1">{stats.highRisk}</div>
          <div className="text-sm text-red-800 font-medium uppercase tracking-wide">High Risk Apps</div>
        </div>

        <div className="bg-green-50 border border-green-100 p-6 rounded-lg text-center">
          <div className="text-4xl font-bold text-green-600 mb-1">100%</div>
          <div className="text-sm text-green-800 font-medium uppercase tracking-wide">System Uptime</div>
        </div>
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-semibold mb-4 text-gray-700">Quick Actions</h3>
        <div className="flex gap-4">
          <Link to="/initiation/new" className="block w-full md:w-auto text-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-md font-medium shadow-sm transition-colors">
            + New Business Application
          </Link>
          <Link to="/tests" className="block w-full md:w-auto text-center px-6 py-3 bg-white hover:bg-gray-50 text-gray-700 border border-gray-300 rounded-md font-medium shadow-sm transition-colors">
            View Test Reports
          </Link>
        </div>
      </div>
    </div>
  );
};

export default SimpleDashboard;
