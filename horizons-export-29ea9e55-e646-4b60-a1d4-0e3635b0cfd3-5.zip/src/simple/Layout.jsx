
import React from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';

const SimpleLayout = () => {
  const location = useLocation();

  const isActive = (path) => {
    return location.pathname === path ? 'bg-blue-700 text-white' : 'text-blue-100 hover:bg-blue-600';
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      {/* Simple Header */}
      <header className="bg-blue-800 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center text-blue-800 font-bold">C</div>
            <h1 className="text-xl font-bold tracking-tight">C-RISK Lite</h1>
          </div>
          <nav className="flex gap-4 text-sm font-medium">
            <Link to="/" className={`px-3 py-2 rounded-md transition-colors ${isActive('/')}`}>Dashboard</Link>
            <Link to="/initiation" className={`px-3 py-2 rounded-md transition-colors ${isActive('/initiation')}`}>Module 1: Initiation</Link>
            <Link to="/tests" className={`px-3 py-2 rounded-md transition-colors ${isActive('/tests')}`}>Test Status</Link>
          </nav>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 md:p-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 min-h-[500px] p-6">
          <Outlet />
        </div>
      </main>

      {/* Simple Footer */}
      <footer className="bg-gray-100 border-t border-gray-200 py-6 text-center text-sm text-gray-500">
        <p>Simplified C-RISK Environment | LocalStorage Mode</p>
      </footer>
    </div>
  );
};

export default SimpleLayout;
