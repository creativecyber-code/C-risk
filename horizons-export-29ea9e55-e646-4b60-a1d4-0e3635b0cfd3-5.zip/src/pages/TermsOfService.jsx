
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Logo from '@/components/Logo'; // Import the Logo component

const TermsOfService = () => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans">
      <Helmet>
        <title>Terms of Service - CreativeCyber</title>
        <meta name="description" content="Read the terms of service for CreativeCyber." />
      </Helmet>

      {/* Header */}
      <header className="py-4 border-b border-slate-200 bg-white">
        <div className="container mx-auto px-4 flex items-center justify-between">
          <Logo />
          <Link to="/" className="text-sm font-medium text-slate-600 hover:text-blue-600 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" /> Back to Home
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 md:py-16">
        <article className="prose prose-lg max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">Terms of Service</h1>
          <p className="text-slate-600 text-lg mb-8">
            Last updated: December 30, 2025
          </p>

          <p>
            Welcome to CreativeCyber! These Terms of Service ("Terms") govern your access to and use of CreativeCyber's website, products, and services ("Services"). By accessing or using our Services, you agree to be bound by these Terms. If you do not agree to these Terms, you may not use our Services.
          </p>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">1. Acceptance of Terms</h2>
          <p>
            By creating an account, accessing, or using the Services, you signify that you have read, understood, and agree to be bound by these Terms, including our Privacy Policy. We may modify these Terms at any time by posting the revised Terms on our website. Your continued use of the Services after such changes constitutes your acceptance of the new Terms.
          </p>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">2. Your Account</h2>
          <ul>
            <li>You must be at least 18 years old to use our Services.</li>
            <li>You are responsible for maintaining the confidentiality of your account login information and are fully responsible for all activities that occur under your account.</li>
            <li>You agree to notify us immediately of any unauthorized use of your account.</li>
          </ul>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">3. Use of Services</h2>
          <ul>
            <li>You agree to use the Services only for lawful purposes and in accordance with these Terms.</li>
            <li>You agree not to use the Services in any way that could damage, disable, overburden, or impair the Services or interfere with any other party's use of the Services.</li>
            <li>Prohibited activities include, but are not limited to, reverse engineering, hacking, distributing malware, or engaging in any activity that violates the rights of others.</li>
          </ul>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">4. Intellectual Property</h2>
          <p>
            All content, trademarks, service marks, and logos on the Services are the property of CreativeCyber or its licensors and are protected by intellectual property laws. You may not use any of these without our prior written consent.
          </p>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">5. Disclaimer of Warranties</h2>
          <p>
            THE SERVICES ARE PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT ANY WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED. CREATIVECYBER DISCLAIMS ALL WARRANTIES, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
          </p>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">6. Limitation of Liability</h2>
          <p>
            IN NO EVENT SHALL CREATIVECYBER, ITS AFFILIATES, DIRECTORS, EMPLOYEES, OR AGENTS BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING WITHOUT LIMITATION, LOSS OF PROFITS, DATA, USE, GOODWILL, OR OTHER INTANGIBLE LOSSES, RESULTING FROM (I) YOUR ACCESS TO OR USE OF OR INABILITY TO ACCESS OR USE THE SERVICES; (II) ANY CONDUCT OR CONTENT OF ANY THIRD PARTY ON THE SERVICES; (III) ANY CONTENT OBTAINED FROM THE SERVICES; AND (IV) UNAUTHORIZED ACCESS, USE OR ALTERATION OF YOUR TRANSMISSIONS OR CONTENT, WHETHER BASED ON WARRANTY, CONTRACT, TORT (INCLUDING NEGLIGENCE) OR ANY OTHER LEGAL THEORY, WHETHER OR NOT WE HAVE BEEN INFORMED OF THE POSSIBILITY OF SUCH DAMAGE.
          </p>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">7. Governing Law</h2>
          <p>
            These Terms shall be governed and construed in accordance with the laws of India, without regard to its conflict of law provisions.
          </p>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">8. Contact Us</h2>
          <p>
            If you have any questions about these Terms, please contact us:
          </p>
          <ul>
            <li>By email: support@creativecyber.com</li>
            <li>By visiting this page on our website: <a href="https://www.creativecyber.com/contact" className="text-blue-600 hover:underline">Contact Us</a></li>
          </ul>
        </article>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-8">
        <div className="container mx-auto px-4 text-center text-sm">
          <p>&copy; {new Date().getFullYear()} CreativeCyber. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default TermsOfService;
