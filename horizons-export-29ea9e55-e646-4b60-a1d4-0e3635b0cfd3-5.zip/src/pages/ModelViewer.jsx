import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import ThreatModelingCanvas from '@/components/ThreatModelingCanvas';
import { threatModelService } from '@/services/threatModelService';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Helmet } from 'react-helmet';

// Wrapper for the canvas to handle route parameters
const ModelViewer = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // In a real application, you might fetch model metadata here to verify access
    // before rendering the canvas. For this example, we directly render the canvas
    // and let its internal logic handle loading based on the ID.
    setLoading(false);
  }, [id, navigate]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen bg-slate-900 text-white">
        <span className="text-xl">Loading Threat Model...</span>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Threat Model #{id} - CreativeCyber</title>
        <meta name="description" content={`Viewing threat model with ID: ${id} on the CreativeCyber platform.`} />
      </Helmet>
      <div className="h-screen relative">
        <ThreatModelingCanvas modelId={id} /> 
      </div>
    </>
  );
};

export default ModelViewer;