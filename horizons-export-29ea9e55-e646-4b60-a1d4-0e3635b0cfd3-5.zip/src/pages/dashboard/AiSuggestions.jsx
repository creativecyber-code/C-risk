
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Sparkles, BrainCircuit, RefreshCw, Wand2, ArrowRight, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { threatModelService } from '@/services/threatModelService';
import { aiThreatService } from '@/services/aiThreatService';
import SuggestionCard from '@/components/ai/SuggestionCard';
import GapAnalysisWidget from '@/components/ai/GapAnalysisWidget';
import { Card } from '@/components/ui/card';

const AiSuggestions = () => {
  const [models, setModels] = useState([]);
  const [selectedModelId, setSelectedModelId] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [results, setResults] = useState(null); // { suggestions: [], gapAnalysis: {} }
  const [processedCount, setProcessedCount] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    loadModels();
  }, []);

  const loadModels = async () => {
    try {
      const data = await threatModelService.listModels();
      setModels(data);
      if (data.length > 0) setSelectedModelId(data[0].id);
    } catch (error) {
      toast({ title: "Failed to load models", variant: "destructive" });
    }
  };

  const handleAnalyze = async () => {
    if (!selectedModelId) return;
    setAnalyzing(true);
    setResults(null);
    setProcessedCount(0);

    try {
      // Simulate network delay for "thinking" effect
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const data = await aiThreatService.generateSuggestions(selectedModelId);
      setResults(data);
      toast({ 
        title: "Analysis Complete", 
        description: `AI identified ${data.suggestions.length} potential threats.`,
        className: "bg-purple-50 border-purple-200 text-purple-900"
      });
    } catch (error) {
      toast({ title: "Analysis failed", description: error.message, variant: "destructive" });
    } finally {
      setAnalyzing(false);
    }
  };

  const handleAction = async (suggestion, action) => {
    try {
      // Log feedback
      await aiThreatService.logFeedback(
        selectedModelId, 
        suggestion.signature, 
        action === 'accept' ? 'accepted' : 'rejected'
      );

      if (action === 'accept') {
        await aiThreatService.importThreats(selectedModelId, [suggestion]);
        toast({ title: "Threat Added", description: "Suggestion accepted and added to model." });
      } else {
        toast({ title: "Suggestion Rejected", description: "We'll show fewer threats like this in the future." });
      }

      // Remove from UI
      setResults(prev => ({
        ...prev,
        suggestions: prev.suggestions.filter(s => s.id !== suggestion.id)
      }));
      setProcessedCount(prev => prev + 1);

    } catch (error) {
      toast({ title: "Action failed", variant: "destructive" });
    }
  };

  const handleBatchAccept = async () => {
    if (!results?.suggestions.length) return;
    // Mock batch
    toast({ title: "Batch Import", description: `Importing ${results.suggestions.length} threats...` });
    setResults(prev => ({ ...prev, suggestions: [] }));
    setProcessedCount(prev => prev + results.suggestions.length);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-10">
      <Helmet>
        <title>AI Recommendations | CreativeCyber</title>
      </Helmet>

      {/* Header */}
      <div className="bg-gradient-to-r from-violet-600 to-indigo-600 rounded-2xl p-8 text-white shadow-lg overflow-hidden relative">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <BrainCircuit className="w-64 h-64" />
        </div>
        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
              <Sparkles className="w-6 h-6 text-yellow-300" />
            </div>
            <h1 className="text-3xl font-bold">AI Threat Intelligence</h1>
          </div>
          <p className="text-indigo-100 text-lg mb-8 leading-relaxed">
            Leverage our advanced heuristic engine to scan your architecture for hidden vulnerabilities, 
            compliance gaps, and architectural anomalies.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 bg-white/10 p-4 rounded-xl backdrop-blur-md border border-white/20">
            <Select value={selectedModelId || ''} onValueChange={setSelectedModelId}>
              <SelectTrigger className="bg-white text-slate-900 border-0 h-12 min-w-[250px]">
                <SelectValue placeholder="Select a model to analyze" />
              </SelectTrigger>
              <SelectContent>
                {models.map(m => (
                  <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button 
              size="lg" 
              onClick={handleAnalyze} 
              disabled={!selectedModelId || analyzing}
              className="bg-white text-indigo-600 hover:bg-indigo-50 font-semibold h-12 px-8"
            >
              {analyzing ? (
                <><RefreshCw className="w-5 h-5 mr-2 animate-spin" /> Analyzing Model...</>
              ) : (
                <><Wand2 className="w-5 h-5 mr-2" /> Generate Suggestions</>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Results Section */}
      {results && (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          {/* Metrics Row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
               <GapAnalysisWidget gapData={results.gapAnalysis} />
            </div>
            <div className="space-y-4">
              <Card className="p-6 bg-gradient-to-br from-slate-900 to-slate-800 text-white border-0">
                <h3 className="text-slate-400 text-sm font-medium uppercase mb-1">AI Confidence</h3>
                <div className="text-4xl font-bold mb-2">{(results.meta.confidenceScore * 100).toFixed(0)}%</div>
                <p className="text-sm text-slate-400">Based on architectural patterns and {models.find(m => m.id === selectedModelId)?.industry || 'industry'} standards.</p>
              </Card>
              <Card className="p-6">
                <h3 className="text-slate-500 text-sm font-medium uppercase mb-1">Suggestions Found</h3>
                <div className="text-4xl font-bold text-slate-900 mb-2">{results.suggestions.length}</div>
                <div className="flex items-center text-sm text-green-600 gap-1">
                  <ArrowRight className="w-4 h-4" /> {processedCount} processed this session
                </div>
              </Card>
            </div>
          </div>

          {/* Suggestions List */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-slate-900">Recommended Actions</h2>
              {results.suggestions.length > 0 && (
                <Button variant="outline" onClick={handleBatchAccept}>
                  Import All ({results.suggestions.length})
                </Button>
              )}
            </div>

            {results.suggestions.length === 0 ? (
               <div className="bg-green-50 border border-green-100 rounded-xl p-12 text-center">
                 <ShieldCheck className="w-16 h-16 text-green-500 mx-auto mb-4" />
                 <h3 className="text-xl font-semibold text-green-900 mb-2">All Clear!</h3>
                 <p className="text-green-700">No new high-confidence threats detected based on current analysis rules.</p>
               </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {results.suggestions.map(suggestion => (
                  <SuggestionCard 
                    key={suggestion.id} 
                    suggestion={suggestion} 
                    onAccept={() => handleAction(suggestion, 'accept')}
                    onReject={() => handleAction(suggestion, 'reject')}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}
      
      {!results && !analyzing && (
        <div className="text-center py-20 opacity-50">
          <BrainCircuit className="w-20 h-20 mx-auto text-slate-300 mb-4" />
          <h3 className="text-xl font-medium text-slate-500">Ready to Analyze</h3>
          <p className="text-slate-400">Select a model above to begin AI threat discovery.</p>
        </div>
      )}
    </div>
  );
};

export default AiSuggestions;
