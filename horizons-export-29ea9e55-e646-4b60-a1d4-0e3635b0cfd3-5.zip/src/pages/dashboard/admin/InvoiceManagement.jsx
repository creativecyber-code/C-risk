
import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { 
  FileText, Download, Edit, Plus, CheckCircle, AlertCircle, XCircle, Search, Filter, 
  ArrowUpDown, Calendar as CalendarIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/components/ui/use-toast';
import { adminService } from '@/services/adminService';
import { formatCurrency } from '@/utils/exportUtils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

const InvoiceManagement = () => {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [sortConfig, setSortConfig] = useState({ key: 'date', direction: 'desc' });
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const data = await adminService.getAllInvoices();
      setInvoices(data);
    } catch (e) {
      toast({ title: "Failed to load invoices", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (id, status) => {
    try {
      await adminService.updateInvoiceStatus(id, status);
      setInvoices(invoices.map(inv => inv.id === id ? { ...inv, status } : inv));
      toast({ title: "Invoice Updated", description: `Status changed to ${status}` });
    } catch (e) {
      toast({ title: "Update Failed", variant: "destructive" });
    }
  };

  // Sorting Logic
  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  // Filter & Sort Logic
  const processedInvoices = useMemo(() => {
    let filtered = invoices.filter(inv => {
      // Text Search
      const searchLower = searchQuery.toLowerCase();
      const matchesText = 
        inv.orgName.toLowerCase().includes(searchLower) || 
        inv.id.toLowerCase().includes(searchLower) ||
        inv.customerId.toLowerCase().includes(searchLower) ||
        inv.email.toLowerCase().includes(searchLower);

      // Date Range Filter
      let matchesDate = true;
      const invDate = new Date(inv.date);
      if (dateRange.start) {
        matchesDate = matchesDate && invDate >= new Date(dateRange.start);
      }
      if (dateRange.end) {
        matchesDate = matchesDate && invDate <= new Date(dateRange.end);
      }

      return matchesText && matchesDate;
    });

    // Sorting
    return filtered.sort((a, b) => {
      if (a[sortConfig.key] < b[sortConfig.key]) {
        return sortConfig.direction === 'asc' ? -1 : 1;
      }
      if (a[sortConfig.key] > b[sortConfig.key]) {
        return sortConfig.direction === 'asc' ? 1 : -1;
      }
      return 0;
    });
  }, [invoices, searchQuery, dateRange, sortConfig]);

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Paid': return <Badge className="bg-green-100 text-green-800 hover:bg-green-100 border-green-200"><CheckCircle className="w-3 h-3 mr-1"/> Paid</Badge>;
      case 'Overdue': return <Badge className="bg-red-100 text-red-800 hover:bg-red-100 border-red-200"><AlertCircle className="w-3 h-3 mr-1"/> Overdue</Badge>;
      case 'Void': return <Badge variant="secondary" className="bg-slate-100 text-slate-800"><XCircle className="w-3 h-3 mr-1"/> Void</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-8 h-[calc(100vh-140px)] flex flex-col">
      <Helmet>
        <title>Admin - Invoice Management</title>
      </Helmet>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Invoice Management</h1>
          <p className="text-slate-500 mt-1">Generate, view, and modify invoices across all tenants.</p>
        </div>
        <div className="flex gap-2">
           <Dialog>
            <DialogTrigger asChild>
              <Button><Plus className="w-4 h-4 mr-2" /> Generate Invoice</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Generate New Invoice</DialogTitle>
                <DialogDescription>Manually create an invoice for an organization.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <span className="text-right text-sm font-medium">Organization</span>
                  <Input id="name" placeholder="Acme Corp" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <span className="text-right text-sm font-medium">Customer ID</span>
                  <Input id="custId" placeholder="CUST-XXXXX" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <span className="text-right text-sm font-medium">Amount</span>
                  <Input id="amount" type="number" placeholder="499.00" className="col-span-3" />
                </div>
              </div>
              <DialogFooter>
                <Button onClick={() => {
                  toast({ title: "Invoice Generated", description: "The invoice has been sent to the customer." });
                }}>Create Invoice</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card className="flex-1 flex flex-col overflow-hidden">
        <CardHeader className="border-b bg-slate-50/50">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <CardTitle>Invoices</CardTitle>
              <Badge variant="secondary" className="ml-2">{processedInvoices.length}</Badge>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
               {/* Search Bar */}
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-slate-400" />
                <Input 
                  placeholder="Search ID, Org, Email..." 
                  className="pl-8 bg-white" 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {/* Date Filters */}
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Input 
                    type="date" 
                    className="w-36 bg-white"
                    value={dateRange.start}
                    onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
                  />
                </div>
                <span className="text-slate-400">-</span>
                <div className="relative">
                  <Input 
                    type="date" 
                    className="w-36 bg-white"
                    value={dateRange.end}
                    onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
                  />
                </div>
              </div>

              {/* Clear Filters */}
              {(searchQuery || dateRange.start || dateRange.end) && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => {
                    setSearchQuery('');
                    setDateRange({ start: '', end: '' });
                  }}
                  className="text-slate-500 hover:text-red-600"
                >
                  <XCircle className="w-4 h-4 mr-1" /> Clear
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0 flex-1 overflow-auto">
          <Table>
            <TableHeader className="bg-slate-50 sticky top-0 z-10">
              <TableRow>
                <TableHead 
                  className="cursor-pointer hover:bg-slate-100 w-[140px]" 
                  onClick={() => handleSort('id')}
                >
                  <div className="flex items-center gap-1">
                    Invoice ID 
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </TableHead>
                <TableHead 
                  className="cursor-pointer hover:bg-slate-100" 
                  onClick={() => handleSort('customerId')}
                >
                  <div className="flex items-center gap-1">
                    Customer ID
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </TableHead>
                <TableHead 
                  className="cursor-pointer hover:bg-slate-100" 
                  onClick={() => handleSort('orgName')}
                >
                  <div className="flex items-center gap-1">
                    Organization
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </TableHead>
                <TableHead>Subscription Email</TableHead>
                <TableHead 
                  className="cursor-pointer hover:bg-slate-100" 
                  onClick={() => handleSort('date')}
                >
                  <div className="flex items-center gap-1">
                    Date
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </TableHead>
                <TableHead 
                  className="cursor-pointer hover:bg-slate-100" 
                  onClick={() => handleSort('amount')}
                >
                  <div className="flex items-center gap-1">
                    Amount
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </TableHead>
                <TableHead 
                  className="cursor-pointer hover:bg-slate-100" 
                  onClick={() => handleSort('status')}
                >
                  <div className="flex items-center gap-1">
                    Status
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-12 text-slate-500">
                    <div className="flex justify-center items-center gap-2">
                       <div className="w-4 h-4 rounded-full border-2 border-slate-300 border-t-brand-600 animate-spin"></div>
                       Loading invoices...
                    </div>
                  </TableCell>
                </TableRow>
              ) : processedInvoices.length === 0 ? (
                 <TableRow>
                  <TableCell colSpan={8} className="text-center py-12 text-slate-500">
                    No invoices found matching your criteria.
                  </TableCell>
                </TableRow>
              ) : processedInvoices.map((inv) => (
                <TableRow key={inv.id} className="hover:bg-slate-50/50">
                  <TableCell className="font-mono text-xs font-medium text-slate-600">
                    {inv.id}
                  </TableCell>
                  <TableCell className="font-mono text-xs text-slate-500">
                    {inv.customerId}
                  </TableCell>
                  <TableCell className="font-medium text-slate-900">
                    {inv.orgName}
                  </TableCell>
                  <TableCell className="text-sm text-slate-500">
                    {inv.email}
                  </TableCell>
                  <TableCell className="whitespace-nowrap">
                    {inv.date}
                  </TableCell>
                  <TableCell className="font-medium font-mono">
                    {formatCurrency(inv.amount)}
                  </TableCell>
                  <TableCell>
                    {getStatusBadge(inv.status)}
                    <div className="text-[10px] text-slate-400 mt-1">Due: {inv.dueDate}</div>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Edit className="w-4 h-4 text-slate-500" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => toast({ title: "Downloading PDF..." })}>
                          <Download className="w-4 h-4 mr-2" /> Download PDF
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleStatusUpdate(inv.id, 'Paid')}>
                          <CheckCircle className="w-4 h-4 mr-2 text-green-500" /> Mark as Paid
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleStatusUpdate(inv.id, 'Overdue')}>
                          <AlertCircle className="w-4 h-4 mr-2 text-orange-500" /> Mark as Overdue
                        </DropdownMenuItem>
                         <DropdownMenuItem onClick={() => handleStatusUpdate(inv.id, 'Void')} className="text-red-600 focus:text-red-600">
                          <XCircle className="w-4 h-4 mr-2" /> Void Invoice
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default InvoiceManagement;
