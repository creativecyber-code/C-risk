
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { 
  CreditCard, TrendingUp, Users, Calendar, 
  MoreVertical, AlertCircle, CheckCircle, XCircle 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/components/ui/use-toast';
import { adminService } from '@/services/adminService';
import { auditService } from '@/services/auditService';
import { formatCurrency } from '@/utils/exportUtils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const SubscriptionManagement = () => {
  const [subscriptions, setSubscriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const data = await adminService.getAllSubscriptions();
      setSubscriptions(data);
    } catch (e) {
      toast({ title: "Failed to load subscriptions", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleCancelSubscription = async (subId, orgName) => {
    try {
       // Mock action
       toast({ title: "Subscription Cancelled" });
       await auditService.logAction(
         'CANCEL_SUBSCRIPTION',
         'Subscription',
         { subId, orgName },
         'success'
       );
       // Refresh list (mock)
       setSubscriptions(subscriptions.map(s => s.id === subId ? { ...s, status: 'cancelled' } : s));
    } catch (e) {
       toast({ title: "Action Failed", variant: "destructive" });
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'active': return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Active</Badge>;
      case 'past_due': return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Past Due</Badge>;
      case 'cancelled': return <Badge variant="secondary" className="bg-slate-100 text-slate-800">Cancelled</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  // KPI Calculations
  const totalMRR = subscriptions.reduce((acc, sub) => sub.status === 'active' ? acc + sub.mrr : acc, 0);
  const totalUsers = subscriptions.reduce((acc, sub) => acc + sub.usersCount, 0);
  const activeTenants = subscriptions.filter(sub => sub.status === 'active').length;

  return (
    <div className="space-y-8">
      <Helmet>
        <title>Admin - Subscription Management</title>
      </Helmet>

      <div>
        <h1 className="text-3xl font-bold text-slate-900">Subscription Management</h1>
        <p className="text-slate-500 mt-1">Manage tenant plans, billing status, and revenue.</p>
      </div>

      {/* Admin KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-slate-500">Total MRR</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalMRR)}</div>
            <p className="text-xs text-slate-500">Monthly Recurring Revenue</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-slate-500">Active Tenants</CardTitle>
            <CreditCard className="h-4 w-4 text-brand-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeTenants}</div>
            <p className="text-xs text-slate-500">Paying Organizations</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-slate-500">Total Users</CardTitle>
            <Users className="h-4 w-4 text-slate-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalUsers}</div>
            <p className="text-xs text-slate-500">Across all tenants</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Tenant Subscriptions</CardTitle>
          <CardDescription>View and manage all organization subscriptions.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Organization</TableHead>
                <TableHead>Plan</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Users</TableHead>
                <TableHead>MRR</TableHead>
                <TableHead>Renewal</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                 <TableRow>
                   <TableCell colSpan={7} className="text-center py-8">Loading subscriptions...</TableCell>
                 </TableRow>
              ) : subscriptions.map((sub) => (
                <TableRow key={sub.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium text-slate-900">{sub.orgName}</div>
                      <div className="text-xs text-slate-500">{sub.contactEmail}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="border-brand-200 text-brand-700 bg-brand-50">
                      {sub.plan}
                    </Badge>
                  </TableCell>
                  <TableCell>{getStatusBadge(sub.status)}</TableCell>
                  <TableCell>{sub.usersCount}</TableCell>
                  <TableCell className="font-mono">{formatCurrency(sub.mrr)}</TableCell>
                  <TableCell>{new Date(sub.renewalDate).toLocaleDateString()}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="w-4 h-4 text-slate-500" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Manage Subscription</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => toast({ title: "Opening Billing Portal" })}>
                          View Invoices
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => toast({ title: "Feature not implemented" })}>
                          Change Plan
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          className="text-red-600 focus:text-red-600"
                          onClick={() => handleCancelSubscription(sub.id, sub.orgName)}
                        >
                          Cancel Subscription
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default SubscriptionManagement;
