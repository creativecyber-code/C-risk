
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { Check, X, Clock, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { adminService } from '@/services/adminService';

const PendingApprovals = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const data = await adminService.getPendingApprovals();
      setRequests(data);
    } catch (e) {
      toast({ title: "Error loading requests", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleAction = async (id, orgName, action) => {
    setProcessing(id);
    try {
      if (action === 'approve') {
        await adminService.approveOrganization(id, orgName);
        toast({ title: "Organization Approved", className: "bg-green-600 text-white" });
      } else {
        await adminService.rejectOrganization(id, orgName);
        toast({ title: "Organization Rejected" });
      }
      // Remove from list
      setRequests(requests.filter(r => r.id !== id));
    } catch (e) {
      toast({ title: "Action Failed", variant: "destructive" });
    } finally {
      setProcessing(null);
    }
  };

  return (
    <div className="space-y-8">
      <Helmet>
        <title>Admin - Pending Approvals</title>
      </Helmet>

      <div>
        <h1 className="text-3xl font-bold text-slate-900">Pending Approvals</h1>
        <p className="text-slate-500 mt-1">Review and approve new customer organization signups.</p>
      </div>

      {loading ? (
        <div className="flex justify-center p-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-600"></div>
        </div>
      ) : requests.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16 text-slate-500">
            <ShieldAlert className="w-12 h-12 mb-4 text-slate-300" />
            <h3 className="text-lg font-medium text-slate-900">No Pending Requests</h3>
            <p>All customer signups have been processed.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {requests.map((req) => (
            <Card key={req.id} className="overflow-hidden">
              <div className="flex flex-col md:flex-row">
                <div className="flex-1 p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900">{req.orgName}</h3>
                      <div className="flex items-center gap-2 mt-1 text-sm text-slate-500">
                        <Clock className="w-3 h-3" />
                        <span>Requested: {new Date(req.requestedAt).toLocaleString()}</span>
                      </div>
                    </div>
                    <Badge>{req.plan} Plan</Badge>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="p-3 bg-slate-50 rounded-lg">
                      <p className="text-xs font-semibold text-slate-500 uppercase">Contact Person</p>
                      <p className="font-medium">{req.contactName}</p>
                      <p className="text-sm text-slate-600">{req.email}</p>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-lg">
                      <p className="text-xs font-semibold text-slate-500 uppercase">Usage Intent</p>
                      <p className="text-sm text-slate-700 italic">"{req.reason}"</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-slate-50 border-t md:border-t-0 md:border-l p-6 flex flex-row md:flex-col items-center justify-center gap-3 min-w-[200px]">
                  <Button 
                    className="w-full bg-green-600 hover:bg-green-700" 
                    onClick={() => handleAction(req.id, req.orgName, 'approve')}
                    disabled={processing === req.id}
                  >
                    <Check className="w-4 h-4 mr-2" /> Approve
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full border-red-200 text-red-700 hover:bg-red-50 hover:text-red-800"
                    onClick={() => handleAction(req.id, req.orgName, 'reject')}
                    disabled={processing === req.id}
                  >
                    <X className="w-4 h-4 mr-2" /> Reject
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default PendingApprovals;
