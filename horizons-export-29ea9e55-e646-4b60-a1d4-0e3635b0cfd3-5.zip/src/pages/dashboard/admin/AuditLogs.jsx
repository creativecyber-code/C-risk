
import React from 'react';
import { Helmet } from 'react-helmet-async';
import AuditLogViewer from '@/components/security/AuditLogViewer';

const AuditLogs = () => {
  return (
    <div className="space-y-6 h-[calc(100vh-140px)] flex flex-col">
      <Helmet>
        <title>Admin - Audit Logs</title>
      </Helmet>

      <div>
        <h1 className="text-3xl font-bold text-slate-900">System Audit Logs</h1>
        <p className="text-slate-500 mt-1">Comprehensive log of all administrative actions, security events, and system changes.</p>
      </div>

      <div className="flex-1 overflow-hidden">
        <AuditLogViewer />
      </div>
    </div>
  );
};

export default AuditLogs;
