import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Plus, Rocket, BookOpen, Clock, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import QuickStartWizard from '@/components/wizards/QuickStartWizard';
import Templates from './Templates'; // Re-using existing templates grid

const TemplatesWizards = () => {
  const [wizardOpen, setWizardOpen] = useState(false);

  return (
    <div className="space-y-8 pb-10">
      <Helmet>
        <title>Templates & Wizards | CreativeCyber</title>
      </Helmet>

      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 p-8 text-white shadow-lg">
        <div className="relative z-10 max-w-2xl">
          <h1 className="text-3xl font-bold font-heading mb-4">Start Modeling Faster</h1>
          <p className="text-blue-100 text-lg mb-8 leading-relaxed">
            Use our Quick Start Wizard to bootstrap your threat model in minutes, or browse our extensive library of industry-standard templates.
          </p>
          
          <div className="flex gap-4">
            <Button 
              size="lg" 
              className="bg-white text-blue-600 hover:bg-blue-50 font-semibold border-0"
              onClick={() => setWizardOpen(true)}
            >
              <Rocket className="w-5 h-5 mr-2" /> Launch Wizard
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-blue-400 text-blue-100 hover:bg-blue-700/50 hover:text-white"
            >
              <BookOpen className="w-5 h-5 mr-2" /> Browse Guide
            </Button>
          </div>
        </div>
        
        {/* Decorative Background */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none" />
        <div className="absolute bottom-0 right-20 w-40 h-40 bg-indigo-500/30 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Recommended for You */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" /> Recommended For You
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           <Card className="hover:border-brand-300 transition-colors cursor-pointer group" onClick={() => setWizardOpen(true)}>
             <CardHeader className="pb-2">
               <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center mb-3 group-hover:bg-indigo-200 transition-colors">
                 <Rocket className="w-5 h-5 text-indigo-600" />
               </div>
               <CardTitle className="text-lg">Web App Quick Start</CardTitle>
             </CardHeader>
             <CardContent>
               <p className="text-sm text-slate-500">Standard 3-tier architecture with React frontend, Node backend, and SQL database.</p>
             </CardContent>
             <CardFooter className="text-xs text-indigo-600 font-medium">
               2 min setup
             </CardFooter>
           </Card>

           <Card className="hover:border-brand-300 transition-colors cursor-pointer group" onClick={() => setWizardOpen(true)}>
             <CardHeader className="pb-2">
               <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mb-3 group-hover:bg-purple-200 transition-colors">
                 <Clock className="w-5 h-5 text-purple-600" />
               </div>
               <CardTitle className="text-lg">Microservices Base</CardTitle>
             </CardHeader>
             <CardContent>
               <p className="text-sm text-slate-500">Foundation for distributed systems with API Gateway and Auth service.</p>
             </CardContent>
             <CardFooter className="text-xs text-purple-600 font-medium">
               5 min setup
             </CardFooter>
           </Card>

           <Card className="hover:border-brand-300 transition-colors cursor-pointer group">
             <CardHeader className="pb-2">
               <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mb-3 group-hover:bg-green-200 transition-colors">
                 <Plus className="w-5 h-5 text-green-600" />
               </div>
               <CardTitle className="text-lg">Blank Canvas</CardTitle>
             </CardHeader>
             <CardContent>
               <p className="text-sm text-slate-500">Start from scratch without any pre-defined components or threats.</p>
             </CardContent>
             <CardFooter className="text-xs text-green-600 font-medium">
               Custom setup
             </CardFooter>
           </Card>
        </div>
      </div>

      {/* Main Library (Reusing Templates Component) */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-slate-900">Full Template Library</h2>
        <Templates /> 
      </div>

      {/* Wizard Modal */}
      <Dialog open={wizardOpen} onOpenChange={setWizardOpen}>
        <DialogContent className="max-w-5xl h-[85vh] p-0 gap-0 border-0 bg-transparent shadow-none">
          <QuickStartWizard onClose={() => setWizardOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TemplatesWizards;