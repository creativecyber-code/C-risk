
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { 
  ShieldCheck, 
  FileText, 
  Download, 
  Activity, 
  AlertTriangle,
  CheckCircle2,
  Lock,
  Globe
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import SecurityAlertsPanel from '@/components/security/SecurityAlertsPanel';
import AuditLogViewer from '@/components/security/AuditLogViewer';
import KeyManagementPanel from '@/components/security/KeyManagementPanel';
import { 
  generateSOC2Report, 
  generateGDPRReport, 
  generateHIPAAReport, 
  generatePCIDSSReport 
} from '@/utils/pdfReportGenerators';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';

const SecurityAuditDashboard = () => {
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const orgName = profile?.organization?.name || "My Organization";

  const handleDownload = async (reportType) => {
    toast({
      title: "Generating Report",
      description: `Preparing your ${reportType} report...`,
    });

    try {
      switch(reportType) {
        case 'SOC2':
          await generateSOC2Report(orgName);
          break;
        case 'GDPR':
          await generateGDPRReport(orgName);
          break;
        case 'HIPAA':
          await generateHIPAAReport(orgName);
          break;
        case 'PCI-DSS':
          await generatePCIDSSReport(orgName);
          break;
        default:
          throw new Error("Unknown report type");
      }
      
      toast({
        title: "Download Started",
        description: `${reportType} report has been successfully generated.`,
      });
    } catch (error) {
      console.error(error);
      toast({
        title: "Generation Failed",
        description: "There was an error generating the PDF. Please try again.",
        variant: "destructive"
      });
    }
  };

  const reports = [
    {
      id: 'soc2',
      title: 'SOC 2 Type II Readiness',
      description: 'Audit report covering Security, Availability, and Confidentiality.',
      status: 'Ready',
      date: 'Dec 15, 2025',
      icon: ShieldCheck,
      color: 'text-blue-600',
      type: 'SOC2'
    },
    {
      id: 'gdpr',
      title: 'GDPR Compliance',
      description: 'Data privacy impact assessment and Article 30 records.',
      status: 'Updated',
      date: 'Jan 02, 2026',
      icon: Globe,
      color: 'text-indigo-600',
      type: 'GDPR'
    },
    {
      id: 'hipaa',
      title: 'HIPAA Security Rule',
      description: 'Technical and administrative safeguards for ePHI.',
      status: 'Review Needed',
      date: 'Nov 20, 2025',
      icon: Activity,
      color: 'text-teal-600',
      type: 'HIPAA'
    },
    {
      id: 'pci',
      title: 'PCI-DSS v4.0',
      description: 'Payment card industry data security standard compliance.',
      status: 'Pending',
      date: 'Pending',
      icon: Lock,
      color: 'text-orange-600',
      type: 'PCI-DSS'
    }
  ];

  return (
    <div className="space-y-6">
      <Helmet>
        <title>Security & Audit - CreativeCyber</title>
      </Helmet>

      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Security & Audit Center</h1>
        <p className="text-slate-500">Monitor compliance status, review logs, and manage security configurations.</p>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="reports">Compliance Reports</TabsTrigger>
          <TabsTrigger value="logs">Audit Logs</TabsTrigger>
          <TabsTrigger value="settings">Encryption & Settings</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Compliance Score</CardTitle>
                <ShieldCheck className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">92%</div>
                <p className="text-xs text-slate-500">+4% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Alerts</CardTitle>
                <AlertTriangle className="h-4 w-4 text-orange-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3</div>
                <p className="text-xs text-slate-500">2 High Priority</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Security Gates</CardTitle>
                <Lock className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">12</div>
                <p className="text-xs text-slate-500">Passed in last 24h</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Audit Events</CardTitle>
                <FileText className="h-4 w-4 text-slate-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1.4k</div>
                <p className="text-xs text-slate-500">In the last 7 days</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
            <div className="col-span-4">
              <SecurityAlertsPanel />
            </div>
            <div className="col-span-3">
              <KeyManagementPanel />
            </div>
          </div>
        </TabsContent>

        {/* Reports Tab */}
        <TabsContent value="reports" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {reports.map((report) => (
              <Card key={report.id} className="flex flex-col">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg bg-slate-100 ${report.color}`}>
                        <report.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{report.title}</CardTitle>
                        <CardDescription className="mt-1">{report.description}</CardDescription>
                      </div>
                    </div>
                    {report.status === 'Ready' || report.status === 'Updated' ? (
                      <Badge className="bg-green-100 text-green-700 hover:bg-green-200 border-0">
                        <CheckCircle2 className="w-3 h-3 mr-1" /> {report.status}
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-slate-500 border-slate-200">
                        {report.status}
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="flex-1">
                  <div className="grid grid-cols-2 gap-4 text-sm mt-2">
                    <div>
                      <span className="text-slate-500 block">Last Generated</span>
                      <span className="font-medium">{report.date}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Format</span>
                      <span className="font-medium">PDF (v4.2)</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="bg-slate-50/50 border-t p-4">
                  <Button 
                    variant="outline" 
                    className="w-full sm:w-auto ml-auto" 
                    onClick={() => handleDownload(report.type)}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download PDF
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Logs Tab */}
        <TabsContent value="logs">
          <AuditLogViewer />
        </TabsContent>
        
        {/* Settings Tab */}
        <TabsContent value="settings">
          <div className="grid gap-6 md:grid-cols-2">
             <KeyManagementPanel />
             <Card>
                <CardHeader>
                   <CardTitle>Log Retention Policies</CardTitle>
                   <CardDescription>Configure how long audit data is stored.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex justify-between items-center p-3 bg-slate-50 rounded border">
                        <div>
                            <p className="font-medium">Security Logs</p>
                            <p className="text-xs text-slate-500">Login attempts, critical failures</p>
                        </div>
                        <Badge>1 Year</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-slate-50 rounded border">
                        <div>
                            <p className="font-medium">Access Logs</p>
                            <p className="text-xs text-slate-500">Resource views and edits</p>
                        </div>
                        <Badge>90 Days</Badge>
                    </div>
                </CardContent>
             </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SecurityAuditDashboard;
