
import React, { useState, useEffect, Suspense } from 'react';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Building2, 
  ShieldCheck, 
  CreditCard, 
  FileText, 
  Key,
  MessageSquare,
  Loader2
} from 'lucide-react';

// Lazy load sub-components to prevent circular dependencies and hook errors
const UserManagementPanel = React.lazy(() => import('@/components/access/UserManagementPanel'));
const OrganizationManagement = React.lazy(() => import('@/pages/dashboard/OrganizationManagement'));
const AccessControl = React.lazy(() => import('@/pages/dashboard/AccessControl'));
const SecuritySettingsPanel = React.lazy(() => import('@/components/access/SecuritySettingsPanel'));
const PricingManagement = React.lazy(() => import('@/components/access/PricingManagement'));
const AuditLogViewer = React.lazy(() => import('@/components/security/AuditLogViewer'));
const EnquiryManagement = React.lazy(() => import('@/components/access/EnquiryManagement'));

const Administration = () => {
  const { user, profile, loading: authLoading } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  
  // Default to 'overview' or read from URL
  const currentTab = searchParams.get('tab') || 'overview';
  const orgId = profile?.org_id;
  
  const isSiteOwner = profile?.role === 'Site Owner' || user?.email?.includes('admin@');

  const handleTabChange = (value) => {
    setSearchParams({ tab: value });
  };

  if (authLoading) {
    return (
      <div className="flex h-[50vh] w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!orgId) {
    return (
      <div className="p-8 text-center">
        <h2 className="text-xl font-semibold text-red-600">Organization Not Found</h2>
        <p className="text-muted-foreground mt-2">
          Your account is not associated with a valid organization. Please contact support.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20">
      <Helmet>
        <title>Administration | CreativeCyber</title>
      </Helmet>

      <div>
        <h1 className="text-3xl font-bold tracking-tight">Administration</h1>
        <p className="text-muted-foreground mt-2">
          Centralized management for users, security, and organization settings.
        </p>
      </div>

      <Tabs value={currentTab} onValueChange={handleTabChange} className="space-y-6">
        <div className="border-b bg-white px-2 shadow-sm rounded-lg overflow-x-auto">
          <TabsList className="bg-transparent h-auto p-0 space-x-2 w-full justify-start">
            <TabTriggerItem value="overview" icon={<LayoutDashboard className="w-4 h-4 mr-2" />} label="Overview" />
            <TabTriggerItem value="organization" icon={<Building2 className="w-4 h-4 mr-2" />} label="Organization" />
            <TabTriggerItem value="users" icon={<Users className="w-4 h-4 mr-2" />} label="Users & Teams" />
            <TabTriggerItem value="access" icon={<Key className="w-4 h-4 mr-2" />} label="Access Control" />
            <TabTriggerItem value="security" icon={<ShieldCheck className="w-4 h-4 mr-2" />} label="Security" />
            {isSiteOwner && (
              <TabTriggerItem value="billing" icon={<CreditCard className="w-4 h-4 mr-2" />} label="Billing" />
            )}
            <TabTriggerItem value="audit" icon={<FileText className="w-4 h-4 mr-2" />} label="Audit Logs" />
             {isSiteOwner && (
              <TabTriggerItem value="enquiries" icon={<MessageSquare className="w-4 h-4 mr-2" />} label="Enquiries" />
            )}
          </TabsList>
        </div>

        <Suspense fallback={<div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-slate-300" /></div>}>
          {/* OVERVIEW TAB */}
          <TabsContent value="overview" className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
               <OverviewCard 
                  title="Manage Users" 
                  desc="Invite team members and manage roles." 
                  icon={<Users className="w-6 h-6 text-blue-600" />}
                  onClick={() => handleTabChange('users')}
               />
               <OverviewCard 
                  title="Security Policies" 
                  desc="Configure SSO, MFA, and password policies." 
                  icon={<ShieldCheck className="w-6 h-6 text-emerald-600" />}
                  onClick={() => handleTabChange('security')}
               />
               <OverviewCard 
                  title="Audit Logs" 
                  desc="Review system activity and access logs." 
                  icon={<FileText className="w-6 h-6 text-amber-600" />}
                  onClick={() => handleTabChange('audit')}
               />
            </div>
          </TabsContent>

          {/* MODULE TABS */}
          <TabsContent value="organization">
             <OrganizationManagement isEmbedded={true} orgId={orgId} />
          </TabsContent>

          <TabsContent value="users">
             <UserManagementPanel orgId={orgId} />
          </TabsContent>

          <TabsContent value="access">
             <AccessControl isEmbedded={true} orgId={orgId} />
          </TabsContent>

          <TabsContent value="security">
             <SecuritySettingsPanel orgId={orgId} />
          </TabsContent>

          {isSiteOwner && (
            <TabsContent value="billing">
               <PricingManagement />
            </TabsContent>
          )}

          <TabsContent value="audit">
             <AuditLogViewer orgId={orgId} />
          </TabsContent>
          
          {isSiteOwner && (
             <TabsContent value="enquiries">
                <EnquiryManagement />
             </TabsContent>
          )}
        </Suspense>
      </Tabs>
    </div>
  );
};

// Helper Components
const TabTriggerItem = ({ value, icon, label }) => (
  <TabsTrigger 
    value={value}
    className="data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:shadow-none rounded-none px-4 py-3 text-sm font-medium text-slate-500 hover:text-slate-700 data-[state=active]:text-blue-600 transition-all bg-transparent"
  >
    <div className="flex items-center">
      {icon}
      <span>{label}</span>
    </div>
  </TabsTrigger>
);

const OverviewCard = ({ title, desc, icon, onClick }) => (
  <Card className="cursor-pointer hover:bg-slate-50 transition-colors" onClick={onClick}>
    <CardHeader className="flex flex-row items-center gap-4">
      <div className="p-2 bg-slate-100 rounded-lg">{icon}</div>
      <div>
        <CardTitle className="text-base">{title}</CardTitle>
        <CardDescription>{desc}</CardDescription>
      </div>
    </CardHeader>
  </Card>
);

export default Administration;
