
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { 
  Database, Shield, Server, Layout, Lock, FileText, 
  Users, Activity, Globe, Code, Layers, CheckCircle2 
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';

const SystemDocumentation = () => {
  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-10">
      <Helmet>
        <title>System Documentation | CreativeCyber</title>
      </Helmet>

      <div>
        <h1 className="text-3xl font-bold font-heading text-slate-900">System Architecture & Analysis</h1>
        <p className="text-slate-500 mt-2">
          Comprehensive technical overview of the CreativeCyber platform, including feature sets, data models, and security implementation.
        </p>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 h-auto">
          <TabsTrigger value="overview" className="py-2">Feature Overview</TabsTrigger>
          <TabsTrigger value="database" className="py-2">Data Models</TabsTrigger>
          <TabsTrigger value="security" className="py-2">Auth & Security</TabsTrigger>
          <TabsTrigger value="compliance" className="py-2">Compliance & Risk</TabsTrigger>
          <TabsTrigger value="integrations" className="py-2">Integrations</TabsTrigger>
        </TabsList>

        {/* --- 1. FEATURE OVERVIEW --- */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FeatureCard 
              icon={<Layout className="w-5 h-5 text-blue-600" />}
              title="Threat Modeling Engine"
              features={[
                "Interactive Canvas (Diagramming)",
                "STRIDE Methodology Support",
                "Automated Threat Generation",
                "Trust Boundary & Data Flow Mapping",
                "Version Control (Time-travel/Snapshots)",
                "Quick Start Wizards"
              ]}
            />
            <FeatureCard 
              icon={<Activity className="w-5 h-5 text-emerald-600" />}
              title="Risk Management"
              features={[
                "FAIR Quantitative Analysis (ALE Calculation)",
                "CVSS Qualitative Scoring",
                "Risk Prioritization Matrix",
                "Financial Exposure Analysis",
                "Risk Acceptance Workflows",
                "Business Justification Tracking"
              ]}
            />
            <FeatureCard 
              icon={<Shield className="w-5 h-5 text-indigo-600" />}
              title="Compliance & Audit"
              features={[
                "Multi-framework Support (NIST, ISO27001, GDPR, etc.)",
                "Automated Control Mapping",
                "Evidence Collection Repository",
                "Audit Log Generation",
                "Gap Analysis Reports",
                "Real-time Compliance Scoring"
              ]}
            />
            <FeatureCard 
              icon={<Users className="w-5 h-5 text-orange-600" />}
              title="Collaboration & Admin"
              features={[
                "Role-Based Access Control (RBAC)",
                "Team Management & Invites",
                "Approval Workflows (Manager Sign-off)",
                "In-app Comments & Mentions",
                "Notification Center (Email/In-app)",
                "Subscription & Billing Management"
              ]}
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Application Structure</CardTitle>
              <CardDescription>Current Page Inventory</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="space-y-2">
                  <h4 className="font-semibold text-slate-900">Core Dashboard</h4>
                  <ul className="space-y-1 text-slate-600 list-disc pl-4">
                    <li>Threat Models List</li>
                    <li>Model Canvas (Editor)</li>
                    <li>Risk Prioritization</li>
                    <li>Compliance Dashboard</li>
                    <li>Remediation Plans</li>
                    <li>Reports & Analytics</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold text-slate-900">Libraries & Tools</h4>
                  <ul className="space-y-1 text-slate-600 list-disc pl-4">
                    <li>Threat Library (Knowledge Base)</li>
                    <li>Template Wizard</li>
                    <li>AI Suggestions</li>
                    <li>Integration Hub</li>
                    <li>Model Version History</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold text-slate-900">Admin & Settings</h4>
                  <ul className="space-y-1 text-slate-600 list-disc pl-4">
                    <li>Team Management</li>
                    <li>Access Control (RBAC)</li>
                    <li>Audit Logs</li>
                    <li>Pending Approvals</li>
                    <li>Billing & Invoices</li>
                    <li>Notification Settings</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* --- 2. DATA MODELS --- */}
        <TabsContent value="database" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5 text-slate-600" />
                Database Schema (Supabase / PostgreSQL)
              </CardTitle>
              <CardDescription>
                The application uses a relational schema with Row Level Security (RLS) enabled on all tables.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-6">
                  <SchemaGroup title="Organization & Identity" tables={[
                    { name: "organizations", desc: "Tenancy root. Stores subscription tier." },
                    { name: "user_profiles", desc: "Extended user data, links auth.users to organizations." },
                    { name: "roles", desc: "Custom RBAC roles definition." },
                    { name: "permissions", desc: "Granular permissions catalog." },
                    { name: "organization_invites", desc: "Pending email invitations." }
                  ]} />
                  
                  <SchemaGroup title="Threat Modeling Core" tables={[
                    { name: "threat_models", desc: "Header table for a model/diagram." },
                    { name: "threat_elements", desc: "Canvas nodes (processes, stores, external entities)." },
                    { name: "data_flows", desc: "Canvas edges (connections between elements)." },
                    { name: "trust_boundaries", desc: "Zones of trust on the canvas." },
                    { name: "threat_model_versions", desc: "Historical snapshots of models." }
                  ]} />

                  <SchemaGroup title="Risk & Assessment" tables={[
                    { name: "threat_assessments", desc: "Generated threats with status, scores (CVSS/FAIR)." },
                    { name: "threat_approvals", desc: "Workflow state for accepting/mitigating risks." },
                    { name: "mitigation_plans", desc: "Action items to resolve threats." },
                    { name: "mitigation_blockers", desc: "Issues preventing mitigation." }
                  ]} />

                  <SchemaGroup title="Knowledge & Compliance" tables={[
                    { name: "threat_patterns", desc: "Library of reusable threat definitions." },
                    { name: "compliance_records", desc: "Status of specific control frameworks." },
                    { name: "compliance_evidence", desc: "Links to proofs/documents for audits." },
                    { name: "audit_reports", desc: "Generated historical reports." }
                  ]} />

                  <SchemaGroup title="System & Integrations" tables={[
                    { name: "app_audit_logs", desc: "Immutable record of user actions." },
                    { name: "integrations", desc: "Config for 3rd party tools (Jira, GitHub)." },
                    { name: "notifications", desc: "User alerts and messages." },
                    { name: "ai_suggestion_actions", desc: "Tracking AI implementation rates." }
                  ]} />
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* --- 3. SECURITY --- */}
        <TabsContent value="security" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                   <Lock className="w-5 h-5 text-indigo-600" />
                   Authentication
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                   <h4 className="font-semibold text-sm">Mechanism</h4>
                   <p className="text-sm text-slate-600">Supabase Auth (GoTrue) handling JWT tokens.</p>
                </div>
                <div>
                   <h4 className="font-semibold text-sm">Methods</h4>
                   <div className="flex gap-2 mt-1">
                     <Badge variant="outline">Email/Password</Badge>
                     <Badge variant="outline">Magic Link</Badge>
                     <Badge variant="outline">SSO (Enterprise)</Badge>
                   </div>
                </div>
                <div>
                   <h4 className="font-semibold text-sm">Session Management</h4>
                   <p className="text-sm text-slate-600">Secure HttpOnly cookies / LocalStorage (depending on client config) with automatic token refresh.</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                   <Shield className="w-5 h-5 text-indigo-600" />
                   Authorization & RBAC
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                   <h4 className="font-semibold text-sm">Database Level (RLS)</h4>
                   <p className="text-sm text-slate-600">
                     Row Level Security policies enforce multi-tenancy.
                     <code className="block bg-slate-100 p-2 rounded mt-1 text-xs">
                       ((auth.role() = 'authenticated') AND (org_id = get_auth_org_id()))
                     </code>
                   </p>
                </div>
                <div>
                   <h4 className="font-semibold text-sm">Roles</h4>
                   <ul className="text-sm text-slate-600 list-disc pl-4 mt-1">
                     <li><strong>Owner:</strong> Full access + Billing + Deletion.</li>
                     <li><strong>Admin:</strong> User management + System config.</li>
                     <li><strong>Editor:</strong> Create/Edit models and assessments.</li>
                     <li><strong>Viewer:</strong> Read-only access to specific models.</li>
                     <li><strong>Auditor:</strong> Read-only access to compliance reports.</li>
                   </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* --- 4. COMPLIANCE --- */}
        <TabsContent value="compliance" className="space-y-6">
          <Card>
             <CardHeader>
               <CardTitle>Compliance Frameworks</CardTitle>
               <CardDescription>Implemented standards currently tracked by the system.</CardDescription>
             </CardHeader>
             <CardContent>
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                 {[
                   { name: "NIST CSF 2.0", desc: "National Institute of Standards and Technology" },
                   { name: "ISO/IEC 27001", desc: "Information Security Management" },
                   { name: "CIS Controls v8", desc: "Critical Security Controls" },
                   { name: "OWASP Top 10", desc: "Web Application Security Risks" },
                   { name: "RBI Cyber Security", desc: "Banking Framework (India)" },
                   { name: "DPDP Act 2023", desc: "Digital Personal Data Protection" }
                 ].map((fw, i) => (
                   <div key={i} className="flex items-start gap-3 p-3 border rounded-lg bg-slate-50">
                     <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
                     <div>
                       <div className="font-semibold text-sm">{fw.name}</div>
                       <div className="text-xs text-slate-500">{fw.desc}</div>
                     </div>
                   </div>
                 ))}
               </div>
             </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Reporting Capabilities</CardTitle>
            </CardHeader>
            <CardContent>
               <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                 <li className="flex items-center gap-2"><FileText className="w-4 h-4 text-slate-400"/> Executive Risk Summary (PDF)</li>
                 <li className="flex items-center gap-2"><FileText className="w-4 h-4 text-slate-400"/> Detailed Threat Assessment (CSV/PDF)</li>
                 <li className="flex items-center gap-2"><FileText className="w-4 h-4 text-slate-400"/> Compliance Gap Analysis</li>
                 <li className="flex items-center gap-2"><FileText className="w-4 h-4 text-slate-400"/> Audit Trail History Export</li>
                 <li className="flex items-center gap-2"><FileText className="w-4 h-4 text-slate-400"/> Financial Exposure (FAIR) Report</li>
               </ul>
            </CardContent>
          </Card>
        </TabsContent>

        {/* --- 5. INTEGRATIONS --- */}
        <TabsContent value="integrations" className="space-y-6">
           <Card>
             <CardHeader>
               <CardTitle>Third-Party & System Integrations</CardTitle>
             </CardHeader>
             <CardContent>
               <div className="space-y-4">
                 <IntegrationRow 
                   name="Supabase" 
                   type="Infrastructure" 
                   status="Active" 
                   desc="Provides Authentication, Database, Realtime subscriptions, and Edge Functions."
                 />
                 <IntegrationRow 
                   name="OpenAI (Simulated)" 
                   type="AI Service" 
                   status="Active" 
                   desc="Powers the 'AiSuggestions' engine for gap analysis and threat discovery."
                 />
                 <IntegrationRow 
                   name="Jira / GitHub" 
                   type="Issue Tracker" 
                   status="Configurable" 
                   desc="Data model supports pushing Mitigation Plans to external issue trackers."
                 />
                 <IntegrationRow 
                   name="SMTP / Email" 
                   type="Notification" 
                   status="Active" 
                   desc="Transactional emails for invites and approval requests."
                 />
               </div>
             </CardContent>
           </Card>
        </TabsContent>

      </Tabs>
    </div>
  );
};

const FeatureCard = ({ icon, title, features }) => (
  <Card className="h-full">
    <CardHeader className="pb-2">
      <CardTitle className="text-lg flex items-center gap-2">
        {icon} {title}
      </CardTitle>
    </CardHeader>
    <CardContent>
      <ul className="space-y-2">
        {features.map((f, i) => (
          <li key={i} className="text-sm text-slate-600 flex items-start gap-2">
            <span className="block w-1.5 h-1.5 rounded-full bg-slate-300 mt-1.5 shrink-0" />
            {f}
          </li>
        ))}
      </ul>
    </CardContent>
  </Card>
);

const SchemaGroup = ({ title, tables }) => (
  <div className="mb-6 last:mb-0">
    <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3 border-b pb-1">{title}</h3>
    <div className="grid grid-cols-1 gap-2">
      {tables.map((t, i) => (
        <div key={i} className="flex flex-col md:flex-row md:items-center justify-between p-2 rounded hover:bg-slate-50 border border-transparent hover:border-slate-100 transition-colors">
          <div className="font-mono text-sm text-brand-700 font-medium">{t.name}</div>
          <div className="text-xs text-slate-500 md:text-right">{t.desc}</div>
        </div>
      ))}
    </div>
  </div>
);

const IntegrationRow = ({ name, type, status, desc }) => (
  <div className="flex items-start justify-between p-3 border rounded-lg bg-white">
    <div>
      <div className="flex items-center gap-2">
        <span className="font-semibold text-sm">{name}</span>
        <Badge variant="secondary" className="text-[10px] h-5">{type}</Badge>
      </div>
      <p className="text-xs text-slate-500 mt-1">{desc}</p>
    </div>
    <Badge variant={status === 'Active' ? 'default' : 'outline'} className={status === 'Active' ? 'bg-green-600' : ''}>
      {status}
    </Badge>
  </div>
);

export default SystemDocumentation;
