
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/components/ui/use-toast';
import { 
  Building2, 
  MoreHorizontal, 
  Plus, 
  Search, 
  ShieldAlert, 
  Users, 
  Activity,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { adminService } from '@/services/adminService';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const TenantManagement = () => {
  const { profile, signOut } = useAuth();
  const { toast } = useToast();
  
  const [tenants, setTenants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [error, setError] = useState(null);

  // Authorization Check
  const isSiteOwner = profile?.role === 'Site Owner';

  const fetchTenants = async (isRefresh = false) => {
    if (!isSiteOwner) return;
    
    if (isRefresh) setRefreshing(true);
    else setLoading(true);
    setError(null);
    
    try {
      // 15s timeout to prevent infinite loading states
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timed out - Server took too long to respond')), 15000)
      );
      
      const fetchPromise = adminService.getAllOrganizations();
      const data = await Promise.race([fetchPromise, timeoutPromise]);
      
      setTenants(data || []);
    } catch (err) {
      console.error("Error fetching tenants:", err);
      const errorMessage = err.message || "Unknown error occurred";
      
      // Handle session errors specifically
      if (errorMessage.includes("session_not_found") || errorMessage.includes("JWT") || errorMessage.includes("refresh_token")) {
        setError("Your session has expired. Please log in again.");
        toast({
          title: "Session Expired",
          description: "Please log in again to continue.",
          variant: "destructive"
        });
        // Optional: Auto logout after a delay
        setTimeout(() => signOut(), 2000);
      } else {
        setError(errorMessage);
        toast({
          title: "Error loading data",
          description: `Could not retrieve tenant list: ${errorMessage}`,
          variant: "destructive"
        });
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (isSiteOwner) {
      fetchTenants();
    } else {
      setLoading(false);
    }
  }, [isSiteOwner]);

  const handleStatusChange = async (orgId, newStatus) => {
    try {
      await adminService.updateTenantStatus(orgId, newStatus);
      setTenants(prev => prev.map(t => t.id === orgId ? { ...t, status: newStatus } : t));
      toast({ title: "Status Updated", description: `Tenant is now ${newStatus}` });
    } catch (err) {
      toast({ title: "Update Failed", description: err.message, variant: "destructive" });
    }
  };

  if (!isSiteOwner) {
    return (
      <div className="p-8">
        <Alert variant="destructive">
          <ShieldAlert className="h-4 w-4" />
          <AlertTitle>Access Denied</AlertTitle>
          <AlertDescription>
            You do not have permission to view this page. Site Owner privileges are required.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const filteredTenants = tenants.filter(t => 
    t.name?.toLowerCase().includes(searchQuery.toLowerCase()) || 
    t.slug?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Tenant Management</h2>
          <p className="text-muted-foreground">Monitor and manage all customer organizations.</p>
        </div>
        <div className="flex items-center gap-2">
           <Button variant="outline" size="sm" onClick={() => fetchTenants(true)} disabled={loading || refreshing}>
            <RefreshCw className={`mr-2 h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
           </Button>
           <Button>
            <Plus className="mr-2 h-4 w-4" /> New Tenant
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Tenants</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tenants.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Subscriptions</CardTitle>
            <Activity className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {tenants.filter(t => t.status === 'Active').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {tenants.reduce((acc, t) => acc + (t.userCount || 0), 0)}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Organizations</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search tenants..." 
                className="pl-8" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {error ? (
             <div className="text-center py-8 text-red-500">
                <ShieldAlert className="mx-auto h-8 w-8 mb-2" />
                <p className="font-semibold">Failed to load tenants</p>
                <p className="text-sm opacity-90 mb-4">{error}</p>
                <Button variant="link" onClick={() => fetchTenants(true)}>Try Again</Button>
             </div>
          ) : loading && !refreshing ? (
             <div className="flex justify-center py-12">
               <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
             </div>
          ) : filteredTenants.length === 0 ? (
             <div className="text-center py-12 text-muted-foreground">
               No tenants found matching your search.
             </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Users</TableHead>
                  <TableHead>Owner</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTenants.map((tenant) => (
                  <TableRow key={tenant.id}>
                    <TableCell>
                      <div className="font-medium">{tenant.name}</div>
                      <div className="text-xs text-muted-foreground font-mono">{tenant.slug}</div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={
                        tenant.status === 'Active' ? 'default' : 
                        tenant.status === 'Suspended' ? 'destructive' : 'secondary'
                      }>
                        {tenant.status || 'Unknown'}
                      </Badge>
                    </TableCell>
                    <TableCell>{tenant.subscription_tier || 'Free'}</TableCell>
                    <TableCell>{tenant.userCount || 0}</TableCell>
                    <TableCell>
                      <div className="text-sm">{tenant.ownerName}</div>
                      <div className="text-xs text-muted-foreground">{tenant.ownerEmail}</div>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {new Date(tenant.created_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => window.location.href = `/dashboard/organization?id=${tenant.id}`}>
                            View Details
                          </DropdownMenuItem>
                          {tenant.status === 'Active' ? (
                            <DropdownMenuItem 
                              className="text-red-600"
                              onClick={() => handleStatusChange(tenant.id, 'Suspended')}
                            >
                              Suspend Tenant
                            </DropdownMenuItem>
                          ) : (
                            <DropdownMenuItem 
                              className="text-green-600"
                              onClick={() => handleStatusChange(tenant.id, 'Active')}
                            >
                              Activate Tenant
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default TenantManagement;
