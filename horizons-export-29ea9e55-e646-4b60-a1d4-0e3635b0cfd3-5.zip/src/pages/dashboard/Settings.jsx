
import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Save, Lock, Bell, Database, Shield, Zap, FileText } from 'lucide-react';

// Sections
import SystemDocumentation from './SystemDocumentation';
import NotificationSettings from './NotificationSettings';
import RegParser from './settings/RegParser';

// Services
import { bankingSeedingService } from '@/services/bankingSeedingService';

const Settings = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [seedingLoading, setSeedingLoading] = useState(false);

  const handleSave = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Settings Saved",
        description: "Your preferences have been updated successfully.",
      });
    }, 1000);
  };

  const handleSeedBankingData = async () => {
    setSeedingLoading(true);
    try {
        const results = await bankingSeedingService.seedBankingModels();
        toast({
            title: "Data Generation Complete",
            description: `Successfully created ${results.created} banking threat models with sample data. Check the "Threat Models" page.`,
            className: "bg-green-600 text-white"
        });
    } catch (e) {
        toast({
            title: "Generation Failed",
            description: e.message || "Could not generate sample data.",
            variant: "destructive"
        });
    } finally {
        setSeedingLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <Helmet>
        <title>Settings - CreativeCyber</title>
      </Helmet>

      <div>
        <h1 className="text-3xl font-bold text-slate-900">Settings</h1>
        <p className="text-slate-500 mt-2">Manage your account, preferences, and system configurations.</p>
      </div>

      <Tabs defaultValue="regparser" className="w-full">
        <TabsList className="grid w-full grid-cols-5 lg:w-[750px]">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="regparser">Reg Parser</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="data">Data & Demo</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>Update your personal details and public profile.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input id="name" defaultValue={user?.user_metadata?.full_name || 'User'} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" defaultValue={user?.email} disabled className="bg-slate-50" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="org">Organization</Label>
                <Input id="org" defaultValue="My Organization" />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSave} disabled={loading}>
                {loading ? 'Saving...' : <><Save className="w-4 h-4 mr-2" /> Save Changes</>}
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>Customize the look and feel of the platform.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Dark Mode</Label>
                  <p className="text-sm text-slate-500">Enable dark mode for the interface.</p>
                </div>
                <Switch disabled />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Compact View</Label>
                  <p className="text-sm text-slate-500">Reduce whitespace in tables and lists.</p>
                </div>
                <Switch />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="mt-6">
           <Card>
            <CardHeader>
              <CardTitle>Password & Authentication</CardTitle>
              <CardDescription>Manage your password and security settings.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current">Current Password</Label>
                <Input id="current" type="password" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="new">New Password</Label>
                  <Input id="new" type="password" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirm">Confirm Password</Label>
                  <Input id="confirm" type="password" />
                </div>
              </div>
              <div className="flex items-center justify-between pt-4 border-t">
                  <div className="space-y-0.5">
                      <Label>Two-Factor Authentication</Label>
                      <p className="text-sm text-slate-500">Add an extra layer of security to your account.</p>
                  </div>
                  <Button variant="outline" size="sm">Enable 2FA</Button>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSave} disabled={loading}>
                <Lock className="w-4 h-4 mr-2" /> Update Password
              </Button>
            </CardFooter>
           </Card>
        </TabsContent>

        <TabsContent value="regparser" className="mt-6 h-[600px]">
            <RegParser />
        </TabsContent>

        <TabsContent value="notifications" className="mt-6">
            <NotificationSettings />
        </TabsContent>

        <TabsContent value="data" className="mt-6 space-y-6">
            <Card className="border-brand-200 bg-brand-50/20">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-brand-800">
                        <Zap className="w-5 h-5" />
                        Demo Data Generation
                    </CardTitle>
                    <CardDescription>
                        Populate your workspace with realistic banking threat models, controls, and risks for demonstration purposes.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="text-sm text-slate-600 mb-4">
                        This will create 7 comprehensive threat models covering Digital Banking, CBS, Payments, AI, and more.
                        Each model will be populated with:
                        <ul className="list-disc pl-5 mt-2 space-y-1">
                            <li>Architecture diagrams (Elements & Flows)</li>
                            <li>8-10 Realistic threats per model</li>
                            <li>Risk calculations (Loss magnitude, TEF)</li>
                            <li>Mapped Internal Controls</li>
                        </ul>
                    </div>
                    <Button 
                        onClick={handleSeedBankingData} 
                        disabled={seedingLoading}
                        className="bg-brand-600 hover:bg-brand-700 w-full sm:w-auto"
                    >
                        {seedingLoading ? 'Generating Data...' : <><Database className="w-4 h-4 mr-2" /> Generate Banking Sample Models</>}
                    </Button>
                </CardContent>
            </Card>

            <SystemDocumentation />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
