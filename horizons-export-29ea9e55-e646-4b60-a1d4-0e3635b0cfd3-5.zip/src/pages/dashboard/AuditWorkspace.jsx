
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Shield, FileCheck, History, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

export default function AuditWorkspace() {
  return (
    <div className="space-y-6">
       <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Audit Workspace</h1>
            <p className="text-slate-500 mt-1">Manage internal controls, compliance evidence, and audit trails.</p>
          </div>
          <Button className="bg-blue-600 hover:bg-blue-700">
             <Shield className="mr-2 h-4 w-4" /> New Audit
          </Button>
       </div>

       <Tabs defaultValue="active" className="w-full">
          <div className="flex items-center justify-between mb-4">
            <TabsList>
              <TabsTrigger value="active">Active Audits</TabsTrigger>
              <TabsTrigger value="planned">Planned</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>
            <div className="relative w-64 hidden md:block">
               <Search className="absolute left-2 top-2.5 h-4 w-4 text-slate-400" />
               <Input placeholder="Search audits..." className="pl-8" />
            </div>
          </div>

          <TabsContent value="active" className="space-y-4">
             <Card>
               <CardHeader>
                 <CardTitle className="text-lg flex items-center gap-2">
                    <FileCheck className="h-5 w-5 text-blue-600" />
                    SOC2 Type II Readiness
                 </CardTitle>
                 <CardDescription>Quarterly review of security controls</CardDescription>
               </CardHeader>
               <CardContent>
                  <div className="flex items-center gap-4 text-sm text-slate-600">
                     <div className="flex flex-col">
                        <span className="font-semibold text-slate-900">45%</span>
                        <span>Complete</span>
                     </div>
                     <div className="h-8 w-px bg-slate-200" />
                     <div className="flex flex-col">
                        <span className="font-semibold text-slate-900">12</span>
                        <span>Open Findings</span>
                     </div>
                     <div className="h-8 w-px bg-slate-200" />
                     <div className="flex flex-col">
                        <span className="font-semibold text-slate-900">Oct 25</span>
                        <span>Due Date</span>
                     </div>
                  </div>
                  <div className="mt-4 w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                     <div className="bg-blue-600 h-full w-[45%]" />
                  </div>
               </CardContent>
             </Card>

             <Card>
               <CardHeader>
                 <CardTitle className="text-lg flex items-center gap-2">
                    <FileCheck className="h-5 w-5 text-indigo-600" />
                    ISO 27001 Internal Audit
                 </CardTitle>
                 <CardDescription>Annual surveillance audit preparation</CardDescription>
               </CardHeader>
               <CardContent>
                  <div className="flex items-center gap-4 text-sm text-slate-600">
                     <div className="flex flex-col">
                        <span className="font-semibold text-slate-900">10%</span>
                        <span>Complete</span>
                     </div>
                     <div className="h-8 w-px bg-slate-200" />
                     <div className="flex flex-col">
                        <span className="font-semibold text-slate-900">0</span>
                        <span>Open Findings</span>
                     </div>
                     <div className="h-8 w-px bg-slate-200" />
                     <div className="flex flex-col">
                        <span className="font-semibold text-slate-900">Nov 15</span>
                        <span>Due Date</span>
                     </div>
                  </div>
                  <div className="mt-4 w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                     <div className="bg-indigo-600 h-full w-[10%]" />
                  </div>
               </CardContent>
             </Card>
          </TabsContent>

          <TabsContent value="planned">
             <div className="flex flex-col items-center justify-center py-12 text-slate-500 bg-slate-50 rounded-lg border border-dashed">
                <History className="h-10 w-10 mb-3 opacity-20" />
                <p>No planned audits scheduled for next quarter.</p>
                <Button variant="link">Schedule Audit</Button>
             </div>
          </TabsContent>
          
          <TabsContent value="history">
             <div className="flex flex-col items-center justify-center py-12 text-slate-500 bg-slate-50 rounded-lg border border-dashed">
                <p>Audit history archive is empty.</p>
             </div>
          </TabsContent>
       </Tabs>
    </div>
  );
}
