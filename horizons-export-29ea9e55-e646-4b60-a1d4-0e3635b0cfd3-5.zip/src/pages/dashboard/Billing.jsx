
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { 
  CreditCard, Calendar, CheckCircle, Download, FileText, 
  AlertCircle, Clock, ShieldCheck, RefreshCw, AlertTriangle, ArrowRightLeft
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/components/ui/use-toast';
import { billingService } from '@/services/billingService';
import { formatCurrency, exportToCSV } from '@/utils/exportUtils';
import { format } from 'date-fns';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';

const Billing = () => {
  const [subscription, setSubscription] = useState(null);
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Modals state
  const [isSwitchOpen, setIsSwitchOpen] = useState(false);
  const [isCancelOpen, setIsCancelOpen] = useState(false);
  const [consentSwitch, setConsentSwitch] = useState(false);
  const [consentCancel, setConsentCancel] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [cancelReason, setCancelReason] = useState("");

  const { toast } = useToast();

  useEffect(() => {
    loadBillingData();
  }, []);

  const loadBillingData = async () => {
    try {
      setLoading(true);
      const [subData, invData] = await Promise.all([
        billingService.getSubscriptionDetails(),
        billingService.getBillingHistory()
      ]);
      setSubscription(subData);
      setInvoices(invData);
    } catch (error) {
      console.error("Billing load error:", error);
      toast({
        title: "Error loading billing data",
        description: "Could not fetch subscription details.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadInvoice = async (invoice, format) => {
    toast({ title: "Downloading...", description: `Preparing invoice ${invoice.id}` });
    try {
      await billingService.downloadInvoice(invoice.id, format);
      if (format === 'csv') exportToCSV([invoice], `invoice_${invoice.id}`);
      else toast({ title: "Success", description: "Invoice downloaded." });
    } catch (e) {
      toast({ title: "Failed", variant: "destructive" });
    }
  };

  const handleSwitchPlan = async () => {
    if (!consentSwitch) return;
    setProcessing(true);
    try {
      const currentInterval = subscription?.plan?.interval || 'month';
      await billingService.switchPlan(currentInterval);
      
      toast({
        title: "Plan Switched Successfully",
        description: `You have switched to the ${currentInterval === 'month' ? 'Annual' : 'Monthly'} plan. A confirmation email has been sent.`,
        className: "bg-green-50 border-green-200 text-green-900"
      });
      setIsSwitchOpen(false);
      setConsentSwitch(false);
      
      // Reload data to reflect changes (mock update)
      const updatedSub = { ...subscription };
      if (currentInterval === 'month') {
        updatedSub.plan.interval = 'year';
        updatedSub.billingPeriod = 'Yearly';
        updatedSub.plan.price = 500000;
      } else {
        updatedSub.plan.interval = 'month';
        updatedSub.billingPeriod = 'Monthly';
        updatedSub.plan.price = 50000;
      }
      setSubscription(updatedSub);

    } catch (error) {
      toast({ title: "Switch Failed", description: error.message, variant: "destructive" });
    } finally {
      setProcessing(false);
    }
  };

  const handleCancelPlan = async () => {
    if (!consentCancel) return;
    setProcessing(true);
    try {
      await billingService.cancelPlan(cancelReason || "No reason provided");
      
      toast({
        title: "Subscription Cancelled",
        description: "Your plan has been cancelled. Confirmation email sent.",
        variant: "destructive"
      });
      setIsCancelOpen(false);
      setConsentCancel(false);
      
      setSubscription(prev => ({ ...prev, status: 'cancelled' }));
    } catch (error) {
      toast({ title: "Cancellation Failed", description: error.message, variant: "destructive" });
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-[500px] items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-600"></div>
      </div>
    );
  }

  // Derive Plan Details for Modal
  const isMonthly = subscription?.plan?.interval === 'month';
  const currentPrice = isMonthly ? 50000 : 500000;
  const targetPlanName = isMonthly ? "Annual Plan" : "Monthly Plan";
  const targetPrice = isMonthly ? 500000 : 50000;
  const savingText = isMonthly ? "Save ₹1,00,000 per year!" : "";
  const effectiveDate = format(new Date(), 'MMMM d, yyyy');

  return (
    <div className="space-y-8 pb-8">
      <Helmet>
        <title>Billing & Subscription | CreativeCyber</title>
      </Helmet>

      <div>
        <h1 className="text-3xl font-bold text-slate-900">Billing & Subscription</h1>
        <p className="text-slate-500 mt-1">Manage your plan, billing cycle, and view history.</p>
      </div>

      <div className="grid grid-cols-1 gap-6"> 
        {/* Current Plan Card */}
        <Card className={`lg:col-span-3 border-l-4 shadow-sm ${subscription?.status === 'cancelled' ? 'border-l-slate-400 opacity-75' : 'border-l-brand-500'}`}>
          <CardHeader>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <CardTitle className="text-xl">Current Plan</CardTitle>
                <CardDescription>Your subscription status and renewal info</CardDescription>
              </div>
              <div className="flex items-center gap-4">
                <Badge className={`${subscription?.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-700'} hover:bg-opacity-80 border-transparent uppercase`}>
                  {subscription?.status}
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-8">
              <div className="flex-1">
                <h3 className="text-3xl font-bold text-slate-900 mb-2">{subscription?.plan.name}</h3>
                <div className="flex items-baseline gap-1 text-slate-600 mb-6">
                  <span className="text-3xl font-bold text-slate-900 font-mono tracking-tight">
                    {formatCurrency(currentPrice)}
                  </span>
                  <span className="text-sm font-medium text-slate-500">
                    /{isMonthly ? 'month' : 'year'}
                  </span>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Calendar className="w-4 h-4 text-brand-500" />
                    <span>Started: <span className="font-medium text-slate-900">{format(new Date(subscription?.startDate), 'MMMM d, yyyy')}</span></span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Clock className="w-4 h-4 text-brand-500" />
                    <span>Next Billing: <span className="font-medium text-slate-900">{format(new Date(subscription?.nextBillingDate), 'MMMM d, yyyy')}</span></span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <RefreshCw className="w-4 h-4 text-brand-500" />
                    <span>Current Cycle: <span className="font-medium text-slate-900">{subscription?.billingPeriod || 'Monthly'}</span></span>
                  </div>
                </div>
              </div>

              <div className="flex-1 bg-slate-50 rounded-lg p-5 border border-slate-100">
                <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-brand-600" /> Plan Features
                </h4>
                <ul className="space-y-2">
                  {subscription?.plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                      <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
          
          {subscription?.status === 'active' && (
            <CardFooter className="bg-slate-50/50 border-t flex flex-col sm:flex-row justify-end gap-3 py-4">
              
              {/* Cancel Plan Button & Modal */}
              <Dialog open={isCancelOpen} onOpenChange={setIsCancelOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-100">
                    Cancel Plan
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2 text-red-600">
                      <AlertTriangle className="h-5 w-5" /> Cancel Subscription
                    </DialogTitle>
                    <DialogDescription>
                      Are you sure you want to cancel your subscription? You will lose access to premium features at the end of your current billing cycle.
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="py-4 space-y-4">
                    <div className="bg-red-50 p-3 rounded-md border border-red-100 text-sm text-red-800">
                      <strong>Warning:</strong> Cancellation is final. We do not offer refunds for partial billing periods. Your data will be retained for 30 days before deletion.
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Reason for cancellation (Optional)</Label>
                      <Input 
                        placeholder="Tell us why you're leaving..." 
                        value={cancelReason}
                        onChange={(e) => setCancelReason(e.target.value)}
                      />
                    </div>

                    <div className="flex items-center space-x-2 pt-2">
                      <Checkbox 
                        id="cancel-consent" 
                        checked={consentCancel} 
                        onCheckedChange={setConsentCancel}
                      />
                      <Label htmlFor="cancel-consent" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        I confirm plan cancellation and understand the policy.
                      </Label>
                    </div>
                  </div>

                  <DialogFooter>
                    <Button variant="ghost" onClick={() => setIsCancelOpen(false)}>Keep Plan</Button>
                    <Button 
                      variant="destructive" 
                      onClick={handleCancelPlan}
                      disabled={!consentCancel || processing}
                    >
                      {processing ? "Processing..." : "Confirm Cancellation"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              {/* Switch Plan Button & Modal */}
              <Dialog open={isSwitchOpen} onOpenChange={setIsSwitchOpen}>
                <DialogTrigger asChild>
                  <Button>
                     <ArrowRightLeft className="w-4 h-4 mr-2" />
                     {isMonthly ? 'Switch to Annual Plan' : 'Switch to Monthly Plan'}
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Switch to {targetPlanName}</DialogTitle>
                    <DialogDescription>
                      Review the changes to your billing cycle below.
                    </DialogDescription>
                  </DialogHeader>

                  <div className="py-4 space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div className="p-3 bg-slate-50 rounded-lg border">
                        <div className="text-xs text-slate-500 uppercase font-semibold">Current</div>
                        <div className="font-bold text-slate-900 mt-1">{formatCurrency(currentPrice)}</div>
                        <div className="text-xs text-slate-500">/{isMonthly ? 'month' : 'year'}</div>
                      </div>
                      <div className="flex items-center justify-center">
                        <ArrowRightLeft className="text-slate-300" />
                      </div>
                      <div className="p-3 bg-brand-50 rounded-lg border border-brand-100 col-start-2 row-start-1">
                        <div className="text-xs text-brand-600 uppercase font-semibold">New</div>
                        <div className="font-bold text-brand-900 mt-1">{formatCurrency(targetPrice)}</div>
                        <div className="text-xs text-brand-600">/{isMonthly ? 'year' : 'month'}</div>
                      </div>
                    </div>

                    {savingText && (
                      <div className="flex items-center gap-2 text-green-700 bg-green-50 p-2 rounded text-sm font-medium justify-center">
                        <CheckCircle className="w-4 h-4" /> {savingText}
                      </div>
                    )}

                    <div className="text-sm text-slate-600 bg-slate-50 p-3 rounded">
                      <p><strong>Effective Date:</strong> {effectiveDate}</p>
                      <p className="mt-1">The prorated amount will be charged/credited to your payment method immediately.</p>
                    </div>

                    <div className="flex items-start space-x-2 pt-2">
                      <Checkbox 
                        id="switch-consent" 
                        checked={consentSwitch} 
                        onCheckedChange={setConsentSwitch}
                        className="mt-1"
                      />
                      <Label htmlFor="switch-consent" className="text-sm font-medium leading-tight peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        I confirm switching from {isMonthly ? 'Monthly' : 'Annual'} ({formatCurrency(currentPrice)}) to {targetPlanName} ({formatCurrency(targetPrice)}).
                      </Label>
                    </div>
                  </div>

                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsSwitchOpen(false)}>Cancel</Button>
                    <Button 
                      onClick={handleSwitchPlan}
                      disabled={!consentSwitch || processing}
                    >
                       {processing ? "Processing..." : "Confirm Switch"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

            </CardFooter>
          )}
        </Card>
      </div>

      {/* Billing History */}
      <Card>
        <CardHeader>
          <CardTitle>Billing History</CardTitle>
          <CardDescription>View and download your past invoices</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice ID</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Billing Period</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoices.map((invoice) => (
                <TableRow key={invoice.id}>
                  <TableCell className="font-mono text-xs font-medium text-slate-600">{invoice.id}</TableCell>
                  <TableCell>{format(new Date(invoice.date), 'MMM d, yyyy')}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="bg-slate-50">
                      {invoice.billingPeriod || 'Monthly'}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-mono font-medium">{formatCurrency(invoice.amount)}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      {invoice.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-8 px-2 text-slate-500 hover:text-brand-600"
                        onClick={() => handleDownloadInvoice(invoice, 'pdf')}
                        title="Download PDF"
                      >
                        <FileText className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-8 px-2 text-slate-500 hover:text-brand-600"
                        onClick={() => handleDownloadInvoice(invoice, 'csv')}
                        title="Download CSV"
                      >
                         <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Billing;
