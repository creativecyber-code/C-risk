
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, XCircle, AlertTriangle, Clock } from 'lucide-react';
import { exportUtils } from '@/utils/exportUtils';
import { Button } from '@/components/ui/button';

// Static test data as requested
const TEST_DATA = [
  { id: 1, name: 'Auth Service: Login Latency', status: 'PASS', duration: '45ms', suite: 'Performance', timestamp: '2 mins ago' },
  { id: 2, name: 'API Gateway: Rate Limiting', status: 'PASS', duration: '120ms', suite: 'Security', timestamp: '5 mins ago' },
  { id: 3, name: 'DB: SQL Injection Check', status: 'PASS', duration: '210ms', suite: 'Security', timestamp: '10 mins ago' },
  { id: 4, name: 'Payment: Transaction Rollback', status: 'FAIL', duration: '500ms', suite: 'Reliability', timestamp: '15 mins ago', error: 'Transaction timeout' },
  { id: 5, name: 'User Profile: XSS Validation', status: 'PASS', duration: '35ms', suite: 'Security', timestamp: '20 mins ago' },
  { id: 6, name: 'Session Management: Timeout', status: 'WARN', duration: '850ms', suite: 'Compliance', timestamp: '25 mins ago', error: 'Near threshold' },
];

const TestMonitoring = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Test Monitoring</h1>
          <p className="text-muted-foreground">Automated verification of security and reliability controls.</p>
        </div>
        <Button variant="outline" onClick={() => exportUtils.downloadJSON(TEST_DATA, 'test_report')}>
          Export Report
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="bg-green-50 border-green-200">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-900">Passing Tests</p>
                <div className="text-3xl font-bold text-green-700">83%</div>
              </div>
              <CheckCircle2 className="h-8 w-8 text-green-600 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-red-50 border-red-200">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-red-900">Critical Failures</p>
                <div className="text-3xl font-bold text-red-700">1</div>
              </div>
              <XCircle className="h-8 w-8 text-red-600 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-900">Avg Duration</p>
                <div className="text-3xl font-bold text-blue-700">293ms</div>
              </div>
              <Clock className="h-8 w-8 text-blue-600 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Test Runs</CardTitle>
          <CardDescription>Live feed of automated test execution results.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-1">
            {TEST_DATA.map((test) => (
              <div key={test.id} className="flex items-center justify-between p-4 hover:bg-slate-50 border-b last:border-0 transition-colors">
                <div className="flex items-center gap-4">
                  {test.status === 'PASS' && <CheckCircle2 className="h-5 w-5 text-green-500" />}
                  {test.status === 'FAIL' && <XCircle className="h-5 w-5 text-red-500" />}
                  {test.status === 'WARN' && <AlertTriangle className="h-5 w-5 text-orange-500" />}
                  
                  <div>
                    <div className="font-medium text-sm text-slate-900">{test.name}</div>
                    <div className="text-xs text-muted-foreground flex gap-2">
                       <span>{test.suite}</span>
                       <span>•</span>
                       <span>{test.timestamp}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 text-right">
                  {test.error && (
                    <span className="text-xs text-red-600 bg-red-50 px-2 py-1 rounded hidden md:inline-block">
                      {test.error}
                    </span>
                  )}
                  <div className="text-sm font-mono text-slate-500 w-16 text-right">
                    {test.duration}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TestMonitoring;
