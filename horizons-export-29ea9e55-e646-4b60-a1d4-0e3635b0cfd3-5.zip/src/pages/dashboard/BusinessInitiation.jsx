
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Helmet } from 'react-helmet-async';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { ArrowLeft, Plus, RefreshCw, FileText, CheckCircle2, AlertTriangle, Play } from 'lucide-react';
import { cRiskService } from '@/services/cRiskService';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';

// C-RISK Modules
import BusinessIntake from '@/components/c-risk/BusinessIntake';
import DataClassification from '@/components/c-risk/DataClassification';
import InherentRiskAssessment from '@/components/c-risk/InherentRiskAssessment';
import SecurityGating from '@/components/c-risk/SecurityGating';
import DynamicRiskQuestionnaire from '@/components/c-risk/DynamicRiskQuestionnaire'; 
import RiskAssessmentSummary from '@/components/c-risk/RiskAssessmentSummary';
import InitiativeComplianceDashboard from '@/components/business/InitiativeComplianceDashboard'; 

const BusinessInitiation = () => {
  const { user, profile, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(false);
  
  // Centralized Application State
  const [currentAppId, setCurrentAppId] = useState(null); 
  const [currentAppData, setCurrentAppData] = useState(null); 
  
  const [gates, setGates] = useState([]);
  const [regulatoryMap, setRegulatoryMap] = useState([]);
  
  const [validationState, setValidationState] = useState({
    dimensionsCompleted: false,
    fairCompleted: false,
    questionnaireCompleted: false
  });

  const [questionnaireSummary, setQuestionnaireSummary] = useState(null);
  const [applications, setApplications] = useState([]);
  const [loadingApps, setLoadingApps] = useState(false);
  
  const isMounted = useRef(false);
  const orgId = profile?.org_id;

  // Debugging Hook
  useEffect(() => {
    if (currentAppData) {
      console.log("APP STATE DEBUG:", {
        id: currentAppId,
        riskLevel: currentAppData.inherent_risk_level,
        status: currentAppData.status,
        stage: currentAppData.stage
      });
    }
  }, [currentAppData, currentAppId]);

  const fetchApplications = useCallback(async () => {
    if (!orgId) return;
    setLoadingApps(true);
    try {
      const data = await cRiskService.getApplications(orgId);
      if (isMounted.current) {
        setApplications(data || []);
      }
    } catch (error) {
      if (isMounted.current) {
        toast({ title: "Connection Error", description: "Failed to load applications.", variant: "destructive" });
      }
    } finally {
      if (isMounted.current) {
        setLoadingApps(false);
      }
    }
  }, [orgId, toast]);

  useEffect(() => {
    isMounted.current = true;
    if (orgId && activeTab === 'dashboard') {
      fetchApplications();
    }
    return () => { isMounted.current = false; };
  }, [orgId, activeTab, fetchApplications]);

  if (authLoading) {
     return <div className="p-8 space-y-4"><Skeleton className="h-12 w-64"/><Skeleton className="h-64 w-full"/></div>;
  }

  if (!user) return <div className="p-8">Please log in to continue.</div>;

  const handleCreateApplication = async (data) => {
    if (!orgId) {
      toast({ title: "Organization Missing", description: "Your user profile is not linked to an organization.", variant: "destructive" });
      return;
    }

    setLoading(true);
    try {
      const newApp = await cRiskService.createApplication(data, user.id, orgId);
      setCurrentAppId(newApp.id);
      setCurrentAppData(newApp); 
      
      toast({ title: "Application Created", description: "Proceeding to data classification." });
      setActiveTab('classification');
      
      const appDetails = await cRiskService.getApplication(newApp.id);
      setGates(appDetails.security_gates || []);
      
      fetchApplications();
    } catch (e) {
      console.error(e);
      toast({ title: "Error", description: e.message || "Failed to create application", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleClassificationSave = async (data) => {
    try {
      const mappings = await cRiskService.getRegulatoryMappings(data.dataTypes);
      setRegulatoryMap(mappings);
      toast({ title: "Classification Saved", description: "Regulatory mappings updated." });
      setActiveTab('risk');
    } catch(e) {
      toast({ title: "Error", description: "Failed to update classification.", variant: "destructive" });
    }
  };

  const handleRiskSave = (data) => {
    setValidationState(prev => ({
        ...prev,
        dimensionsCompleted: true,
        fairCompleted: true
    }));
    
    // CRITICAL FIX: Ensure inherent risk is captured from assessment
    const newRiskLevel = data.risk_label || 'Low';
    
    console.log("Risk Assessment Complete. Calculated Level:", newRiskLevel);

    // Update local state immediately
    setCurrentAppData(prev => ({
       ...prev,
       inherent_risk_level: newRiskLevel,
       risk_level: newRiskLevel // Legacy support
    }));

    toast({ title: "Risk Dimensions Saved", description: `Risk Level: ${newRiskLevel} (Score: ${data.overall_score})` });
    
    // Auto-navigate to questionnaire
    setActiveTab('questionnaire');
  };

  const handleQuestionnaireComplete = (summary) => {
     setQuestionnaireSummary(summary);
     setValidationState(prev => ({
        ...prev,
        questionnaireCompleted: true
     }));
     console.log("Questionnaire Completed:", summary);
     toast({ title: "Questionnaire Submitted", description: "Risk Assessment phase complete." });
     setActiveTab('gating');
  };

  const handleGateUpdate = (id, status) => {
    setGates(prev => prev.map(g => g.id === id ? { ...g, status } : g));
    toast({ title: "Gate Updated", description: "Status changed successfully." });
    
    cRiskService.updateGateStatus(id, status, user.id)
       .catch(err => {
          console.error("Failed to persist gate update", err);
          toast({ title: "Sync Error", description: "Could not save gate status.", variant: "destructive" });
       });
  };

  const handleDeployment = async (appId) => {
    try {
       await cRiskService.approveApplication(appId);
       
       toast({
         title: "Deployment Approved",
         description: "Application is now LIVE in production.",
         variant: "default"
       });
       
       setTimeout(() => {
          setCurrentAppId(null);
          setCurrentAppData(null);
          setQuestionnaireSummary(null);
          setValidationState({dimensionsCompleted:false, fairCompleted:false, questionnaireCompleted:false});
          setActiveTab('dashboard'); 
          fetchApplications(); 
       }, 500);

    } catch (err) {
       console.error("Deployment Error:", err);
       toast({
         title: "Error",
         description: "Failed to process deployment approval.",
         variant: "destructive"
       });
    }
  };

  const handleContinueApp = async (app) => {
    setCurrentAppId(app.id);
    setCurrentAppData(app);
    
    try {
       const details = await cRiskService.getApplication(app.id);
       setGates(details.security_gates || []);
       
       if (app.stage === 'PRODUCTION' || app.status === 'Approved') {
           setValidationState({dimensionsCompleted:true, fairCompleted:true, questionnaireCompleted:true});
           setActiveTab('gating'); 
       } else if (app.stage === 'INTAKE') {
           setActiveTab('classification');
       } else if (app.status === 'Under Review') {
           setActiveTab('risk');
       } else {
           setActiveTab('gating');
       }
       
    } catch (e) {
       toast({ title: "Error", description: "Could not load application details." });
    }
  };

  // Safe accessor for Risk Level
  const getRiskLevel = () => {
    return currentAppData?.inherent_risk_level || currentAppData?.risk_level || 'Medium';
  };

  return (
    <div className="space-y-6 pb-20">
      <Helmet>
        <title>C-RISK Platform | Business Initiation</title>
      </Helmet>

      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Business Initiative & Risk</h1>
          <p className="text-muted-foreground mt-2">
            End-to-end lifecycle management for new technology initiatives.
          </p>
        </div>
        <div className="flex gap-2">
          {activeTab !== 'dashboard' && activeTab !== 'compliance' && (
            <Button variant="outline" onClick={() => setActiveTab('dashboard')}>
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to List
            </Button>
          )}
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <div className="border-b bg-white px-4 pt-2 shadow-sm rounded-lg overflow-hidden">
          <TabsList className="bg-transparent h-auto p-0 space-x-6 overflow-x-auto w-full justify-start no-scrollbar">
            <TabTriggerItem value="dashboard" label="Portfolio" />
            <TabTriggerItem value="intake" label="1. Intake" />
            <TabTriggerItem value="classification" label="2. Classification" disabled={!currentAppId && activeTab !== 'intake'} />
            <TabTriggerItem value="risk" label="3. Risk Assessment" disabled={!currentAppId && activeTab !== 'risk'} />
            <TabTriggerItem value="questionnaire" label="4. Questionnaire" disabled={!currentAppId && activeTab !== 'questionnaire'} />
            <TabTriggerItem value="gating" label="5. Security Gates" disabled={!currentAppId && activeTab !== 'gating'} />
            <TabTriggerItem value="compliance" label="7. Initiative Compliance" />
          </TabsList>
        </div>

        <TabsContent value="dashboard" className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          
          <div className="flex justify-between items-center">
             <h2 className="text-xl font-semibold">Active Initiatives</h2>
             <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={fetchApplications} disabled={loadingApps}>
                   <RefreshCw className={`h-4 w-4 mr-2 ${loadingApps ? 'animate-spin' : ''}`} />
                   Refresh
                </Button>
                <Button onClick={() => { setCurrentAppId(null); setActiveTab('intake'); }}>
                   <Plus className="h-4 w-4 mr-2" /> New Initiative
                </Button>
             </div>
          </div>

          <Card>
            <CardContent className="p-0">
               <Table>
                  <TableHeader>
                     <TableRow>
                        <TableHead>Application Name</TableHead>
                        <TableHead>Business Unit</TableHead>
                        <TableHead>Stage</TableHead>
                        <TableHead>Risk Level</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                     </TableRow>
                  </TableHeader>
                  <TableBody>
                     {loadingApps ? (
                        [1,2,3].map(i => (
                           <TableRow key={i}>
                              <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                              <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                              <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                              <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                              <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                              <TableCell><Skeleton className="h-8 w-20 float-right" /></TableCell>
                           </TableRow>
                        ))
                     ) : applications.length === 0 ? (
                        <TableRow>
                           <TableCell colSpan={6} className="text-center h-32 text-muted-foreground">
                              No active initiatives found. Click "New Initiative" to start.
                           </TableCell>
                        </TableRow>
                     ) : (
                        applications.map((app) => (
                           <TableRow key={app.id}>
                              <TableCell className="font-medium">
                                 <div className="flex items-center gap-2">
                                    <FileText className="h-4 w-4 text-slate-400" />
                                    {app.name}
                                 </div>
                              </TableCell>
                              <TableCell>{app.business_unit}</TableCell>
                              <TableCell>
                                 <Badge variant="outline" className="font-mono text-xs">
                                    {app.stage || 'INTAKE'}
                                 </Badge>
                              </TableCell>
                              <TableCell>
                                 <Badge variant={
                                    app.inherent_risk_level === 'Critical' ? 'destructive' :
                                    app.inherent_risk_level === 'High' ? 'destructive' :
                                    app.inherent_risk_level === 'Medium' ? 'default' : 'secondary'
                                 }>
                                    {app.inherent_risk_level}
                                 </Badge>
                              </TableCell>
                              <TableCell>
                                 {app.status === 'Approved' ? (
                                    <div className="flex items-center text-green-600 text-sm font-medium">
                                       <CheckCircle2 className="h-4 w-4 mr-1.5" /> Live
                                    </div>
                                 ) : (
                                    <div className="flex items-center text-amber-600 text-sm">
                                       <AlertTriangle className="h-4 w-4 mr-1.5" /> {app.status || 'Draft'}
                                    </div>
                                 )}
                              </TableCell>
                              <TableCell className="text-right">
                                 <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="hover:bg-blue-50 hover:text-blue-700"
                                    onClick={() => handleContinueApp(app)}
                                 >
                                    {app.status === 'Approved' ? 'View Details' : 'Continue'} <ArrowLeft className="h-4 w-4 ml-2 rotate-180" />
                                 </Button>
                              </TableCell>
                           </TableRow>
                        ))
                     )}
                  </TableBody>
               </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="intake" className="animate-in fade-in slide-in-from-right-4 duration-300">
          <BusinessIntake onSave={handleCreateApplication} userOrgId={orgId} />
        </TabsContent>

        <TabsContent value="classification" className="animate-in fade-in slide-in-from-right-4 duration-300">
          <DataClassification onSave={handleClassificationSave} appId={currentAppId} />
        </TabsContent>

        <TabsContent value="risk" className="animate-in fade-in slide-in-from-right-4 duration-300">
          <InherentRiskAssessment 
             onSave={handleRiskSave} 
             appId={currentAppId} 
             // Pass initial values if reloading existing app
             initialScores={currentAppData?.risk_dimensions}
             initialFAIR={currentAppData?.quantitative_ale}
          />
        </TabsContent>

        <TabsContent value="questionnaire" className="animate-in fade-in slide-in-from-right-4 duration-300">
           {/* Pass getRiskLevel() result to ensure we use latest state */}
           <DynamicRiskQuestionnaire 
             riskLevel={getRiskLevel()} 
             onComplete={handleQuestionnaireComplete}
           />
        </TabsContent>

        <TabsContent value="gating" className="animate-in fade-in slide-in-from-right-4 duration-300">
           <div className="space-y-8">
              <RiskAssessmentSummary 
                 appData={currentAppData} 
                 questionnaireSummary={questionnaireSummary} 
              />
              <SecurityGating 
                 gates={gates} 
                 onUpdateStatus={handleGateUpdate} 
                 onDeploy={handleDeployment}
                 appId={currentAppId} 
                 validationState={validationState} 
                 riskLevel={getRiskLevel()}
              />
           </div>
        </TabsContent>

        <TabsContent value="compliance" className="animate-in fade-in slide-in-from-right-4 duration-300">
           <InitiativeComplianceDashboard orgId={orgId} />
        </TabsContent>

      </Tabs>
    </div>
  );
};

const TabTriggerItem = ({ value, label, disabled }) => (
  <TabsTrigger 
    value={value}
    disabled={disabled}
    className="data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:shadow-none rounded-none px-2 py-3 text-sm font-medium text-slate-500 hover:text-slate-700 data-[state=active]:text-blue-600 disabled:opacity-50 transition-all"
  >
    {label}
  </TabsTrigger>
);

export default BusinessInitiation;
