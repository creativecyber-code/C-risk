
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { 
  Building2, Plus, MoreHorizontal, Shield, User, Globe, 
  Search, RefreshCw, Loader2, CheckCircle, XCircle 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from '@/components/ui/use-toast';
import { adminService } from '@/services/adminService';

const PlatformTenantManagement = () => {
  const { toast } = useToast();
  const [tenants, setTenants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    adminEmail: '',
    tier: 'Free',
    region: 'US-East'
  });

  const fetchTenants = async () => {
    setLoading(true);
    try {
      const data = await adminService.getAllOrganizations();
      setTenants(data);
    } catch (error) {
      console.error("Failed to load tenants:", error);
      toast({
        title: "Error loading tenants",
        description: "Could not fetch organization list. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTenants();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    if (!formData.name.trim()) {
      toast({ title: "Validation Error", description: "Tenant Name is required", variant: "destructive" });
      return false;
    }
    if (formData.name.length < 3) {
      toast({ title: "Validation Error", description: "Tenant Name must be at least 3 characters", variant: "destructive" });
      return false;
    }
    if (!formData.adminEmail.trim()) {
      toast({ title: "Validation Error", description: "Admin Email is required", variant: "destructive" });
      return false;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.adminEmail)) {
      toast({ title: "Validation Error", description: "Please enter a valid email address", variant: "destructive" });
      return false;
    }
    return true;
  };

  const handleCreateTenant = async () => {
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      console.log("Submitting form data:", formData);
      await adminService.createTenant(formData);
      
      toast({
        title: "Tenant Created",
        description: `${formData.name} has been successfully initialized.`,
        className: "bg-green-50 border-green-200 text-green-800"
      });

      setIsCreateModalOpen(false);
      setFormData({ name: '', adminEmail: '', tier: 'Free', region: 'US-East' }); // Reset form
      fetchTenants(); // Refresh list
    } catch (error) {
      console.error("Create tenant error:", error);
      toast({
        title: "Creation Failed",
        description: error.message || "An unexpected error occurred while creating the tenant.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredTenants = tenants.filter(t => 
    t.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    t.slug?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.billing_email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <Helmet>
        <title>Tenant Management | Platform Admin</title>
      </Helmet>

      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Tenant Management</h1>
          <p className="text-slate-500 mt-1">Manage organizations, subscriptions, and tenant lifecycles.</p>
        </div>
        
        <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
          <DialogTrigger asChild>
            <Button>
                <Plus className="w-4 h-4 mr-2" /> Create Tenant
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>Create New Tenant</DialogTitle>
              <DialogDescription>
                Initialize a new organization workspace. An invitation will be sent to the admin email.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Organization Name</Label>
                <Input 
                  id="name" 
                  name="name" 
                  value={formData.name} 
                  onChange={handleInputChange} 
                  placeholder="e.g. Acme Corporation" 
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="adminEmail">Admin Email</Label>
                <Input 
                  id="adminEmail" 
                  name="adminEmail" 
                  type="email" 
                  value={formData.adminEmail} 
                  onChange={handleInputChange} 
                  placeholder="admin@company.com" 
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="tier">Subscription Tier</Label>
                  <Select 
                    value={formData.tier} 
                    onValueChange={(val) => handleSelectChange('tier', val)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select Tier" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Free">Free</SelectItem>
                      <SelectItem value="Starter">Starter</SelectItem>
                      <SelectItem value="Growth">Growth</SelectItem>
                      <SelectItem value="Enterprise">Enterprise</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="region">Data Region</Label>
                  <Select 
                    value={formData.region} 
                    onValueChange={(val) => handleSelectChange('region', val)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select Region" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="US-East">US East (N. Virginia)</SelectItem>
                      <SelectItem value="US-West">US West (Oregon)</SelectItem>
                      <SelectItem value="EU-West">EU West (Ireland)</SelectItem>
                      <SelectItem value="Asia-Pac">Asia Pacific (Singapore)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateModalOpen(false)} disabled={isSubmitting}>
                Cancel
              </Button>
              <Button onClick={handleCreateTenant} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Creating...
                  </>
                ) : (
                  'Create Tenant'
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
           <div className="flex justify-between items-center">
             <div className="space-y-1">
               <CardTitle>All Organizations</CardTitle>
               <CardDescription>
                  {loading ? 'Loading tenants...' : `Showing ${filteredTenants.length} organizations`}
               </CardDescription>
             </div>
             <div className="flex gap-2">
                <div className="relative w-64">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500" />
                    <Input 
                      placeholder="Search tenants..." 
                      className="pl-9" 
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <Button variant="outline" size="icon" onClick={fetchTenants} title="Refresh List">
                   <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                </Button>
             </div>
           </div>
        </CardHeader>
        <CardContent>
           <div className="rounded-md border">
             <Table>
               <TableHeader>
                  <TableRow>
                     <TableHead>Organization</TableHead>
                     <TableHead>Status</TableHead>
                     <TableHead>Tier</TableHead>
                     <TableHead>Region</TableHead>
                     <TableHead>Created</TableHead>
                     <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
               </TableHeader>
               <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="h-24 text-center text-slate-500">
                        <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
                        Loading organization data...
                      </TableCell>
                    </TableRow>
                  ) : filteredTenants.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="h-24 text-center text-slate-500">
                        No tenants found matching your search.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredTenants.map((t) => (
                      <TableRow key={t.id}>
                         <TableCell>
                            <div className="flex items-center gap-3">
                               <div className="w-8 h-8 rounded bg-slate-100 flex items-center justify-center text-slate-500 font-bold text-xs uppercase">
                                  {t.name.substring(0, 2)}
                               </div>
                               <div className="flex flex-col">
                                  <span className="font-medium text-slate-900">{t.name}</span>
                                  <span className="text-xs text-slate-500">{t.slug}</span>
                               </div>
                            </div>
                         </TableCell>
                         <TableCell>
                            <Badge 
                              variant="outline" 
                              className={
                                t.status === 'Active' 
                                  ? 'bg-green-50 text-green-700 border-green-200' 
                                  : 'bg-red-50 text-red-700 border-red-200'
                              }
                            >
                               {t.status === 'Active' ? <CheckCircle className="w-3 h-3 mr-1" /> : <XCircle className="w-3 h-3 mr-1" />}
                               {t.status}
                            </Badge>
                         </TableCell>
                         <TableCell>
                            <Badge variant="secondary" className="font-normal">{t.subscription_tier}</Badge>
                         </TableCell>
                         <TableCell>
                            <div className="flex items-center gap-1 text-slate-500 text-sm">
                               <Globe className="w-3 h-3" /> {t.settings?.region || 'US-East'}
                            </div>
                         </TableCell>
                         <TableCell>
                            <span className="text-sm text-slate-500">
                              {new Date(t.created_at).toLocaleDateString()}
                            </span>
                         </TableCell>
                         <TableCell className="text-right">
                            <DropdownMenu>
                               <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon"><MoreHorizontal className="w-4 h-4" /></Button>
                               </DropdownMenuTrigger>
                               <DropdownMenuContent align="end">
                                  <DropdownMenuItem>View Details</DropdownMenuItem>
                                  <DropdownMenuItem>Manage Subscription</DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem className="text-red-600">Suspend Tenant</DropdownMenuItem>
                               </DropdownMenuContent>
                            </DropdownMenu>
                         </TableCell>
                      </TableRow>
                    ))
                  )}
               </TableBody>
             </Table>
           </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PlatformTenantManagement;
