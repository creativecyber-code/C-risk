
import React from 'react';
import UserManagementPanel from '@/components/access/UserManagementPanel';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Helmet } from 'react-helmet-async';

const UserManagement = () => {
  const { profile } = useAuth();

  return (
    <div className="space-y-6 animate-in fade-in duration-500 p-6 md:p-8 pt-6">
      <Helmet>
        <title>User Management - Dashboard</title>
        <meta name="description" content="Manage users, roles, and access controls for your organization." />
      </Helmet>
      
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Team Members</h1>
        <p className="text-muted-foreground">
          View and manage who has access to your organization's workspace.
        </p>
      </div>

      <UserManagementPanel orgId={profile?.org_id} />
    </div>
  );
};

export default UserManagement;
