
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { Loader2, Download, ChevronLeft, Settings as SettingsIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { threatModelService } from '@/services/threatModelService';
import { calculateThreats } from '@/utils/threatCalculation';
import ReportTemplate from '@/components/report/ReportTemplate';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';

const ReportGenerator = () => {
  const { modelId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [model, setModel] = useState(null);
  const [threats, setThreats] = useState([]);
  const [organization, setOrganization] = useState(null);
  const [creatorProfile, setCreatorProfile] = useState(null);

  // Report Section Toggles
  const [options, setOptions] = useState({
    summary: true,
    charts: true,
    compliance: true,
    threats: true,
  });

  useEffect(() => {
    fetchData();
  }, [modelId, user]);

  const fetchData = async () => {
    if (!user || !modelId) return;
    try {
      // 1. Load Threat Model Data
      const { model: loadedModel, elements, connections } = await threatModelService.loadModel(modelId);
      setModel(loadedModel);

      // 2. Calculate Threats (using shared utility)
      const detectedThreats = calculateThreats(elements, connections);
      setThreats(detectedThreats);

      // 3. Fetch Organization & Creator Details
      const { data: profile } = await supabase
        .from('user_profiles')
        .select('*, organizations(*)')
        .eq('id', user.id)
        .single();
      
      if (profile) {
        setCreatorProfile(profile);
        setOrganization(profile.organizations);
      }

    } catch (error) {
      console.error(error);
      toast({
        title: "Error loading report data",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleExportPDF = async () => {
    setGenerating(true);
    try {
      const element = document.getElementById('report-content');
      if (!element) throw new Error("Report content not found");

      const canvas = await html2canvas(element, {
        scale: 2, // Higher quality
        useCORS: true,
        logging: false
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      
      // Calculate dimensions to fit A4
      const pdfImageWidth = 210; // A4 width mm
      const pdfImageHeight = (canvas.height * pdfImageWidth) / canvas.width;

      pdf.addImage(imgData, 'PNG', 0, 0, pdfImageWidth, pdfImageHeight);
      pdf.save(`CISO-Report-${model?.name.replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.pdf`);

      toast({
        title: "Report Generated",
        description: "Your PDF report has been downloaded successfully.",
        className: "bg-green-600 text-white border-none"
      });
    } catch (error) {
      console.error(error);
      toast({
        title: "Export Failed",
        description: "Could not generate PDF. Please try again.",
        variant: "destructive"
      });
    } finally {
      setGenerating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-50">
        <div className="text-center">
          <Loader2 className="h-10 w-10 animate-spin text-brand-600 mx-auto mb-4" />
          <p className="text-slate-600 font-medium">Preparing audit data...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Generate Report - {model?.name} | CreativeCyber</title>
      </Helmet>
      
      <div className="min-h-screen bg-slate-100 flex flex-col md:flex-row">
        {/* Sidebar Controls */}
        <div className="w-full md:w-80 bg-white border-r p-6 flex-shrink-0 md:h-screen overflow-y-auto sticky top-0">
          <Button variant="ghost" className="mb-6 pl-0 hover:pl-2 transition-all" onClick={() => navigate('/dashboard/models')}>
            <ChevronLeft className="w-4 h-4 mr-2" /> Back to Dashboard
          </Button>
          
          <div className="mb-8">
            <h1 className="text-2xl font-bold font-heading text-slate-900 mb-2">Report Generator</h1>
            <p className="text-sm text-slate-500">Customize and export your CISO executive report.</p>
          </div>

          <Card className="mb-6 border-slate-200 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <SettingsIcon className="w-4 h-4 text-brand-600" /> Report Sections
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="summary" 
                  checked={options.summary} 
                  onCheckedChange={(c) => setOptions(prev => ({ ...prev, summary: c }))} 
                />
                <Label htmlFor="summary">Executive Summary</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="charts" 
                  checked={options.charts} 
                  onCheckedChange={(c) => setOptions(prev => ({ ...prev, charts: c }))} 
                />
                <Label htmlFor="charts">Visual Analytics</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="compliance" 
                  checked={options.compliance} 
                  onCheckedChange={(c) => setOptions(prev => ({ ...prev, compliance: c }))} 
                />
                <Label htmlFor="compliance">Compliance Matrix</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="threats" 
                  checked={options.threats} 
                  onCheckedChange={(c) => setOptions(prev => ({ ...prev, threats: c }))} 
                />
                <Label htmlFor="threats">Detailed Audit Trail</Label>
              </div>
            </CardContent>
          </Card>

          <Button 
            onClick={handleExportPDF} 
            disabled={generating}
            className="w-full bg-brand-600 hover:bg-brand-700 h-12 text-lg shadow-md"
          >
            {generating ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Generating...
              </>
            ) : (
              <>
                <Download className="mr-2 h-5 w-5" /> Download PDF
              </>
            )}
          </Button>
        </div>

        {/* Live Preview Area */}
        <div className="flex-1 p-8 overflow-y-auto flex justify-center bg-slate-200/50">
          <div className="shadow-2xl print:shadow-none">
            {/* We render the template here. This div is what gets captured by html2canvas */}
            <ReportTemplate 
              model={model}
              threats={threats}
              organization={organization}
              creator={creatorProfile}
              generatedDate={new Date().toLocaleDateString()}
              options={options}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default ReportGenerator;
