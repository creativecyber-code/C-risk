
import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { BellRing, Mail, MessageSquare, Save, Clock, SlidersHorizontal } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { notificationService } from '@/services/notificationService';

const NotificationSettings = () => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [prefs, setPrefs] = useState({
    email_enabled: true,
    slack_enabled: false,
    slack_webhook_url: '',
    min_severity: 'Low',
    enabled_types: { THREAT: true, RISK: true, COMPLIANCE: true, INTEGRATION: true, TEAM: true },
    quiet_hours_start: '',
    quiet_hours_end: ''
  });
  
  const { toast } = useToast();

  useEffect(() => {
    loadPreferences();
  }, []);

  const loadPreferences = async () => {
    try {
      const data = await notificationService.getPreferences();
      if (data) {
        setPrefs(prev => ({
          ...prev,
          ...data,
          // Handle jsonb defaults if null
          enabled_types: data.enabled_types || prev.enabled_types
        }));
      }
    } catch (error) {
      toast({ title: "Error loading settings", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await notificationService.updatePreferences(prefs);
      toast({ title: "Preferences saved successfully" });
      
      // Send a test notification to verify
      await notificationService.notify({
        type: 'TEAM',
        title: 'Settings Updated',
        message: 'Your notification preferences have been updated successfully.',
        severity: 'Info'
      });
      
    } catch (error) {
      toast({ title: "Failed to save settings", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const toggleType = (type) => {
    setPrefs(p => ({
      ...p,
      enabled_types: { ...p.enabled_types, [type]: !p.enabled_types[type] }
    }));
  };

  if (loading) return <div className="p-8">Loading settings...</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Helmet>
        <title>Notification Preferences | CreativeCyber</title>
      </Helmet>

      <div>
        <h1 className="text-2xl font-bold text-slate-900">Notification Preferences</h1>
        <p className="text-slate-500">Manage how and when you receive alerts.</p>
      </div>

      <div className="grid gap-6">
        {/* Delivery Channels */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BellRing className="w-5 h-5" /> Delivery Channels
            </CardTitle>
            <CardDescription>Choose where you want to receive notifications.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base">Email Notifications</Label>
                <p className="text-sm text-slate-500">Receive high-priority alerts via email.</p>
              </div>
              <Switch 
                checked={prefs.email_enabled} 
                onCheckedChange={(c) => setPrefs({...prefs, email_enabled: c})} 
              />
            </div>
            
            <div className="border-t pt-6">
              <div className="flex items-center justify-between mb-4">
                <div className="space-y-0.5">
                  <Label className="text-base">Slack Integration</Label>
                  <p className="text-sm text-slate-500">Post alerts to a specific Slack channel.</p>
                </div>
                <Switch 
                  checked={prefs.slack_enabled} 
                  onCheckedChange={(c) => setPrefs({...prefs, slack_enabled: c})} 
                />
              </div>
              {prefs.slack_enabled && (
                <div className="animate-in slide-in-from-top-2 fade-in">
                  <Label>Webhook URL</Label>
                  <div className="flex gap-2 mt-1.5">
                    <div className="relative flex-1">
                      <MessageSquare className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                      <Input 
                        placeholder="https://hooks.slack.com/services/..." 
                        className="pl-9"
                        value={prefs.slack_webhook_url || ''}
                        onChange={(e) => setPrefs({...prefs, slack_webhook_url: e.target.value})}
                      />
                    </div>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Only 'Critical' and 'High' severity alerts are sent to Slack to reduce noise.
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Filters & Rules */}
        <Card>
          <CardHeader>
             <CardTitle className="flex items-center gap-2">
                <SlidersHorizontal className="w-5 h-5" /> Rules & Filters
             </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className="space-y-2">
                  <Label>Minimum Severity Level</Label>
                  <Select 
                    value={prefs.min_severity} 
                    onValueChange={(v) => setPrefs({...prefs, min_severity: v})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select severity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Info">Info (All)</SelectItem>
                      <SelectItem value="Low">Low & Above</SelectItem>
                      <SelectItem value="Medium">Medium & Above</SelectItem>
                      <SelectItem value="High">High & Above</SelectItem>
                      <SelectItem value="Critical">Critical Only</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-slate-500">
                    Notifications below this level will be completely suppressed.
                  </p>
               </div>

               <div className="space-y-2">
                 <Label className="flex items-center gap-2"><Clock className="w-4 h-4" /> Quiet Hours</Label>
                 <div className="flex items-center gap-2">
                   <Input 
                      type="time" 
                      value={prefs.quiet_hours_start || ''}
                      onChange={(e) => setPrefs({...prefs, quiet_hours_start: e.target.value})}
                   />
                   <span className="text-slate-400">to</span>
                   <Input 
                      type="time" 
                      value={prefs.quiet_hours_end || ''}
                      onChange={(e) => setPrefs({...prefs, quiet_hours_end: e.target.value})}
                   />
                 </div>
                 <p className="text-xs text-slate-500">
                    External notifications (Email/Slack) are paused during these hours.
                  </p>
               </div>
            </div>

            <div className="space-y-3">
              <Label>Notification Types</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 {[
                   { id: 'THREAT', label: 'Threat Detected', desc: 'New threats identified in models' },
                   { id: 'RISK', label: 'Risk Score Change', desc: 'Significant changes in risk calculation' },
                   { id: 'COMPLIANCE', label: 'Compliance Alerts', desc: 'Control failures or status updates' },
                   { id: 'INTEGRATION', label: 'Integration Issues', desc: 'Connection failures or sync errors' },
                   { id: 'TEAM', label: 'Team Activity', desc: 'Assignments, comments, and mentions' },
                 ].map(type => (
                   <div key={type.id} className="flex items-start space-x-3 p-3 border rounded-lg bg-slate-50/50">
                     <Switch 
                        checked={prefs.enabled_types[type.id]} 
                        onCheckedChange={() => toggleType(type.id)}
                     />
                     <div>
                       <Label className="font-medium">{type.label}</Label>
                       <p className="text-xs text-slate-500">{type.desc}</p>
                     </div>
                   </div>
                 ))}
              </div>
            </div>
          </CardContent>
          <CardFooter className="bg-slate-50/50 border-t p-4 flex justify-end">
            <Button onClick={handleSave} disabled={saving}>
              {saving ? 'Saving...' : <><Save className="w-4 h-4 mr-2" /> Save Preferences</>}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default NotificationSettings;
