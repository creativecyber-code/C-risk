
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { 
  ShieldAlert, TrendingUp, AlertTriangle, CheckCircle2, 
  Activity, Search, Filter, Layers, DollarSign, Calculator
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { threatModelService } from '@/services/threatModelService';
import { riskService } from '@/services/riskService';
import { calculateOverallRisk, getRiskLevel, formatCurrency } from '@/utils/riskCalculations';

import RiskMatrix from '@/components/risk/RiskMatrix';
import RiskAssessmentModal from '@/components/risk/RiskAssessmentModal';

const RiskPrioritization = () => {
  const [models, setModels] = useState([]);
  const [selectedModelId, setSelectedModelId] = useState('all');
  const [loading, setLoading] = useState(true);
  const [allAssessments, setAllAssessments] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal State
  const [selectedAssessment, setSelectedAssessment] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const { toast } = useToast();

  // Initial Load
  useEffect(() => {
    const initData = async () => {
      setLoading(true);
      try {
        // 1. Load Models List
        const modelsData = await threatModelService.listModels();
        setModels(modelsData);

        // 2. Load ALL Assessments for Organization
        const assessmentsData = await riskService.getAllOrgAssessments();
        setAllAssessments(assessmentsData);
        
      } catch (error) {
        console.error("Failed to load risk data:", error);
        toast({ title: "Error loading risk data", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    };
    initData();
  }, [toast]);

  const handleAssessmentSave = async (updated) => {
    try {
      const saved = await riskService.saveAssessment(updated);
      
      // Update local state
      setAllAssessments(prev => 
        prev.map(a => a.id === saved.id ? { ...saved, model_name: a.model_name } : a)
      );
      
      toast({ title: "Risk Assessment Updated", description: "Changes saved successfully." });
    } catch (error) {
      console.error(error);
      toast({ title: "Save failed", variant: "destructive" });
    }
  };

  // Filter Logic
  const filteredAssessments = allAssessments.filter(a => {
    // 1. Model Filter
    if (selectedModelId !== 'all' && a.model_id !== selectedModelId) return false;
    
    // 2. Search Filter
    if (searchTerm && !a.title.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    
    return true;
  }).sort((a, b) => b.risk_score - a.risk_score);

  // Metrics Calculation
  const totalRiskScore = calculateOverallRisk(filteredAssessments);
  const criticalCount = filteredAssessments.filter(a => getRiskLevel(a.risk_score).label === 'Critical').length;
  const highCount = filteredAssessments.filter(a => getRiskLevel(a.risk_score).label === 'High').length;
  
  // Financial Metrics
  const totalALE = filteredAssessments.reduce((acc, curr) => acc + (curr.ale || 0), 0);
  const topFinancialRisks = [...filteredAssessments]
    .sort((a, b) => (b.ale || 0) - (a.ale || 0))
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <Helmet>
        <title>Risk Prioritization | CreativeCyber</title>
      </Helmet>

      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
           <h1 className="text-3xl font-bold font-heading text-slate-900">Risk & Prioritization</h1>
           <p className="text-slate-500">Quantify, visualize, and manage security risks using FAIR & CVSS methodologies.</p>
        </div>
        
        {/* Filter Controls */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <Layers className="w-4 h-4 text-slate-400 hidden md:block" />
          <Select value={selectedModelId} onValueChange={setSelectedModelId}>
            <SelectTrigger className="w-full md:w-[250px]">
              <SelectValue placeholder="Filter by Model" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Models</SelectItem>
              {models.map(m => <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      {loading ? (
         <div className="flex flex-col items-center justify-center h-64 gap-4">
           <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
           <p className="text-sm text-slate-500">Aggregating risks across organization...</p>
         </div>
      ) : allAssessments.length === 0 ? (
        <div className="text-center py-12 bg-slate-50 rounded border border-dashed">
           <ShieldAlert className="w-12 h-12 text-slate-300 mx-auto mb-4" />
           <h3 className="text-lg font-medium">No threats detected yet</h3>
           <p className="text-slate-500">Create threat models and identify threats to populate this dashboard.</p>
        </div>
      ) : (
        <>
          {/* Top Metrics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-white border-slate-200 shadow-sm">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-slate-500 uppercase">Total Exposure (ALE)</p>
                  <div className="text-2xl font-bold text-emerald-700">{formatCurrency(totalALE)}</div>
                  <p className="text-[10px] text-slate-400 mt-1">Annual Loss Expectancy</p>
                </div>
                <div className="p-2 rounded-full bg-emerald-100">
                  <DollarSign className="w-6 h-6 text-emerald-600" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white border-slate-200 shadow-sm">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-slate-500 uppercase">Critical & High</p>
                  <div className="text-2xl font-bold text-slate-900">{criticalCount + highCount}</div>
                  <p className="text-[10px] text-slate-400 mt-1">Requiring immediate attention</p>
                </div>
                <div className="p-2 rounded-full bg-red-100">
                  <AlertTriangle className="w-6 h-6 text-red-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white border-slate-200 shadow-sm">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-slate-500 uppercase">View Risk Score</p>
                  <div className={`text-2xl font-bold ${getRiskLevel(totalRiskScore).text}`}>
                    {totalRiskScore}/10
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">Qualitative aggregate</p>
                </div>
                <div className={`p-2 rounded-full ${getRiskLevel(totalRiskScore).color} bg-opacity-10`}>
                  <Activity className={`w-6 h-6 ${getRiskLevel(totalRiskScore).text}`} />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white border-slate-200 shadow-sm">
              <CardContent className="p-4 flex items-center justify-between">
                 <div>
                    <p className="text-xs font-medium text-slate-500 uppercase">Risk Trend</p>
                    <div className="flex items-center gap-1 text-green-600 font-bold text-lg">
                      <TrendingUp className="w-4 h-4" /> -5%
                    </div>
                    <p className="text-[10px] text-slate-400">vs last month</p>
                 </div>
                 {/* Mini Chart Visualization */}
                 <div className="h-10 w-20 flex items-end justify-between px-1">
                    {[40, 65, 50, 80, 45].map((h, i) => (
                      <div key={i} className="w-2 bg-slate-100 rounded-t-sm relative overflow-hidden">
                        <div className="absolute bottom-0 w-full bg-green-500 transition-all duration-500" style={{ height: `${h}%` }}></div>
                      </div>
                    ))}
                 </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Risk Matrix */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg">Risk Matrix (Likelihood vs Impact)</CardTitle>
              </CardHeader>
              <CardContent>
                <RiskMatrix 
                  threats={filteredAssessments} 
                  onThreatClick={(t) => {
                    const real = filteredAssessments.find(a => a.threat_source_id === t.id);
                    if (real) {
                      setSelectedAssessment(real); 
                      setIsModalOpen(true); 
                    }
                  }}
                />
              </CardContent>
            </Card>

            {/* Top Financial Risks (FAIR) */}
            <Card className="lg:col-span-1 flex flex-col h-[500px]">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-emerald-600"/>
                  Top Financial Risks
                </CardTitle>
                <p className="text-xs text-slate-500">Ranked by Annual Loss Expectancy (ALE)</p>
              </CardHeader>
              <CardContent className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
                <div className="space-y-3">
                  {topFinancialRisks.length === 0 || topFinancialRisks.every(r => !r.ale) ? (
                    <div className="text-center py-8 bg-slate-50 rounded">
                      <p className="text-sm text-slate-500">No financial data added.</p>
                      <Button variant="link" size="sm" onClick={() => { if(filteredAssessments[0]) { setSelectedAssessment(filteredAssessments[0]); setIsModalOpen(true); }}}>
                        Add FAIR data to risks
                      </Button>
                    </div>
                  ) : (
                    topFinancialRisks.map(threat => {
                      const hasAle = threat.ale > 0;
                      return (
                        <div 
                          key={threat.id} 
                          className="p-3 border rounded-lg hover:bg-slate-50 cursor-pointer transition-colors group bg-white shadow-sm"
                          onClick={() => { setSelectedAssessment(threat); setIsModalOpen(true); }}
                        >
                           <div className="flex justify-between items-start mb-1">
                             <Badge variant="outline" className="text-[10px] h-5">{threat.model_name || 'Model'}</Badge>
                             <span className="font-bold text-emerald-700 text-sm">
                               {hasAle ? formatCurrency(threat.ale) : '$0'}
                             </span>
                           </div>
                           <h4 className="font-medium text-sm text-slate-800 line-clamp-2 group-hover:text-blue-700">{threat.title}</h4>
                           
                           {hasAle && (
                             <div className="grid grid-cols-3 gap-1 mt-2 pt-2 border-t border-slate-100">
                               <div className="text-center">
                                 <div className="text-[9px] text-slate-400 uppercase">Freq</div>
                                 <div className="text-xs font-medium">{threat.tef}/yr</div>
                               </div>
                               <div className="text-center border-l border-slate-100">
                                 <div className="text-[9px] text-slate-400 uppercase">Vuln</div>
                                 <div className="text-xs font-medium">{threat.vulnerability_percentage}%</div>
                               </div>
                               <div className="text-center border-l border-slate-100">
                                 <div className="text-[9px] text-slate-400 uppercase">Loss</div>
                                 <div className="text-xs font-medium">${parseInt(threat.loss_magnitude).toLocaleString()}</div>
                               </div>
                             </div>
                           )}
                        </div>
                      );
                    })
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Table */}
          <Card>
            <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <CardTitle>Detailed Risk Inventory</CardTitle>
              <div className="relative w-full sm:w-72">
                 <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                 <Input 
                    placeholder="Search by threat name..." 
                    className="pl-9"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                 />
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="bg-slate-50 text-slate-500 font-medium border-b">
                    <tr>
                      <th className="px-4 py-3 min-w-[200px]">Threat Name</th>
                      <th className="px-4 py-3">Source Model</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Score</th>
                      <th className="px-4 py-3">ALE (Financial)</th>
                      <th className="px-4 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAssessments.length === 0 ? (
                       <tr><td colSpan="6" className="text-center py-8 text-slate-500">No risks found matching your filters.</td></tr>
                    ) : (
                      filteredAssessments.map(item => {
                        const level = getRiskLevel(item.risk_score);
                        return (
                          <tr key={item.id} className="border-b hover:bg-slate-50/50 transition-colors">
                            <td className="px-4 py-3 font-medium text-slate-900">
                              {item.title}
                              {item.status === 'Accepted' && <span className="ml-2 inline-block w-2 h-2 rounded-full bg-orange-50" title="Accepted Risk"></span>}
                            </td>
                            <td className="px-4 py-3 text-slate-500 text-xs">{item.model_name || 'N/A'}</td>
                            <td className="px-4 py-3">
                              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border 
                                ${item.status === 'Accepted' ? 'bg-orange-50 text-orange-700 border-orange-200' : 
                                  item.status === 'Mitigated' ? 'bg-green-50 text-green-700 border-green-200' : 
                                  item.status === 'In Progress' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                                  'bg-slate-100 text-slate-700 border-slate-200'}`}>
                                {item.status}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                               <div className="flex items-center gap-2">
                                 <div className={`w-2 h-2 rounded-full ${level.color}`}></div>
                                 <span className="font-mono font-bold">{item.risk_score}</span>
                               </div>
                            </td>
                            <td className="px-4 py-3">
                              {item.ale > 0 ? (
                                <span className="text-emerald-700 font-medium font-mono">
                                  {formatCurrency(item.ale)}
                                </span>
                              ) : (
                                <span className="text-slate-400 text-xs">-</span>
                              )}
                            </td>
                            <td className="px-4 py-3 text-right">
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="h-8"
                                onClick={() => { setSelectedAssessment(item); setIsModalOpen(true); }}
                              >
                                Assess
                              </Button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {selectedAssessment && (
        <RiskAssessmentModal 
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          assessment={selectedAssessment}
          onSave={handleAssessmentSave}
        />
      )}
    </div>
  );
};

export default RiskPrioritization;
