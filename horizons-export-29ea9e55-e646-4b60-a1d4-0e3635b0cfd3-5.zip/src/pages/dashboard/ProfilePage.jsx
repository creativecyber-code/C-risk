
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Shield, Smartphone, Building2, UserCircle, KeyRound, LayoutDashboard } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import SecuritySettings from '@/components/settings/SecuritySettings';
import { Helmet } from 'react-helmet-async';

export default function ProfilePage() {
  const { user, userRole, tenant, userRoleDefinition } = useAuth(); // Added userRoleDefinition
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [mfaEnabled, setMfaEnabled] = useState(false);
  const [profileData, setProfileData] = useState(null);

  useEffect(() => {
    if (user) {
      fetchProfile();
    }
  }, [user, userRoleDefinition]); // React to role definition loading

  const fetchProfile = async () => {
    try {
      setLoading(true);
      const { data: factors } = await supabase.auth.mfa.listFactors();
      const hasVerified = factors?.totp?.some(f => f.status === 'verified');
      setMfaEnabled(!!hasVerified);

      setProfileData({
        fullName: user.user_metadata?.full_name || user.email?.split('@')[0],
        email: user.email,
        role: userRoleDefinition ? userRoleDefinition.display_name : (userRole || 'User'), // Prefer display name
        lastLogin: user.last_sign_in_at ? new Date(user.last_sign_in_at).toLocaleString() : 'N/A',
        organization: tenant?.name || "C-RISK Enterprise"
      });

    } catch (error) {
      console.error("Profile load error", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return (
    <div className="flex items-center justify-center p-12 text-slate-500">
      Loading profile...
    </div>
  );

  return (
    <div className="space-y-6 max-w-5xl mx-auto p-6">
      <Helmet>
        <title>My Profile | C-RISK</title>
      </Helmet>

      <div className="flex flex-col md:flex-row gap-6 items-start">
        {/* Profile Card */}
        <Card className="w-full md:w-80 shadow-sm border-slate-200">
          <CardContent className="pt-6 flex flex-col items-center text-center">
            <Avatar className="w-24 h-24 mb-4 border-2 border-slate-100">
              <AvatarImage src={`https://ui-avatars.com/api/?name=${profileData?.fullName}&background=0f172a&color=fff`} />
              <AvatarFallback>User</AvatarFallback>
            </Avatar>
            <h2 className="text-xl font-bold text-slate-900">{profileData?.fullName}</h2>
            <p className="text-sm text-slate-500 mb-4">{profileData?.email}</p>
            
            <Badge variant="outline" className="mb-6 capitalize bg-slate-50 text-slate-700 border-slate-200 px-3 py-1">
              {profileData?.role}
            </Badge>

            <div className="w-full space-y-3 text-left text-sm">
               <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-md">
                  <Building2 className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-700 font-medium">{profileData?.organization}</span>
               </div>
               <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-md">
                  <Shield className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-700">MFA: </span>
                  {mfaEnabled ? (
                    <span className="text-green-600 font-bold text-xs uppercase tracking-wide">Enabled</span>
                  ) : (
                    <span className="text-red-500 font-bold text-xs uppercase tracking-wide">Disabled</span>
                  )}
               </div>
            </div>

            <Separator className="my-6" />

            <Button 
                onClick={() => navigate('/app-dashboard/overview')} 
                className="w-full"
            >
                <LayoutDashboard className="w-4 h-4 mr-2" /> Go to Overview
            </Button>
          </CardContent>
        </Card>

        {/* Content Tabs */}
        <div className="flex-1 w-full">
           <Tabs defaultValue="security" className="w-full">
              <TabsList className="bg-white border border-slate-200 p-1 mb-6 w-full md:w-auto">
                 <TabsTrigger value="security" className="flex-1 md:flex-none data-[state=active]:bg-slate-100 data-[state=active]:text-slate-900">
                    <KeyRound className="w-4 h-4 mr-2" /> Security
                 </TabsTrigger>
                 <TabsTrigger value="general" className="flex-1 md:flex-none data-[state=active]:bg-slate-100 data-[state=active]:text-slate-900">
                    <UserCircle className="w-4 h-4 mr-2" /> Account Info
                 </TabsTrigger>
              </TabsList>

              <TabsContent value="security" className="space-y-6">
                 {/* Direct Call to Action for MFA */}
                 <Card className={mfaEnabled ? "border-green-200 bg-green-50/30" : "border-amber-200 bg-amber-50/30"}>
                    <CardHeader className="pb-3">
                       <CardTitle className="text-lg flex items-center gap-2">
                          <Smartphone className={`w-5 h-5 ${mfaEnabled ? 'text-green-600' : 'text-amber-600'}`} />
                          Multi-Factor Authentication
                       </CardTitle>
                       <CardDescription>
                          {mfaEnabled 
                             ? "Your account is secured with two-factor authentication." 
                             : "Protect your account by enabling two-factor authentication."}
                       </CardDescription>
                    </CardHeader>
                    <CardContent>
                       <div className="flex items-center justify-between">
                          <div className="text-sm text-slate-600">
                             {mfaEnabled 
                               ? "Manage your devices and backup codes." 
                               : "Recommended: Use Google Authenticator or Authy."}
                          </div>
                          <Button 
                             onClick={() => navigate('/mfa-setup')}
                             variant={mfaEnabled ? "outline" : "default"}
                             className={!mfaEnabled ? "bg-amber-600 hover:bg-amber-700 text-white" : ""}
                          >
                             {mfaEnabled ? "Manage MFA" : "Setup MFA Now"}
                          </Button>
                       </div>
                    </CardContent>
                 </Card>

                 {/* Detailed Security Settings Component */}
                 <SecuritySettings />
              </TabsContent>

              <TabsContent value="general">
                 <Card>
                    <CardHeader>
                       <CardTitle>Personal Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                       <div className="grid grid-cols-2 gap-4">
                          <div>
                             <label className="text-xs font-semibold text-slate-500 uppercase">Full Name</label>
                             <div className="p-2 border rounded bg-slate-50 text-slate-700 mt-1">{profileData?.fullName}</div>
                          </div>
                          <div>
                             <label className="text-xs font-semibold text-slate-500 uppercase">Email Address</label>
                             <div className="p-2 border rounded bg-slate-50 text-slate-700 mt-1">{profileData?.email}</div>
                          </div>
                          <div>
                             <label className="text-xs font-semibold text-slate-500 uppercase">Current Role</label>
                             <div className="p-2 border rounded bg-slate-50 text-slate-700 mt-1">{profileData?.role}</div>
                          </div>
                          <div>
                             <label className="text-xs font-semibold text-slate-500 uppercase">Last Login</label>
                             <div className="p-2 border rounded bg-slate-50 text-slate-700 mt-1">{profileData?.lastLogin}</div>
                          </div>
                          <div>
                             <label className="text-xs font-semibold text-slate-500 uppercase">User ID</label>
                             <div className="p-2 border rounded bg-slate-50 text-slate-700 mt-1 font-mono text-xs overflow-hidden text-ellipsis">{user.id}</div>
                          </div>
                       </div>
                    </CardContent>
                 </Card>
              </TabsContent>
           </Tabs>
        </div>
      </div>
    </div>
  );
}
