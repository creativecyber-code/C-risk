
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter
} from '@/components/ui/card';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  ArrowLeft,
  Calendar,
  ShieldAlert,
  CheckCircle2,
  FileText,
  DollarSign,
  Globe,
  Lock,
  Building2,
  Loader2,
  AlertTriangle,
  Send,
  User,
  GitBranch
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

// --- Helper Components ---

const DetailRow = ({ label, value, icon: Icon, className }) => (
  <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between py-3 border-b border-slate-50 last:border-0", className)}>
    <span className="text-sm font-medium text-slate-500 flex items-center gap-2">
      {Icon && <Icon className="h-4 w-4 text-slate-400" />}
      {label}
    </span>
    <span className="text-sm font-medium text-slate-900 mt-1 sm:mt-0 text-right">{value || '-'}</span>
  </div>
);

const RiskBadge = ({ rating }) => {
  const colors = {
    'Critical': 'bg-red-50 text-red-700 border-red-200',
    'Very High': 'bg-orange-50 text-orange-700 border-orange-200',
    'High': 'bg-amber-50 text-amber-700 border-amber-200',
    'Medium': 'bg-yellow-50 text-yellow-700 border-yellow-200',
    'Low': 'bg-green-50 text-green-700 border-green-200',
  };
  return (
    <Badge variant="outline" className={cn("border px-2 py-0.5", colors[rating] || 'bg-slate-50')}>
      {rating || 'Not Rated'}
    </Badge>
  );
};

// --- Main Component ---

export default function BusinessInitiationDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { tenant, user, userRole } = useAuth();
  
  const [initiation, setInitiation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);
  
  // Fetch Data
  useEffect(() => {
    if (tenant?.id && id) {
      fetchInitiationDetails();
    }
  }, [tenant?.id, id]);

  const fetchInitiationDetails = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('business_initiations')
        .select('*')
        .eq('id', id)
        .eq('org_id', tenant.id)
        .single();

      if (error) throw error;
      setInitiation(data);
    } catch (err) {
      console.error("Error fetching initiation:", err);
      setError("Could not load initiation details. It may not exist or you lack permission.");
    } finally {
      setLoading(false);
    }
  };

  // --- Actions ---

  const handleRequestSignOff = async () => {
    setActionLoading(true);
    try {
      const { error } = await supabase
        .from('business_initiations')
        .update({ status: 'in_review', updated_at: new Date() })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Submitted for Review",
        description: "Status updated to In Review.",
      });
      fetchInitiationDetails();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Action Failed",
        description: err.message
      });
    } finally {
      setActionLoading(false);
    }
  };

  const handleMarkSignedOff = async () => {
    setActionLoading(true);
    try {
      const { error } = await supabase
        .from('business_initiations')
        .update({ 
          status: 'signed_off', 
          inherent_risk_signed_off: true,
          updated_at: new Date() 
        })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Sign-off Complete",
        description: "Initiative successfully signed off.",
      });
      fetchInitiationDetails();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Action Failed",
        description: err.message
      });
    } finally {
      setActionLoading(false);
    }
  };

  const handleCreateArchitectureReview = async () => {
    setActionLoading(true);
    try {
      // Create new Architecture Review record
      const payload = {
        org_id: tenant.id,
        initiation_id: id,
        title: `Arch Review: ${initiation.title}`,
        status: 'draft',
        attributes: { 
            source: 'business_initiation',
            risk_rating: initiation.inherent_risk_rating
        },
        created_by: user.id
      };

      const { data, error } = await supabase
        .from('architecture_reviews')
        .insert([payload])
        .select()
        .single();

      if (error) throw error;

      toast({
        title: "Review Created",
        description: "Redirecting to Architecture Review workspace...",
      });

      // Navigate to the new review page (assuming route exists or will be created)
      navigate(`/dashboard/architecture-review/${data.id}`);

    } catch (err) {
       console.error(err);
       toast({
        variant: "destructive",
        title: "Creation Failed",
        description: err.message
      });
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center space-y-4">
           <Loader2 className="h-10 w-10 animate-spin text-blue-600 mx-auto" />
           <p className="text-slate-500 font-medium">Loading initiation details...</p>
        </div>
      </div>
    );
  }

  if (error || !initiation) {
    return (
      <div className="max-w-4xl mx-auto py-12 px-4 text-center">
        <div className="bg-red-50 text-red-800 p-6 rounded-2xl border border-red-100 max-w-md mx-auto">
          <AlertTriangle className="h-10 w-10 mx-auto mb-3 text-red-600" />
          <h3 className="text-lg font-bold mb-1">Error Loading Initiation</h3>
          <p className="text-sm opacity-90 mb-4">{error || "Record not found."}</p>
          <Button variant="outline" onClick={() => navigate('/dashboard/initiation')} className="bg-white border-red-200 text-red-700 hover:bg-red-50">
             Return to List
          </Button>
        </div>
      </div>
    );
  }

  const isHighRisk = ['High', 'Very High', 'Critical'].includes(initiation.inherent_risk_rating);
  const canEdit = initiation.status === 'draft' || initiation.status === 'in_review'; // Simple logic
  const isSignedOff = initiation.status === 'signed_off' || initiation.status === 'approved';

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      
      {/* --- Breadcrumb / Nav --- */}
      <div className="flex items-center gap-2 text-sm text-slate-500 mb-2">
         <Link to="/dashboard/initiation" className="hover:text-blue-600 flex items-center gap-1 transition-colors">
            <ArrowLeft className="h-4 w-4" /> Back to List
         </Link>
         <span className="text-slate-300">/</span>
         <span className="text-slate-900 font-medium truncate max-w-[200px]">{initiation.title}</span>
      </div>

      {/* --- Header --- */}
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
             <h1 className="text-3xl font-bold text-slate-900 tracking-tight">{initiation.title}</h1>
             <Badge variant={initiation.status === 'draft' ? 'secondary' : 'default'} className="capitalize">
               {initiation.status?.replace('_', ' ')}
             </Badge>
          </div>
          <p className="text-slate-500 max-w-2xl text-lg leading-relaxed">
            {initiation.description || "No description provided."}
          </p>
          <div className="flex flex-wrap items-center gap-4 mt-4 text-sm text-slate-500">
             <div className="flex items-center gap-1.5">
                <Calendar className="h-4 w-4 text-slate-400" />
                Created {format(new Date(initiation.created_at), 'MMM d, yyyy')}
             </div>
             <div className="flex items-center gap-1.5">
                <User className="h-4 w-4 text-slate-400" />
                Owner: {userRole || 'Unknown'}
             </div>
          </div>
        </div>

        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row gap-3 min-w-[200px] justify-end">
           {initiation.status === 'draft' && (
             <AlertDialog>
               <AlertDialogTrigger asChild>
                 <Button className="w-full sm:w-auto gap-2 bg-blue-600 hover:bg-blue-700">
                   <Send className="h-4 w-4" /> Request Review
                 </Button>
               </AlertDialogTrigger>
               <AlertDialogContent>
                 <AlertDialogHeader>
                   <AlertDialogTitle>Request Sign-Off?</AlertDialogTitle>
                   <AlertDialogDescription>
                     This will lock the initiation details and notify the risk team for review. You won't be able to make major changes until reviewed.
                   </AlertDialogDescription>
                 </AlertDialogHeader>
                 <AlertDialogFooter>
                   <AlertDialogCancel>Cancel</AlertDialogCancel>
                   <AlertDialogAction onClick={handleRequestSignOff} disabled={actionLoading}>
                     {actionLoading ? 'Submitting...' : 'Submit for Review'}
                   </AlertDialogAction>
                 </AlertDialogFooter>
               </AlertDialogContent>
             </AlertDialog>
           )}

           {initiation.status === 'in_review' && (
             <AlertDialog>
               <AlertDialogTrigger asChild>
                 <Button variant="outline" className="w-full sm:w-auto gap-2 border-green-200 bg-green-50 text-green-700 hover:bg-green-100 hover:text-green-800">
                   <CheckCircle2 className="h-4 w-4" /> Approve & Sign-Off
                 </Button>
               </AlertDialogTrigger>
               <AlertDialogContent>
                 <AlertDialogHeader>
                   <AlertDialogTitle>Confirm Sign-Off</AlertDialogTitle>
                   <AlertDialogDescription>
                     You are confirming that the inherent risk rating is accurate. This will mark the initiation as approved.
                   </AlertDialogDescription>
                 </AlertDialogHeader>
                 <AlertDialogFooter>
                   <AlertDialogCancel>Cancel</AlertDialogCancel>
                   <AlertDialogAction onClick={handleMarkSignedOff} className="bg-green-600 hover:bg-green-700" disabled={actionLoading}>
                     {actionLoading ? 'Processing...' : 'Confirm Sign-Off'}
                   </AlertDialogAction>
                 </AlertDialogFooter>
               </AlertDialogContent>
             </AlertDialog>
           )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* --- Main Details Column --- */}
        <div className="lg:col-span-2 space-y-6">
           <Card className="rounded-2xl border-slate-200 shadow-sm overflow-hidden">
             <CardHeader className="bg-slate-50/50 border-b border-slate-100 pb-4">
                <CardTitle className="text-lg flex items-center gap-2">
                   <FileText className="h-5 w-5 text-blue-600" />
                   Initiative Details
                </CardTitle>
             </CardHeader>
             <CardContent className="p-0">
               <div className="p-6 space-y-1">
                 <DetailRow label="Application Type" value={initiation.application_type?.replace(/_/g, ' ') || 'N/A'} className="capitalize" />
                 <DetailRow 
                    label="Hosting Model" 
                    value={initiation.hosting?.replace('_', ' ')} 
                    className="capitalize" 
                    icon={Globe}
                 />
                 <DetailRow 
                    label="Connectivity" 
                    value={initiation.internet_facing ? 'Public Internet Facing' : 'Internal Only'} 
                    icon={initiation.internet_facing ? Globe : Lock}
                    className={initiation.internet_facing ? "text-amber-600" : "text-slate-600"}
                 />
                 <DetailRow 
                    label="Vendor Involvement" 
                    value={initiation.vendor_involved ? 'Yes' : 'No'} 
                    icon={Building2}
                 />
                 {initiation.vendor_involved && (
                    <DetailRow label="Vendor Name" value={initiation.vendor_name} className="bg-blue-50/30" />
                 )}
                 <DetailRow label="Cost Code" value={initiation.cost_code} />
                 <DetailRow 
                    label="Est. Budget" 
                    value={initiation.estimated_budget ? `$${initiation.estimated_budget.toLocaleString()}` : '-'} 
                    icon={DollarSign}
                 />
               </div>
               
               {initiation.data_tags && initiation.data_tags.length > 0 && (
                 <div className="px-6 pb-6 pt-2 border-t border-slate-50">
                    <p className="text-sm font-medium text-slate-500 mb-3">Data Classification Tags</p>
                    <div className="flex flex-wrap gap-2">
                       {initiation.data_tags.map(tag => (
                         <Badge key={tag} variant="secondary" className="bg-slate-100 text-slate-600 hover:bg-slate-200 font-normal">
                            {tag}
                         </Badge>
                       ))}
                    </div>
                 </div>
               )}
             </CardContent>
           </Card>

           {/* --- Audit Trail / Comments (Placeholder) --- */}
           <Card className="rounded-2xl border-slate-200 shadow-sm">
             <CardHeader className="pb-3">
               <CardTitle className="text-base">Discussion & Audit Trail</CardTitle>
             </CardHeader>
             <CardContent>
                <div className="bg-slate-50 rounded-lg p-8 text-center border border-dashed border-slate-200">
                   <p className="text-sm text-slate-500 italic">No comments yet. Start a discussion or log an event.</p>
                </div>
                <div className="mt-4 flex gap-2">
                   <Textarea placeholder="Add a comment or note..." className="min-h-[80px] text-sm resize-none" />
                   <Button variant="ghost" size="icon" className="h-[80px] w-12 border border-slate-200">
                      <Send className="h-4 w-4 text-slate-400" />
                   </Button>
                </div>
             </CardContent>
           </Card>
        </div>

        {/* --- Side Column: Risk Gate --- */}
        <div className="space-y-6">
           <Card className={cn(
             "rounded-2xl shadow-sm border-l-4", 
             isHighRisk ? "border-l-orange-500 border-slate-200" : "border-l-green-500 border-slate-200"
           )}>
              <CardHeader className="pb-2">
                 <CardTitle className="flex items-center justify-between text-base">
                    <span>Risk Gate</span>
                    <ShieldAlert className={cn("h-5 w-5", isHighRisk ? "text-orange-500" : "text-green-500")} />
                 </CardTitle>
                 <CardDescription>Inherent Risk Assessment</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-4">
                 
                 <div className="flex flex-col items-center justify-center py-4 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Risk Rating</span>
                    <div className="scale-125">
                       <RiskBadge rating={initiation.inherent_risk_rating} />
                    </div>
                 </div>

                 <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                       <span className="text-slate-500">Sign-Off Status</span>
                       {initiation.inherent_risk_signed_off ? (
                          <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-none px-2 py-0.5 flex gap-1">
                             <CheckCircle2 className="h-3 w-3" /> Signed Off
                          </Badge>
                       ) : (
                          <Badge variant="outline" className="text-slate-400 font-normal">Pending</Badge>
                       )}
                    </div>
                    
                    {/* Architecture Review CTA */}
                    {isHighRisk && (
                       <div className="mt-6 pt-6 border-t border-slate-100 animate-in fade-in slide-in-from-bottom-2">
                          <div className="bg-orange-50 p-3 rounded-lg border border-orange-100 mb-3">
                             <p className="text-xs text-orange-800 leading-relaxed">
                                <span className="font-bold">Recommendation:</span> High inherent risk triggers a mandatory Architecture Review.
                             </p>
                          </div>
                          
                          <Button 
                             onClick={handleCreateArchitectureReview} 
                             className="w-full bg-slate-900 hover:bg-slate-800 text-white shadow-lg shadow-slate-900/10"
                             disabled={actionLoading}
                          >
                             {actionLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <GitBranch className="h-4 w-4 mr-2" />}
                             Start Architecture Review
                          </Button>
                       </div>
                    )}
                 </div>

              </CardContent>
              {isSignedOff && (
                  <CardFooter className="bg-slate-50/50 border-t border-slate-100 py-3">
                     <p className="text-xs text-center w-full text-slate-400">
                        Locked for edits due to sign-off.
                     </p>
                  </CardFooter>
              )}
           </Card>

           {/* Additional Metadata Card */}
           <Card className="rounded-2xl border-slate-200 shadow-sm">
              <CardHeader className="pb-2">
                 <CardTitle className="text-sm font-semibold text-slate-500 uppercase tracking-wider">System Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-xs text-slate-500">
                 <div className="flex justify-between">
                    <span>Initiation ID</span>
                    <span className="font-mono text-slate-700 truncate max-w-[120px]" title={id}>{id.split('-')[0]}...</span>
                 </div>
                 <div className="flex justify-between">
                    <span>Tenant ID</span>
                    <span className="font-mono text-slate-700 truncate max-w-[120px]">{tenant.id.split('-')[0]}...</span>
                 </div>
                 <div className="flex justify-between">
                    <span>Last Updated</span>
                    <span>{initiation.updated_at ? format(new Date(initiation.updated_at), 'MMM d, HH:mm') : '-'}</span>
                 </div>
              </CardContent>
           </Card>
        </div>

      </div>

    </div>
  );
}
