
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { GitBranch, History, RotateCcw, Copy, Download, FileText, ArrowLeftRight, User, AlertCircle, RefreshCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { threatModelService } from '@/services/threatModelService';
import { versionControlService } from '@/services/versionControlService';
import VersionTimeline from '@/components/versions/VersionTimeline';
import VersionDiffView from '@/components/versions/VersionDiffView';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Spinner } from '@/components/ui/spinner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const ModelVersions = () => {
  const [models, setModels] = useState([]);
  const [selectedModelId, setSelectedModelId] = useState(null);
  const [versions, setVersions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  // State for compare/view
  const [selectedVersion, setSelectedVersion] = useState(null);
  const [compareMode, setCompareMode] = useState(false);
  const [compareSelection, setCompareSelection] = useState([]);
  const [diffData, setDiffData] = useState(null);

  // Restore Dialog
  const [restoreDialogOpen, setRestoreDialogOpen] = useState(false);
  const [restoreAsNew, setRestoreAsNew] = useState(false);
  const [branchName, setBranchName] = useState('');

  const { toast } = useToast();

  useEffect(() => {
    loadModels();
  }, []);

  useEffect(() => {
    if (selectedModelId) {
      loadVersions(selectedModelId);
    } else {
      setVersions([]);
      setSelectedVersion(null);
    }
  }, [selectedModelId]);

  useEffect(() => {
    if (compareSelection.length === 2) {
      runComparison();
    } else {
      setDiffData(null);
    }
  }, [compareSelection]);

  const loadModels = async () => {
    try {
      const data = await threatModelService.listModels();
      setModels(data);
      if (data.length > 0) setSelectedModelId(data[0].id);
    } catch (error) {
      console.error(error);
      toast({ title: "Failed to load models", description: error.message, variant: "destructive" });
    }
  };

  const loadVersions = async (id) => {
    setLoading(true);
    setError(null);
    try {
      const data = await versionControlService.getVersions(id);
      setVersions(data);
      if (data.length > 0) {
        setSelectedVersion(data[0]);
      } else {
        setSelectedVersion(null);
      }
    } catch (error) {
      console.error("Error loading versions:", error);
      setError("Failed to load version history. Please check your network connection or try again.");
      toast({ 
        title: "Error", 
        description: "Could not fetch version history. See console for details.", 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCompareSelect = (id) => {
    if (compareSelection.includes(id)) {
      setCompareSelection(prev => prev.filter(v => v !== id));
    } else {
      if (compareSelection.length >= 2) {
        setCompareSelection([compareSelection[1], id]); // Keep last one + new one
      } else {
        setCompareSelection(prev => [...prev, id]);
      }
    }
  };

  const runComparison = async () => {
    try {
      const diff = await versionControlService.compareVersions(compareSelection[1], compareSelection[0]);
      setDiffData(diff);
    } catch (error) {
      console.error("Comparison error:", error);
      toast({ title: "Comparison failed", description: error.message, variant: "destructive" });
    }
  };

  const handleRestore = async () => {
    if (!selectedVersion) return;
    try {
      await versionControlService.restoreVersion(selectedVersion.id, restoreAsNew, branchName);
      toast({ 
        title: restoreAsNew ? "Branched successfully" : "Restored successfully",
        description: restoreAsNew ? `Created model "${branchName}"` : "Model state reverted."
      });
      setRestoreDialogOpen(false);
      setBranchName('');
      if (restoreAsNew) {
         loadModels(); // Refresh list to show new branch
      } else {
        // Just reload versions/UI if needed, typically we stay on current page
      }
    } catch (error) {
      toast({ title: "Action failed", description: error.message, variant: "destructive" });
    }
  };

  return (
    <div className="h-[calc(100vh-theme(spacing.20))] flex flex-col gap-6">
      <Helmet>
        <title>Version Control | CreativeCyber</title>
      </Helmet>

      {/* Header / Toolbar */}
      <div className="flex items-center justify-between bg-white p-4 rounded-lg border shadow-sm shrink-0">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-brand-100 rounded-lg">
             <GitBranch className="w-6 h-6 text-brand-600" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Version Control</h1>
            <p className="text-sm text-slate-500">Track, compare, and restore model snapshots.</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Select value={selectedModelId || ''} onValueChange={setSelectedModelId}>
            <SelectTrigger className="w-[250px]">
              <SelectValue placeholder="Select Threat Model" />
            </SelectTrigger>
            <SelectContent>
              {models.map(m => (
                <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Button 
            variant={compareMode ? "secondary" : "outline"}
            onClick={() => {
              setCompareMode(!compareMode);
              setCompareSelection([]);
              setDiffData(null);
            }}
            disabled={loading || versions.length < 2}
          >
            <ArrowLeftRight className="w-4 h-4 mr-2" />
            {compareMode ? "Exit Compare" : "Compare Versions"}
          </Button>
        </div>
      </div>

      <div className="flex-1 flex gap-6 min-h-0 overflow-hidden">
        {/* Left: Timeline List */}
        <div className="w-80 shrink-0 flex flex-col">
          {error ? (
            <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-700 text-sm">
              <p className="flex items-center gap-2 font-semibold mb-2">
                <AlertCircle className="w-4 h-4" /> Error
              </p>
              {error}
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-3 w-full bg-white border-red-200 hover:bg-red-50 text-red-700"
                onClick={() => loadVersions(selectedModelId)}
              >
                <RefreshCcw className="w-3 h-3 mr-2" /> Retry
              </Button>
            </div>
          ) : loading ? (
             <div className="flex-1 flex items-center justify-center bg-white border rounded-lg">
                <Spinner />
             </div>
          ) : versions.length === 0 ? (
             <div className="p-8 text-center bg-slate-50 border rounded-lg h-full flex flex-col items-center justify-center text-slate-500">
               <History className="w-10 h-10 opacity-30 mb-3" />
               <p>No versions found for this model.</p>
             </div>
          ) : (
            <VersionTimeline 
              versions={versions} 
              selectedVersion={selectedVersion}
              onSelect={setSelectedVersion}
              compareMode={compareMode}
              onCompareSelect={handleCompareSelect}
              selectedForCompare={compareSelection}
            />
          )}
        </div>

        {/* Right: Detail View or Diff View */}
        <div className="flex-1 bg-white rounded-lg border p-6 overflow-hidden flex flex-col shadow-sm relative">
          {loading && (
             <div className="absolute inset-0 bg-white/80 z-10 flex items-center justify-center">
               <Spinner />
             </div>
          )}

          {compareMode ? (
             <VersionDiffView diffData={diffData} />
          ) : selectedVersion ? (
             <div className="h-full flex flex-col animate-in fade-in duration-300">
               <div className="flex justify-between items-start mb-6 pb-6 border-b">
                 <div>
                   <div className="flex items-center gap-3 mb-2">
                     <h2 className="text-2xl font-bold text-slate-900">{selectedVersion.version_tag}</h2>
                     <span className="text-sm text-slate-500 bg-slate-100 px-2 py-1 rounded">
                       {new Date(selectedVersion.created_at).toLocaleString()}
                     </span>
                   </div>
                   <p className="text-slate-600">{selectedVersion.description}</p>
                 </div>
                 <div className="flex gap-2">
                   <Button variant="outline" onClick={() => {
                     setRestoreAsNew(true);
                     setRestoreDialogOpen(true);
                   }}>
                     <Copy className="w-4 h-4 mr-2" /> Branch from Here
                   </Button>
                   <Button variant="destructive" onClick={() => {
                     setRestoreAsNew(false);
                     setRestoreDialogOpen(true);
                   }}>
                     <RotateCcw className="w-4 h-4 mr-2" /> Restore
                   </Button>
                 </div>
               </div>

               <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                 <div className="p-4 bg-slate-50 rounded-lg border text-center">
                    <div className="text-2xl font-bold text-slate-800">{selectedVersion.snapshot_data.elements?.length || 0}</div>
                    <div className="text-xs text-slate-500 uppercase tracking-wide">Elements</div>
                 </div>
                 <div className="p-4 bg-slate-50 rounded-lg border text-center">
                    <div className="text-2xl font-bold text-slate-800">{selectedVersion.snapshot_data.connections?.length || 0}</div>
                    <div className="text-xs text-slate-500 uppercase tracking-wide">Flows</div>
                 </div>
                 <div className="p-4 bg-slate-50 rounded-lg border text-center">
                    <div className="text-2xl font-bold text-slate-800">{selectedVersion.snapshot_data.metadata?.threatCount || '-'}</div>
                    <div className="text-xs text-slate-500 uppercase tracking-wide">Threats</div>
                 </div>
                 <div className="p-4 bg-slate-50 rounded-lg border text-center">
                    <div className="text-2xl font-bold text-slate-800 flex justify-center"><User className="w-6 h-6" /></div>
                    <div className="text-xs text-slate-500 uppercase tracking-wide">Author</div>
                 </div>
               </div>
               
               <div className="flex-1 flex items-center justify-center bg-slate-50 rounded-lg border border-dashed">
                 <div className="text-center text-slate-400">
                   <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
                   <p>Snapshot Data Preview Available in JSON Export</p>
                   <Button variant="link" className="text-brand-600">
                     <Download className="w-4 h-4 mr-2" /> Download Snapshot JSON
                   </Button>
                 </div>
               </div>
             </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-slate-400">
              <div className="text-center">
                <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Select a version from the timeline to view details.</p>
              </div>
            </div>
          )}
        </div>
      </div>

      <Dialog open={restoreDialogOpen} onOpenChange={setRestoreDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{restoreAsNew ? "Branch New Model" : "Confirm Restore"}</DialogTitle>
            <DialogDescription>
              {restoreAsNew 
                ? "This will create a completely new model based on this version state. The original model will remain unchanged."
                : "Are you sure? This will overwrite the current live model state with this snapshot. Any unsaved changes will be lost."}
            </DialogDescription>
          </DialogHeader>

          {restoreAsNew && (
            <div className="py-4">
               <label className="text-sm font-medium mb-2 block">New Model Name</label>
               <Input 
                 value={branchName} 
                 onChange={e => setBranchName(e.target.value)} 
                 placeholder={`Branch of ${selectedVersion?.version_tag}`}
               />
            </div>
          )}

          <DialogFooter>
            <Button variant="ghost" onClick={() => setRestoreDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleRestore} className={restoreAsNew ? "bg-brand-600" : "bg-red-600 hover:bg-red-700"}>
              {restoreAsNew ? "Create Branch" : "Restore Version"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ModelVersions;
