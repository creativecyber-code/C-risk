import React, { useState, useEffect } from 'react';
import { Outlet, NavLink, useNavigate, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  FileInput, 
  BookOpen, 
  ShieldCheck, 
  Settings, 
  LogOut, 
  Menu, 
  UserCircle,
  Building2,
  Users,
  Activity,
  FileText,
  Server
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';
import NotificationCenter from '@/components/notifications/NotificationCenter';
import { LOGO_URL, COMPANY_NAME } from '@/lib/constants';
import { PLATFORM_ROLES } from '@/lib/rbac_constants';

const DashboardLayout = () => {
  const { user, signOut, profile, isInitialized } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [role, setRole] = useState(null);

  useEffect(() => {
    if (isInitialized && profile) {
      setRole(profile.role);
    }
  }, [isInitialized, profile]);

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/login');
    } catch (error) {
      toast({
        title: "Error signing out",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const isPlatformAdmin = role === PLATFORM_ROLES.PLATFORM_ADMIN || role === PLATFORM_ROLES.SECURITY_OFFICER;

  // --- Sidebar Configurations ---
  const tenantNavItems = [
    { title: "Overview", href: "/dashboard", icon: LayoutDashboard, end: true },
    { title: "Business Initiation", href: "/dashboard/initiation", icon: FileInput },
    { title: "Architecture Review", href: "/dashboard/architecture-review", icon: BookOpen },
    { title: "Security & Audit", href: "/dashboard/security", icon: ShieldCheck },
    { title: "Administration", href: "/dashboard/admin", icon: Settings }
  ];

  const platformNavItems = [
    { title: "Platform Overview", href: "/dashboard/platform", icon: Activity, end: true },
    { title: "Tenants", href: "/dashboard/platform/tenants", icon: Building2 },
    { title: "Platform Users", href: "/dashboard/platform/users", icon: Users },
    { title: "Audit Logs", href: "/dashboard/platform/audit", icon: FileText },
    { title: "System Health", href: "/dashboard/platform/health", icon: Server },
    { title: "Global Settings", href: "/dashboard/platform/settings", icon: Settings }
  ];

  const activeNavItems = isPlatformAdmin ? platformNavItems : tenantNavItems;

  const NavContent = () => (
    <div className="flex flex-col h-full bg-slate-900 text-slate-100">
      <div className="p-6 flex items-center gap-3">
        <img 
          src={LOGO_URL} 
          alt={COMPANY_NAME} 
          className="h-8 w-auto object-contain"
        />
        <div className="flex flex-col">
          <span className="font-bold text-lg tracking-tight text-white leading-none">{COMPANY_NAME}</span>
          <span className="text-[10px] text-slate-400 uppercase tracking-wider mt-1">
            {isPlatformAdmin ? 'Platform Admin' : 'Tenant Portal'}
          </span>
        </div>
      </div>

      <ScrollArea className="flex-1 px-4 py-2">
        <nav className="space-y-1">
          {activeNavItems.map((item) => (
            <NavLink
              key={item.href}
              to={item.href}
              end={item.end}
              onClick={() => setIsMobileOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-md transition-all duration-200 text-sm font-medium ${
                  isActive
                    ? "bg-blue-600 text-white shadow-md shadow-blue-900/20"
                    : "text-slate-400 hover:text-white hover:bg-white/10"
                }`
              }
            >
              <item.icon className="h-4 w-4" />
              {item.title}
            </NavLink>
          ))}
        </nav>
      </ScrollArea>

      <div className="p-4 bg-slate-950/50">
        <div className="flex items-center gap-3 mb-4 px-2">
          <Avatar className="h-9 w-9 border border-slate-700">
             <AvatarImage src={profile?.avatar_url} />
             <AvatarFallback className="bg-slate-800 text-slate-200">
                {user?.email?.charAt(0).toUpperCase()}
             </AvatarFallback>
          </Avatar>
          <div className="flex-1 overflow-hidden">
            <p className="text-sm font-medium truncate text-white">{profile?.full_name || 'User'}</p>
            <p className="text-xs text-slate-500 truncate">{user?.email}</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-2">
            <Button 
                variant="ghost" 
                size="sm" 
                className="w-full justify-start text-slate-400 hover:text-white hover:bg-white/10"
                onClick={() => navigate('/dashboard/profile')}
            >
                <UserCircle className="h-4 w-4 mr-2" />
                Profile
            </Button>
            <Button 
                variant="ghost" 
                size="sm" 
                className="w-full justify-start text-slate-400 hover:text-red-400 hover:bg-red-950/30"
                onClick={handleSignOut}
            >
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
            </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-slate-50">
      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-64 border-r bg-slate-900 fixed h-full z-30">
        <NavContent />
      </aside>

      {/* Main Content */}
      <div className="flex-1 md:ml-64 flex flex-col min-h-screen transition-all duration-300">
        <header className="sticky top-0 z-20 h-16 bg-white/80 backdrop-blur-md border-b px-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
                <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
                    <SheetTrigger asChild className="md:hidden">
                        <Button variant="ghost" size="icon">
                            <Menu className="h-5 w-5" />
                        </Button>
                    </SheetTrigger>
                    <SheetContent side="left" className="p-0 w-72 bg-slate-900 border-r-slate-800 text-white">
                        <NavContent />
                    </SheetContent>
                </Sheet>
                <div className="hidden md:block">
                  <h2 className="text-sm font-semibold text-slate-800">
                     {activeNavItems.find(i => 
                        i.end ? location.pathname === i.href : location.pathname.startsWith(i.href)
                     )?.title || 'Dashboard'}
                  </h2>
                </div>
            </div>

            <div className="flex items-center gap-2">
                <NotificationCenter />
            </div>
        </header>

        <main className="flex-1 p-6 overflow-x-hidden">
           <div className="mx-auto max-w-7xl animate-in fade-in slide-in-from-bottom-2 duration-500">
              <Outlet />
           </div>
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;