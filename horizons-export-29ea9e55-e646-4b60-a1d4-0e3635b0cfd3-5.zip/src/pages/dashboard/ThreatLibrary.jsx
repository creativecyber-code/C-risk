import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { 
  Search, Book, Filter, Plus, LayoutGrid, List as ListIcon, 
  TrendingUp, Download, Globe, Lock, ShieldCheck, FileText 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { threatLibraryService } from '@/services/threatLibraryService';
import ThreatPatternCard from '@/components/library/ThreatPatternCard';
import PatternDetailsSheet from '@/components/library/PatternDetailsSheet';
import { useToast } from '@/components/ui/use-toast';

const ThreatLibrary = () => {
  const [patterns, setPatterns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState('grid');
  const [selectedPattern, setSelectedPattern] = useState(null);
  
  // Filters
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [severityFilter, setSeverityFilter] = useState('All');
  const [industryFilter, setIndustryFilter] = useState('All');

  const { toast } = useToast();

  useEffect(() => {
    fetchPatterns();
  }, [categoryFilter, severityFilter, industryFilter]); // Re-fetch on filter change

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      fetchPatterns();
    }, 500);
    return () => clearTimeout(timer);
  }, [search]);

  const fetchPatterns = async () => {
    setLoading(true);
    try {
      const data = await threatLibraryService.getPatterns({
        search,
        category: categoryFilter,
        severity: severityFilter,
        industry: industryFilter
      });
      setPatterns(data);
    } catch (error) {
      toast({
        title: "Error fetching library",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleImport = (pattern) => {
    toast({
      title: "Pattern Selected",
      description: `Opened import dialog for "${pattern.title}". Select a target model.`,
    });
    // In a real app, this would open a modal to select which Threat Model to add to.
    // For this demo, we just show the intent.
  };

  return (
    <div className="space-y-6">
      <Helmet>
        <title>Threat Library | CreativeCyber</title>
      </Helmet>

      {/* Hero / Header */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-xl p-8 text-white relative overflow-hidden shadow-lg">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Book className="w-48 h-48" />
        </div>
        <div className="relative z-10 max-w-2xl">
          <h1 className="text-3xl font-bold font-heading mb-2">Threat Library & Knowledge Base</h1>
          <p className="text-slate-300 mb-6">
            Discover, adapt, and deploy standardized threat patterns to your models. 
            Access a community-driven repository of security knowledge.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
             <div className="relative flex-1">
               <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
               <Input 
                 placeholder="Search patterns, CVEs, or attack vectors..." 
                 className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-slate-400 focus:bg-white/20"
                 value={search}
                 onChange={(e) => setSearch(e.target.value)}
               />
             </div>
             <Button className="bg-brand-500 hover:bg-brand-600 text-white">
               <Plus className="w-4 h-4 mr-2" /> New Pattern
             </Button>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Patterns', value: '1,240', icon: Book, color: 'bg-blue-100 text-blue-600' },
          { label: 'New This Week', value: '+12', icon: TrendingUp, color: 'bg-green-100 text-green-600' },
          { label: 'Active Contribs', value: '85', icon: Globe, color: 'bg-purple-100 text-purple-600' },
          { label: 'Org Custom', value: '24', icon: Lock, color: 'bg-orange-100 text-orange-600' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-4 rounded-lg border shadow-sm flex items-center gap-4">
            <div className={`p-3 rounded-full ${stat.color}`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">{stat.value}</div>
              <div className="text-xs text-slate-500 font-medium uppercase tracking-wide">{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      <Tabs defaultValue="browse" className="w-full">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
          <TabsList>
            <TabsTrigger value="browse">Browse Patterns</TabsTrigger>
            <TabsTrigger value="knowledge">Knowledge Base</TabsTrigger>
            <TabsTrigger value="my-patterns">My Organization</TabsTrigger>
          </TabsList>

          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setViewMode('grid')} className={viewMode === 'grid' ? 'bg-slate-100' : ''}>
              <LayoutGrid className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={() => setViewMode('list')} className={viewMode === 'list' ? 'bg-slate-100' : ''}>
              <ListIcon className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" /> Export
            </Button>
          </div>
        </div>

        {/* Filters Panel */}
        <div className="bg-white p-4 rounded-lg border mb-6 flex flex-wrap gap-4 items-center">
          <div className="flex items-center gap-2 text-sm font-medium text-slate-600 mr-2">
            <Filter className="w-4 h-4" /> Filters:
          </div>
          
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[160px] h-9">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Categories</SelectItem>
              <SelectItem value="Spoofing">Spoofing</SelectItem>
              <SelectItem value="Tampering">Tampering</SelectItem>
              <SelectItem value="Repudiation">Repudiation</SelectItem>
              <SelectItem value="Information Disclosure">Info Disclosure</SelectItem>
              <SelectItem value="Denial of Service">DoS</SelectItem>
              <SelectItem value="Elevation of Privilege">Elevation of Privilege</SelectItem>
            </SelectContent>
          </Select>

          <Select value={severityFilter} onValueChange={setSeverityFilter}>
            <SelectTrigger className="w-[160px] h-9">
              <SelectValue placeholder="Severity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Severities</SelectItem>
              <SelectItem value="Critical">Critical</SelectItem>
              <SelectItem value="High">High</SelectItem>
              <SelectItem value="Medium">Medium</SelectItem>
              <SelectItem value="Low">Low</SelectItem>
            </SelectContent>
          </Select>

          <Select value={industryFilter} onValueChange={setIndustryFilter}>
            <SelectTrigger className="w-[160px] h-9">
              <SelectValue placeholder="Industry" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Industries</SelectItem>
              <SelectItem value="Finance">Finance</SelectItem>
              <SelectItem value="Healthcare">Healthcare</SelectItem>
              <SelectItem value="Retail">Retail</SelectItem>
              <SelectItem value="Tech">Technology</SelectItem>
            </SelectContent>
          </Select>

          {loading && <span className="ml-auto text-sm text-slate-400 animate-pulse">Updating...</span>}
        </div>

        <TabsContent value="browse">
          <div className={`grid gap-6 ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'}`}>
            {patterns.map(pattern => (
              <ThreatPatternCard 
                key={pattern.id} 
                pattern={pattern} 
                onViewDetails={setSelectedPattern}
                onImport={handleImport}
              />
            ))}
            {patterns.length === 0 && !loading && (
               <div className="col-span-full py-20 text-center">
                 <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-100 mb-4">
                   <Search className="w-8 h-8 text-slate-400" />
                 </div>
                 <h3 className="text-lg font-medium text-slate-900">No patterns found</h3>
                 <p className="text-slate-500">Try adjusting your filters or search query.</p>
               </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="knowledge">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Knowledge Base Content Placeholder */}
            {[1,2,3].map(i => (
              <div key={i} className="bg-white p-6 rounded-lg border hover:shadow-md transition-all cursor-pointer group">
                <div className="flex items-center gap-2 mb-3">
                  <Badge variant="secondary" className="bg-blue-50 text-blue-700">Methodology</Badge>
                  <span className="text-xs text-slate-400">5 min read</span>
                </div>
                <h3 className="font-bold text-lg text-slate-900 group-hover:text-brand-600 mb-2">
                  Understanding STRIDE in Modern Microservices
                </h3>
                <p className="text-slate-500 text-sm mb-4 line-clamp-3">
                  A comprehensive guide on how to apply the STRIDE threat modeling methodology to distributed microservice architectures...
                </p>
                <div className="flex items-center text-sm font-medium text-brand-600">
                  Read Article <ArrowRight className="w-4 h-4 ml-1 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="my-patterns">
           <div className="text-center py-20 bg-slate-50 border border-dashed rounded-lg">
             <Lock className="w-12 h-12 text-slate-300 mx-auto mb-4" />
             <h3 className="text-lg font-medium text-slate-900">Private Pattern Repository</h3>
             <p className="text-slate-500 max-w-md mx-auto mb-6">
               Your organization hasn't created any custom patterns yet. Custom patterns are only visible to your team.
             </p>
             <Button>Create First Pattern</Button>
           </div>
        </TabsContent>
      </Tabs>

      <PatternDetailsSheet 
        pattern={selectedPattern} 
        open={!!selectedPattern} 
        onOpenChange={(open) => !open && setSelectedPattern(null)}
        onImport={handleImport}
      />
    </div>
  );
};

// Simple icon for placeholder
const ArrowRight = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M5 12h14" />
    <path d="m12 5 7 7-7 7" />
  </svg>
);

export default ThreatLibrary;