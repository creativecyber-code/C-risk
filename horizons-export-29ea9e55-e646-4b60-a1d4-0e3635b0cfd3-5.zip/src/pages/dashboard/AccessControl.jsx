
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ShieldAlert } from 'lucide-react';

const AccessControl = ({ orgId }) => {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Role-Based Access Control (RBAC)</CardTitle>
          <CardDescription>Configure roles and permissions for your organization.</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <ShieldAlert className="h-4 w-4" />
            <AlertTitle>Configuration Required</AlertTitle>
            <AlertDescription>
              Advanced RBAC settings are currently managed via the User Management tab. 
              Granular permission editing will be available in a future update.
            </AlertDescription>
          </Alert>
          
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <div className="p-4 border rounded-lg bg-slate-50">
              <h3 className="font-semibold mb-2">Admin</h3>
              <p className="text-sm text-slate-600">Full access to all resources and settings.</p>
            </div>
            <div className="p-4 border rounded-lg bg-slate-50">
              <h3 className="font-semibold mb-2">Editor</h3>
              <p className="text-sm text-slate-600">Can create and edit content, but cannot manage users.</p>
            </div>
            <div className="p-4 border rounded-lg bg-slate-50">
              <h3 className="font-semibold mb-2">Viewer</h3>
              <p className="text-sm text-slate-600">Read-only access to published resources.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AccessControl;
