
import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { FileCheck, CheckCircle2, XCircle, Clock } from 'lucide-react';
import { collaborationService } from '@/services/collaborationService';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useToast } from '@/components/ui/use-toast';

const ApprovalDashboard = () => {
  const [approvals, setApprovals] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadApprovals();
  }, []);

  const loadApprovals = async () => {
    try {
      const data = await collaborationService.getPendingApprovals();
      setApprovals(data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleReview = async (id, status) => {
    try {
      await collaborationService.reviewApproval(id, status, status === 'Approved' ? 'Looks good' : 'Needs changes');
      toast({ title: `Request ${status}` });
      loadApprovals(); // Refresh list
    } catch (e) {
      toast({ title: "Action failed", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-6">
      <Helmet><title>Approval Dashboard | CreativeCyber</title></Helmet>
      
      <div className="flex items-center gap-3">
         <div className="p-3 bg-indigo-100 text-indigo-700 rounded-lg">
           <FileCheck className="w-6 h-6" />
         </div>
         <div>
           <h1 className="text-2xl font-bold text-slate-900">Approvals</h1>
           <p className="text-slate-500">Manage risk acceptance and mitigation plan requests.</p>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         {/* Stats */}
         <Card>
            <CardContent className="p-6 flex items-center gap-4">
               <div className="p-2 rounded-full bg-yellow-100 text-yellow-600"><Clock className="w-6 h-6"/></div>
               <div>
                  <p className="text-sm text-slate-500 font-medium">Pending</p>
                  <p className="text-2xl font-bold">{approvals.length}</p>
               </div>
            </CardContent>
         </Card>
         <Card>
            <CardContent className="p-6 flex items-center gap-4">
               <div className="p-2 rounded-full bg-green-100 text-green-600"><CheckCircle2 className="w-6 h-6"/></div>
               <div>
                  <p className="text-sm text-slate-500 font-medium">Approved (Month)</p>
                  <p className="text-2xl font-bold">12</p>
               </div>
            </CardContent>
         </Card>
         <Card>
            <CardContent className="p-6 flex items-center gap-4">
               <div className="p-2 rounded-full bg-red-100 text-red-600"><XCircle className="w-6 h-6"/></div>
               <div>
                  <p className="text-sm text-slate-500 font-medium">Rejected (Month)</p>
                  <p className="text-2xl font-bold">3</p>
               </div>
            </CardContent>
         </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>Pending Requests</CardTitle></CardHeader>
        <CardContent>
           {loading ? <div className="p-8 text-center text-slate-500">Loading...</div> : 
            approvals.length === 0 ? (
               <div className="p-12 text-center border-2 border-dashed rounded-lg">
                  <FileCheck className="w-12 h-12 text-slate-300 mx-auto mb-4"/>
                  <h3 className="text-lg font-medium text-slate-900">All caught up!</h3>
                  <p className="text-slate-500">No pending approval requests found.</p>
               </div>
            ) : (
               <div className="space-y-4">
                  {approvals.map(req => (
                     <div key={req.id} className="p-4 border rounded-lg bg-white flex flex-col md:flex-row gap-4 justify-between items-start md:items-center shadow-sm">
                        <div className="space-y-1">
                           <div className="flex items-center gap-2">
                              <Badge>{req.type}</Badge>
                              <span className="text-sm text-slate-500">for</span>
                              <span className="font-semibold text-sm">{req.threat_assessments?.title}</span>
                           </div>
                           <p className="text-sm text-slate-600 max-w-xl italic">"{req.justification}"</p>
                           <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
                              <Avatar className="w-4 h-4"><AvatarFallback>U</AvatarFallback></Avatar>
                              Requested by {req.requester?.full_name || 'Unknown'}
                              <span>•</span>
                              {new Date(req.created_at).toLocaleDateString()}
                           </div>
                        </div>
                        <div className="flex gap-2">
                           <Button size="sm" variant="default" className="bg-green-600 hover:bg-green-700" onClick={() => handleReview(req.id, 'Approved')}>Approve</Button>
                           <Button size="sm" variant="outline" className="text-red-600 hover:bg-red-50 hover:text-red-700" onClick={() => handleReview(req.id, 'Rejected')}>Reject</Button>
                        </div>
                     </div>
                  ))}
               </div>
            )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ApprovalDashboard;
