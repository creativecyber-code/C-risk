
import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Filter, Check, Trash2, Search, SlidersHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { notificationService } from '@/services/notificationService';
import NotificationItem from '@/components/notifications/NotificationItem';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const NotificationHistory = () => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    if (user?.id) {
      loadNotifications();
    }
  }, [user?.id]);

  const loadNotifications = async () => {
    setLoading(true);
    try {
      // Pass user.id and a larger limit
      const data = await notificationService.getNotifications(user.id, 50);
      setNotifications(data || []);
    } catch (error) {
      console.error(error);
      toast({ title: "Failed to load history", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAllRead = async () => {
    if (!user?.id) return;
    await notificationService.markAllAsRead(user.id);
    toast({ title: "All notifications marked as read" });
    loadNotifications();
  };

  // Logic for filtering locally since we fetched a batch
  const filtered = notifications.filter(n => {
    const matchesType = filterType === 'ALL' || n.type === filterType;
    const matchesSearch = n.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         n.message.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  });

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <Helmet>
        <title>Notifications History | CreativeCyber</title>
      </Helmet>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Notifications</h1>
          <p className="text-slate-500">View and manage your system alerts and team updates.</p>
        </div>
        <div className="flex gap-2">
           <Button variant="outline" onClick={handleMarkAllRead}>
             <Check className="w-4 h-4 mr-2" /> Mark all read
           </Button>
           <Button variant="outline" onClick={() => window.location.href='/dashboard/settings/notifications'}>
             <SlidersHorizontal className="w-4 h-4 mr-2" /> Preferences
           </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3 border-b bg-slate-50/50">
          <div className="flex flex-col md:flex-row gap-4 justify-between">
            <div className="relative w-full md:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
              <Input 
                placeholder="Search notifications..." 
                className="pl-9 bg-white"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-slate-400" />
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-[180px] bg-white">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All Types</SelectItem>
                  <SelectItem value="THREAT">Threats</SelectItem>
                  <SelectItem value="RISK">Risk Score</SelectItem>
                  <SelectItem value="COMPLIANCE">Compliance</SelectItem>
                  <SelectItem value="INTEGRATION">Integrations</SelectItem>
                  <SelectItem value="TEAM">Team</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-8 text-center text-slate-500">Loading notifications...</div>
          ) : filtered.length === 0 ? (
            <div className="p-12 text-center flex flex-col items-center">
               <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                 <Check className="w-6 h-6 text-slate-400" />
               </div>
               <h3 className="text-lg font-medium text-slate-900">All caught up!</h3>
               <p className="text-slate-500">No notifications found matching your filters.</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filtered.map(n => (
                <NotificationItem key={n.id} notification={n} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default NotificationHistory;
