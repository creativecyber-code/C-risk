
import React, { useState, useEffect } from 'react';
import { remediationService } from '@/services/remediationService';
import { integrationService } from '@/services/integrationService';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import RemediationPlanTable from '@/components/remediation/RemediationPlanTable';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import IntegrationPushModal from '@/components/remediation/IntegrationPushModal';
import { generateRemediationReport } from '@/utils/pdfExport';
import { Download, Share2, Loader2, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';

const RemediationPlan = () => {
  const [threats, setThreats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedThreats, setSelectedThreats] = useState([]);
  const [isPushModalOpen, setIsPushModalOpen] = useState(false);
  const [threatsToPush, setThreatsToPush] = useState([]); 
  
  const { toast } = useToast();

  useEffect(() => {
    fetchData();
    setupRealtimeListeners();

    return () => {
      supabase.channel('remediation-plan-sync').unsubscribe();
    };
  }, []);

  const setupRealtimeListeners = () => {
    supabase.channel('remediation-plan-sync')
      .on(
        'postgres_changes', 
        { event: '*', schema: 'public', table: 'threat_assessments' },
        (payload) => {
          console.log('Real-time threat update:', payload);
          // Small delay to allow DB joins to settle if necessary
          setTimeout(() => fetchData(true), 500);
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'threat_models' },
        (payload) => {
          console.log('Real-time model update:', payload);
          setTimeout(() => fetchData(true), 500);
        }
      )
      .subscribe();
  };

  const fetchData = async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    else setLoading(true);

    try {
      const data = await remediationService.getAllThreats();
      setThreats(data);
    } catch (error) {
      console.error(error);
      toast({ 
        title: "Error loading threats", 
        description: "Failed to sync with database.", 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleSelectionChange = (ids) => {
    const selected = threats.filter(t => ids.includes(t.id));
    setSelectedThreats(selected);
  };

  const handleCloseThreat = async (id) => {
    try {
      await remediationService.updateThreatStatus(id, 'Resolved');
      toast({ title: "Threat Resolved", description: "Threat status updated successfully." });
      // No need to manually fetch, real-time listener will catch the update
    } catch (error) {
      toast({ title: "Update failed", variant: "destructive" });
    }
  };

  const handlePushClick = (threatsToPushArray) => {
    setThreatsToPush(threatsToPushArray);
    setIsPushModalOpen(true);
  };

  const handlePushSuccess = (results) => {
    setIsPushModalOpen(false);
    // Listener will catch update, but we can optimistically toast
    toast({ 
      title: "Integration Sync", 
      description: `Synced ${results.success} threats successfully.` 
    });
  };

  const handleExportPDF = () => {
    generateRemediationReport(threats);
    toast({ title: "Report Generated", description: "Download started." });
  };

  if (loading && !refreshing && threats.length === 0) {
     return (
       <div className="flex flex-col items-center justify-center p-10 space-y-3">
         <Loader2 className="w-8 h-8 animate-spin text-brand-600" />
         <p className="text-slate-500">Syncing threats from all models...</p>
       </div>
     );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
           <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
             Threat Inventory
             {refreshing && <RefreshCw className="w-3 h-3 animate-spin text-slate-400" />}
           </h2>
           <p className="text-sm text-slate-500">Manage, resolve, and sync identified threats across {new Set(threats.map(t => t.model_name)).size} models.</p>
        </div>
        <div className="flex gap-2">
           {selectedThreats.length > 0 && (
              <Button onClick={() => handlePushClick(selectedThreats)} className="bg-indigo-600 hover:bg-indigo-700 text-white">
                 <Share2 className="w-4 h-4 mr-2" /> Push Selected ({selectedThreats.length})
              </Button>
           )}
           <Button variant="outline" onClick={handleExportPDF}>
              <Download className="w-4 h-4 mr-2" /> Export Report
           </Button>
        </div>
      </div>

      <RemediationPlanTable 
        threats={threats}
        onCloseThreat={handleCloseThreat}
        onPushThreat={(tArray) => handlePushClick(tArray)}
        onSelectionChange={handleSelectionChange}
      />

      <Dialog open={isPushModalOpen} onOpenChange={setIsPushModalOpen}>
        <DialogContent className="sm:max-w-md">
           <IntegrationPushModal 
              selectedThreats={threatsToPush}
              onClose={() => setIsPushModalOpen(false)}
              onSuccess={handlePushSuccess}
           />
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default RemediationPlan;
