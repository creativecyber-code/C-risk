
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, FileCheck, Library, History } from 'lucide-react';

const Compliance = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // Determine active tab based on current path
  const currentTab = location.pathname.split('/').pop();
  const activeValue = ['overview', 'controls', 'audit'].includes(currentTab) 
    ? currentTab 
    : 'overview';

  return (
    <div className="space-y-6">
      <Helmet>
        <title>Compliance & Controls | CreativeCyber</title>
      </Helmet>

      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold font-heading text-slate-900">Compliance & Controls</h1>
          <p className="text-slate-500">Manage internal controls, audit trails, and compliance mappings.</p>
        </div>
      </div>

      <Tabs value={activeValue} onValueChange={(val) => navigate(val)} className="w-full">
        <TabsList className="grid w-full grid-cols-3 lg:w-[600px]">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            Overview & Mapping
          </TabsTrigger>
          <TabsTrigger value="controls" className="flex items-center gap-2">
            <Library className="w-4 h-4" />
            Control Library
          </TabsTrigger>
          <TabsTrigger value="audit" className="flex items-center gap-2">
            <History className="w-4 h-4" />
            Audit Trail
          </TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="mt-6">
        <Outlet />
      </div>
    </div>
  );
};

export default Compliance;
