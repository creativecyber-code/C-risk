
import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Activity, Shield, AlertTriangle, CheckCircle, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Overview() {
  const { tenant, user } = useAuth();

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">Dashboard</h1>
        <p className="text-slate-500">
          Welcome back, {user?.user_metadata?.full_name || 'User'}. Here's what's happening in {tenant?.name || 'your organization'}.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Risks</CardTitle>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">
              +2 from last month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Audits</CardTitle>
            <Shield className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">
              1 pending review
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">System Health</CardTitle>
            <Activity className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">98.2%</div>
            <p className="text-xs text-muted-foreground">
              +0.1% uptime
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Compliance</CardTitle>
            <CheckCircle className="h-4 w-4 text-indigo-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">B+</div>
            <p className="text-xs text-muted-foreground">
              Last assessed 2 days ago
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>
              Latest actions performed across your tenant environment.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
               <div className="flex items-center">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">New Project Created</p>
                    <p className="text-sm text-muted-foreground">
                      "Payment Gateway Integration" was initiated.
                    </p>
                  </div>
                  <div className="ml-auto font-medium text-xs text-slate-500">2h ago</div>
               </div>
               <div className="flex items-center">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">Policy Updated</p>
                    <p className="text-sm text-muted-foreground">
                      Access Control Policy v2.1 approved.
                    </p>
                  </div>
                  <div className="ml-auto font-medium text-xs text-slate-500">5h ago</div>
               </div>
               <div className="flex items-center">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">Risk Assessment Completed</p>
                    <p className="text-sm text-muted-foreground">
                      Cloud Storage Review completed with 0 critical findings.
                    </p>
                  </div>
                  <div className="ml-auto font-medium text-xs text-slate-500">1d ago</div>
               </div>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-3">
           <CardHeader>
             <CardTitle>Quick Actions</CardTitle>
             <CardDescription>Common tasks for your role.</CardDescription>
           </CardHeader>
           <CardContent className="space-y-4">
              <Link to="/dashboard/initiation">
                <Button variant="outline" className="w-full justify-between group">
                   Start Business Initiation
                   <ArrowRight className="h-4 w-4 opacity-50 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Link to="/dashboard/architecture-review">
                <Button variant="outline" className="w-full justify-between group">
                   Review Architecture
                   <ArrowRight className="h-4 w-4 opacity-50 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Link to="/dashboard/audit-workspace">
                <Button variant="outline" className="w-full justify-between group">
                   Open Audit Workspace
                   <ArrowRight className="h-4 w-4 opacity-50 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
           </CardContent>
        </Card>
      </div>
    </div>
  );
}
