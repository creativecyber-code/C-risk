
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/AuthContext';
import { businessInitService } from '@/services/businessInitService';
import { useToast } from '@/components/ui/use-toast';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardFooter
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import {
  Plus,
  Calendar,
  FolderOpen,
  Loader2,
  ArrowRight,
  Sparkles,
  Laptop,
  Smartphone,
  Server,
  Monitor
} from 'lucide-react';
import { format } from 'date-fns';

export default function BusinessInitiationPage() {
  const { tenant, user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  // Data States
  const [initiations, setInitiations] = useState([]);
  const [scenarios, setScenarios] = useState([]);
  
  // Loading States
  const [loading, setLoading] = useState(true);
  const [loadingScenarios, setLoadingScenarios] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  
  // Modal States
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [formState, setFormState] = useState({
    title: '',
    description: '',
    selectedScenarioId: 'custom',
    applicationType: 'web_application'
  });

  useEffect(() => {
    if (tenant?.id) {
      loadInitiations();
      loadScenarios();
    }
  }, [tenant?.id]);

  const loadInitiations = async () => {
    setLoading(true);
    try {
      const data = await businessInitService.listInitiations(tenant.id);
      setInitiations(data || []);
    } catch (error) {
      console.error("Failed to load initiations", error);
      toast({
        title: "Error",
        description: "Failed to load business initiatives.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadScenarios = async () => {
    setLoadingScenarios(true);
    try {
      const data = await businessInitService.getScenarioLibrary(tenant.id);
      setScenarios(data || []);
    } catch (error) {
      console.error("Failed to load scenario library", error);
      // Fail silently for UX, but log error
    } finally {
      setLoadingScenarios(false);
    }
  };

  const handleScenarioChange = (value) => {
    setFormState(prev => ({ ...prev, selectedScenarioId: value }));
    
    if (value !== 'custom') {
      const scenario = scenarios.find(s => s.id === value);
      if (scenario) {
        setFormState(prev => ({
          ...prev,
          title: prev.title || scenario.name, // Only autofill if empty
          description: scenario.description || ''
        }));
      }
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!formState.title.trim()) return;

    setIsCreating(true);
    try {
      // Determine values based on scenario or custom
      let riskRating = 'Low';
      let tags = [];
      let scenarioId = null;

      if (formState.selectedScenarioId !== 'custom') {
        const scenario = scenarios.find(s => s.id === formState.selectedScenarioId);
        if (scenario) {
          riskRating = scenario.risk_level || 'Low';
          tags = scenario.compliance_tags || [];
          scenarioId = scenario.id;
        }
      }

      const newInit = await businessInitService.createInitiation({
        org_id: tenant.id,
        title: formState.title,
        description: formState.description,
        created_by: user.id,
        status: 'draft',
        intake_mode: 'manual',
        scenario_id: scenarioId,
        application_type: formState.applicationType,
        hosting: 'cloud', // Fixed: Changed from 'cloud_native' to 'cloud' to satisfy DB constraint
        internet_facing: false,
        data_tags: tags,
        vendor_involved: false,
        inherent_risk_signed_off: false,
        inherent_risk_rating: riskRating
      });

      toast({
        title: "Success",
        description: "New initiative created successfully."
      });
      
      setIsCreateOpen(false);
      setFormState({ 
        title: '', 
        description: '', 
        selectedScenarioId: 'custom',
        applicationType: 'web_application'
      });
      navigate(`/dashboard/initiation/${newInit.id}`);
      
    } catch (error) {
      console.error("Create error", error);
      toast({
        title: "Error",
        description: error.message || "Failed to create initiative.",
        variant: "destructive"
      });
    } finally {
      setIsCreating(false);
    }
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'draft': return 'bg-slate-100 text-slate-700 border-slate-200';
      case 'in_review': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'signed_off': return 'bg-green-50 text-green-700 border-green-200';
      default: return 'bg-slate-100 text-slate-600';
    }
  };

  const getAppTypeIcon = (type) => {
    switch(type) {
      case 'mobile_application': return <Smartphone className="h-3 w-3" />;
      case 'api_service': return <Server className="h-3 w-3" />;
      case 'desktop_application': return <Monitor className="h-3 w-3" />;
      default: return <Laptop className="h-3 w-3" />;
    }
  };

  const formatAppType = (type) => {
    return type?.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') || 'Unknown';
  };

  return (
    <div className="space-y-6 pb-12">
      <Helmet>
        <title>Business Initiation | CyberWorkbench</title>
      </Helmet>

      {/* Breadcrumb */}
      <div className="px-1">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/dashboard">Dashboard</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Business Initiation</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-6">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Business Initiation</h1>
          <p className="text-slate-500 text-lg">
            Manage new project intakes and risk assessments.
          </p>
        </div>
        <div className="flex items-center gap-2">
           <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
             <DialogTrigger asChild>
               <Button className="shadow-lg shadow-blue-900/20">
                 <Plus className="mr-2 h-4 w-4" /> New Initiative
               </Button>
             </DialogTrigger>
             <DialogContent className="sm:max-w-[500px]">
               <DialogHeader>
                 <DialogTitle>Start New Initiative</DialogTitle>
                 <DialogDescription>
                   Choose a template or start from scratch to assess risks.
                 </DialogDescription>
               </DialogHeader>
               <form onSubmit={handleCreate} className="space-y-4 py-4">
                 
                 <div className="space-y-2">
                   <Label htmlFor="scenario">Scenario Template</Label>
                   <Select 
                      value={formState.selectedScenarioId} 
                      onValueChange={handleScenarioChange}
                      disabled={loadingScenarios}
                   >
                      <SelectTrigger>
                        <SelectValue placeholder={loadingScenarios ? "Loading templates..." : "Select a scenario (Optional)"} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="custom">
                          <span className="font-medium">Custom (Blank)</span>
                        </SelectItem>
                        {scenarios.map(scenario => (
                          <SelectItem key={scenario.id} value={scenario.id}>
                            {scenario.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                   </Select>
                   {formState.selectedScenarioId !== 'custom' && (
                      <div className="flex items-center gap-2 text-xs text-blue-600 bg-blue-50 p-2 rounded border border-blue-100">
                        <Sparkles className="h-3 w-3" />
                        <span>Pre-configured with risk profile: {scenarios.find(s => s.id === formState.selectedScenarioId)?.risk_level}</span>
                      </div>
                   )}
                 </div>

                 <div className="space-y-2">
                   <Label htmlFor="title">Project Title <span className="text-red-500">*</span></Label>
                   <Input 
                     id="title" 
                     placeholder="e.g. Customer Portal Redesign" 
                     value={formState.title}
                     onChange={(e) => setFormState(prev => ({ ...prev, title: e.target.value }))}
                     autoFocus
                   />
                 </div>

                 <div className="space-y-2">
                   <Label htmlFor="appType">Application Type <span className="text-red-500">*</span></Label>
                   <Select 
                      value={formState.applicationType} 
                      onValueChange={(val) => setFormState(prev => ({ ...prev, applicationType: val }))}
                   >
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="web_application">Web Application</SelectItem>
                        <SelectItem value="mobile_application">Mobile Application</SelectItem>
                        <SelectItem value="api_service">API Service</SelectItem>
                        <SelectItem value="desktop_application">Desktop Application</SelectItem>
                        <SelectItem value="background_service">Background Service</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                   </Select>
                 </div>

                 <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea 
                      id="description"
                      placeholder="Briefly describe the project..."
                      className="resize-none"
                      rows={3}
                      value={formState.description}
                      onChange={(e) => setFormState(prev => ({ ...prev, description: e.target.value }))}
                    />
                 </div>

                 <DialogFooter>
                   <Button type="button" variant="outline" onClick={() => setIsCreateOpen(false)}>Cancel</Button>
                   <Button type="submit" disabled={!formState.title.trim() || isCreating}>
                     {isCreating && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                     Create & Continue
                   </Button>
                 </DialogFooter>
               </form>
             </DialogContent>
           </Dialog>
        </div>
      </div>

      {/* Content */}
      {loading ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="bg-white border-slate-200">
              <CardHeader className="pb-3">
                <Skeleton className="h-4 w-1/3 mb-2" />
                <Skeleton className="h-6 w-3/4" />
              </CardHeader>
              <CardContent className="pb-3">
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-2/3" />
              </CardContent>
              <CardFooter>
                <Skeleton className="h-8 w-24" />
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : initiations.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 px-4 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50">
          <div className="bg-white p-4 rounded-full shadow-sm mb-4">
            <FolderOpen className="h-8 w-8 text-slate-400" />
          </div>
          <h3 className="text-lg font-semibold text-slate-900 mb-1">No initiatives yet</h3>
          <p className="text-slate-500 text-center max-w-sm mb-6">
            Start by creating a new business initiative to assess risks and compliance requirements early.
          </p>
          <Button onClick={() => setIsCreateOpen(true)} variant="outline">
            <Plus className="mr-2 h-4 w-4" /> Create your first initiative
          </Button>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {initiations.map((init) => (
            <Link key={init.id} to={`/dashboard/initiation/${init.id}`} className="block group h-full">
              <Card className="h-full border-slate-200 shadow-sm hover:shadow-md hover:border-blue-300 transition-all duration-200 flex flex-col">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start gap-4 mb-1">
                    <Badge variant="outline" className={getStatusColor(init.status)}>
                      {init.status?.replace('_', ' ')}
                    </Badge>
                    {init.inherent_risk_rating && (
                       <Badge variant="outline" className={`text-xs ${
                         init.inherent_risk_rating === 'Critical' ? 'text-red-700 bg-red-50 border-red-200' :
                         init.inherent_risk_rating === 'High' ? 'text-orange-700 bg-orange-50 border-orange-200' :
                         'text-slate-600 border-slate-200'
                       }`}>
                         Risk: {init.inherent_risk_rating}
                       </Badge>
                    )}
                  </div>
                  <CardTitle className="text-lg leading-tight group-hover:text-blue-700 transition-colors">
                    {init.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex-1 pb-3">
                  <p className="text-sm text-slate-500 line-clamp-2 mb-3">
                    {init.description || "No description provided."}
                  </p>
                  
                  <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 p-2 rounded w-fit">
                    {getAppTypeIcon(init.application_type)}
                    <span>{formatAppType(init.application_type)}</span>
                  </div>

                  <div className="mt-4 flex items-center gap-2 text-xs text-slate-400">
                    <Calendar className="h-3 w-3" />
                    <span>Updated {format(new Date(init.updated_at), 'MMM d, yyyy')}</span>
                  </div>
                </CardContent>
                <CardFooter className="pt-3 border-t border-slate-50 bg-slate-50/30">
                  <span className="text-sm font-medium text-blue-600 flex items-center group-hover:underline">
                    View Details <ArrowRight className="ml-1 h-3 w-3" />
                  </span>
                </CardFooter>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
