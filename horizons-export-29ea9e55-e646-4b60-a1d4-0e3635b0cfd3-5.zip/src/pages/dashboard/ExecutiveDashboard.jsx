
import React, { useEffect, useState, useCallback, useRef } from 'react';
import { 
  ShieldAlert, 
  CheckCircle2, 
  FileText, 
  Activity, 
  RefreshCw, 
  Loader2, 
  TrendingUp,
  Clock,
  AlertTriangle,
  XCircle,
  Check
} from 'lucide-react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip, 
  Legend,
  CartesianGrid,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis
} from 'recharts';
import { formatDistanceToNow } from 'date-fns';

import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { businessInitService } from '@/services/businessInitService';
import { riskAssessmentService } from '@/services/riskAssessmentService';
import { decisionService } from '@/services/decisionService';

// --- Theme Config ---
// Optimized for lighter gradient (slate-800 to slate-900) while keeping premium feel
const THEME = {
  bg: "bg-gradient-to-br from-slate-800 via-slate-900 to-slate-950",
  cardBg: "bg-slate-800/40 backdrop-blur-md border-slate-700/50 hover:bg-slate-800/60 transition-colors",
  textPrimary: "text-slate-100",
  textSecondary: "text-slate-400",
  accentGold: "text-amber-400",
  accentBlue: "text-blue-400",
};

const COLORS = ['#ef4444', '#f97316', '#22c55e', '#3b82f6']; 
const HEATMAP_COLORS = { 'Critical': '#dc2626', 'High': '#ea580c', 'Medium': '#eab308', 'Low': '#22c55e' };

const ExecutiveDashboard = () => {
  const { user, profile, isInitialized } = useAuth();
  const { toast } = useToast();
  
  // --- State ---
  const [stats, setStats] = useState({ total: 0, highRisk: 0, pending: 0, approved: 0 });
  const [threatStats, setThreatStats] = useState({ totalOpen: 0, criticalCount: 0, byCategory: [], topThreats: [] });
  const [decisions, setDecisions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);
  
  const isMounted = useRef(false);

  // --- Data Loading ---
  const loadData = useCallback(async (isRefresh = false) => {
    const orgId = profile?.org_id || user?.user_metadata?.org_id;
    if (!orgId) return;
    
    if (isRefresh) setRefreshing(true);
    else setLoading(true);
    
    try {
      const [businessData, threats, pendingDecisions] = await Promise.all([
          businessInitService.getDashboardStats(orgId),
          riskAssessmentService.getOpenThreats(),
          decisionService.getPendingDecisions()
      ]);
      
      if (isMounted.current) {
        setStats(businessData);
        setDecisions(pendingDecisions);

        // Process Threats
        const categoryCounts = {};
        let criticalC = 0;
        (threats || []).forEach(t => {
            if (t.category) categoryCounts[t.category] = (categoryCounts[t.category] || 0) + 1;
            if (t.risk_score >= 8) criticalC++;
        });
        
        setThreatStats({
            totalOpen: (threats || []).length,
            criticalCount: criticalC,
            byCategory: Object.entries(categoryCounts).map(([name, value]) => ({ name, value })),
            topThreats: (threats || []).filter(t => t.risk_score >= 5).sort((a,b) => b.risk_score - a.risk_score).slice(0, 5) // High+ risks
        });

        setLastUpdated(new Date());
      }
    } catch (e) {
      console.error("Dashboard Load Error", e);
      // Silent fail or toast if critical
    } finally {
      if (isMounted.current) {
        setLoading(false);
        setRefreshing(false);
      }
    }
  }, [profile, user]);

  // --- Real-time Sync ---
  useEffect(() => {
    isMounted.current = true;
    const orgId = profile?.org_id || user?.user_metadata?.org_id;

    if (isInitialized && orgId) {
      loadData();

      const channel = supabase
        .channel(`exec-dash-premium-${orgId}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'business_applications', filter: `org_id=eq.${orgId}` }, 
            () => { setTimeout(() => isMounted.current && loadData(true), 1000); })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'threat_assessments' }, 
            () => { setTimeout(() => isMounted.current && loadData(true), 1000); })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'security_gates' }, 
            () => { setTimeout(() => isMounted.current && loadData(true), 1000); })
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
        isMounted.current = false;
      };
    }
  }, [isInitialized, profile, user, loadData]);

  // --- Handlers ---
  const handleDecision = async (item, action) => {
    toast({ title: "Processing...", description: `Submitting ${action} for ${item.title}` });
    const success = action === 'approve' 
        ? await decisionService.approveDecision(item)
        : await decisionService.rejectDecision(item);
    
    if (success) {
        toast({ title: "Success", description: `Decision ${action}d successfully.` });
        loadData(true);
    } else {
        toast({ title: "Error", description: "Operation failed.", variant: "destructive" });
    }
  };

  // --- UI Components ---
  const PremiumCard = ({ children, className }) => (
    <div className={`rounded-xl border border-slate-700/50 ${THEME.cardBg} shadow-lg ${className}`}>
        {children}
    </div>
  );

  const KPICard = ({ title, value, subtext, icon: Icon, trend }) => (
    <PremiumCard className="p-6 relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <Icon className="w-16 h-16 text-white" />
        </div>
        <div className="relative z-10">
            <p className="text-sm font-medium text-slate-400 mb-1">{title}</p>
            <h3 className="text-3xl font-bold text-white tracking-tight mb-2 flex items-end gap-2">
                {value}
                {trend && <span className="text-xs font-normal text-emerald-400 mb-1 flex items-center">{trend} <TrendingUp className="w-3 h-3 ml-0.5" /></span>}
            </h3>
            <p className="text-xs text-slate-500">{subtext}</p>
        </div>
        <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-purple-500 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500" />
    </PremiumCard>
  );

  if (!isInitialized || loading) {
    return (
        <div className={`flex items-center justify-center min-h-screen w-full ${THEME.bg}`}>
            <div className="flex flex-col items-center gap-4">
                <Loader2 className="h-12 w-12 text-blue-500 animate-spin" />
                <p className="text-slate-400 animate-pulse">Loading Executive Intelligence...</p>
            </div>
        </div>
    );
  }

  // Generate Dummy Heatmap Data if real data is sparse
  const heatMapData = threatStats.topThreats.length > 0 ? threatStats.topThreats.map((t, i) => ({
      x: (i * 10) + 10, 
      y: t.risk_score * 10, 
      z: 200, 
      name: t.title,
      risk: t.risk_score >= 8 ? 'Critical' : 'High'
  })) : [
     { x: 85, y: 90, z: 100, name: "Data Breach", risk: "Critical" },
     { x: 45, y: 60, z: 100, name: "System Outage", risk: "Medium" },
     { x: 70, y: 80, z: 100, name: "Insider Threat", risk: "High" },
     { x: 30, y: 40, z: 100, name: "Phishing", risk: "Low" }
  ];

  return (
    <div className={`min-h-screen w-full ${THEME.bg} text-slate-200 p-6 sm:p-8 space-y-6 font-sans selection:bg-blue-500/30 overflow-x-hidden flex flex-col`}>
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
                <h1 className="text-4xl font-bold text-white tracking-tight">
                    Security Command Center
                </h1>
                <p className="text-slate-400 mt-1 flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-amber-400" />
                    Real-time Risk Posture & Decision Support
                </p>
            </div>
            <div className="flex items-center gap-3">
                 <div className="text-right hidden sm:block">
                     <div className="text-xs text-slate-500 uppercase tracking-wider">Last Updated</div>
                     <div className="text-sm font-mono text-emerald-400">{lastUpdated?.toLocaleTimeString()}</div>
                 </div>
                 <Button variant="outline" size="icon" onClick={() => loadData(true)} disabled={refreshing} className="border-slate-700 bg-slate-800 hover:bg-slate-700 text-white">
                    <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
                 </Button>
            </div>
        </div>

        {/* Row 1: KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <KPICard 
                title="Risk Exposure" 
                value={threatStats.criticalCount > 0 ? "CRITICAL" : "MODERATE"} 
                subtext={`${threatStats.totalOpen} Active Threats Detected`}
                icon={AlertTriangle}
                trend={threatStats.criticalCount > 0 ? "+12%" : "-5%"}
            />
            <KPICard 
                title="Pending Decisions" 
                value={decisions.length} 
                subtext="Requires Executive Sign-off"
                icon={FileText}
            />
            <KPICard 
                title="Compliance Score" 
                value="92%" 
                subtext="Against RBI Master Directions"
                icon={CheckCircle2}
                trend="+2%"
            />
            <KPICard 
                title="Application Assets" 
                value={stats.total} 
                subtext={`${stats.pending} Onboarding Requests`}
                icon={Activity}
            />
        </div>

        {/* Row 2: Main Vis */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[450px]">
             {/* Heatmap */}
             <PremiumCard className="lg:col-span-2 p-6 flex flex-col h-full">
                 <div className="flex justify-between items-center mb-4">
                    <div>
                        <h3 className="text-lg font-semibold text-white">Risk Heatmap</h3>
                        <p className="text-sm text-slate-400">Impact vs Likelihood Analysis</p>
                    </div>
                    <Badge variant="outline" className="border-amber-500/50 text-amber-400 bg-amber-900/10">Live</Badge>
                 </div>
                 <div className="flex-1 min-h-0">
                    <ResponsiveContainer width="100%" height="100%">
                        <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis type="number" dataKey="x" name="Likelihood" unit="%" stroke="#94a3b8" />
                            <YAxis type="number" dataKey="y" name="Impact" unit="" stroke="#94a3b8" />
                            <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f1f5f9' }} />
                            <Scatter name="Risks" data={heatMapData} fill="#8884d8">
                                {heatMapData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={HEATMAP_COLORS[entry.risk] || '#8884d8'} />
                                ))}
                            </Scatter>
                        </ScatterChart>
                    </ResponsiveContainer>
                 </div>
             </PremiumCard>

             {/* Threat Distribution */}
             <PremiumCard className="p-6 flex flex-col h-full">
                 <h3 className="text-lg font-semibold text-white mb-2">Threat Distribution</h3>
                 <p className="text-sm text-slate-400 mb-4">By STRIDE Category</p>
                 <div className="flex-1 relative min-h-0">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={threatStats.byCategory.length > 0 ? threatStats.byCategory : [{name: 'None', value: 1}]}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={80}
                                paddingAngle={5}
                                dataKey="value"
                            >
                                {(threatStats.byCategory.length > 0 ? threatStats.byCategory : [{value:1}]).map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', borderRadius: '8px' }} />
                            <Legend verticalAlign="bottom" wrapperStyle={{ paddingTop: '20px' }}/>
                        </PieChart>
                    </ResponsiveContainer>
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none pb-8">
                        <div className="text-center">
                            <span className="text-3xl font-bold text-white block">{threatStats.totalOpen}</span>
                            <span className="text-xs text-slate-500 uppercase">Total</span>
                        </div>
                    </div>
                 </div>
             </PremiumCard>
        </div>

        {/* Row 3: Decision Widget */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pb-6">
            <PremiumCard className="p-0 overflow-hidden flex flex-col h-[400px]">
                <div className="p-6 border-b border-slate-700/50 flex justify-between items-center bg-slate-800/80">
                    <div>
                        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                            <FileText className="w-5 h-5 text-blue-400" /> Executive Decisions
                        </h3>
                        <p className="text-sm text-slate-400">Pending approvals across all modules</p>
                    </div>
                    <Badge className="bg-blue-600 hover:bg-blue-500 text-white">{decisions.length} Pending</Badge>
                </div>
                <div className="flex-1 overflow-y-auto">
                    {decisions.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-slate-500 p-8">
                            <CheckCircle2 className="w-12 h-12 mb-3 text-emerald-500/20" />
                            <p>All caught up! No pending decisions.</p>
                        </div>
                    ) : (
                        <div className="divide-y divide-slate-700/50">
                            {decisions.map((item) => (
                                <div key={item.id} className="p-5 hover:bg-slate-700/30 transition-colors flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-2 mb-1">
                                            <Badge variant="outline" className={`
                                                ${item.source === 'Security Gate' ? 'border-amber-500/30 text-amber-400 bg-amber-500/10' : 'border-blue-500/30 text-blue-400 bg-blue-500/10'}
                                            `}>
                                                {item.source}
                                            </Badge>
                                            <span className="text-xs text-slate-500">{formatDistanceToNow(new Date(item.date))} ago</span>
                                        </div>
                                        <h4 className="text-sm font-medium text-white">{item.title}</h4>
                                        <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">{item.description}</p>
                                    </div>
                                    <div className="flex items-center gap-2 w-full sm:w-auto">
                                        <Button size="sm" variant="ghost" className="flex-1 sm:flex-none text-red-400 hover:text-red-300 hover:bg-red-950/30" onClick={() => handleDecision(item, 'reject')}>
                                            <XCircle className="w-4 h-4 mr-1" /> Reject
                                        </Button>
                                        <Button size="sm" className="flex-1 sm:flex-none bg-emerald-600 hover:bg-emerald-500 text-white border-0" onClick={() => handleDecision(item, 'approve')}>
                                            <Check className="w-4 h-4 mr-1" /> Approve
                                        </Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </PremiumCard>

            <PremiumCard className="p-6 h-[400px]">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-lg font-semibold text-white">Remediation Roadmap</h3>
                    <Button variant="link" className="text-blue-400">View Timeline</Button>
                </div>
                <div className="space-y-6">
                    {/* Mock Remediation Items */}
                    {[
                        { title: 'API Gateway WAF Implementation', progress: 75, due: '2 Days', risk: 'Critical' },
                        { title: 'Database Encryption (AES-256)', progress: 40, due: '1 Week', risk: 'High' },
                        { title: 'MFA Enforcement for Admins', progress: 90, due: 'Today', risk: 'Critical' },
                        { title: 'Legacy Protocol Decommission', progress: 15, due: '2 Weeks', risk: 'Medium' },
                        { title: 'Vendor Security Assessment (Azure)', progress: 5, due: '3 Weeks', risk: 'Low' }
                    ].map((item, i) => (
                        <div key={i} className="group">
                            <div className="flex justify-between text-sm mb-2">
                                <span className="text-slate-200 font-medium">{item.title}</span>
                                <span className="text-slate-400">{item.progress}%</span>
                            </div>
                            <div className="h-2 bg-slate-700/50 rounded-full overflow-hidden">
                                <div 
                                    className={`h-full rounded-full transition-all duration-1000 ${
                                        item.risk === 'Critical' ? 'bg-red-500' : 
                                        item.risk === 'High' ? 'bg-orange-500' : 'bg-blue-500'
                                    }`} 
                                    style={{ width: `${item.progress}%` }} 
                                />
                            </div>
                            <div className="flex justify-between mt-1.5">
                                <span className={`text-[10px] px-1.5 rounded ${
                                    item.risk === 'Critical' ? 'bg-red-900/30 text-red-400' : 
                                    item.risk === 'High' ? 'bg-orange-900/30 text-orange-400' : 'bg-blue-900/30 text-blue-400'
                                }`}>{item.risk}</span>
                                <span className="text-[10px] text-slate-500 flex items-center">
                                    <Clock className="w-3 h-3 mr-1" /> Due: {item.due}
                                </span>
                            </div>
                        </div>
                    ))}
                </div>
            </PremiumCard>
        </div>
    </div>
  );
};

export default ExecutiveDashboard;
