
import React, { useState, useEffect } from 'react';
import { PlusCircle, Search, Filter, KeyRound as UserRoundPlus, Trash2, Mail, Edit, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { emailService } from '@/services/emailService';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Helmet } from 'react-helmet-async';

const userRoles = ['Admin', 'Architect', 'Auditor'];

const Team = () => {
  const [members, setMembers] = useState([]);
  const [invites, setInvites] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sendingInvite, setSendingInvite] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [newInviteEmail, setNewInviteEmail] = useState('');
  const [newInviteRole, setNewInviteRole] = useState('Architect');
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    fetchTeamData();
  }, [user]);

  const fetchTeamData = async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const { data: profileData, error: profileError } = await supabase
        .from('user_profiles')
        .select('org_id')
        .eq('id', user.id)
        .single();

      if (profileError) throw profileError;
      if (!profileData?.org_id) throw new Error("User organization not found.");

      // Fetch members
      const { data: membersData, error: membersError } = await supabase
        .from('user_profiles')
        .select('id, full_name, email, role')
        .eq('org_id', profileData.org_id);

      if (membersError) throw membersError;
      setMembers(membersData);

      // Fetch invites
      const { data: invitesData, error: invitesError } = await supabase
        .from('organization_invites')
        .select('id, email, role, created_at, expires_at')
        .eq('org_id', profileData.org_id);

      if (invitesError) throw invitesError;
      setInvites(invitesData);

    } catch (error) {
      toast({
        title: "Error fetching team data",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleInviteMember = async (e) => {
    e.preventDefault();
    if (!user) return;
    setSendingInvite(true);

    try {
      const { data: profileData } = await supabase
        .from('user_profiles')
        .select('org_id, organizations(name)')
        .eq('id', user.id)
        .single();

      const inviteToken = crypto.randomUUID();

      // 1. Insert into DB
      const { data, error } = await supabase
        .from('organization_invites')
        .insert({
          org_id: profileData.org_id,
          email: newInviteEmail,
          role: newInviteRole,
          token: inviteToken,
          expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
          created_by: user.id
        })
        .select()
        .single();

      if (error) throw error;

      // 2. Send Email
      await emailService.sendInvitation(
        newInviteEmail, 
        newInviteRole, 
        profileData.organizations?.name || 'CreativeCyber',
        inviteToken
      );

      setInvites([...invites, data]);
      toast({
        title: "Invitation Sent",
        description: `Email sent to ${newInviteEmail}.`,
        className: "bg-green-500 text-white border-none",
      });
      setNewInviteEmail('');
      setNewInviteRole('Architect');
      setIsInviteModalOpen(false);
    } catch (error) {
      toast({
        title: "Failed to send invitation",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSendingInvite(false);
    }
  };

  const handleDeleteInvite = async (inviteId) => {
    try {
      await supabase
        .from('organization_invites')
        .delete()
        .eq('id', inviteId);
      
      setInvites(invites.filter(invite => invite.id !== inviteId));
      toast({
        title: "Invitation Revoked",
        description: "The invitation has been successfully revoked.",
        className: "bg-green-500 text-white border-none",
      });
    } catch (error) {
      toast({
        title: "Failed to revoke invitation",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const filteredMembers = members.filter(member =>
    member.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredInvites = invites.filter(invite =>
    invite.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full min-h-[50vh]">
        <UserRoundPlus className="h-12 w-12 animate-pulse text-brand-600" />
        <p className="ml-3 text-lg text-gray-700">Loading team data...</p>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Team Management - CreativeCyber</title>
        <meta name="description" content="Manage your organization's team members and invitations on CreativeCyber." />
      </Helmet>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-gray-900 font-heading">Team Members</h1>
        <Dialog open={isInviteModalOpen} onOpenChange={setIsInviteModalOpen}>
          <DialogTrigger asChild>
            <Button className="bg-brand-600 hover:bg-brand-700 text-white rounded-lg shadow-md px-6 py-3 transition-all duration-200 ease-in-out">
              <PlusCircle className="mr-2 h-5 w-5" /> Invite Member
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Invite New Team Member</DialogTitle>
              <DialogDescription>
                Enter the email and assign a role to invite a new member to your organization.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleInviteMember} className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="email" className="text-right">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="name@example.com"
                  value={newInviteEmail}
                  onChange={(e) => setNewInviteEmail(e.target.value)}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="role" className="text-right">
                  Role
                </Label>
                <Select value={newInviteRole} onValueChange={setNewInviteRole}>
                  <SelectTrigger id="role" className="col-span-3">
                    <SelectValue placeholder="Select a role" />
                  </SelectTrigger>
                  <SelectContent>
                    {userRoles.map(role => (
                      <SelectItem key={role} value={role}>{role}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button type="submit" className="bg-brand-600 hover:bg-brand-700" disabled={sendingInvite}>
                   {sendingInvite ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                   Send Invitation
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex space-x-4 mb-6">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <Input
            placeholder="Search members or invites..."
            className="pl-10 pr-4 py-2 border rounded-lg focus:ring-brand-500 focus:border-brand-500 w-full"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-50 rounded-lg">
          <Filter className="mr-2 h-5 w-5" /> Filter
        </Button>
      </div>

      <Card className="mb-8 shadow-sm">
        <CardHeader>
          <CardTitle>Current Members ({filteredMembers.length})</CardTitle>
          <CardDescription>Users currently part of your organization.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredMembers.map((member) => (
                <TableRow key={member.id}>
                  <TableCell className="font-medium">{member.full_name}</TableCell>
                  <TableCell>{member.email || <span className="text-gray-400 italic">No email set</span>}</TableCell>
                  <TableCell>{member.role}</TableCell>
                  <TableCell className="text-right">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredMembers.length === 0 && (
            <p className="text-center text-gray-500 py-4">No current members match your search.</p>
          )}
        </CardContent>
      </Card>

      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>Pending Invitations ({filteredInvites.length})</CardTitle>
          <CardDescription>Invitations sent to potential team members.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Invited On</TableHead>
                <TableHead>Expires On</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInvites.map((invite) => (
                <TableRow key={invite.id}>
                  <TableCell className="font-medium">{invite.email}</TableCell>
                  <TableCell>{invite.role}</TableCell>
                  <TableCell>{new Date(invite.created_at).toLocaleDateString()}</TableCell>
                  <TableCell>{new Date(invite.expires_at).toLocaleDateString()}</TableCell>
                  <TableCell className="text-right">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => toast({ title: "Email Sent", description: `Re-sent invite to ${invite.email}` })}
                      className="text-brand-500 hover:text-brand-700"
                    >
                      <Mail className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleDeleteInvite(invite.id)} 
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredInvites.length === 0 && (
            <p className="text-center text-gray-500 py-4">No pending invitations match your search.</p>
          )}
        </CardContent>
      </Card>
    </>
  );
};

export default Team;
