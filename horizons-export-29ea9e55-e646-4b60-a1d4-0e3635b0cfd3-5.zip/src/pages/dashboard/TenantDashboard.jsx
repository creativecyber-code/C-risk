
import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { 
  Layout, ShieldCheck, FileCheck, Users, Settings, 
  LogOut, Menu, ChevronRight, Database
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

const TenantDashboard = () => {
  const { signOut, user } = useAuth();
  const location = useLocation();
  const orgName = "Acme Corp"; // In real app, get from profile

  const navItems = [
    { label: 'Overview', path: '/dashboard/overview', icon: Layout },
    { label: 'Initiatives', path: '/dashboard/initiation', icon: FileCheck },
    { label: 'Security & Audit', path: '/dashboard/security', icon: ShieldCheck },
    { label: 'IAM & RBAC', path: '/dashboard/admin?tab=users', icon: Users },
    { label: 'Master Data', path: '/dashboard/admin?tab=organization', icon: Database },
    { label: 'Settings', path: '/dashboard/admin', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex w-64 bg-white border-r border-slate-200 flex-col sticky top-0 h-screen">
        <div className="p-6 border-b border-slate-100">
          <div className="flex items-center gap-2 text-indigo-700 font-bold text-xl">
            <ShieldCheck className="h-6 w-6" /> C-RISK
          </div>
          <div className="mt-4 px-3 py-2 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2 overflow-hidden">
              <div className="h-6 w-6 rounded bg-indigo-100 flex items-center justify-center text-indigo-700 text-xs font-bold">
                {orgName.substring(0,2).toUpperCase()}
              </div>
              <span className="text-sm font-medium truncate">{orgName}</span>
            </div>
            <Settings className="h-3 w-3 text-slate-400 cursor-pointer hover:text-slate-600" />
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link 
                key={item.path} 
                to={item.path}
                className={`
                  flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors
                  ${isActive 
                    ? 'bg-indigo-50 text-indigo-700 shadow-sm' 
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }
                `}
              >
                <item.icon className={`h-4 w-4 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                {item.label}
                {isActive && <ChevronRight className="ml-auto h-3 w-3 opacity-50" />}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-100">
          <div className="flex items-center gap-3 px-2 mb-4">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="bg-indigo-100 text-indigo-700">U</AvatarFallback>
            </Avatar>
            <div className="overflow-hidden">
              <p className="text-sm font-medium truncate">{user?.email}</p>
              <p className="text-xs text-slate-500">Tenant Admin</p>
            </div>
          </div>
          <Button variant="outline" className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50 border-red-100" onClick={signOut}>
            <LogOut className="h-4 w-4 mr-2" /> Sign Out
          </Button>
        </div>
      </aside>

      {/* Mobile Header & Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="md:hidden h-16 bg-white border-b flex items-center justify-between px-4 sticky top-0 z-20">
          <span className="font-bold text-indigo-700">C-RISK</span>
          <Sheet>
            <SheetTrigger asChild>
              <Button size="icon" variant="ghost"><Menu className="h-5 w-5" /></Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0">
              {/* Mobile Menu Content (Simplified duplicate of sidebar) */}
              <div className="p-6">Menu</div>
            </SheetContent>
          </Sheet>
        </header>

        <main className="flex-1 p-6 md:p-8 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default TenantDashboard;
