
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle2, 
  Activity, 
  Lock,
  ArrowUpRight,
  Search,
  Users
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { COMPANY_NAME } from '@/lib/constants';
import LogoHeader from '@/components/LogoHeader';

const CyberOverviewPage = () => {
  return (
    <div className="space-y-6">
      <Helmet>
        <title>Dashboard Overview | {COMPANY_NAME}</title>
      </Helmet>

      {/* Header Section with Welcome & Logo for context if needed */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b pb-6">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Security Overview</h1>
          <p className="text-slate-500 text-lg">
            Real-time insights into your security posture and compliance status.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative hidden md:block">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500" />
            <Input 
              type="search" 
              placeholder="Search assets..." 
              className="pl-9 w-[250px] bg-white"
            />
          </div>
          <Button>
            <ArrowUpRight className="mr-2 h-4 w-4" /> Generate Report
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Security Score</CardTitle>
            <Shield className="h-4 w-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">82/100</div>
            <p className="text-xs text-slate-500 mt-1">
              +4% from last month
            </p>
            <Progress value={82} className="h-2 mt-3 bg-slate-100" indicatorClassName="bg-emerald-500" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Incidents</CardTitle>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">3</div>
            <p className="text-xs text-slate-500 mt-1">
              2 Moderate, 1 Low
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Compliance Rate</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">94%</div>
            <p className="text-xs text-slate-500 mt-1">
              ISO 27001, SOC 2
            </p>
            <Progress value={94} className="h-2 mt-3 bg-slate-100" indicatorClassName="bg-blue-600" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Protected Assets</CardTitle>
            <Lock className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">1,248</div>
            <p className="text-xs text-slate-500 mt-1">
              +12 new this week
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        
        {/* Main Chart Area */}
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Threat Landscape</CardTitle>
            <CardDescription>
              Threat detection volume over the last 30 days.
            </CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[300px] w-full flex items-center justify-center bg-slate-50 rounded-md border border-dashed border-slate-200">
               <div className="text-center text-slate-400">
                 <Activity className="h-10 w-10 mx-auto mb-2 opacity-50" />
                 <p>Chart Visualization Placeholder</p>
                 <span className="text-xs">Data loading...</span>
               </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity / Tasks */}
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>
              Latest security events and system actions.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              <div className="flex items-center">
                <div className="h-9 w-9 rounded-full bg-blue-100 flex items-center justify-center mr-3 border border-blue-200">
                  <Shield className="h-4 w-4 text-blue-600" />
                </div>
                <div className="ml-2 space-y-1">
                  <p className="text-sm font-medium leading-none">Policy Update</p>
                  <p className="text-xs text-slate-500">Access control policy refreshed</p>
                </div>
                <div className="ml-auto font-medium text-xs text-slate-400">2h ago</div>
              </div>

              <div className="flex items-center">
                <div className="h-9 w-9 rounded-full bg-amber-100 flex items-center justify-center mr-3 border border-amber-200">
                  <AlertTriangle className="h-4 w-4 text-amber-600" />
                </div>
                <div className="ml-2 space-y-1">
                  <p className="text-sm font-medium leading-none">Suspicious Login</p>
                  <p className="text-xs text-slate-500">Failed attempt from IP 192.168.1.1</p>
                </div>
                <div className="ml-auto font-medium text-xs text-slate-400">5h ago</div>
              </div>

              <div className="flex items-center">
                <div className="h-9 w-9 rounded-full bg-emerald-100 flex items-center justify-center mr-3 border border-emerald-200">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                </div>
                <div className="ml-2 space-y-1">
                  <p className="text-sm font-medium leading-none">Audit Completed</p>
                  <p className="text-xs text-slate-500">Monthly vulnerability scan finished</p>
                </div>
                <div className="ml-auto font-medium text-xs text-slate-400">1d ago</div>
              </div>
               <div className="flex items-center">
                <div className="h-9 w-9 rounded-full bg-purple-100 flex items-center justify-center mr-3 border border-purple-200">
                  <Users className="h-4 w-4 text-purple-600" />
                </div>
                <div className="ml-2 space-y-1">
                  <p className="text-sm font-medium leading-none">New User Added</p>
                  <p className="text-xs text-slate-500">j.smith@company.com invited</p>
                </div>
                <div className="ml-auto font-medium text-xs text-slate-400">1d ago</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CyberOverviewPage;
