
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusCircle, Edit, Trash2, Search, Filter, AlertCircle, Shield, FileText } from 'lucide-react';
import { Helmet } from 'react-helmet-async';

// Components
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import QuickStartWizard from '@/components/wizards/QuickStartWizard';

// Hooks & Services
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { threatModelService } from '@/services/threatModelService';

const ThreatModels = () => {
  const [models, setModels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedModelToDelete, setSelectedModelToDelete] = useState(null);
  const [wizardOpen, setWizardOpen] = useState(false);
  
  const { toast } = useToast();
  const navigate = useNavigate();
  const { user } = useAuth();

  const fetchModels = useCallback(async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    
    try {
      setLoading(true);
      const fetchedModels = await threatModelService.getModels();
      setModels(fetchedModels || []);
    } catch (error) {
      console.error("Error fetching models:", error);
      toast({
        title: "Error loading models",
        description: error.message || "Could not fetch your threat models.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [user, toast]);

  useEffect(() => {
    fetchModels();
  }, [fetchModels]);

  // Refresh when wizard closes
  useEffect(() => {
    if (!wizardOpen && user) {
      fetchModels();
    }
  }, [wizardOpen, user, fetchModels]);

  const handleDeleteModel = async () => {
    if (!selectedModelToDelete) return;
    
    try {
      await threatModelService.deleteModel(selectedModelToDelete.id);
      setModels(prev => prev.filter(model => model.id !== selectedModelToDelete.id));
      toast({
        title: "Model Deleted",
        description: `Threat model "${selectedModelToDelete.name}" has been deleted.`,
        className: "bg-green-500 text-white border-none",
      });
    } catch (error) {
      console.error("Error deleting model:", error);
      toast({
        title: "Deletion Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSelectedModelToDelete(null);
    }
  };

  // Filter models safely
  const filteredModels = models.filter(model => {
    if (!model) return false;
    const nameMatch = model.name?.toLowerCase().includes(searchTerm.toLowerCase());
    const descMatch = model.description?.toLowerCase().includes(searchTerm.toLowerCase());
    return nameMatch || descMatch;
  });

  if (loading) {
    return (
      <div className="flex flex-col h-full min-h-[50vh] justify-center items-center">
        <Shield className="h-12 w-12 animate-pulse text-brand-600" />
        <p className="mt-3 text-lg text-slate-700">Loading threat models...</p>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Threat Models - CreativeCyber</title>
        <meta name="description" content="Manage and view your threat models." />
      </Helmet>
      
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-slate-900 font-heading">Your Threat Models</h1>
        <Button 
          onClick={() => setWizardOpen(true)} 
          className="bg-brand-600 hover:bg-brand-700 text-white shadow-md"
        >
          <PlusCircle className="mr-2 h-5 w-5" /> Create New Model
        </Button>
      </div>

      <div className="flex gap-4 mb-6">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
          <Input
            placeholder="Search models..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button variant="outline" onClick={() => toast({ title: "Coming Soon", description: "Advanced filtering will be available shortly." })}>
          <Filter className="mr-2 h-5 w-5" /> Filter
        </Button>
      </div>

      {filteredModels.length === 0 ? (
        <div className="text-center py-16 bg-slate-50 rounded-xl border border-dashed border-slate-300">
          <AlertCircle className="mx-auto h-12 w-12 text-slate-400" />
          <h3 className="mt-4 text-xl font-semibold text-slate-900">No threat models found</h3>
          <p className="mt-2 text-slate-500 max-w-sm mx-auto">
            {searchTerm ? "No models match your search criteria." : "Get started by creating your first threat model using our wizard."}
          </p>
          {!searchTerm && (
            <div className="mt-8">
              <Button 
                onClick={() => setWizardOpen(true)} 
                className="bg-brand-600 hover:bg-brand-700"
              >
                <PlusCircle className="mr-2 h-5 w-5" /> Start Wizard
              </Button>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredModels.map((model) => (
            <Card key={model.id} className="hover:shadow-lg transition-shadow duration-200 flex flex-col">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center justify-between text-lg">
                  <span className="truncate pr-2" title={model.name}>{model.name}</span>
                  {model.is_public && (
                    <span className="text-[10px] font-medium text-brand-600 bg-brand-100 px-2 py-0.5 rounded-full uppercase tracking-wider">Public</span>
                  )}
                </CardTitle>
                <CardDescription className="line-clamp-2 min-h-[40px] mt-1">
                  {model.description || 'No description provided.'}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-grow pb-3">
                <div className="space-y-1 text-xs text-slate-500">
                  <div className="flex justify-between">
                    <span>Created:</span>
                    <span className="font-medium">{new Date(model.created_at).toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Updated:</span>
                    <span className="font-medium">{new Date(model.updated_at).toLocaleDateString()}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between pt-3 pb-3 px-4 border-t bg-slate-50/50">
                <Button 
                   variant="outline"
                   size="sm"
                   className="h-8 text-xs gap-1.5"
                   onClick={() => navigate(`/dashboard/report/${model.id}`)}
                >
                  <FileText className="h-3.5 w-3.5" />
                  Report
                </Button>
                <div className="flex gap-1">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => navigate(`/model/${model.id}`)}
                    className="h-8 w-8 p-0 text-slate-500 hover:text-brand-600"
                    title="Edit Model"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => setSelectedModelToDelete(model)}
                        className="h-8 w-8 p-0 text-slate-500 hover:text-red-600"
                        title="Delete Model"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Threat Model?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This action cannot be undone. This will permanently delete <strong>{selectedModelToDelete?.name}</strong> and all associated data.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleDeleteModel} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={wizardOpen} onOpenChange={setWizardOpen}>
        <DialogContent className="max-w-5xl h-[85vh] p-0 border-0 bg-transparent shadow-none">
          <QuickStartWizard 
            onClose={() => {
              setWizardOpen(false);
            }} 
          />
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ThreatModels;
