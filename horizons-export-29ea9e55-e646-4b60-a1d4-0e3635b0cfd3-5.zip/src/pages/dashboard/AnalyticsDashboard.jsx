
import React from 'react';
import { Navigate } from 'react-router-dom';

/**
 * DEPRECATED: This component has been removed from the application.
 * Any accidental access will redirect to the Reports page.
 */
const AnalyticsDashboard = () => {
  return <Navigate to="/dashboard/reports" replace />;
};

export default AnalyticsDashboard;
