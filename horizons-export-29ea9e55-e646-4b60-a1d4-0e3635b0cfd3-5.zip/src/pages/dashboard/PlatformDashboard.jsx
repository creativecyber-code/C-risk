
import React, { useState } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, Server, Shield, Users, Activity, 
  Settings, LogOut, Search, Bell
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';

// Sub-components (Internal to Platform Dashboard)
import GlobalHealthMap from '@/components/platform/GlobalHealthMap';
import TenantManagementConsole from './PlatformTenantManagement';
import AuditLogViewer from '@/components/security/AuditLogViewer';

const PlatformDashboard = () => {
  const { signOut, user } = useAuth();
  const location = useLocation();
  const [searchQuery, setSearchQuery] = useState('');

  const isActive = (path) => location.pathname.includes(path);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-red-500 selection:text-white">
      {/* Top Navigation - Command Bar */}
      <header className="h-16 border-b border-slate-800 bg-slate-900/50 backdrop-blur-md fixed top-0 w-full z-50 flex items-center justify-between px-6">
        <div className="flex items-center gap-4">
          <div className="h-8 w-8 bg-gradient-to-br from-red-600 to-red-800 rounded-lg flex items-center justify-center shadow-lg shadow-red-900/20">
            <Shield className="h-5 w-5 text-white" />
          </div>
          <span className="font-bold text-lg tracking-tight text-white">FLEET COMMAND</span>
        </div>

        <div className="flex-1 max-w-xl mx-8">
          <div className="relative group">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500 group-focus-within:text-red-400 transition-colors" />
            <Input 
              placeholder="Search tenants, users, or audit logs..." 
              className="bg-slate-950 border-slate-800 pl-10 text-sm focus:border-red-500/50 focus:ring-red-500/20 rounded-full h-9 transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Button size="icon" variant="ghost" className="text-slate-400 hover:text-white hover:bg-slate-800">
            <Bell className="h-5 w-5" />
          </Button>
          <div className="h-6 w-px bg-slate-800" />
          <div className="flex items-center gap-3">
            <div className="text-right hidden md:block">
              <p className="text-sm font-medium text-white">Administrator</p>
              <p className="text-xs text-slate-500">Last login: {new Date().toLocaleTimeString()}</p>
            </div>
            <Avatar className="h-8 w-8 border border-slate-700">
              <AvatarFallback className="bg-slate-800 text-red-400">AD</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      {/* Sidebar Navigation */}
      <aside className="fixed left-0 top-16 h-[calc(100vh-4rem)] w-64 border-r border-slate-800 bg-slate-900 overflow-y-auto">
        <div className="p-4 space-y-6">
          <div className="space-y-1">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 mb-2">Monitor</p>
            <NavLink to="/dashboard/platform" icon={Activity} active={location.pathname === '/dashboard/platform'}>Global Health</NavLink>
            <NavLink to="/dashboard/platform/audit" icon={Shield} active={isActive('audit')}>Security Audit</NavLink>
          </div>
          
          <div className="space-y-1">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 mb-2">Manage</p>
            <NavLink to="/dashboard/platform/tenants" icon={Server} active={isActive('tenants')}>Tenants</NavLink>
            <NavLink to="/dashboard/platform/users" icon={Users} active={isActive('users')}>Platform Users</NavLink>
          </div>

          <div className="space-y-1">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 mb-2">System</p>
            <NavLink to="/dashboard/platform/settings" icon={Settings} active={isActive('settings')}>Configuration</NavLink>
          </div>
        </div>

        <div className="absolute bottom-4 left-4 right-4">
          <Button 
            variant="outline" 
            className="w-full justify-start text-slate-400 border-slate-800 hover:bg-slate-800 hover:text-red-400"
            onClick={signOut}
          >
            <LogOut className="h-4 w-4 mr-2" /> Sign Out
          </Button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="ml-64 mt-16 p-8 min-h-[calc(100vh-4rem)]">
        <Routes>
          <Route index element={<GlobalHealthMap />} />
          <Route path="tenants" element={<TenantManagementConsole />} />
          <Route path="audit" element={<AuditLogViewer orgId="platform" />} />
          <Route path="*" element={<div className="text-center py-20 text-slate-500">Module under construction</div>} />
        </Routes>
      </main>
    </div>
  );
};

const NavLink = ({ to, icon: Icon, children, active }) => (
  <Link 
    to={to} 
    className={`
      flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-all
      ${active 
        ? 'bg-red-500/10 text-red-400 border border-red-500/20 shadow-sm' 
        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
      }
    `}
  >
    <Icon className={`h-4 w-4 ${active ? 'text-red-400' : 'text-slate-500'}`} />
    {children}
  </Link>
);

export default PlatformDashboard;
