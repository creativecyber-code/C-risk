import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Search, Filter, Layers, Plus } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { templateService } from '@/services/templateService';
import TemplateCard from '@/components/templates/TemplateCard';
import TemplatePreviewModal from '@/components/templates/TemplatePreviewModal';
import { useToast } from '@/components/ui/use-toast';

const INDUSTRIES = ['All Industries', 'Finance', 'Healthcare', 'Tech', 'SaaS', 'E-commerce', 'Manufacturing', 'Consumer'];
const COMPLEXITIES = ['All Levels', 'Basic', 'Intermediate', 'Advanced'];

const Templates = () => {
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState('All Industries');
  const [selectedComplexity, setSelectedComplexity] = useState('All Levels');
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [activeTab, setActiveTab] = useState('all'); // all, system, custom
  const { toast } = useToast();

  useEffect(() => {
    const fetchTemplates = async () => {
      try {
        const data = await templateService.getTemplates();
        setTemplates(data);
      } catch (error) {
        toast({ title: "Failed to load templates", description: error.message, variant: "destructive" });
      } finally {
        setLoading(false);
      }
    };
    fetchTemplates();
  }, [toast]);

  const filteredTemplates = templates.filter(tpl => {
    const matchesSearch = tpl.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          tpl.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesIndustry = selectedIndustry === 'All Industries' || tpl.industry === selectedIndustry;
    const matchesComplexity = selectedComplexity === 'All Levels' || tpl.complexity === selectedComplexity;
    const matchesTab = activeTab === 'all' || 
                       (activeTab === 'system' && tpl.source === 'SYSTEM') ||
                       (activeTab === 'custom' && tpl.source === 'CUSTOM');

    return matchesSearch && matchesIndustry && matchesComplexity && matchesTab;
  });

  return (
    <div className="space-y-6">
      <Helmet>
        <title>Data Flow Templates | CreativeCyber</title>
      </Helmet>

      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold font-heading text-slate-900">Data Flow Library</h1>
          <p className="text-slate-500 mt-1">Jumpstart your threat modeling with pre-built architectural templates.</p>
        </div>
        <Button onClick={() => toast({ title: "Save as Template", description: "To create a custom template, open a Threat Model and choose 'Save as Template' from settings." })}>
          <Plus className="w-4 h-4 mr-2" /> Create Template
        </Button>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-lg border shadow-sm flex flex-col md:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input 
            placeholder="Search templates..." 
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2 w-full md:w-auto">
           <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
             <SelectTrigger className="w-[180px]">
               <SelectValue placeholder="Industry" />
             </SelectTrigger>
             <SelectContent>
               {INDUSTRIES.map(i => <SelectItem key={i} value={i}>{i}</SelectItem>)}
             </SelectContent>
           </Select>

           <Select value={selectedComplexity} onValueChange={setSelectedComplexity}>
             <SelectTrigger className="w-[180px]">
               <SelectValue placeholder="Complexity" />
             </SelectTrigger>
             <SelectContent>
               {COMPLEXITIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
             </SelectContent>
           </Select>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-slate-100 p-1">
          <TabsTrigger value="all">All Templates</TabsTrigger>
          <TabsTrigger value="system">System Gallery</TabsTrigger>
          <TabsTrigger value="custom">My Team's Templates</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3].map(i => (
             <div key={i} className="h-80 bg-slate-100 animate-pulse rounded-lg"></div>
          ))}
        </div>
      ) : filteredTemplates.length === 0 ? (
        <div className="text-center py-20 bg-slate-50 rounded-lg border border-dashed">
          <Layers className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-slate-900">No templates found</h3>
          <p className="text-slate-500">Try adjusting your filters or search terms.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-500">
          {filteredTemplates.map(template => (
            <TemplateCard 
              key={template.id} 
              template={template} 
              onSelect={setSelectedTemplate} 
            />
          ))}
        </div>
      )}

      {/* Modal */}
      <TemplatePreviewModal 
        template={selectedTemplate} 
        isOpen={!!selectedTemplate} 
        onClose={() => setSelectedTemplate(null)} 
      />
    </div>
  );
};

export default Templates;