
import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { 
  CheckCircle2, Clock, AlertTriangle, TrendingUp, Plus, 
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import { remediationService } from '@/services/remediationService';
import RemediationTimeline from '@/components/remediation/RemediationTimeline';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import CreateMitigationForm from '@/components/remediation/CreateMitigationForm';
import RemediationPlan from './RemediationPlan';
import { supabase } from '@/lib/customSupabaseClient';

const MetricCard = ({ title, value, subtitle, icon: Icon, color }) => (
  <Card>
    <CardContent className="p-6">
      <div className="flex items-center justify-between space-y-0 pb-2">
        <p className="text-sm font-medium text-slate-500">{title}</p>
        <Icon className={`h-4 w-4 text-${color}-500`} />
      </div>
      <div className="flex flex-col gap-1">
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-slate-500">{subtitle}</p>
      </div>
    </CardContent>
  </Card>
);

const RemediationDashboard = () => {
  const [metrics, setMetrics] = useState({ total: 0, completed: 0, overdue: 0, atRisk: 0, velocity: 0, plans: [] });
  const [loading, setLoading] = useState(true);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
    setupRealtimeSubscription();

    return () => {
      // Cleanup subscriptions
      supabase.channel('remediation-metrics').unsubscribe();
    };
  }, []);

  const setupRealtimeSubscription = () => {
    const channel = supabase.channel('remediation-metrics')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'mitigation_plans' },
        (payload) => {
          console.log('Realtime update received for mitigation_plans:', payload);
          loadData();
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'threat_assessments' },
        (payload) => {
           // While metrics primarily track plans, threat changes might affect new plans needed
           console.log('Realtime update received for threat_assessments:', payload);
           loadData(); // Re-fetch to ensure sync
        }
      )
      .subscribe();
  };

  const loadData = async () => {
    try {
      const data = await remediationService.getMetrics();
      setMetrics(data);
    } catch (error) {
      console.error(error);
      toast({ 
        title: "Error loading metrics", 
        description: "Could not fetch latest data.", 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateSuccess = () => {
    setIsCreateOpen(false);
    loadData();
    toast({ title: "Mitigation Plan Created" });
  };

  if (loading) {
    return (
      <div className="flex h-[50vh] w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-brand-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Helmet><title>Remediation Center | CreativeCyber</title></Helmet>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 font-heading">Remediation Center</h1>
          <p className="text-slate-500">Unified view of threats, mitigation plans, and remediation progress.</p>
        </div>
        <div className="flex gap-2">
           <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
             <DialogTrigger asChild>
               <Button className="bg-brand-600 hover:bg-brand-700">
                 <Plus className="w-4 h-4 mr-2" /> New Mitigation Plan
               </Button>
             </DialogTrigger>
             <DialogContent className="max-w-2xl">
               <DialogHeader><DialogTitle>Create Mitigation Plan</DialogTitle></DialogHeader>
               <CreateMitigationForm onSuccess={handleCreateSuccess} onCancel={() => setIsCreateOpen(false)} />
             </DialogContent>
           </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <MetricCard title="Completion Rate" value={`${metrics.total > 0 ? Math.round((metrics.completed / metrics.total) * 100) : 0}%`} subtitle="Of all mitigation plans" icon={CheckCircle2} color="green" />
        <MetricCard title="Overdue Items" value={metrics.overdue} subtitle="Requires attention" icon={Clock} color="red" />
        <MetricCard title="At Risk" value={metrics.atRisk} subtitle="Blocked items" icon={AlertTriangle} color="orange" />
        <MetricCard title="Velocity" value={metrics.velocity} subtitle="Items / week" icon={TrendingUp} color="blue" />
      </div>

      <Tabs defaultValue="plan" className="space-y-4">
        <TabsList>
          <TabsTrigger value="plan">Remediation Plan</TabsTrigger>
          <TabsTrigger value="projects">Mitigation Projects</TabsTrigger>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
        </TabsList>

        <TabsContent value="plan" className="border-none p-0 outline-none">
           <RemediationPlan />
        </TabsContent>

        <TabsContent value="projects">
          <Card>
            <CardHeader><CardTitle>Active Mitigation Projects</CardTitle></CardHeader>
            <CardContent>
               <div className="space-y-2">
                 {metrics.plans.length === 0 ? (
                    <p className="text-slate-500 italic py-4">No active mitigation projects.</p>
                 ) : (
                   metrics.plans.map(p => (
                      <div key={p.id} className="p-4 border rounded hover:bg-slate-50 flex justify-between items-center transition-colors">
                         <div>
                           <p className="font-medium">{p.description}</p>
                           <p className="text-xs text-slate-500 mt-1">
                             <span className={`inline-block w-2 h-2 rounded-full mr-2 ${p.status === 'Completed' ? 'bg-green-500' : p.status === 'Overdue' ? 'bg-red-500' : 'bg-blue-500'}`}></span>
                             {p.status} - {p.priority}
                           </p>
                         </div>
                         <div className="text-right">
                           <span className="text-sm font-bold block">{p.progress_percentage}%</span>
                           <span className="text-[10px] text-slate-400">Progress</span>
                         </div>
                      </div>
                   ))
                 )}
               </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="timeline">
           <RemediationTimeline plans={metrics.plans} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default RemediationDashboard;
