
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/AuthContext';
import { architectureService } from '@/services/architectureService';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Plus,
  ShieldAlert,
  Search,
  ArrowRight,
  Shield,
  Layers
} from 'lucide-react';
import { format } from 'date-fns';

export default function ArchitectureReview() {
  const { tenant } = useAuth();
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (tenant?.id) {
      loadReviews();
    }
  }, [tenant?.id]);

  const loadReviews = async () => {
    setLoading(true);
    try {
      const data = await architectureService.listReviews(tenant.id);
      setReviews(data || []);
    } catch (error) {
      console.error("Failed to load reviews", error);
    } finally {
      setLoading(false);
    }
  };

  const getRiskBadgeColor = (rating) => {
    switch (rating) {
      case 'Critical': return 'bg-red-50 text-red-700 border-red-200';
      case 'High': return 'bg-orange-50 text-orange-700 border-orange-200';
      case 'Medium': return 'bg-yellow-50 text-yellow-700 border-yellow-200';
      case 'Low': return 'bg-green-50 text-green-700 border-green-200';
      default: return 'bg-slate-100 text-slate-600 border-slate-200';
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <Helmet>
        <title>Architecture Reviews | CyberWorkbench</title>
      </Helmet>

      {/* Breadcrumb */}
      <div className="px-1">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/dashboard">Dashboard</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Architecture Reviews</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-6">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Architecture Reviews</h1>
          <p className="text-slate-500 text-lg">
             Threat modeling and security design reviews for your systems.
          </p>
        </div>
        {/* Placeholder for future Create button - usually reviews start from Initiation, but could be manual */}
        <Button disabled variant="outline" className="hidden sm:flex">
           <Plus className="mr-2 h-4 w-4" /> Manual Review
        </Button>
      </div>

      {/* Content */}
      <Card className="border-slate-200 shadow-sm bg-white">
        <CardContent className="p-0">
          {loading ? (
             <div className="p-6 space-y-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="flex items-center gap-4">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-4 w-1/3" />
                      <Skeleton className="h-4 w-1/2" />
                    </div>
                  </div>
                ))}
             </div>
          ) : reviews.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
              <div className="bg-slate-50 p-4 rounded-full mb-4">
                 <Shield className="h-8 w-8 text-slate-300" />
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-1">No reviews found</h3>
              <p className="text-slate-500 max-w-sm mb-6">
                Architecture reviews are typically triggered from high-risk Business Initiatives.
              </p>
              <Button asChild variant="outline">
                 <Link to="/dashboard/initiation">Go to Business Initiation</Link>
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader className="bg-slate-50/50">
                <TableRow>
                  <TableHead className="w-[350px]">Review Title</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Risk Rating</TableHead>
                  <TableHead>Last Updated</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reviews.map((review) => (
                  <TableRow key={review.id} className="group hover:bg-slate-50/50">
                    <TableCell className="font-medium">
                       <div className="flex items-center gap-3">
                          <div className="h-8 w-8 rounded-lg bg-blue-50 flex items-center justify-center text-blue-600">
                             <Layers className="h-4 w-4" />
                          </div>
                          <div className="flex flex-col">
                             <span className="text-slate-900">{review.title}</span>
                             <span className="text-xs text-slate-500">{review.template_key}</span>
                          </div>
                       </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize font-normal">
                        {review.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {review.architecture_risk_rating && (
                        <Badge variant="outline" className={getRiskBadgeColor(review.architecture_risk_rating)}>
                           {review.architecture_risk_rating}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-slate-500 text-sm">
                       {format(new Date(review.updated_at), 'MMM d, yyyy')}
                    </TableCell>
                    <TableCell className="text-right">
                       <Button asChild size="sm" variant="ghost" className="hover:bg-blue-50 hover:text-blue-600">
                          <Link to={`/dashboard/architecture-review/${review.id}`}>
                             View <ArrowRight className="ml-2 h-3 w-3" />
                          </Link>
                       </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
