
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { 
  Activity, ShieldAlert, CheckSquare, 
  Scale, Download, Calendar, ArrowUpRight,
  FileText
} from 'lucide-react';
import { analyticsService } from '@/services/analyticsService';
import { useToast } from '@/components/ui/use-toast';
import { exportToCSV, exportToJSON } from '@/utils/exportUtils';
import { generateComprehensiveReport } from '@/utils/pdfReportGenerator';
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

// Import Dashboards - Explicitly using Report components to avoid naming conflicts with Pages
import ExecutiveDashboardReport from '@/components/reports/ExecutiveDashboardReport';
import RiskDashboard from '@/components/reports/RiskDashboard';
import MitigationDashboard from '@/components/reports/MitigationDashboard';
import ComplianceDashboard from '@/components/reports/ComplianceDashboard';

const ReportsAnalytics = () => {
  const [activeTab, setActiveTab] = useState('executive');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const analytics = await analyticsService.getAnalyticsData();
      setData(analytics);
    } catch (e) {
      toast({ title: "Failed to load report data", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async (format) => {
    if (!data) return;
    const filename = `security_report_${activeTab}_${new Date().toISOString().split('T')[0]}`;
    
    if (format === 'json') {
      exportToJSON(data, filename);
      toast({ title: "Export Started", description: `Downloading JSON report...` });
    } else if (format === 'csv') {
      if (activeTab === 'executive') {
         exportToCSV(data.trendData, `${filename}_trends`);
      } else if (activeTab === 'risk') {
         exportToCSV(data.threats, `${filename}_threats`);
      } else if (activeTab === 'mitigation') {
         exportToCSV(data.mitigationStats, `${filename}_mitigation`);
      } else {
         exportToCSV(data.complianceData, `${filename}_compliance`);
      }
      toast({ title: "Export Started", description: `Downloading CSV report...` });
    } else if (format === 'pdf') {
       toast({ title: "Generating PDF", description: "This may take a moment..." });
       try {
         // In a real app, organization name would come from auth context or organization service
         await generateComprehensiveReport(data, "CreativeCyber Inc.");
         toast({ title: "Success", description: "PDF Report downloaded successfully." });
       } catch (error) {
         console.error(error);
         toast({ title: "Export Failed", description: "Could not generate PDF.", variant: "destructive" });
       }
    }
  };

  return (
    <div className="space-y-6 md:space-y-8 pb-4">
      <Helmet>
        <title>Security Reports | CreativeCyber</title>
      </Helmet>

      {/* Mobile-Friendly Header */}
      <div className="flex flex-col gap-4 md:flex-row md:justify-between md:items-center">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Security Reports</h1>
          <p className="text-sm md:text-base text-slate-500 mt-1">Comprehensive security insights and reporting.</p>
        </div>
        
        {/* Mobile Actions Drawer */}
        <div className="md:hidden">
           <Sheet>
             <SheetTrigger asChild>
               <Button variant="outline" className="w-full justify-between">
                 Actions <ArrowUpRight className="w-4 h-4 ml-2" />
               </Button>
             </SheetTrigger>
             <SheetContent side="bottom" className="h-[350px]">
               <div className="grid gap-4 py-4">
                 <Button variant="outline" onClick={() => handleExport('pdf')} className="bg-red-50 text-red-600 border-red-100 hover:bg-red-100">
                   <FileText className="w-4 h-4 mr-2" /> Export PDF Report
                 </Button>
                 <Button variant="outline" onClick={() => handleExport('json')}>
                   <Download className="w-4 h-4 mr-2" /> Export JSON
                 </Button>
                 <Button variant="outline" onClick={() => handleExport('csv')}>
                   <Download className="w-4 h-4 mr-2" /> Export CSV
                 </Button>
                 <Button>
                   <Calendar className="w-4 h-4 mr-2" /> Schedule Report
                 </Button>
               </div>
             </SheetContent>
           </Sheet>
        </div>

        {/* Desktop Actions */}
        <div className="hidden md:flex gap-2">
          <Button variant="outline" onClick={() => handleExport('pdf')} className="text-red-700 bg-red-50 hover:bg-red-100 border-red-200">
             <FileText className="w-4 h-4 mr-2" /> PDF Report
          </Button>
          <Button variant="outline" onClick={() => handleExport('json')}>
             <Download className="w-4 h-4 mr-2" /> JSON
          </Button>
          <Button variant="outline" onClick={() => handleExport('csv')}>
             <Download className="w-4 h-4 mr-2" /> CSV
          </Button>
          <Button>
             <Calendar className="w-4 h-4 mr-2" /> Schedule
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        {/* Scrollable Tabs List */}
        <div className="overflow-x-auto pb-2 -mx-4 px-4 md:mx-0 md:px-0 scrollbar-hide">
          <TabsList className="bg-white border p-1 h-12 w-auto inline-flex md:w-full justify-start md:grid md:grid-cols-4 min-w-[600px] md:min-w-0">
            <TabsTrigger value="executive" className="data-[state=active]:bg-brand-50 data-[state=active]:text-brand-700">
              <Activity className="w-4 h-4 mr-2" /> Executive Perspective
            </TabsTrigger>
            <TabsTrigger value="risk" className="data-[state=active]:bg-brand-50 data-[state=active]:text-brand-700">
              <ShieldAlert className="w-4 h-4 mr-2" /> Risk Analysis
            </TabsTrigger>
            <TabsTrigger value="mitigation" className="data-[state=active]:bg-brand-50 data-[state=active]:text-brand-700">
              <CheckSquare className="w-4 h-4 mr-2" /> Fixes & Remediation
            </TabsTrigger>
            <TabsTrigger value="compliance" className="data-[state=active]:bg-brand-50 data-[state=active]:text-brand-700">
              <Scale className="w-4 h-4 mr-2" /> Compliance
            </TabsTrigger>
          </TabsList>
        </div>

        <div className="min-h-[500px]">
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-600"></div>
            </div>
          ) : (
            <div className="space-y-4">
              <TabsContent value="executive">
                <ExecutiveDashboardReport data={data} />
              </TabsContent>

              <TabsContent value="risk">
                <RiskDashboard data={data} />
              </TabsContent>

              <TabsContent value="mitigation">
                <MitigationDashboard data={data} />
              </TabsContent>

              <TabsContent value="compliance">
                <ComplianceDashboard data={data} />
              </TabsContent>
            </div>
          )}
        </div>
      </Tabs>
    </div>
  );
};

export default ReportsAnalytics;
