
import React from 'react';
import OrgSettingsPanel from '@/components/access/OrgSettingsPanel';
import DNSSettings from '@/components/access/DNSSettings';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const OrganizationManagement = ({ orgId }) => {
  return (
    <div className="space-y-6">
      <Tabs defaultValue="settings" className="w-full">
        <TabsList className="w-full justify-start border-b rounded-none h-auto p-0 bg-transparent space-x-6">
          <TabsTrigger 
            value="settings" 
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-0 py-2"
          >
            General Settings
          </TabsTrigger>
          <TabsTrigger 
            value="dns" 
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-0 py-2"
          >
            DNS & Domains
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="settings" className="mt-6">
          <OrgSettingsPanel orgId={orgId} />
        </TabsContent>
        
        <TabsContent value="dns" className="mt-6">
          <DNSSettings orgId={orgId} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default OrganizationManagement;
