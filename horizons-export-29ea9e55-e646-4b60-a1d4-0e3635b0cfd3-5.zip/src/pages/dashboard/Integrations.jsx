
import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Plus, Trash2, RefreshCw, Key, Shield, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { integrationService } from '@/services/integrationService';
import { INTEGRATION_TOOLS } from '@/data/integrationTools';

const Integrations = () => {
  const [activeIntegrations, setActiveIntegrations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [connecting, setConnecting] = useState(false);
  const [selectedTool, setSelectedTool] = useState(null);
  const [formData, setFormData] = useState({});
  const { toast } = useToast();

  useEffect(() => {
    fetchIntegrations();
  }, []);

  const fetchIntegrations = async () => {
    try {
      const data = await integrationService.getMyIntegrations();
      setActiveIntegrations(data);
    } catch (error) {
      console.error(error);
      toast({ title: "Error fetching integrations", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleConnect = async () => {
    setConnecting(true);
    try {
      await integrationService.connectIntegration(selectedTool.id, formData, { domain: formData.domain });
      toast({ title: "Connected Successfully", description: `${selectedTool.name} is now active.` });
      setSelectedTool(null);
      setFormData({});
      fetchIntegrations();
    } catch (error) {
      toast({ title: "Connection Failed", description: error.message, variant: "destructive" });
    } finally {
      setConnecting(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await integrationService.deleteIntegration(id);
      setActiveIntegrations(prev => prev.filter(i => i.id !== id));
      toast({ title: "Integration Removed" });
    } catch (error) {
      toast({ title: "Error", variant: "destructive" });
    }
  };

  const getActiveStatus = (toolId) => activeIntegrations.some(i => i.provider_key === toolId);

  return (
    <div className="space-y-6">
      <Helmet><title>Integrations | CreativeCyber</title></Helmet>

      <div>
        <h1 className="text-2xl font-bold text-slate-900">Integrations</h1>
        <p className="text-slate-500">Connect your security tools, issue trackers, and CI/CD pipelines.</p>
      </div>

      <Tabs defaultValue="available" className="space-y-6">
        <TabsList>
          <TabsTrigger value="available">Available Tools</TabsTrigger>
          <TabsTrigger value="active">Active Connections ({activeIntegrations.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="available" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
           {INTEGRATION_TOOLS.map(tool => (
             <Card key={tool.id} className="flex flex-col">
               <CardHeader>
                 <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{tool.name}</CardTitle>
                    {getActiveStatus(tool.id) && <CheckCircle className="text-green-500 w-5 h-5"/>}
                 </div>
                 <Badge variant="secondary" className="w-fit">{tool.category}</Badge>
               </CardHeader>
               <CardContent className="flex-grow">
                 <p className="text-sm text-slate-500">{tool.description}</p>
               </CardContent>
               <CardFooter>
                  {getActiveStatus(tool.id) ? (
                    <Button variant="outline" className="w-full" disabled>Connected</Button>
                  ) : (
                    <Dialog onOpenChange={(open) => { if(!open) { setSelectedTool(null); setFormData({}); } }}>
                      <DialogTrigger asChild>
                         <Button className="w-full" onClick={() => setSelectedTool(tool)}>Connect</Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Connect {tool.name}</DialogTitle>
                          <DialogDescription>Enter your credentials to enable two-way sync.</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                           {tool.setupFields.map(field => (
                             <div key={field.name} className="space-y-2">
                               <Label>{field.label}</Label>
                               <Input 
                                 type={field.type} 
                                 placeholder={field.placeholder || ''}
                                 onChange={(e) => setFormData({...formData, [field.name]: e.target.value})}
                               />
                             </div>
                           ))}
                        </div>
                        <DialogFooter>
                          <Button onClick={handleConnect} disabled={connecting}>
                             {connecting ? 'Connecting...' : 'Save & Connect'}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  )}
               </CardFooter>
             </Card>
           ))}
        </TabsContent>

        <TabsContent value="active">
           {activeIntegrations.length === 0 ? (
             <div className="text-center py-10 text-slate-500">No active integrations.</div>
           ) : (
             <div className="space-y-4">
               {activeIntegrations.map(integration => (
                 <div key={integration.id} className="flex items-center justify-between p-4 border rounded-lg bg-white shadow-sm">
                    <div className="flex items-center gap-4">
                       <div className="h-10 w-10 bg-slate-100 rounded-full flex items-center justify-center">
                          <Key className="w-5 h-5 text-slate-500"/>
                       </div>
                       <div>
                          <h3 className="font-semibold">{integration.name}</h3>
                          <p className="text-xs text-slate-400">Last synced: {new Date(integration.last_sync_at).toLocaleString()}</p>
                       </div>
                    </div>
                    <div className="flex gap-2">
                       <Button variant="outline" size="sm"><RefreshCw className="w-4 h-4 mr-2"/> Sync Now</Button>
                       <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-600 hover:bg-red-50" onClick={() => handleDelete(integration.id)}>
                          <Trash2 className="w-4 h-4"/>
                       </Button>
                    </div>
                 </div>
               ))}
             </div>
           )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Integrations;
