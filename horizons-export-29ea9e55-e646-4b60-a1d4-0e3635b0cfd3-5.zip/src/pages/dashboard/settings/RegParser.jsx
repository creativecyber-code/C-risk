
import React, { useState, useEffect } from 'react';
import { Upload, FileText, Server, RefreshCw, CheckCircle, BrainCircuit, Activity, AlertCircle, FileSpreadsheet, FileJson, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/components/ui/use-toast';
import { regParserService } from '@/services/regParserService';
import { excelParserService } from '@/services/excelParserService';
import ExtractionReview from '@/components/compliance/ExtractionReview';
import ImportMapper from '@/components/compliance/ImportMapper';

const RegParser = () => {
  const [documents, setDocuments] = useState([]);
  const [rbiFeed, setRbiFeed] = useState([]);
  const [loading, setLoading] = useState(false);
  const [feedLoading, setFeedLoading] = useState(false);
  const [uploadFile, setUploadFile] = useState(null);
  
  // Selection
  const [selectedDocId, setSelectedDocId] = useState(null);
  const [extracts, setExtracts] = useState([]);

  // Structured Import State
  const [isMapping, setIsMapping] = useState(false);
  const [importFile, setImportFile] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    loadDocuments();
    loadRBIFeed();
  }, []);

  const loadDocuments = async () => {
    try {
      const docs = await regParserService.getDocuments();
      setDocuments(docs || []);
    } catch (e) {
      console.error("Failed to load docs", e);
    }
  };

  const loadRBIFeed = async () => {
    setFeedLoading(true);
    try {
      const feed = await regParserService.fetchRecentRBICirculars();
      setRbiFeed(feed);
    } catch (e) {
      console.error(e);
    } finally {
      setFeedLoading(false);
    }
  };

  const handleFileSelect = (e) => {
    if (e.target.files && e.target.files[0]) {
        const file = e.target.files[0];
        setUploadFile(file);
    }
  };

  const handleUpload = async () => {
    if (!uploadFile) return;
    
    // Check file type
    const isStructured = uploadFile.name.endsWith('.xlsx') || uploadFile.name.endsWith('.xls') || uploadFile.name.endsWith('.csv');

    if (isStructured) {
        // Structured Flow
        setImportFile(uploadFile);
        setIsMapping(true);
    } else {
        // PDF/Standard Flow
        setLoading(true);
        try {
            await regParserService.importDocument(uploadFile, 'UPLOAD');
            toast({ title: "Upload Successful", description: "Document queued for parsing." });
            setUploadFile(null);
            loadDocuments();
        } catch (e) {
            toast({ title: "Upload Failed", description: e.message, variant: "destructive" });
        } finally {
            setLoading(false);
        }
    }
  };

  const handleMappingComplete = async (mappedData, sheetName) => {
    setLoading(true);
    try {
        // 1. First upload the file to get a Doc ID
        const doc = await regParserService.importDocument(importFile, 'IMPORT');
        
        // 2. Process the mapped data
        const count = await regParserService.processStructuredImport(doc.id, mappedData);
        
        toast({ title: "Import Complete", description: `Successfully imported ${count} controls from ${sheetName}.` });
        setIsMapping(false);
        setImportFile(null);
        setUploadFile(null);
        loadDocuments();
        // Automatically view the result
        handleViewExtracts(doc.id);

    } catch (e) {
        toast({ title: "Import Failed", description: e.message, variant: "destructive" });
    } finally {
        setLoading(false);
    }
  };

  const handleImportFromFeed = async (item) => {
    setLoading(true);
    try {
      await regParserService.importDocument(item, 'RBI_WEB');
      toast({ title: "Import Successful", description: "Circular imported from RBI." });
      loadDocuments();
    } catch (e) {
      toast({ title: "Import Failed", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleParse = async (docId) => {
    try {
       setDocuments(prev => prev.map(d => d.id === docId ? {...d, status: 'PARSING'} : d));
       toast({ title: "AI Parsing Started", description: "Extracting regulatory requirements..." });
       await regParserService.parseDocument(docId);
       toast({ title: "Parsing Complete", className: "bg-green-600 text-white" });
       loadDocuments();
    } catch (e) {
       toast({ title: "Parsing Error", variant: "destructive" });
       loadDocuments();
    }
  };

  const handleViewExtracts = async (docId) => {
    try {
      const data = await regParserService.getExtracts(docId);
      setExtracts(data);
      setSelectedDocId(docId);
      // Ensure mapping is closed
      setIsMapping(false);
    } catch (e) {
      toast({ title: "Error loading extracts", variant: "destructive" });
    }
  };

  const handleDownloadTemplate = () => {
    excelParserService.downloadTemplate();
    toast({ title: "Template Downloaded", description: "Check your downloads folder." });
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 h-full">
      {/* Left Panel: Upload & Import */}
      <div className="xl:col-span-1 space-y-6">
         <Card>
            <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                    <Upload className="w-5 h-5" /> Import Data
                </CardTitle>
                <CardDescription>Upload Documents or Import Data</CardDescription>
            </CardHeader>
            <CardContent>
                <Tabs defaultValue="upload">
                    <TabsList className="w-full mb-4">
                        <TabsTrigger value="upload" className="flex-1">File Upload</TabsTrigger>
                        <TabsTrigger value="rbi" className="flex-1">RBI Website</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="upload" className="space-y-4">
                        <div className="border-2 border-dashed border-slate-200 rounded-lg p-6 text-center hover:bg-slate-50 transition-colors">
                            <Input 
                                type="file" 
                                accept=".pdf,.xlsx,.xls,.csv" 
                                onChange={handleFileSelect}
                                className="hidden" 
                                id="file-upload"
                            />
                            <Label htmlFor="file-upload" className="cursor-pointer block">
                                {uploadFile ? (
                                    <div className="flex flex-col items-center">
                                        {uploadFile.name.endsWith('.pdf') ? (
                                            <FileText className="w-10 h-10 text-red-500 mb-2" />
                                        ) : (
                                            <FileSpreadsheet className="w-10 h-10 text-green-600 mb-2" />
                                        )}
                                        <span className="text-sm font-medium text-slate-800 break-all">{uploadFile.name}</span>
                                        <span className="text-xs text-slate-500 mt-1">{(uploadFile.size / 1024).toFixed(0)} KB</span>
                                    </div>
                                ) : (
                                    <>
                                        <div className="flex justify-center gap-2 mb-2">
                                            <FileText className="w-8 h-8 text-slate-400" />
                                            <FileSpreadsheet className="w-8 h-8 text-slate-400" />
                                        </div>
                                        <span className="text-sm text-slate-600 font-medium">
                                            Click to select PDF, Excel, or CSV
                                        </span>
                                        <p className="text-xs text-slate-400 mt-2">
                                            Supports PDF for AI parsing or Excel/CSV for structured import.
                                        </p>
                                    </>
                                )}
                            </Label>
                        </div>
                        
                        <div className="flex gap-2">
                            <Button className="flex-1" disabled={!uploadFile || loading} onClick={handleUpload}>
                                {loading ? 'Processing...' : 'Upload & Process'}
                            </Button>
                        </div>

                        <div className="pt-2 border-t mt-4">
                             <Button variant="outline" size="sm" className="w-full text-xs" onClick={handleDownloadTemplate}>
                                 <Download className="w-3 h-3 mr-2" /> Download Import Template
                             </Button>
                        </div>
                    </TabsContent>

                    <TabsContent value="rbi" className="space-y-4">
                        <div className="flex justify-between items-center mb-2">
                            <Label>Recent Notifications</Label>
                            <Button variant="ghost" size="sm" onClick={loadRBIFeed} disabled={feedLoading}>
                                <RefreshCw className={`w-3 h-3 ${feedLoading ? 'animate-spin' : ''}`} />
                            </Button>
                        </div>
                        <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
                            {rbiFeed.map((item) => (
                                <div key={item.id} className="p-3 border rounded text-sm hover:bg-slate-50 transition-colors">
                                    <div className="font-semibold text-slate-800 line-clamp-1">{item.title}</div>
                                    <div className="flex justify-between items-center mt-2 text-xs text-slate-500">
                                        <span>{item.reference}</span>
                                        <Button size="sm" variant="outline" className="h-6" onClick={() => handleImportFromFeed(item)}>
                                            Import
                                        </Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </TabsContent>
                </Tabs>
            </CardContent>
         </Card>

         <Card className="bg-brand-50 border-brand-200">
             <CardHeader className="pb-2">
                 <CardTitle className="text-base text-brand-800 flex items-center gap-2">
                     <Activity className="w-4 h-4" /> Compliance Gap
                 </CardTitle>
             </CardHeader>
             <CardContent>
                 <div className="space-y-2">
                     <div className="flex justify-between text-sm">
                         <span className="text-brand-700">RBI Coverage</span>
                         <span className="font-bold text-brand-900">42%</span>
                     </div>
                     <Progress value={42} className="h-2 bg-brand-200" indicatorClassName="bg-brand-600" />
                     <p className="text-xs text-brand-600 mt-2">
                         15 new controls suggested from imported documents.
                     </p>
                 </div>
             </CardContent>
         </Card>
      </div>

      {/* Right Panel: Content Area */}
      <div className="xl:col-span-2 space-y-6">
         <Card className="h-full flex flex-col">
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <BrainCircuit className="w-5 h-5 text-indigo-600" />
                    Reg-Parser Processing Queue
                </CardTitle>
                <CardDescription>Manage your document ingestion and control extraction pipeline.</CardDescription>
            </CardHeader>
            <CardContent className="flex-1 overflow-hidden flex flex-col gap-6">
                
                {/* 1. Import Mapper Mode */}
                {isMapping && importFile ? (
                    <div className="flex-1 animate-in fade-in zoom-in-95 duration-200">
                        <ImportMapper 
                            file={importFile} 
                            onCancel={() => { setIsMapping(false); setImportFile(null); }}
                            onComplete={handleMappingComplete}
                        />
                    </div>
                ) : (
                    /* 2. Standard View (Table + Review) */
                    <>
                        {/* Document Table */}
                        <div className="border rounded-lg overflow-hidden max-h-[300px] overflow-y-auto">
                           <table className="w-full text-sm text-left">
                               <thead className="bg-slate-50 text-slate-500 border-b sticky top-0">
                                   <tr>
                                       <th className="p-3 font-medium">Document</th>
                                       <th className="p-3 font-medium">Source</th>
                                       <th className="p-3 font-medium">Status</th>
                                       <th className="p-3 font-medium text-right">Actions</th>
                                   </tr>
                               </thead>
                               <tbody className="divide-y">
                                   {documents.length === 0 && (
                                       <tr><td colSpan="4" className="p-8 text-center text-slate-500">No documents imported yet.</td></tr>
                                   )}
                                   {documents.map((doc) => (
                                       <tr key={doc.id} className={`hover:bg-slate-50 transition-colors cursor-pointer ${selectedDocId === doc.id ? 'bg-indigo-50/50' : ''}`} onClick={() => doc.status === 'PARSED' && handleViewExtracts(doc.id)}>
                                           <td className="p-3">
                                               <div className="font-medium text-slate-900 line-clamp-1">{doc.title}</div>
                                               <div className="text-xs text-slate-500">{doc.reference_number} • {new Date(doc.created_at).toLocaleDateString()}</div>
                                           </td>
                                           <td className="p-3">
                                               <span className="text-xs font-mono bg-slate-100 px-2 py-1 rounded">{doc.source}</span>
                                           </td>
                                           <td className="p-3">
                                               {doc.status === 'UPLOADED' && <span className="text-slate-500 flex items-center gap-1"><Server className="w-3 h-3"/> Uploaded</span>}
                                               {doc.status === 'PARSING' && <span className="text-indigo-600 flex items-center gap-1"><RefreshCw className="w-3 h-3 animate-spin"/> AI Parsing...</span>}
                                               {doc.status === 'PARSED' && <span className="text-green-600 flex items-center gap-1"><CheckCircle className="w-3 h-3"/> Ready</span>}
                                           </td>
                                           <td className="p-3 text-right space-x-2">
                                               {doc.status === 'UPLOADED' && (
                                                   <Button size="sm" variant="default" className="h-7 text-xs bg-indigo-600 hover:bg-indigo-700" onClick={(e) => { e.stopPropagation(); handleParse(doc.id); }}>
                                                       Parse with AI
                                                   </Button>
                                               )}
                                               {doc.status === 'PARSED' && (
                                                   <Button size="sm" variant="outline" className="h-7 text-xs border-indigo-200 text-indigo-700 hover:bg-indigo-50" onClick={(e) => { e.stopPropagation(); handleViewExtracts(doc.id); }}>
                                                       Review
                                                   </Button>
                                               )}
                                           </td>
                                       </tr>
                                   ))}
                               </tbody>
                           </table>
                        </div>

                        {/* Extraction View Area */}
                        {selectedDocId && extracts.length > 0 && (
                            <div className="flex-1 border-t pt-4 animate-in fade-in slide-in-from-bottom-4">
                                <ExtractionReview 
                                    docId={selectedDocId}
                                    extracts={extracts} 
                                    onUpdate={() => {
                                        loadDocuments();
                                        handleViewExtracts(selectedDocId);
                                    }} 
                                />
                            </div>
                        )}
                    </>
                )}
            </CardContent>
         </Card>
      </div>
    </div>
  );
};

export default RegParser;
