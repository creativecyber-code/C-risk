
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, CheckCircle2, XCircle, AlertTriangle, RefreshCw, Database } from 'lucide-react';

const Diagnostics = () => {
  const [loading, setLoading] = useState(false);
  const [sessionInfo, setSessionInfo] = useState(null);
  const [platformResult, setPlatformResult] = useState({ data: null, error: null, status: 'idle' });
  const [tenantResult, setTenantResult] = useState({ data: null, error: null, status: 'idle' });
  const [connectionCheck, setConnectionCheck] = useState(null);

  const runDiagnostics = async () => {
    setLoading(true);
    setPlatformResult({ data: null, error: null, status: 'loading' });
    setTenantResult({ data: null, error: null, status: 'loading' });

    try {
      // 1. Check Session
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      const userInfo = {
        hasSession: !!session,
        userId: session?.user?.id || 'No User ID',
        email: session?.user?.email || 'No Email',
        role: session?.user?.role || 'No Auth Role',
        sessionError: sessionError ? sessionError.message : null
      };
      setSessionInfo(userInfo);

      if (!session) {
        setLoading(false);
        return; // Stop if no user
      }

      // 2. Check Platform Staff Table
      // We purposefully select * to see everything, and avoid .single() to see if we get duplicates or empty lists
      const startPlatform = performance.now();
      const { data: pData, error: pError } = await supabase
        .from('platform_staff')
        .select('*')
        .eq('user_id', session.user.id);
      
      setPlatformResult({
        data: pData,
        error: pError,
        status: pError ? 'error' : (pData?.length ? 'found' : 'empty'),
        duration: (performance.now() - startPlatform).toFixed(2)
      });

      // 3. Check Tenant Members Table
      const startTenant = performance.now();
      const { data: tData, error: tError } = await supabase
        .from('tenant_members')
        .select('*')
        .eq('user_id', session.user.id);

      setTenantResult({
        data: tData,
        error: tError,
        status: tError ? 'error' : (tData?.length ? 'found' : 'empty'),
        duration: (performance.now() - startTenant).toFixed(2)
      });

      // 4. Connection / Public Access Check
      // Try to read something we know exists or is public to verify DB connection generally
      const { count, error: countError } = await supabase.from('platform_staff').select('*', { count: 'exact', head: true });
      setConnectionCheck({ ok: !countError, error: countError });

    } catch (err) {
      console.error("Diagnostic crash:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    runDiagnostics();
  }, []);

  const StatusIcon = ({ status }) => {
    if (status === 'loading') return <Loader2 className="h-5 w-5 animate-spin text-blue-500" />;
    if (status === 'error') return <XCircle className="h-5 w-5 text-red-500" />;
    if (status === 'found') return <CheckCircle2 className="h-5 w-5 text-green-500" />;
    if (status === 'empty') return <AlertTriangle className="h-5 w-5 text-amber-500" />;
    return <div className="h-5 w-5 rounded-full bg-slate-200" />;
  };

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">System Diagnostics</h1>
            <p className="text-slate-500">RLS Policy & Role Detection Debugger</p>
          </div>
          <Button onClick={runDiagnostics} disabled={loading}>
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            Run Diagnostics
          </Button>
        </div>

        {/* AUTH SECTION */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className={`h-3 w-3 rounded-full ${sessionInfo?.hasSession ? 'bg-green-500' : 'bg-red-500'}`} />
              Authentication State
            </CardTitle>
          </CardHeader>
          <CardContent>
            {sessionInfo ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-3 bg-slate-100 rounded-lg">
                  <div className="text-xs text-slate-500 uppercase font-bold">User ID</div>
                  <div className="font-mono text-sm break-all">{sessionInfo.userId}</div>
                </div>
                <div className="p-3 bg-slate-100 rounded-lg">
                  <div className="text-xs text-slate-500 uppercase font-bold">Email</div>
                  <div className="font-medium text-sm">{sessionInfo.email}</div>
                </div>
                <div className="p-3 bg-slate-100 rounded-lg">
                  <div className="text-xs text-slate-500 uppercase font-bold">Supabase Role</div>
                  <div className="font-mono text-sm">{sessionInfo.role}</div>
                </div>
                {sessionInfo.sessionError && (
                  <Alert variant="destructive" className="col-span-full">
                    <AlertTitle>Session Error</AlertTitle>
                    <AlertDescription>{sessionInfo.sessionError}</AlertDescription>
                  </Alert>
                )}
              </div>
            ) : (
              <div className="text-center py-4 text-slate-500">Loading session data...</div>
            )}
          </CardContent>
        </Card>

        {/* DATABASE RESULTS */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* PLATFORM STAFF */}
          <Card className={platformResult.status === 'found' ? 'border-green-200 bg-green-50/30' : ''}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Platform Staff Table</CardTitle>
                <StatusIcon status={platformResult.status} />
              </div>
              <CardDescription>Querying 'platform_staff' for current user ID</CardDescription>
            </CardHeader>
            <CardContent>
              {platformResult.status === 'loading' ? (
                <div className="h-20 flex items-center justify-center"><Loader2 className="animate-spin text-slate-400" /></div>
              ) : (
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Status:</span>
                    <span className="font-medium uppercase">{platformResult.status}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Latency:</span>
                    <span className="font-mono">{platformResult.duration}ms</span>
                  </div>
                  
                  {platformResult.error && (
                    <Alert variant="destructive" className="mt-2">
                      <AlertTitle>Supabase Error {platformResult.error.code}</AlertTitle>
                      <AlertDescription className="font-mono text-xs">
                        {platformResult.error.message}
                        {platformResult.error.hint && <div className="mt-1 opacity-80">Hint: {platformResult.error.hint}</div>}
                      </AlertDescription>
                    </Alert>
                  )}

                  {platformResult.data && (
                    <div className="bg-slate-900 text-slate-50 p-3 rounded-md overflow-x-auto">
                      <pre className="text-xs font-mono">{JSON.stringify(platformResult.data, null, 2)}</pre>
                    </div>
                  )}
                  
                  {platformResult.status === 'empty' && !platformResult.error && (
                    <div className="p-3 bg-amber-50 text-amber-800 text-sm rounded border border-amber-200 flex items-start gap-2">
                       <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                       <div>
                         <strong>No records found.</strong>
                         <p className="mt-1 text-xs">
                           Possibilities:
                           <ul className="list-disc pl-4 mt-1 space-y-1">
                             <li>User is actually not in the table.</li>
                             <li><strong>RLS Policy is blocking access.</strong> (Most likely)</li>
                           </ul>
                         </p>
                       </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* TENANT MEMBERS */}
          <Card className={tenantResult.status === 'found' ? 'border-green-200 bg-green-50/30' : ''}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Tenant Members Table</CardTitle>
                <StatusIcon status={tenantResult.status} />
              </div>
              <CardDescription>Querying 'tenant_members' for current user ID</CardDescription>
            </CardHeader>
            <CardContent>
              {tenantResult.status === 'loading' ? (
                 <div className="h-20 flex items-center justify-center"><Loader2 className="animate-spin text-slate-400" /></div>
              ) : (
                <div className="space-y-3">
                   <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Status:</span>
                    <span className="font-medium uppercase">{tenantResult.status}</span>
                  </div>
                  
                  {tenantResult.error && (
                    <Alert variant="destructive" className="mt-2">
                      <AlertTitle>Error {tenantResult.error.code}</AlertTitle>
                      <AlertDescription className="font-mono text-xs">{tenantResult.error.message}</AlertDescription>
                    </Alert>
                  )}

                  {tenantResult.data && (
                    <div className="bg-slate-900 text-slate-50 p-3 rounded-md overflow-x-auto">
                      <pre className="text-xs font-mono">{JSON.stringify(tenantResult.data, null, 2)}</pre>
                    </div>
                  )}

                  {tenantResult.status === 'empty' && !tenantResult.error && (
                    <div className="p-3 bg-amber-50 text-amber-800 text-sm rounded border border-amber-200 flex items-start gap-2">
                       <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                       <div>
                         <strong>No records found.</strong>
                         <p className="mt-1 text-xs">Check RLS policies or verify invitation status.</p>
                       </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* OVERALL HEALTH */}
        <Card>
            <CardHeader><CardTitle className="text-lg">Environment & Policies</CardTitle></CardHeader>
            <CardContent>
               <div className="space-y-2">
                 <div className="flex items-center gap-2">
                    <Database className="h-4 w-4 text-slate-500" />
                    <span className="text-sm font-medium">Database Connection:</span>
                    {connectionCheck?.ok ? (
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Active</span>
                    ) : (
                        <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded">Failed</span>
                    )}
                 </div>
                 <div className="text-xs text-slate-500 bg-slate-100 p-4 rounded mt-4">
                    <strong>RLS Policy Debugging Hint:</strong>
                    <p className="mt-1">
                        If tables show "Status: EMPTY" but you KNOW the user is in there, execute the following SQL in your Supabase SQL Editor to fix RLS:
                    </p>
                    <pre className="mt-2 bg-slate-800 text-slate-300 p-2 rounded overflow-x-auto">
{`-- For Platform Staff
CREATE POLICY "Enable read access for own user" ON "public"."platform_staff"
AS PERMISSIVE FOR SELECT
TO public
USING (auth.uid() = user_id);

-- For Tenant Members
CREATE POLICY "Enable read access for own user" ON "public"."tenant_members"
AS PERMISSIVE FOR SELECT
TO public
USING (auth.uid() = user_id);`}
                    </pre>
                 </div>
               </div>
            </CardContent>
        </Card>

      </div>
    </div>
  );
};

export default Diagnostics;
