
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Shield, Lock, Users, Zap, FileText, CheckCircle, ArrowRight, Layout, Cpu } from 'lucide-react';
import Logo from '@/components/Logo';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const Home = () => {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-white flex flex-col font-sans">
      {/* Navigation */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Logo />
          <nav className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors">Features</a>
            <a href="#how-it-works" className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors">How it Works</a>
            <a href="#pricing" className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors">Pricing</a>
          </nav>
          <div className="flex items-center gap-4">
            {user ? (
               <Link to="/dashboard">
                 <Button className="bg-[#2f6f95] hover:bg-[#265a7a] text-white">Go to Dashboard</Button>
               </Link>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="ghost" className="text-slate-600">Sign In</Button>
                </Link>
                <Link to="/signup">
                  <Button className="bg-[#2f6f95] hover:bg-[#265a7a] text-white">Get Started</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative pt-20 pb-32 overflow-hidden bg-slate-50">
           <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
             <div className="mx-auto max-w-4xl text-center">
               <div className="inline-flex items-center rounded-full border border-slate-200 bg-white px-3 py-1 text-sm font-medium text-slate-800 mb-8 shadow-sm">
                 <span className="flex h-2 w-2 rounded-full bg-[#8fd6d2] mr-2"></span>
                 New: AI-Powered Threat Analysis
               </div>
               <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-slate-900 mb-8 leading-tight">
                 Secure Your Architecture <br className="hidden md:block" />
                 <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#2f6f95] to-[#8fd6d2]">Before You Build</span>
               </h1>
               <p className="mt-6 text-xl leading-8 text-slate-600 max-w-2xl mx-auto">
                 The modern threat modeling platform for agile teams. Identify risks, ensure compliance, and secure your applications by design with automated STRIDE analysis.
               </p>
               <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
                 {user ? (
                    <Link to="/dashboard">
                      <Button size="lg" className="h-12 px-8 text-base w-full sm:w-auto bg-[#2f6f95] hover:bg-[#265a7a] text-white">Launch Platform</Button>
                    </Link>
                 ) : (
                    <Link to="/signup">
                      <Button size="lg" className="h-12 px-8 text-base w-full sm:w-auto bg-[#2f6f95] hover:bg-[#265a7a] text-white">Start Free Trial</Button>
                    </Link>
                 )}
                 <Button variant="outline" size="lg" className="h-12 px-8 text-base w-full sm:w-auto bg-white hover:bg-slate-50 text-[#2f6f95] border-[#2f6f95]/20">
                   <Zap className="mr-2 h-4 w-4" /> View Demo
                 </Button>
               </div>
               
               <div className="mt-12 text-sm text-slate-500 flex items-center justify-center gap-6">
                 <span className="flex items-center"><CheckCircle className="w-4 h-4 mr-2 text-[#8fd6d2]" /> No credit card required</span>
                 <span className="flex items-center"><CheckCircle className="w-4 h-4 mr-2 text-[#8fd6d2]" /> 14-day free trial</span>
               </div>
             </div>
           </div>
           
           {/* Abstract Background Element */}
           <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1200px] h-[600px] bg-gradient-to-tr from-[#8fd6d2]/20 to-[#2f6f95]/20 rounded-full blur-3xl -z-10 opacity-60" />
        </section>

        {/* Features Grid */}
        <section id="features" className="py-24 bg-white">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">Everything you need to secure your app</h2>
              <p className="mt-4 text-lg text-slate-600">From automated threat discovery to compliance mapping, we've got your security architecture covered.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  icon: <Shield className="w-6 h-6 text-white" />,
                  color: "bg-[#2f6f95]",
                  title: "Automated Threat Analysis",
                  description: "Automatically identify threats using STRIDE methodology as you design your system architecture."
                },
                {
                  icon: <Cpu className="w-6 h-6 text-white" />,
                  color: "bg-[#8fd6d2]",
                  title: "AI-Powered Suggestions",
                  description: "Leverage our LLM integration to suggest specific mitigations based on your technology stack."
                },
                {
                  icon: <FileText className="w-6 h-6 text-white" />,
                  color: "bg-teal-600",
                  title: "Compliance Mapping",
                  description: "Map identified threats directly to controls for SOC2, HIPAA, ISO 27001, and GDPR."
                },
                {
                  icon: <Users className="w-6 h-6 text-white" />,
                  color: "bg-purple-600",
                  title: "Team Collaboration",
                  description: "Real-time collaboration for security architects, developers, and product owners in one canvas."
                },
                {
                  icon: <Layout className="w-6 h-6 text-white" />,
                  color: "bg-pink-600",
                  title: "Visual Modeling",
                  description: "Intuitive drag-and-drop interface for creating data flow diagrams (DFDs) and system architectures."
                },
                {
                  icon: <Lock className="w-6 h-6 text-white" />,
                  color: "bg-slate-600",
                  title: "Remediation Tracking",
                  description: "Track mitigation status and push tasks directly to Jira or GitHub issues."
                }
              ].map((feature, index) => (
                <div key={index} className="p-8 rounded-2xl bg-slate-50 border border-slate-100 hover:shadow-lg transition-shadow duration-300">
                  <div className={`w-12 h-12 rounded-lg ${feature.color} flex items-center justify-center mb-6 shadow-md`}>
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">{feature.title}</h3>
                  <p className="text-slate-600 leading-relaxed">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-slate-900 relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1557683316-973673baf926?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-10"></div>
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl mb-6">Ready to start modeling?</h2>
            <p className="text-xl text-slate-300 mb-10 max-w-2xl mx-auto">
              Join thousands of security professionals who are shifting left and securing their applications by design.
            </p>
            <Link to="/signup">
              <Button size="lg" className="h-14 px-8 text-lg bg-[#2f6f95] hover:bg-[#265a7a] border-none text-white">
                Get Started for Free <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <p className="mt-6 text-sm text-slate-400">No credit card required for 14-day trial.</p>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div className="col-span-1 md:col-span-1">
              <Logo />
              <p className="mt-4 text-sm text-slate-500 leading-relaxed">
                Secure by design. The complete platform for threat modeling and risk assessment.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><a href="#" className="hover:text-[#2f6f95]">Features</a></li>
                <li><a href="#" className="hover:text-[#2f6f95]">Integrations</a></li>
                <li><a href="#" className="hover:text-[#2f6f95]">Pricing</a></li>
                <li><a href="#" className="hover:text-[#2f6f95]">Roadmap</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Resources</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><a href="#" className="hover:text-[#2f6f95]">Documentation</a></li>
                <li><a href="#" className="hover:text-[#2f6f95]">API Reference</a></li>
                <li><a href="#" className="hover:text-[#2f6f95]">Blog</a></li>
                <li><a href="#" className="hover:text-[#2f6f95]">Community</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><a href="#" className="hover:text-[#2f6f95]">About</a></li>
                <li><a href="#" className="hover:text-[#2f6f95]">Careers</a></li>
                <li><a href="#" className="hover:text-[#2f6f95]">Legal</a></li>
                <li><a href="#" className="hover:text-[#2f6f95]">Contact</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-slate-500">&copy; 2025 CreativeCyber. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;
