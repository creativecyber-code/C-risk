
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Logo from '@/components/Logo'; // Import the Logo component

const PrivacyPolicy = () => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans">
      <Helmet>
        <title>Privacy Policy - CreativeCyber</title>
        <meta name="description" content="Read the privacy policy for CreativeCyber, detailing data handling and user rights." />
      </Helmet>

      {/* Header */}
      <header className="py-4 border-b border-slate-200 bg-white">
        <div className="container mx-auto px-4 flex items-center justify-between">
          <Logo />
          <Link to="/" className="text-sm font-medium text-slate-600 hover:text-blue-600 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" /> Back to Home
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 md:py-16">
        <article className="prose prose-lg max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">Privacy Policy</h1>
          <p className="text-slate-600 text-lg mb-8">
            Last updated: December 30, 2025
          </p>

          <p>
            Welcome to CreativeCyber! We are committed to protecting your privacy and handling your data in an open and transparent manner. This Privacy Policy explains how CreativeCyber ("we", "us", or "our") collects, uses, discloses, and protects your information when you visit our website, use our services, or interact with us.
          </p>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">1. Information We Collect</h2>
          <p>We collect various types of information in connection with the services we provide, including:</p>
          <ul>
            <li><strong>Personal Information:</strong> This includes data that can be used to identify you directly or indirectly, such as your name, email address, company, job title, and contact details.</li>
            <li><strong>Usage Data:</strong> Information on how you access and use our services, which may include your IP address, browser type, device information, pages visited, and the time and date of your visit.</li>
            <li><strong>Transactional Data:</strong> Details about services you have purchased from us and payment information.</li>
            <li><strong>Communication Data:</strong> Records of your communications with us, including emails, chat messages, and support tickets.</li>
          </ul>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">2. How We Use Your Information</h2>
          <p>We use the collected information for various purposes, including:</p>
          <ul>
            <li>To provide, maintain, and improve our services.</li>
            <li>To manage your account and provide customer support.</li>
            <li>To process transactions and send related information, including purchase confirmations and invoices.</li>
            <li>To communicate with you about products, services, offers, and events.</li>
            <li>To monitor and analyze usage and trends to improve your experience.</li>
            <li>To detect, prevent, and address technical issues or security incidents.</li>
            <li>To comply with legal obligations.</li>
          </ul>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">3. Data Sharing and Disclosure</h2>
          <p>We may share your information with third parties in the following situations:</p>
          <ul>
            <li><strong>Service Providers:</strong> We engage third-party companies and individuals to facilitate our services, provide services on our behalf, or assist us in analyzing how our services are used.</li>
            <li><strong>Business Transfers:</strong> In connection with any merger, sale of company assets, financing, or acquisition of all or a portion of our business to another company.</li>
            <li><strong>Legal Requirements:</strong> We may disclose your information where required to do so by law or in response to valid requests by public authorities.</li>
            <li><strong>With Your Consent:</strong> We may disclose your personal information for any other purpose with your explicit consent.</li>
          </ul>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">4. Data Security</h2>
          <p>
            The security of your data is paramount to us. We implement industry-standard technical and organizational security measures designed to protect your personal information from unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the Internet or electronic storage is 100% secure.
          </p>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">5. Your Data Protection Rights</h2>
          <p>Depending on your location, you may have the following rights regarding your data:</p>
          <ul>
            <li><strong>Access:</strong> The right to request copies of your personal data.</li>
            <li><strong>Rectification:</strong> The right to request that we correct any information you believe is inaccurate or complete information you believe is incomplete.</li>
            <li><strong>Erasure:</strong> The right to request that we erase your personal data, under certain conditions.</li>
            <li><strong>Restrict Processing:</strong> The right to request that we restrict the processing of your personal data, under certain conditions.</li>
            <li><strong>Object to Processing:</strong> The right to object to our processing of your personal data, under certain conditions.</li>
            <li><strong>Data Portability:</strong> The right to request that we transfer the data that we have collected to another organization, or directly to you, under certain conditions.</li>
          </ul>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">6. Changes to This Privacy Policy</h2>
          <p>
            We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date. We advise you to review this Privacy Policy periodically for any changes.
          </p>

          <h2 className="text-2xl font-semibold text-slate-800 mt-8 mb-4">7. Contact Us</h2>
          <p>
            If you have any questions about this Privacy Policy, please contact us:
          </p>
          <ul>
            <li>By email: support@creativecyber.com</li>
            <li>By visiting this page on our website: <a href="https://www.creativecyber.com/contact" className="text-blue-600 hover:underline">Contact Us</a></li>
          </ul>
        </article>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-8">
        <div className="container mx-auto px-4 text-center text-sm">
          <p>&copy; {new Date().getFullYear()} CreativeCyber. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default PrivacyPolicy;
