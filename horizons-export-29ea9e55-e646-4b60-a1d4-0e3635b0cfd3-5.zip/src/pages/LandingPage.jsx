import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Shield, Lock, Activity, Globe, ArrowRight, CheckCircle2, Server, LayoutDashboard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Logo from '@/components/Logo';

// This is the original landing page for crisk.creativecyber.in.
// It has been restored and the sign-in link updated to point to the access gateway.

const LandingPage = () => {
  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans selection:bg-blue-100">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 w-full border-b border-slate-200/80 bg-white/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between">
          <Logo />
          <div className="hidden md:flex items-center gap-8">
            <Link to="#" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">Platform</Link>
            <Link to="#" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">Solutions</Link>
            <Link to="#" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">Compliance</Link>
            <Link to="#" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">Company</Link>
          </div>
          <div className="flex items-center gap-4">
            {/* Updated sign-in link to point to the unified access gateway */}
            <Link to="/login"> 
              <Button variant="ghost" className="font-semibold text-slate-700">Log In</Button>
            </Link>
            <Link to="/contact">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-200">
                Book Demo
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-30 pointer-events-none">
          <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-gradient-to-br from-blue-100/50 to-indigo-100/50 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3" />
          <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-gradient-to-tr from-slate-100 to-blue-50 rounded-full blur-3xl translate-y-1/3 -translate-x-1/4" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-50 border border-blue-100 text-blue-700 text-sm font-medium mb-4"
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
              </span>
              Next-Gen GRC Platform 2.0 is Live
            </motion.div>

            <motion.h1 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-5xl md:text-7xl font-bold tracking-tight text-slate-900 leading-[1.1]"
            >
              Governance, Risk, and Compliance for the <span className="text-blue-600">AI Era</span>
            </motion.h1>

            <motion.p 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl text-slate-500 max-w-2xl mx-auto leading-relaxed"
            >
              Automate your risk management lifecycle, streamline regulatory compliance, and secure your digital assets with C-RISK's intelligent platform.
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4"
            >
              <Button size="lg" className="h-14 px-8 text-lg bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto shadow-xl shadow-blue-200">
                Start Free Trial <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="h-14 px-8 text-lg border-slate-300 text-slate-700 hover:bg-slate-50 w-full sm:w-auto">
                View Documentation
              </Button>
            </motion.div>
          </div>

          {/* Abstract Dashboard Preview */}
          <motion.div 
            initial={{ opacity: 0, y: 60, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mt-20 relative mx-auto max-w-6xl rounded-2xl border border-slate-200 bg-white/50 backdrop-blur-sm shadow-2xl p-4 md:p-8"
          >
             <div className="absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-blue-500/20/20 to-transparent" />
             <div className="rounded-xl overflow-hidden border border-slate-200 bg-white shadow-sm">
                <img alt="C-RISK Dashboard Interface" src="https://images.unsplash.com/photo-1516383274235-5f42d6c6426d" />
             </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-slate-50 border-t border-slate-200">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Enterprise-Grade Security Architecture</h2>
            <p className="text-slate-500 text-lg">Built from the ground up to support the most demanding financial institutions and regulated industries.</p>
          </div>

          <motion.div 
            variants={staggerContainer}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {[
              {
                icon: Shield,
                title: "Bank-Grade Encryption",
                desc: "AES-256 data at rest and TLS 1.3 in transit ensures your sensitive risk data never leaves the secure enclave."
              },
              {
                icon: Activity,
                title: "Real-time Monitoring",
                desc: "Continuous control monitoring detects drift in compliance posture instantly, alerting your team before risks materialize."
              },
              {
                icon: Globe,
                title: "Global Compliance",
                desc: "Pre-mapped controls for GDPR, SOC2, ISO 27001, HIPAA, and regional banking regulations tailored to your jurisdiction."
              },
              {
                icon: Lock,
                title: "Zero Trust Access",
                desc: "Granular RBAC and ABAC policies ensure staff only access what they need, when they need it."
              },
              {
                icon: Server,
                title: "Data Sovereignty",
                desc: "Choose where your data resides. We support multi-region deployments to meet local data residency laws."
              },
              {
                icon: LayoutDashboard,
                title: "Unified Governance",
                desc: "Break down silos. Bring IT, Security, Legal, and Audit teams into a single source of truth."
              }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                variants={fadeInUp}
                className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="h-12 w-12 bg-blue-50 rounded-lg flex items-center justify-center mb-6">
                  <feature.icon className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{feature.title}</h3>
                <p className="text-slate-500 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-[#0B1120] text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 mix-blend-overlay"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h2 className="text-4xl font-bold tracking-tight">Ready to secure your organization?</h2>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Join leading banks, fintechs, and enterprises who trust C-RISK for their governance and compliance needs.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
               <Link to="/login"> {/* Updated link */}
                 <Button size="lg" className="h-14 px-8 text-lg bg-blue-600 hover:bg-blue-500 text-white w-full sm:w-auto">
                   Access Gateway
                 </Button>
               </Link>
               <Button size="lg" variant="outline" className="h-14 px-8 text-lg border-white/20 bg-transparent text-white hover:bg-white hover:text-[#0B1120] w-full sm:w-auto">
                 Schedule Consultation
               </Button>
            </div>
            <p className="pt-8 text-sm text-slate-500 flex items-center justify-center gap-6">
              <span className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-green-500" /> No credit card required</span>
              <span className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-green-500" /> 14-day free trial</span>
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12 border-t border-slate-200">
        <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 bg-blue-600 rounded-md flex items-center justify-center text-white font-bold">C</div>
            <span className="font-bold text-xl text-slate-900">C-RISK</span>
          </div>
          <div className="text-sm text-slate-500">
            © {new Date().getFullYear()} CreativeCyber. All rights reserved.
          </div>
          <div className="flex gap-6 text-sm text-slate-500">
             <Link to="#" className="hover:text-blue-600">Privacy</Link>
             <Link to="#" className="hover:text-blue-600">Terms</Link>
             <Link to="#" className="hover:text-blue-600">Security</Link>
             <Link to="#" className="hover:text-blue-600">Contact</Link>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;