
import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/AuthContext';
import { controlService } from '@/services/controlService';
import { useToast } from '@/components/ui/use-toast';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  ChevronLeft,
  FileText,
  ShieldCheck,
  CheckCircle,
  XCircle,
  AlertCircle,
  Clock,
  ExternalLink,
  Plus,
  Trash2,
  User,
  History,
  Loader2,
  CalendarDays,
  ArrowLeft,
  Link as LinkIcon
} from 'lucide-react';
import { format } from 'date-fns';

const ControlDetailPage = () => {
  const { id } = useParams();
  const { tenant, user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [control, setControl] = useState(null);
  const [evidenceList, setEvidenceList] = useState([]);
  const [auditList, setAuditList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Modals
  const [isEvidenceModalOpen, setIsEvidenceModalOpen] = useState(false);
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  
  // Forms
  const [evidenceForm, setEvidenceForm] = useState({ evidence_type: 'documentation', description: '', evidence_url: '' });
  const [auditForm, setAuditForm] = useState({ audit_type: 'design', result: 'Pass', notes: '' });

  useEffect(() => {
    fetchData();
  }, [id, tenant?.id]);

  const fetchData = async () => {
    if (!id || !tenant?.id) return;
    setLoading(true);
    try {
      const [controlData, evidenceData, auditData] = await Promise.all([
        controlService.getControlDetail(id, tenant.id),
        controlService.getControlEvidence(id, tenant.id),
        controlService.getControlAudits(id, tenant.id)
      ]);
      setControl(controlData);
      setEvidenceList(evidenceData || []);
      setAuditList(auditData || []);
    } catch (err) {
      console.error(err);
      toast({ title: "Error", description: "Could not load control.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleEvidenceSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await controlService.addEvidence({
        control_id: id,
        org_id: tenant.id,
        provided_by: user.id,
        ...evidenceForm
      });
      toast({ title: "Success", description: "Evidence uploaded." });
      setIsEvidenceModalOpen(false);
      setEvidenceForm({ evidence_type: 'documentation', description: '', evidence_url: '' });
      const updatedEvidence = await controlService.getControlEvidence(id, tenant.id);
      setEvidenceList(updatedEvidence);
    } catch (err) {
      toast({ title: "Error", description: "Upload failed.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAuditSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await controlService.addAuditResult({
        control_id: id,
        org_id: tenant.id,
        audited_by: user.id,
        ...auditForm
      });
      toast({ title: "Success", description: "Audit recorded." });
      setIsAuditModalOpen(false);
      setAuditForm({ audit_type: 'design', result: 'Pass', notes: '' });
      const updatedAudits = await controlService.getControlAudits(id, tenant.id);
      setAuditList(updatedAudits);
    } catch (err) {
      toast({ title: "Error", description: "Audit record failed.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteEvidence = async (id) => {
    const prev = [...evidenceList];
    setEvidenceList(list => list.filter(i => i.id !== id));
    try {
      await controlService.deleteEvidence(id);
      toast({ title: "Deleted", description: "Evidence removed." });
    } catch (err) {
      setEvidenceList(prev);
      toast({ title: "Error", description: "Delete failed.", variant: "destructive" });
    }
  };

  const handleDeleteAudit = async (id) => {
    const prev = [...auditList];
    setAuditList(list => list.filter(i => i.id !== id));
    try {
      await controlService.deleteAuditResult(id);
      toast({ title: "Deleted", description: "Record removed." });
    } catch (err) {
      setAuditList(prev);
      toast({ title: "Error", description: "Delete failed.", variant: "destructive" });
    }
  };

  if (loading) {
    return (
       <div className="space-y-6 pb-12 max-w-7xl mx-auto p-6">
          <Skeleton className="h-8 w-1/4 mb-4" />
          <Skeleton className="h-32 w-full mb-8" />
          <div className="grid grid-cols-2 gap-6">
             <Skeleton className="h-64 w-full" />
             <Skeleton className="h-64 w-full" />
          </div>
       </div>
    );
  }

  if (!control) return null;

  return (
    <div className="space-y-6 pb-12 font-sans">
      <Helmet>
        <title>{control.code} | Control Details</title>
      </Helmet>

      {/* Breadcrumb */}
      <div className="px-1">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/dashboard">Dashboard</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink href="/dashboard/audit-workspace">Audit Workspace</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>{control.code}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      </div>

      {/* Header */}
      <div className="flex flex-col md:flex-row gap-6 border-b pb-6">
          <div className="flex-1">
             <div className="flex items-center gap-3 mb-2">
               <Button variant="ghost" size="icon" className="-ml-3 h-8 w-8" onClick={() => navigate(-1)}>
                 <ArrowLeft className="h-5 w-5" />
               </Button>
               <Badge variant="outline" className="text-sm font-bold bg-white">{control.code}</Badge>
               <Badge variant="secondary" className={
                  control.status === 'Effective' ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-700'
               }>
                  {control.status}
               </Badge>
             </div>
             <h1 className="text-3xl font-bold text-slate-900 mb-2 tracking-tight">{control.title}</h1>
             <p className="text-slate-600 leading-relaxed max-w-4xl text-lg">{control.description}</p>
             
             <div className="flex flex-wrap gap-6 mt-6 text-sm text-slate-500">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-slate-400" />
                  <span>Domain: {control.domain || 'Uncategorized'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-slate-400" />
                  <span>Owner: {control.owner?.email || 'Unassigned'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <CalendarDays className="h-4 w-4 text-slate-400" />
                  <span>Updated: {format(new Date(control.updated_at), 'MMM d, yyyy')}</span>
                </div>
             </div>
          </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Evidence Column */}
        <div className="space-y-4">
           <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                 <FileText className="h-5 w-5 text-blue-600" /> Evidence
              </h2>
              <Dialog open={isEvidenceModalOpen} onOpenChange={setIsEvidenceModalOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" variant="outline" className="h-8">
                      <Plus className="h-3.5 w-3.5 mr-1.5" /> Add
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Upload Evidence</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleEvidenceSubmit} className="space-y-4 py-4">
                      <div className="grid gap-2">
                        <Label>Type</Label>
                        <Select value={evidenceForm.evidence_type} onValueChange={(v) => setEvidenceForm(prev => ({...prev, evidence_type: v}))}>
                           <SelectTrigger><SelectValue /></SelectTrigger>
                           <SelectContent>
                              <SelectItem value="documentation">Documentation</SelectItem>
                              <SelectItem value="screenshot">Screenshot</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                           </SelectContent>
                        </Select>
                      </div>
                      <div className="grid gap-2">
                        <Label>Description</Label>
                        <Textarea required value={evidenceForm.description} onChange={(e) => setEvidenceForm(prev => ({...prev, description: e.target.value}))} />
                      </div>
                      <div className="grid gap-2">
                         <Label>URL</Label>
                         <Input value={evidenceForm.evidence_url} onChange={(e) => setEvidenceForm(prev => ({...prev, evidence_url: e.target.value}))} />
                      </div>
                      <DialogFooter>
                         <Button type="button" variant="outline" onClick={() => setIsEvidenceModalOpen(false)}>Cancel</Button>
                         <Button type="submit" disabled={isSubmitting}>Submit</Button>
                      </DialogFooter>
                    </form>
                  </DialogContent>
              </Dialog>
           </div>

           <Card className="border-slate-200 shadow-sm overflow-hidden h-full">
              {evidenceList.length === 0 ? (
                 <div className="flex flex-col items-center justify-center h-48 bg-slate-50/50">
                    <FileText className="h-8 w-8 text-slate-300 mb-2" />
                    <p className="text-sm text-slate-500">No evidence uploaded.</p>
                 </div>
              ) : (
                 <div className="divide-y divide-slate-100">
                    {evidenceList.map(item => (
                       <div key={item.id} className="p-4 hover:bg-slate-50 transition-colors flex gap-3 group">
                          <div className="mt-1 h-8 w-8 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 shrink-0">
                             <LinkIcon className="h-4 w-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                             <div className="flex justify-between">
                                <span className="font-medium text-slate-900 text-sm capitalize">{item.evidence_type}</span>
                                <span className="text-xs text-slate-400">{format(new Date(item.created_at), 'MMM d')}</span>
                             </div>
                             <p className="text-sm text-slate-600 line-clamp-2 mt-0.5">{item.description}</p>
                             {item.evidence_url && (
                                <a href={item.evidence_url} target="_blank" className="text-xs text-blue-600 hover:underline flex items-center gap-1 mt-1">
                                   View Link <ExternalLink className="h-3 w-3" />
                                </a>
                             )}
                          </div>
                          <Button size="icon" variant="ghost" className="opacity-0 group-hover:opacity-100 h-6 w-6 text-slate-400 hover:text-red-600" onClick={() => handleDeleteEvidence(item.id)}>
                             <Trash2 className="h-3 w-3" />
                          </Button>
                       </div>
                    ))}
                 </div>
              )}
           </Card>
        </div>

        {/* Audit Column */}
        <div className="space-y-4">
           <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                 <History className="h-5 w-5 text-purple-600" /> Audit History
              </h2>
              <Dialog open={isAuditModalOpen} onOpenChange={setIsAuditModalOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" variant="outline" className="h-8">
                      <Plus className="h-3.5 w-3.5 mr-1.5" /> Log Result
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                       <DialogTitle>Log Audit Result</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleAuditSubmit} className="space-y-4 py-4">
                       <div className="grid grid-cols-2 gap-4">
                          <div className="grid gap-2">
                             <Label>Type</Label>
                             <Select value={auditForm.audit_type} onValueChange={(v) => setAuditForm(prev => ({...prev, audit_type: v}))}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                   <SelectItem value="design">Design</SelectItem>
                                   <SelectItem value="operating">Operating</SelectItem>
                                </SelectContent>
                             </Select>
                          </div>
                          <div className="grid gap-2">
                             <Label>Result</Label>
                             <Select value={auditForm.result} onValueChange={(v) => setAuditForm(prev => ({...prev, result: v}))}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                   <SelectItem value="Pass">Pass</SelectItem>
                                   <SelectItem value="Fail">Fail</SelectItem>
                                </SelectContent>
                             </Select>
                          </div>
                       </div>
                       <div className="grid gap-2">
                          <Label>Notes</Label>
                          <Textarea required value={auditForm.notes} onChange={(e) => setAuditForm(prev => ({...prev, notes: e.target.value}))} />
                       </div>
                       <DialogFooter>
                          <Button type="button" variant="outline" onClick={() => setIsAuditModalOpen(false)}>Cancel</Button>
                          <Button type="submit" disabled={isSubmitting}>Save</Button>
                       </DialogFooter>
                    </form>
                  </DialogContent>
              </Dialog>
           </div>

           <Card className="border-slate-200 shadow-sm overflow-hidden h-full">
              {auditList.length === 0 ? (
                 <div className="flex flex-col items-center justify-center h-48 bg-slate-50/50">
                    <History className="h-8 w-8 text-slate-300 mb-2" />
                    <p className="text-sm text-slate-500">No audits recorded.</p>
                 </div>
              ) : (
                 <div className="divide-y divide-slate-100">
                    {auditList.map(audit => (
                       <div key={audit.id} className="p-4 hover:bg-slate-50 transition-colors flex gap-3 group">
                          <div className="mt-1">
                             {audit.result === 'Pass' ? <CheckCircle className="h-5 w-5 text-green-500" /> : <XCircle className="h-5 w-5 text-red-500" />}
                          </div>
                          <div className="flex-1 min-w-0">
                             <div className="flex justify-between">
                                <span className="font-medium text-slate-900 text-sm capitalize">{audit.audit_type} Test</span>
                                <span className="text-xs text-slate-400">{format(new Date(audit.audited_at), 'MMM d')}</span>
                             </div>
                             <p className="text-sm text-slate-600 line-clamp-2 mt-0.5">{audit.notes}</p>
                             <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline" className="text-[10px] h-5">{audit.result}</Badge>
                                <span className="text-[10px] text-slate-400">By: {audit.auditor?.email}</span>
                             </div>
                          </div>
                          <Button size="icon" variant="ghost" className="opacity-0 group-hover:opacity-100 h-6 w-6 text-slate-400 hover:text-red-600" onClick={() => handleDeleteAudit(audit.id)}>
                             <Trash2 className="h-3 w-3" />
                          </Button>
                       </div>
                    ))}
                 </div>
              )}
           </Card>
        </div>
      </div>
    </div>
  );
};

export default ControlDetailPage;
