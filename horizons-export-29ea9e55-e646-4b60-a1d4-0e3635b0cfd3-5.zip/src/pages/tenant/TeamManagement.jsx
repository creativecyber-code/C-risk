
import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { invitationService } from '@/services/invitationService';
import { TenantHeader } from '@/components/tenant/TenantHeader';
import { InviteMemberDialog } from '@/components/tenant/InviteMemberDialog';
import { roleService } from '@/services/roleService';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Users, Mail, Clock, MoreHorizontal, UserX, Loader2, RefreshCw, XCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const TeamManagement = () => {
  const { tenant } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("active");
  const [members, setMembers] = useState([]);
  const [invitations, setInvitations] = useState([]);
  const [roles, setRoles] = useState({});
  const [loading, setLoading] = useState(true);
  const [inviteOpen, setInviteOpen] = useState(false);
  
  // Action Dialog States
  const [revokeId, setRevokeId] = useState(null);
  const [resendId, setResendId] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const fetchData = async () => {
    if (!tenant) return;
    setLoading(true);
    try {
        // 1. Fetch Roles
        const rolesData = await roleService.getTenantRoles();
        const rolesMap = rolesData.reduce((acc, role) => {
            acc[role.role_key] = role;
            return acc;
        }, {});
        setRoles(rolesMap);

        // 2. Fetch Active Members
        const { data: memberData } = await supabase
            .from('tenant_members')
            .select('*')
            .eq('tenant_id', tenant.id);
        setMembers(memberData || []);

        // 3. Fetch Invitations (including revoked for history, or just pending/active?)
        // Let's fetch all except accepted to show history or just pending
        // Filter out 'accepted' as they are now members
        const { data: inviteData } = await supabase
            .from('tenant_invitations')
            .select('*')
            .eq('tenant_id', tenant.id)
            .neq('status', 'accepted')
            .order('created_at', { ascending: false });
        setInvitations(inviteData || []);

    } catch (err) {
        console.error("Failed to load team data", err);
        toast({ title: "Error", description: "Failed to load team data", variant: "destructive" });
    } finally {
        setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [tenant]);

  const handleRevoke = async () => {
    if (!revokeId) return;
    setIsProcessing(true);
    try {
        await invitationService.revokeInvite(revokeId);
        toast({ title: "Invitation Revoked", description: "The invitation has been cancelled." });
        await fetchData();
    } catch (error) {
        toast({ title: "Revoke Failed", description: error.message, variant: "destructive" });
    } finally {
        setIsProcessing(false);
        setRevokeId(null);
    }
  };

  const handleResend = async () => {
    if (!resendId) return;
    setIsProcessing(true);
    try {
        await invitationService.resendInvite(resendId);
        toast({ title: "Invitation Resent", description: "A new invitation has been generated." });
        await fetchData();
    } catch (error) {
        toast({ title: "Resend Failed", description: error.message, variant: "destructive" });
    } finally {
        setIsProcessing(false);
        setResendId(null);
    }
  };

  const getRoleBadge = (roleKey) => {
    const role = roles[roleKey];
    const name = role ? role.display_name : roleKey;
    if (roleKey.includes('admin')) return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-200 border-purple-200">{name}</Badge>;
    if (roleKey.includes('manager')) return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200 border-blue-200">{name}</Badge>;
    return <Badge variant="secondary">{name}</Badge>;
  };

  const getStatusBadge = (status, expiresAt) => {
     if (status === 'revoked') return <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">Revoked</Badge>;
     if (new Date(expiresAt) < new Date()) return <Badge variant="outline" className="bg-slate-100 text-slate-500 border-slate-200">Expired</Badge>;
     return <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-200 border-amber-200">Pending</Badge>;
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Helmet>
        <title>Team Management | {tenant?.name || 'C-RISK'}</title>
      </Helmet>

      <TenantHeader />

      <main className="p-6 md:p-8 max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h1 className="text-2xl font-bold text-slate-900">Team Management</h1>
                <p className="text-slate-500 mt-1">Manage user access and roles for your organization.</p>
            </div>
            <Button onClick={() => setInviteOpen(true)} className="gap-2">
                <Plus className="h-4 w-4" /> Invite Member
            </Button>
        </div>

        <Tabs defaultValue="active" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="bg-white border p-1">
                <TabsTrigger value="active" className="gap-2">
                    <Users className="h-4 w-4" /> Active Members ({members.length})
                </TabsTrigger>
                <TabsTrigger value="invitations" className="gap-2">
                    <Mail className="h-4 w-4" /> Invitations ({invitations.length})
                </TabsTrigger>
            </TabsList>

            <TabsContent value="active" className="mt-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Active Team Members</CardTitle>
                        <CardDescription>Users who have access to the tenant portal.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        {loading ? (
                             <div className="flex justify-center p-8"><Loader2 className="animate-spin h-8 w-8 text-blue-500" /></div>
                        ) : members.length === 0 ? (
                            <div className="text-center py-12 text-slate-500">
                                <Users className="h-12 w-12 mx-auto text-slate-300 mb-3" />
                                <p>No active members found.</p>
                            </div>
                        ) : (
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>User</TableHead>
                                        <TableHead>Role</TableHead>
                                        <TableHead>Department</TableHead>
                                        <TableHead>Status</TableHead>
                                        <TableHead className="text-right">Actions</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {members.map((member) => (
                                        <TableRow key={member.id}>
                                            <TableCell>
                                                <div className="flex items-center gap-3">
                                                    <Avatar>
                                                        <AvatarImage src={`https://ui-avatars.com/api/?name=${member.email}&background=random`} />
                                                        <AvatarFallback>U</AvatarFallback>
                                                    </Avatar>
                                                    <div className="flex flex-col">
                                                        <span className="font-medium text-slate-900">{member.email.split('@')[0]}</span>
                                                        <span className="text-xs text-slate-500">{member.email}</span>
                                                    </div>
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                {getRoleBadge(member.role_key)}
                                            </TableCell>
                                            <TableCell>
                                                {member.department || '-'}
                                            </TableCell>
                                            <TableCell>
                                                <Badge variant="outline" className={member.is_active ? "bg-green-50 text-green-700 border-green-200" : "bg-red-50 text-red-700 border-red-200"}>
                                                    {member.is_active ? 'Active' : 'Inactive'}
                                                </Badge>
                                            </TableCell>
                                            <TableCell className="text-right">
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="ghost" size="icon"><MoreHorizontal className="h-4 w-4" /></Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align="end">
                                                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                                        <DropdownMenuItem>Edit Role</DropdownMenuItem>
                                                        <DropdownMenuSeparator />
                                                        <DropdownMenuItem className="text-red-600">
                                                            <UserX className="h-4 w-4 mr-2" /> Remove Access
                                                        </DropdownMenuItem>
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        )}
                    </CardContent>
                </Card>
            </TabsContent>

            <TabsContent value="invitations" className="mt-6">
                 <Card>
                    <CardHeader>
                        <CardTitle>Invitation History</CardTitle>
                        <CardDescription>Track pending, expired, and revoked invitations.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        {loading ? (
                             <div className="flex justify-center p-8"><Loader2 className="animate-spin h-8 w-8 text-blue-500" /></div>
                        ) : invitations.length === 0 ? (
                            <div className="text-center py-12 text-slate-500">
                                <Mail className="h-12 w-12 mx-auto text-slate-300 mb-3" />
                                <p>No invitations found.</p>
                            </div>
                        ) : (
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Email</TableHead>
                                        <TableHead>Assigned Role</TableHead>
                                        <TableHead>Status</TableHead>
                                        <TableHead>Sent Date</TableHead>
                                        <TableHead>Expires</TableHead>
                                        <TableHead className="text-right">Actions</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {invitations.map((invite) => (
                                        <TableRow key={invite.id} className={invite.status === 'revoked' ? 'opacity-60 bg-slate-50/50' : ''}>
                                            <TableCell className="font-medium">{invite.email}</TableCell>
                                            <TableCell>{getRoleBadge(invite.role)}</TableCell>
                                            <TableCell>{getStatusBadge(invite.status, invite.expires_at)}</TableCell>
                                            <TableCell className="text-xs text-slate-500">{new Date(invite.created_at).toLocaleDateString()}</TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-2 text-xs text-slate-500">
                                                    <Clock className="h-3 w-3" />
                                                    {new Date(invite.expires_at).toLocaleDateString()}
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-right">
                                                {invite.status === 'pending' && new Date(invite.expires_at) > new Date() && (
                                                    <div className="flex justify-end gap-2">
                                                        <Button 
                                                            variant="ghost" 
                                                            size="icon" 
                                                            onClick={() => setResendId(invite.id)}
                                                            title="Resend Invite"
                                                            className="text-blue-600 hover:bg-blue-50"
                                                        >
                                                            <RefreshCw className="h-4 w-4" />
                                                        </Button>
                                                        <Button 
                                                            variant="ghost" 
                                                            size="icon"
                                                            onClick={() => setRevokeId(invite.id)}
                                                            title="Revoke Invite"
                                                            className="text-red-600 hover:bg-red-50"
                                                        >
                                                            <XCircle className="h-4 w-4" />
                                                        </Button>
                                                    </div>
                                                )}
                                                {/* Allow resending expired invites too */}
                                                {(invite.status === 'revoked' || new Date(invite.expires_at) < new Date()) && (
                                                     <Button 
                                                        variant="ghost" 
                                                        size="sm" 
                                                        onClick={() => setResendId(invite.id)}
                                                        className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 h-8 text-xs"
                                                     >
                                                        <RefreshCw className="h-3 w-3 mr-1" /> Re-invite
                                                     </Button>
                                                )}
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        )}
                    </CardContent>
                </Card>
            </TabsContent>
        </Tabs>

        <InviteMemberDialog 
            open={inviteOpen} 
            onOpenChange={setInviteOpen} 
            onSuccess={fetchData} 
        />

        {/* Confirmation Dialogs */}
        <AlertDialog open={!!revokeId} onOpenChange={(o) => !o && setRevokeId(null)}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Revoke Invitation?</AlertDialogTitle>
                    <AlertDialogDescription>
                        This will immediately invalidate the invitation link. The user will not be able to join using this invite.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel disabled={isProcessing}>Cancel</AlertDialogCancel>
                    <AlertDialogAction 
                        onClick={(e) => { e.preventDefault(); handleRevoke(); }}
                        className="bg-red-600 hover:bg-red-700"
                        disabled={isProcessing}
                    >
                        {isProcessing ? <Loader2 className="animate-spin h-4 w-4" /> : "Yes, Revoke"}
                    </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>

        <AlertDialog open={!!resendId} onOpenChange={(o) => !o && setResendId(null)}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Resend Invitation?</AlertDialogTitle>
                    <AlertDialogDescription>
                        This will revoke the old invitation and generate a brand new one. A new email notification will be sent.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel disabled={isProcessing}>Cancel</AlertDialogCancel>
                    <AlertDialogAction 
                        onClick={(e) => { e.preventDefault(); handleResend(); }}
                        className="bg-blue-600 hover:bg-blue-700"
                        disabled={isProcessing}
                    >
                        {isProcessing ? <Loader2 className="animate-spin h-4 w-4" /> : "Resend Invite"}
                    </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>

      </main>
    </div>
  );
};

export default TeamManagement;
