
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  ShieldCheck,
  Search,
  ArrowRight,
  Filter,
  CheckCircle2,
  AlertTriangle,
  ClipboardCheck,
  FileCheck
} from 'lucide-react';

export default function AuditWorkspacePage() {
  const { tenant } = useAuth();
  const [controls, setControls] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (tenant?.id) {
      loadControls();
    }
  }, [tenant?.id]);

  const loadControls = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('internal_controls')
        .select('*, evidence_count:compliance_evidence(count)')
        .eq('org_id', tenant.id)
        .order('code', { ascending: true });

      if (error) throw error;
      setControls(data || []);
    } catch (err) {
      console.error("Error loading controls", err);
    } finally {
      setLoading(false);
    }
  };

  const filteredControls = controls.filter(c => 
    c.code.toLowerCase().includes(search.toLowerCase()) || 
    c.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-12">
      <Helmet>
        <title>Audit Workspace | CyberWorkbench</title>
      </Helmet>

      {/* Breadcrumb */}
      <div className="px-1">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/dashboard">Dashboard</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Audit Workspace</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-6">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Audit Workspace</h1>
          <p className="text-slate-500 text-lg">
             Manage internal controls, collect evidence, and track audit readiness.
          </p>
        </div>
        <div className="flex items-center gap-2">
           <Button variant="outline">
              <FileCheck className="mr-2 h-4 w-4" /> Reports
           </Button>
           <Button className="bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-900/10">
              <ShieldCheck className="mr-2 h-4 w-4" /> Run Assessment
           </Button>
        </div>
      </div>

      {/* Stats Cards (Mock for now, replacing with skeletons if loading) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         {loading ? [1,2,3].map(i => <Skeleton key={i} className="h-32 w-full rounded-xl" />) : (
           <>
             <Card className="border-slate-200 shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Controls</CardTitle>
                  <ShieldCheck className="h-4 w-4 text-slate-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{controls.length}</div>
                  <p className="text-xs text-slate-500 mt-1">Active internal controls</p>
                </CardContent>
             </Card>
             <Card className="border-slate-200 shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Effective</CardTitle>
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-700">
                    {controls.filter(c => c.status === 'Effective').length}
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Controls passing tests</p>
                </CardContent>
             </Card>
             <Card className="border-slate-200 shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Attention Needed</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-orange-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-700">
                    {controls.filter(c => c.status === 'Ineffective' || c.status === 'Draft').length}
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Controls failing or draft</p>
                </CardContent>
             </Card>
           </>
         )}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2">
         <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500" />
            <Input 
              placeholder="Search controls..." 
              className="pl-9" 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
         </div>
         <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
         </Button>
      </div>

      {/* Main Table */}
      <Card className="border-slate-200 shadow-sm bg-white overflow-hidden">
         {loading ? (
            <div className="p-6 space-y-4">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="flex gap-4 items-center">
                   <Skeleton className="h-8 w-24" />
                   <Skeleton className="h-4 w-full" />
                   <Skeleton className="h-8 w-20" />
                </div>
              ))}
            </div>
         ) : filteredControls.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 px-4">
               <div className="bg-slate-50 p-4 rounded-full mb-4">
                  <ClipboardCheck className="h-8 w-8 text-slate-300" />
               </div>
               <h3 className="text-lg font-semibold text-slate-900">No controls found</h3>
               <p className="text-slate-500 text-sm max-w-xs text-center mb-4">
                  Try adjusting your search or add new controls to the library.
               </p>
               <Button variant="outline">Reset Filters</Button>
            </div>
         ) : (
            <Table>
               <TableHeader className="bg-slate-50/50">
                  <TableRow>
                     <TableHead className="w-[100px]">Code</TableHead>
                     <TableHead>Control Title</TableHead>
                     <TableHead>Domain</TableHead>
                     <TableHead>Status</TableHead>
                     <TableHead className="text-center">Evidence</TableHead>
                     <TableHead className="text-right">Action</TableHead>
                  </TableRow>
               </TableHeader>
               <TableBody>
                  {filteredControls.map((control) => (
                     <TableRow key={control.id} className="group hover:bg-slate-50/50 cursor-pointer" onClick={() => window.location.href = `/dashboard/control/${control.id}`}>
                        <TableCell className="font-mono font-medium text-slate-900">
                           {control.code}
                        </TableCell>
                        <TableCell>
                           <div className="font-medium text-slate-900">{control.title}</div>
                           {/* <div className="text-xs text-slate-500 line-clamp-1">{control.description}</div> */}
                        </TableCell>
                        <TableCell>
                           <Badge variant="secondary" className="font-normal bg-slate-100 text-slate-600">
                              {control.domain || 'General'}
                           </Badge>
                        </TableCell>
                        <TableCell>
                           <Badge className={`font-normal ${
                              control.status === 'Effective' ? 'bg-green-100 text-green-700 hover:bg-green-200' :
                              control.status === 'Ineffective' ? 'bg-red-100 text-red-700 hover:bg-red-200' :
                              'bg-slate-100 text-slate-700 hover:bg-slate-200'
                           }`}>
                              {control.status}
                           </Badge>
                        </TableCell>
                        <TableCell className="text-center">
                           <Badge variant="outline" className="h-6 w-6 rounded-full p-0 flex items-center justify-center mx-auto">
                              {control.evidence_count?.[0]?.count || 0}
                           </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                           <Button size="icon" variant="ghost" asChild>
                              <Link to={`/dashboard/control/${control.id}`}>
                                 <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-blue-600" />
                              </Link>
                           </Button>
                        </TableCell>
                     </TableRow>
                  ))}
               </TableBody>
            </Table>
         )}
      </Card>
    </div>
  );
}
