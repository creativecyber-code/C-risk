
import React, { useState, useEffect, useRef } from 'react';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/AuthContext';
import { tenantService } from '@/services/tenantService';
import { useToast } from '@/components/ui/use-toast';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose
} from '@/components/ui/dialog';
import { 
  Upload, 
  Trash2, 
  Image as ImageIcon, 
  AlertCircle, 
  CheckCircle2, 
  Loader2,
  X 
} from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const ACCEPTED_TYPES = ['image/png', 'image/jpeg', 'image/webp'];
const MIN_DIMENSION = 100;
const MAX_DIMENSION = 2000;

export default function TenantSettingsPage() {
  const { tenant, user } = useAuth();
  const { toast } = useToast();
  
  // State
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [orgData, setOrgData] = useState(null);
  
  // File Upload State
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [validationError, setValidationError] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (tenant?.id && user?.id) {
      checkPermissionsAndLoad();
    }
  }, [tenant?.id, user?.id]);

  const checkPermissionsAndLoad = async () => {
    setLoading(true);
    try {
      // 1. Check Permissions
      const role = await tenantService.getCurrentMemberRole(tenant.id, user.id);
      
      // Allow 'owner' or 'admin'
      if (role !== 'admin' && role !== 'owner') {
        setIsAdmin(false);
        setLoading(false);
        return;
      }
      setIsAdmin(true);

      // 2. Load Settings
      const data = await tenantService.getTenantSettings(tenant.id);
      setOrgData(data);
    } catch (error) {
      console.error("Failed to load tenant settings", error);
      toast({
        title: "Error",
        description: "Failed to load settings. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const validateFile = (file) => {
    // 1. Type Check
    if (!ACCEPTED_TYPES.includes(file.type)) {
      return "Invalid file type. Please upload PNG, JPG, or WebP.";
    }
    // 2. Size Check
    if (file.size > MAX_FILE_SIZE) {
      return "File is too large. Maximum size is 5MB.";
    }
    return null;
  };

  const validateDimensions = (file) => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.src = URL.createObjectURL(file);
      img.onload = () => {
        const { width, height } = img;
        URL.revokeObjectURL(img.src);
        
        if (width < MIN_DIMENSION || height < MIN_DIMENSION) {
          reject(`Image is too small (${width}x${height}). Min ${MIN_DIMENSION}x${MIN_DIMENSION}px required.`);
        } else if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
          reject(`Image is too large (${width}x${height}). Max ${MAX_DIMENSION}x${MAX_DIMENSION}px allowed.`);
        } else {
          resolve(true);
        }
      };
      img.onerror = () => {
        URL.revokeObjectURL(img.src);
        reject("Failed to load image for validation.");
      };
    });
  };

  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processFile(file);
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await processFile(e.dataTransfer.files[0]);
    }
  };

  const processFile = async (file) => {
    setValidationError(null);
    
    // Synchronous checks
    const error = validateFile(file);
    if (error) {
      setValidationError(error);
      return;
    }

    // Async Dimension check
    try {
      await validateDimensions(file);
      
      // If valid
      setSelectedFile(file);
      const objectUrl = URL.createObjectURL(file);
      setPreviewUrl(objectUrl);
      
      // Cleanup previous preview if exists? React handles new state, but good practice
    } catch (err) {
      setValidationError(err);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;
    
    setUploading(true);
    try {
      const newLogoUrl = await tenantService.uploadTenantLogo(tenant.id, selectedFile);
      
      setOrgData(prev => ({ ...prev, logo_url: newLogoUrl }));
      setSelectedFile(null);
      setPreviewUrl(null);
      
      toast({
        title: "Success",
        description: "Organization logo updated successfully.",
      });
      
      // Force reload page to propagate logo change to header if it doesn't auto-update via context
      // Alternatively, context should be listening to this change, but for now this is safe
      // window.location.reload(); 
      
    } catch (error) {
      console.error("Upload failed", error);
      toast({
        title: "Upload Failed",
        description: "Could not upload logo. Please try again.",
        variant: "destructive"
      });
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await tenantService.deleteTenantLogo(tenant.id);
      setOrgData(prev => ({ ...prev, logo_url: null }));
      setDeleteDialogOpen(false);
      
      toast({
        title: "Logo Removed",
        description: "Organization logo has been reset to default.",
      });
    } catch (error) {
      console.error("Delete failed", error);
      toast({
        title: "Error",
        description: "Failed to remove logo.",
        variant: "destructive"
      });
    } finally {
      setDeleting(false);
    }
  };

  const clearSelection = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setValidationError(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  // --- Render States ---

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <div className="space-y-2">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-4 w-24" />
        </div>
        <Card>
           <CardHeader><Skeleton className="h-6 w-32" /></CardHeader>
           <CardContent><Skeleton className="h-40 w-full" /></CardContent>
        </Card>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center p-6">
        <div className="h-12 w-12 bg-red-100 text-red-600 rounded-full flex items-center justify-center mb-4">
          <AlertCircle className="h-6 w-6" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900">Access Denied</h2>
        <p className="text-slate-500 mt-2 max-w-md">
          You do not have permission to view this page. Only Tenant Administrators can manage organization settings.
        </p>
        <Button className="mt-6" variant="outline" onClick={() => window.history.back()}>
          Go Back
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12">
      <Helmet>
        <title>Tenant Settings | CyberWorkbench</title>
      </Helmet>

      {/* Breadcrumb */}
      <div className="px-1">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/dashboard">Dashboard</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Tenant Settings</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      </div>

      {/* Header */}
      <div className="space-y-1 border-b pb-6">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">Tenant Settings</h1>
        <p className="text-slate-500 text-lg">
          Manage your organization's profile and branding.
        </p>
      </div>

      {/* Content */}
      <div className="grid gap-6 max-w-4xl">
        <Card>
          <CardHeader>
            <CardTitle>Organization Logo</CardTitle>
            <CardDescription>
              This logo will be displayed in the navigation header and on reports generated by the platform.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            
            {/* Current Logo Display */}
            <div className="flex items-center gap-6 p-6 bg-slate-50 rounded-lg border border-slate-100">
              <div className="relative group">
                 <div className="h-24 w-24 rounded-lg bg-white border shadow-sm flex items-center justify-center overflow-hidden">
                   {orgData?.logo_url ? (
                     <img src={orgData.logo_url} alt="Organization Logo" className="h-full w-full object-contain p-2" />
                   ) : (
                     <ImageIcon className="h-10 w-10 text-slate-300" />
                   )}
                 </div>
              </div>
              <div className="flex-1 space-y-1">
                <h4 className="font-medium text-slate-900">Current Logo</h4>
                <p className="text-sm text-slate-500">
                  {orgData?.logo_url ? 'Custom logo uploaded' : 'Using system default'}
                </p>
              </div>
              {orgData?.logo_url && (
                <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200">
                      <Trash2 className="h-4 w-4 mr-2" /> Remove
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Remove Logo?</DialogTitle>
                      <DialogDescription>
                        Are you sure you want to remove the custom logo? The application will revert to the default branding.
                      </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setDeleteDialogOpen(false)} disabled={deleting}>Cancel</Button>
                      <Button variant="destructive" onClick={handleDelete} disabled={deleting}>
                        {deleting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Remove Logo
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              )}
            </div>

            {/* Upload Area */}
            <div className="space-y-4">
              <div 
                className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragActive ? 'border-blue-500 bg-blue-50/50' : 'border-slate-200 hover:border-slate-300'
                } ${validationError ? 'border-red-200 bg-red-50/30' : ''}`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <input 
                  ref={fileInputRef}
                  type="file" 
                  className="hidden" 
                  accept=".png,.jpg,.jpeg,.webp"
                  onChange={handleFileSelect}
                />
                
                {selectedFile ? (
                  <div className="flex flex-col items-center animate-in fade-in zoom-in duration-300">
                    <div className="relative mb-4">
                       <img 
                         src={previewUrl} 
                         alt="Preview" 
                         className="h-32 w-32 object-contain rounded-lg border shadow-sm bg-white"
                       />
                       <button 
                         onClick={clearSelection}
                         className="absolute -top-2 -right-2 bg-white rounded-full p-1 shadow-md border hover:bg-slate-100 text-slate-500"
                       >
                         <X className="h-4 w-4" />
                       </button>
                    </div>
                    <p className="font-medium text-slate-900">{selectedFile.name}</p>
                    <p className="text-sm text-slate-500 mb-4">
                      {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                    <Button onClick={handleUpload} disabled={uploading}>
                      {uploading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      {uploading ? 'Uploading...' : 'Confirm Upload'}
                    </Button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2">
                    <div className="p-4 bg-blue-50 text-blue-600 rounded-full mb-2">
                      <Upload className="h-6 w-6" />
                    </div>
                    <h3 className="text-lg font-semibold text-slate-900">Click or drag file to upload</h3>
                    <p className="text-sm text-slate-500 max-w-xs mx-auto">
                      Support for PNG, JPG or WebP (max 5MB).
                      <br/>
                      Recommended size: 512x512px.
                    </p>
                    <Button variant="secondary" onClick={() => fileInputRef.current?.click()} className="mt-2">
                      Select File
                    </Button>
                  </div>
                )}
              </div>

              {validationError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Invalid File</AlertTitle>
                  <AlertDescription>
                    {validationError}
                  </AlertDescription>
                </Alert>
              )}
            </div>

          </CardContent>
          <CardFooter className="bg-slate-50/50 border-t px-6 py-4">
            <div className="text-xs text-slate-400 flex items-center gap-2">
              <CheckCircle2 className="h-3 w-3" />
              Changes will reflect across the platform immediately after upload.
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
