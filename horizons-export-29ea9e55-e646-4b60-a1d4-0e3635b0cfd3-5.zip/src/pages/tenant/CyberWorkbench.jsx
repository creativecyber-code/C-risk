
import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { 
  LayoutDashboard, 
  Settings, 
  LogOut, 
  Menu, 
  X,
  FileText,
  ShieldCheck,
  Server,
  Activity,
  UserCircle
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import Logo from '@/components/Logo';

export default function CyberWorkbench() {
  const { user, signOut, tenant } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  const navItems = [
    { name: 'Overview', path: '/dashboard/overview', icon: LayoutDashboard },
    { name: 'New Initiative', path: '/dashboard/initiation', icon: FileText },
    { name: 'Architecture Review', path: '/dashboard/architecture-review', icon: Server },
    { name: 'Audit Workspace', path: '/dashboard/audit-workspace', icon: ShieldCheck },
    { name: 'Tenant Settings', path: '/dashboard/tenant-settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      
      {/* Mobile Header */}
      <div className="md:hidden bg-white border-b p-4 flex items-center justify-between sticky top-0 z-50">
        <Logo className="h-8" />
        <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </div>

      {/* Sidebar Navigation */}
      <aside 
        className={cn(
          "bg-slate-900 text-slate-300 w-full md:w-64 flex-shrink-0 flex flex-col transition-all duration-300 ease-in-out fixed md:sticky top-0 h-[calc(100vh-65px)] md:h-screen z-40 overflow-y-auto",
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0",
          "md:translate-x-0" // Always show on desktop
        )}
        style={{ top: isMobileMenuOpen ? '65px' : '0' }}
      >
        <div className="p-6 border-b border-slate-800 hidden md:flex items-center justify-start h-20">
           <Logo className="text-white hover:text-white hover:opacity-100" imgClassName="h-10 w-auto" />
        </div>

        {/* Tenant Info (Compact) */}
        {tenant && (
          <div className="px-6 py-4 border-b border-slate-800 bg-slate-900/50">
             <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Workspace</div>
             <div className="font-medium text-white truncate" title={tenant.name}>{tenant.name}</div>
          </div>
        )}

        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname.startsWith(item.path);
            
            return (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) => cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors group",
                  isActive 
                    ? "bg-blue-600 text-white font-medium" 
                    : "hover:bg-slate-800 hover:text-white text-slate-400"
                )}
              >
                <Icon className={cn("h-5 w-5 flex-shrink-0", isActive ? "text-white" : "text-slate-500 group-hover:text-white")} />
                <span>{item.name}</span>
              </NavLink>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-800">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="w-full flex items-center justify-start gap-3 p-2 h-auto hover:bg-slate-800 rounded-lg text-left">
                <Avatar className="h-9 w-9 border border-slate-700">
                  <AvatarImage src={user?.user_metadata?.avatar_url} />
                  <AvatarFallback className="bg-slate-700 text-slate-200">
                    {user?.email?.charAt(0).toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 overflow-hidden">
                  <p className="text-sm font-medium text-white truncate">{user?.email}</p>
                  <p className="text-xs text-slate-500 truncate">View Profile</p>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56" side="right" sideOffset={10}>
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate('/app-dashboard/profile')}>
                <UserCircle className="mr-2 h-4 w-4" /> Profile
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/dashboard/tenant-settings')}>
                <Settings className="mr-2 h-4 w-4" /> Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSignOut} className="text-red-600 focus:text-red-600 focus:bg-red-50">
                <LogOut className="mr-2 h-4 w-4" /> Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-x-hidden w-full">
         <div className="h-full w-full p-4 md:p-8 max-w-7xl mx-auto">
            <Outlet />
         </div>
      </main>

    </div>
  );
}
