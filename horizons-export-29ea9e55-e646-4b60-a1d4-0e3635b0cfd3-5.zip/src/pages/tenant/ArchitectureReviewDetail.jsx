
import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/AuthContext';
import { architectureService } from '@/services/architectureService';
import { useToast } from '@/components/ui/use-toast';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  ChevronLeft, 
  ShieldAlert, 
  ShieldCheck, 
  Server, 
  Globe, 
  Database, 
  Lock, 
  Layers, 
  Plus, 
  Trash2, 
  FileText,
  Loader2,
  CheckCircle2,
  ExternalLink,
  AlertTriangle,
  ArrowLeft
} from 'lucide-react';

const STRIDE_CATEGORIES = [
  'Spoofing',
  'Tampering', 
  'Repudiation',
  'Information Disclosure',
  'Denial of Service',
  'Elevation of Privilege'
];

const ArchitectureReviewDetail = () => {
  const { id } = useParams();
  const { tenant, user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  // Data State
  const [review, setReview] = useState(null);
  const [threats, setThreats] = useState([]);
  const [controls, setControls] = useState([]);
  const [loading, setLoading] = useState(true);

  // UI State
  const [activeTab, setActiveTab] = useState("summary");
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Threat Modal State
  const [isThreatModalOpen, setIsThreatModalOpen] = useState(false);
  const [editingThreat, setEditingThreat] = useState(null);
  const [threatForm, setThreatForm] = useState({
    stride_category: '',
    threat_statement: '',
    likelihood: 3,
    impact: 3,
    recommended_control_codes: ''
  });

  // Control Modal State
  const [isControlModalOpen, setIsControlModalOpen] = useState(false);
  const [controlForm, setControlForm] = useState({
    control_code: '',
    notes: '',
    applicability: 'Applicable', 
    jira_key: ''
  });
  const [foundInternalControl, setFoundInternalControl] = useState(null);
  const [isLookingUp, setIsLookingUp] = useState(false);

  // Fetch Data
  const fetchData = async () => {
    if (!id || !tenant?.id) return;
    setLoading(true);
    try {
      const [reviewData, threatsData, controlsData] = await Promise.all([
        architectureService.getReviewById(id),
        architectureService.getStrideThreats(id),
        architectureService.getReviewControls(id)
      ]);

      if (reviewData.org_id !== tenant.id) {
        throw new Error("Unauthorized access to this review.");
      }

      setReview(reviewData);
      setThreats(threatsData || []);
      setControls(controlsData || []);
    } catch (error) {
      console.error("Error fetching review details:", error);
      toast({
        title: "Error",
        description: "Could not load review details.",
        variant: "destructive"
      });
      navigate('/dashboard/architecture-review');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [id, tenant?.id]);

  // --- Threat Handlers ---

  const handleThreatSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const riskScore = threatForm.likelihood * threatForm.impact;
      const payload = {
        architecture_review_id: id,
        org_id: tenant.id,
        stride_category: threatForm.stride_category,
        threat_statement: threatForm.threat_statement,
        likelihood: parseInt(threatForm.likelihood),
        impact: parseInt(threatForm.impact),
        risk_score: riskScore,
        recommended_control_codes: threatForm.recommended_control_codes 
          ? threatForm.recommended_control_codes.split(',').map(s => s.trim()) 
          : []
      };

      if (editingThreat) {
        await architectureService.updateStrideThreat(editingThreat.id, payload);
        toast({ title: "Success", description: "Threat updated." });
      } else {
        await architectureService.createStrideThreat({ ...payload, created_by: user.id });
        toast({ title: "Success", description: "New threat added." });
      }
      
      setIsThreatModalOpen(false);
      setEditingThreat(null);
      setThreatForm({ stride_category: '', threat_statement: '', likelihood: 3, impact: 3, recommended_control_codes: '' });
      
      const updatedThreats = await architectureService.getStrideThreats(id);
      setThreats(updatedThreats);
    } catch (error) {
      console.error("Threat save error:", error);
      toast({ title: "Error", description: "Failed to save threat.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteThreat = async (threatId) => {
    // Optimistic delete
    const previousThreats = [...threats];
    setThreats(prev => prev.filter(t => t.id !== threatId));
    
    try {
      await architectureService.deleteStrideThreat(threatId);
      toast({ title: "Deleted", description: "Threat removed." });
    } catch (error) {
      setThreats(previousThreats); // Revert
      console.error("Delete threat error:", error);
      toast({ title: "Error", description: "Could not delete threat.", variant: "destructive" });
    }
  };

  // --- Control Handlers ---

  const handleControlCodeBlur = async () => {
    if (!controlForm.control_code) return;
    setIsLookingUp(true);
    setFoundInternalControl(null);
    try {
      const found = await architectureService.lookupInternalControl(tenant.id, controlForm.control_code);
      if (found) setFoundInternalControl(found);
    } catch (error) {
      // Quiet fail on lookup
    } finally {
      setIsLookingUp(false);
    }
  };

  const handleControlSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const payload = {
        architecture_review_id: id,
        org_id: tenant.id,
        control_code: controlForm.control_code,
        internal_control_id: foundInternalControl?.id || null,
        applicability: controlForm.applicability,
        design_score: 0, 
        operating_score: 0, 
        notes: controlForm.notes,
        jira_key: controlForm.jira_key
      };

      await architectureService.createReviewControl({ ...payload, created_by: user.id });
      toast({ title: "Success", description: "Control added to review." });
      
      setIsControlModalOpen(false);
      setControlForm({ control_code: '', notes: '', applicability: 'Applicable', jira_key: '' });
      setFoundInternalControl(null);

      const updatedControls = await architectureService.getReviewControls(id);
      setControls(updatedControls);

    } catch (error) {
      console.error("Control save error:", error);
      toast({ title: "Error", description: "Failed to add control.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteControl = async (controlId) => {
    // Optimistic delete
    const previousControls = [...controls];
    setControls(prev => prev.filter(c => c.id !== controlId));

    try {
      await architectureService.deleteReviewControl(controlId);
      toast({ title: "Removed", description: "Control removed." });
    } catch (error) {
       setControls(previousControls);
       console.error("Delete control error:", error);
       toast({ title: "Error", description: "Could not remove control.", variant: "destructive" });
    }
  };

  const handleGenerateEvidence = async () => {
    setIsSubmitting(true);
    try {
      const result = await architectureService.generateEvidencePlaceholders(id, tenant.id, user.id);
      toast({
        title: "Evidence Generation",
        description: `Created ${result.count} new evidence tasks.`
      });
    } catch (error) {
      console.error("Evidence generation error:", error);
      toast({ title: "Error", description: "Failed to generate tasks.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Helper renderers
  const getRiskColor = (score) => {
    if (score >= 20) return "text-red-700 bg-red-50 border-red-200";
    if (score >= 10) return "text-orange-700 bg-orange-50 border-orange-200";
    if (score >= 5) return "text-yellow-700 bg-yellow-50 border-yellow-200";
    return "text-green-700 bg-green-50 border-green-200";
  };

  if (loading) {
     return (
        <div className="max-w-7xl mx-auto p-6 space-y-6">
           <Skeleton className="h-8 w-1/3 mb-4" />
           <div className="space-y-4">
              <Skeleton className="h-24 w-full" />
              <div className="grid grid-cols-2 gap-4">
                 <Skeleton className="h-48 w-full" />
                 <Skeleton className="h-48 w-full" />
              </div>
           </div>
        </div>
     )
  }

  if (!review) return null;

  const attributes = review.attributes || {};

  return (
    <div className="space-y-6 pb-12">
      <Helmet>
        <title>{review.title} | Architecture Review</title>
      </Helmet>

      {/* Breadcrumb */}
      <div className="px-1">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
               <BreadcrumbLink href="/dashboard">Dashboard</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
               <BreadcrumbLink href="/dashboard/architecture-review">Reviews</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
               <BreadcrumbPage>{review.title}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      </div>

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 border-b pb-6">
        <div className="space-y-2">
           <div className="flex items-center gap-3">
             <Button variant="ghost" size="icon" className="-ml-3 h-8 w-8 text-slate-500" onClick={() => navigate('/dashboard/architecture-review')}>
               <ArrowLeft className="h-5 w-5" />
             </Button>
             <h1 className="text-3xl font-bold tracking-tight text-slate-900">{review.title}</h1>
             <Badge variant="outline" className="capitalize ml-2">{review.status}</Badge>
           </div>
           <p className="text-slate-500 max-w-2xl pl-8">
              Template: <span className="font-medium text-slate-700">{review.template_key}</span>
           </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => window.print()} className="gap-2">
            <FileText className="h-4 w-4" /> Export
          </Button>
          {review.status === 'draft' && (
            <Button className="bg-blue-600 hover:bg-blue-700">Submit Review</Button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-slate-100 p-1">
          <TabsTrigger value="summary" className="px-6">Summary</TabsTrigger>
          <TabsTrigger value="stride" className="px-6">Threat Model <Badge variant="secondary" className="ml-2 h-5 px-1.5">{threats.length}</Badge></TabsTrigger>
          <TabsTrigger value="controls" className="px-6">Controls <Badge variant="secondary" className="ml-2 h-5 px-1.5">{controls.length}</Badge></TabsTrigger>
        </TabsList>

        <TabsContent value="summary" className="space-y-6 animate-in fade-in slide-in-from-left-1 duration-300">
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              
              {/* Technical Profile */}
              <Card className="col-span-1 md:col-span-2 shadow-sm border-slate-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Server className="h-5 w-5 text-blue-600" /> Technical Profile
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-y-6 gap-x-8">
                  <div>
                    <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Hosting Model</h4>
                    <div className="flex items-center gap-2 text-slate-900 font-medium">
                      <Database className="h-4 w-4 text-slate-400" />
                      {attributes.hosting_model || 'Not specified'}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Exposure</h4>
                    <div className="flex items-center gap-2 text-slate-900 font-medium">
                      <Globe className="h-4 w-4 text-slate-400" />
                      {attributes.internet_facing ? 'Publicly Accessible' : 'Internal Only'}
                    </div>
                  </div>
                  <div className="col-span-1 sm:col-span-2 pt-2">
                    <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Integrations</h4>
                    <div className="flex flex-wrap gap-2">
                      {attributes.major_integrations?.length > 0 ? (
                        attributes.major_integrations.map((integration, idx) => (
                          <Badge key={idx} variant="secondary" className="bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-200">
                            {integration}
                          </Badge>
                        ))
                      ) : (
                        <span className="text-slate-400 italic text-sm">None listed</span>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Risk Score */}
              <Card className="shadow-sm border-slate-200 flex flex-col justify-center items-center text-center p-6">
                 <ShieldAlert className="h-12 w-12 text-slate-300 mb-4" />
                 <div className="text-5xl font-bold text-slate-900 mb-2 tracking-tighter">
                    {review.architecture_risk_score ?? '-'}
                 </div>
                 <p className="text-slate-500 font-medium mb-3">Risk Score</p>
                 <Badge className={`text-sm px-3 py-1 ${
                    review.architecture_risk_rating === 'Critical' ? 'bg-red-100 text-red-800 border-red-200' :
                    review.architecture_risk_rating === 'High' ? 'bg-orange-100 text-orange-800 border-orange-200' :
                    review.architecture_risk_rating === 'Medium' ? 'bg-yellow-100 text-yellow-800 border-yellow-200' :
                    'bg-green-100 text-green-800 border-green-200'
                 }`}>
                    {review.architecture_risk_rating || 'Unrated'}
                 </Badge>
              </Card>
           </div>
        </TabsContent>

        <TabsContent value="stride" className="space-y-6 animate-in fade-in slide-in-from-left-1 duration-300">
           <div className="flex justify-between items-center bg-slate-50 p-4 rounded-lg border border-slate-100">
              <div>
                 <h3 className="text-base font-semibold text-slate-900">Identified Threats</h3>
                 <p className="text-sm text-slate-500">Using STRIDE methodology</p>
              </div>
              <Dialog open={isThreatModalOpen} onOpenChange={setIsThreatModalOpen}>
                <DialogTrigger asChild>
                  <Button className="shadow-sm">
                    <Plus className="h-4 w-4 mr-2" /> Add Threat
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Identify New Threat</DialogTitle>
                    <DialogDescription>Document a potential security threat.</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleThreatSubmit} className="space-y-4 py-4">
                    <div className="grid gap-2">
                      <Label>STRIDE Category <span className="text-red-500">*</span></Label>
                      <Select 
                        value={threatForm.stride_category} 
                        onValueChange={(val) => setThreatForm(prev => ({ ...prev, stride_category: val }))}
                      >
                        <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                        <SelectContent>
                          {STRIDE_CATEGORIES.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label>Threat Statement <span className="text-red-500">*</span></Label>
                      <Textarea 
                         placeholder="Describe the threat scenario..." 
                         value={threatForm.threat_statement}
                         onChange={(e) => setThreatForm(prev => ({ ...prev, threat_statement: e.target.value }))}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label>Likelihood (1-5)</Label>
                        <Input type="number" min="1" max="5" value={threatForm.likelihood} onChange={(e) => setThreatForm(prev => ({ ...prev, likelihood: e.target.value }))} />
                      </div>
                      <div className="grid gap-2">
                        <Label>Impact (1-5)</Label>
                        <Input type="number" min="1" max="5" value={threatForm.impact} onChange={(e) => setThreatForm(prev => ({ ...prev, impact: e.target.value }))} />
                      </div>
                    </div>
                    <div className="grid gap-2">
                       <Label>Mitigation Control Codes</Label>
                       <Input placeholder="e.g. AC-1, CM-3" value={threatForm.recommended_control_codes} onChange={(e) => setThreatForm(prev => ({ ...prev, recommended_control_codes: e.target.value }))} />
                       <p className="text-xs text-slate-500">Comma separated codes</p>
                    </div>
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setIsThreatModalOpen(false)}>Cancel</Button>
                      <Button type="submit" disabled={!threatForm.stride_category || !threatForm.threat_statement || isSubmitting}>
                        {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Save
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
           </div>

           {threats.length === 0 ? (
             <div className="flex flex-col items-center justify-center py-16 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                <ShieldAlert className="h-10 w-10 text-slate-300 mb-3" />
                <h3 className="font-medium text-slate-900">No threats recorded</h3>
                <p className="text-slate-500 text-sm">Use the Add Threat button to document risks.</p>
             </div>
           ) : (
             <div className="grid gap-4">
                {threats.map((threat) => (
                   <Card key={threat.id} className="border-l-4 border-l-transparent hover:border-l-blue-500 transition-all">
                      <CardContent className="p-5 flex gap-4">
                         <div className="flex-1 space-y-2">
                            <div className="flex items-center gap-2">
                               <Badge variant="outline" className="font-semibold bg-white">{threat.stride_category}</Badge>
                            </div>
                            <p className="text-slate-900 font-medium">{threat.threat_statement}</p>
                            {threat.recommended_control_codes?.length > 0 && (
                               <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-100/50 p-1.5 rounded w-fit">
                                  <Layers className="h-3 w-3" />
                                  <span>Mitigation: {threat.recommended_control_codes.join(', ')}</span>
                               </div>
                            )}
                         </div>
                         <div className="flex flex-col items-end gap-2">
                            <Badge variant="outline" className={`border ${getRiskColor(threat.risk_score)}`}>
                               Risk Score: {threat.risk_score}
                            </Badge>
                            <Button 
                              size="icon" 
                              variant="ghost" 
                              className="h-8 w-8 text-slate-400 hover:text-red-600"
                              onClick={() => handleDeleteThreat(threat.id)}
                            >
                               <Trash2 className="h-4 w-4" />
                            </Button>
                         </div>
                      </CardContent>
                   </Card>
                ))}
             </div>
           )}
        </TabsContent>

        <TabsContent value="controls" className="space-y-6 animate-in fade-in slide-in-from-left-1 duration-300">
           <div className="flex justify-between items-center bg-slate-50 p-4 rounded-lg border border-slate-100">
              <div>
                 <h3 className="text-base font-semibold text-slate-900">Security Controls</h3>
                 <p className="text-sm text-slate-500">Measures to mitigate identified threats</p>
              </div>
              <div className="flex gap-2">
                 <Button variant="outline" onClick={handleGenerateEvidence} disabled={isSubmitting || controls.length === 0}>
                    {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileText className="mr-2 h-4 w-4" />}
                    Generate Evidence Tasks
                 </Button>
                 <Dialog open={isControlModalOpen} onOpenChange={setIsControlModalOpen}>
                    <DialogTrigger asChild>
                       <Button className="shadow-sm">
                          <Plus className="h-4 w-4 mr-2" /> Add Control
                       </Button>
                    </DialogTrigger>
                    <DialogContent>
                       <DialogHeader>
                          <DialogTitle>Add Control</DialogTitle>
                          <DialogDescription>Link a standard control or define a custom one.</DialogDescription>
                       </DialogHeader>
                       <form onSubmit={handleControlSubmit} className="space-y-4 py-4">
                          <div className="grid gap-2">
                             <Label>Control Code <span className="text-red-500">*</span></Label>
                             <div className="relative">
                                <Input 
                                   placeholder="e.g. AC-1" 
                                   value={controlForm.control_code}
                                   onChange={(e) => setControlForm(prev => ({ ...prev, control_code: e.target.value }))}
                                   onBlur={handleControlCodeBlur}
                                   className={foundInternalControl ? 'border-green-500 pr-10' : ''}
                                />
                                {isLookingUp && <Loader2 className="absolute right-3 top-2.5 h-4 w-4 animate-spin text-slate-400" />}
                                {foundInternalControl && <CheckCircle2 className="absolute right-3 top-2.5 h-4 w-4 text-green-500" />}
                             </div>
                             {foundInternalControl && <p className="text-xs text-green-600">{foundInternalControl.title}</p>}
                          </div>
                          <div className="grid gap-2">
                             <Label>Applicability</Label>
                             <Select value={controlForm.applicability} onValueChange={(val) => setControlForm(prev => ({ ...prev, applicability: val }))}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                   <SelectItem value="Applicable">Applicable</SelectItem>
                                   <SelectItem value="Not Applicable">Not Applicable</SelectItem>
                                </SelectContent>
                             </Select>
                          </div>
                          <div className="grid gap-2">
                             <Label>Notes</Label>
                             <Textarea value={controlForm.notes} onChange={(e) => setControlForm(prev => ({ ...prev, notes: e.target.value }))} />
                          </div>
                          <DialogFooter>
                             <Button type="button" variant="outline" onClick={() => setIsControlModalOpen(false)}>Cancel</Button>
                             <Button type="submit" disabled={!controlForm.control_code || isSubmitting}>
                                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Add Control
                             </Button>
                          </DialogFooter>
                       </form>
                    </DialogContent>
                 </Dialog>
              </div>
           </div>

           {controls.length === 0 ? (
             <div className="flex flex-col items-center justify-center py-16 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                <ShieldCheck className="h-10 w-10 text-slate-300 mb-3" />
                <h3 className="font-medium text-slate-900">No controls defined</h3>
                <p className="text-slate-500 text-sm">Add controls to address your risks.</p>
             </div>
           ) : (
             <div className="bg-white border rounded-xl overflow-hidden shadow-sm">
                <div className="divide-y divide-slate-100">
                   {controls.map((control) => (
                      <div key={control.id} className="p-4 hover:bg-slate-50 flex items-center justify-between group transition-colors">
                         <div className="space-y-1">
                            <div className="flex items-center gap-2">
                               <span className="font-bold text-slate-900">{control.control_code}</span>
                               <Badge variant={control.applicability === 'Applicable' ? 'default' : 'secondary'} className="text-[10px] h-5">
                                  {control.applicability}
                               </Badge>
                            </div>
                            <p className="text-sm text-slate-600">
                               {control.internal_control ? control.internal_control.title : (control.notes || 'Custom Control')}
                            </p>
                         </div>
                         <Button size="icon" variant="ghost" className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-600 transition-all" onClick={() => handleDeleteControl(control.id)}>
                            <Trash2 className="h-4 w-4" />
                         </Button>
                      </div>
                   ))}
                </div>
             </div>
           )}
        </TabsContent>

      </Tabs>
    </div>
  );
};

export default ArchitectureReviewDetail;
