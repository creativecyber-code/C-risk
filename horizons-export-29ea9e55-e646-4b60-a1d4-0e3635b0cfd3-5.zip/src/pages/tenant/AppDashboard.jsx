
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { 
  LayoutDashboard, 
  FileText, 
  Bell, 
  ShieldCheck, 
  Building2, 
  Calendar, 
  Hash, 
  CheckCircle2, 
  XCircle,
  ArrowRight,
  Settings,
  BookOpen,
  Cpu,
  Layers,
  Lock,
  Activity
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { TenantHeader } from '@/components/tenant/TenantHeader';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';

const AppDashboard = () => {
  const { user, tenant } = useAuth();

  // Define modules available in the system
  // In a real app, 'enabled' status might come from a DB table 'tenant_modules'
  const modules = [
    {
      id: 'biz-init',
      name: 'Business Initiation & Risk',
      description: 'Project intake, inherent risk assessment, and classification.',
      icon: Cpu,
      status: 'enabled',
      link: '/dashboard/initiation'
    },
    {
      id: 'arch-review',
      name: 'Architecture & Design',
      description: 'Threat modeling, STRIDE analysis, and design review.',
      icon: Layers,
      status: 'enabled',
      link: '/dashboard/architecture-review'
    },
    {
      id: 'sec-audit',
      name: 'Security & Audit',
      description: 'Internal controls, compliance mapping, and evidence.',
      icon: Lock,
      status: 'enabled',
      link: '/dashboard/security'
    },
    {
      id: 'compliance',
      name: 'Regulatory Compliance',
      description: 'Manage regulatory obligations and track adherence.',
      icon: BookOpen,
      status: 'enabled', // Assuming enabled for all tenants in this demo
      link: '/dashboard/compliance'
    },
    {
      id: 'vendor-risk',
      name: 'Vendor Risk Management',
      description: 'Third-party assessments and risk tiering.',
      icon: Building2,
      status: 'disabled', // Example of a disabled module
      link: '#'
    }
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      <Helmet>
        <title>{tenant?.name ? `${tenant.name} - Overview` : 'Dashboard'} | C-RISK</title>
      </Helmet>

      <TenantHeader />

      {/* Main Tenant Content */}
      <main className="p-6 md:p-8 max-w-7xl mx-auto space-y-8">
        
        {/* Breadcrumb */}
        <nav className="flex items-center text-sm text-slate-500 mb-2">
            <Link to="/app-dashboard" className="hover:text-blue-600 transition-colors">Home</Link>
            <span className="mx-2">/</span>
            <span className="text-slate-900 font-medium">Overview</span>
        </nav>

        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 tracking-tight">
               {tenant?.name || 'Organization Dashboard'}
            </h1>
            <p className="text-slate-500 mt-1">
               Overview of your compliance posture and active modules.
            </p>
          </div>
          <div className="flex items-center gap-2">
              <Button variant="outline" className="bg-white">
                  <Activity className="h-4 w-4 mr-2 text-slate-500" /> System Status
              </Button>
              <Button>
                  <Settings className="h-4 w-4 mr-2" /> Tenant Settings
              </Button>
          </div>
        </div>

        {/* Tenant Info Card */}
        <Card className="border-l-4 border-l-blue-600 shadow-sm">
            <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="flex flex-col gap-1">
                        <span className="text-xs font-semibold text-slate-500 uppercase flex items-center gap-2">
                           <Building2 className="h-3 w-3" /> Organization Name
                        </span>
                        <span className="font-medium text-lg text-slate-900">
                           {tenant?.name || 'Loading...'}
                        </span>
                    </div>
                    
                    <div className="flex flex-col gap-1">
                        <span className="text-xs font-semibold text-slate-500 uppercase flex items-center gap-2">
                           <Hash className="h-3 w-3" /> Tenant ID
                        </span>
                        <span className="font-mono text-sm text-slate-600 bg-slate-100 px-2 py-1 rounded w-fit">
                           {tenant?.id || '...'}
                        </span>
                    </div>

                    <div className="flex flex-col gap-1">
                        <span className="text-xs font-semibold text-slate-500 uppercase flex items-center gap-2">
                           <Calendar className="h-3 w-3" /> Member Since
                        </span>
                        <span className="font-medium text-slate-900">
                           {tenant?.created_at ? new Date(tenant.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric', day: 'numeric' }) : '...'}
                        </span>
                    </div>
                </div>
            </CardContent>
        </Card>

        {/* KPI Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
           {[
             { title: "Overall Risk", value: "Low", color: "text-emerald-600", bg: "bg-emerald-50", icon: ShieldCheck },
             { title: "Open Issues", value: "12", color: "text-slate-900", bg: "bg-slate-50", icon: FileText },
             { title: "Compliance Score", value: "94%", color: "text-blue-600", bg: "bg-blue-50", icon: LayoutDashboard },
             { title: "Pending Reviews", value: "3", color: "text-amber-600", bg: "bg-amber-50", icon: Bell },
           ].map((kpi, idx) => (
             <Card key={idx} className="shadow-sm hover:shadow-md transition-shadow">
               <CardHeader className="flex flex-row items-center justify-between pb-2">
                 <CardTitle className="text-sm font-medium text-slate-500">{kpi.title}</CardTitle>
                 <div className={`p-2 rounded-full ${kpi.bg}`}>
                    <kpi.icon className={`h-4 w-4 ${kpi.color}`} />
                 </div>
               </CardHeader>
               <CardContent>
                 <div className="text-2xl font-bold text-slate-900">{kpi.value}</div>
               </CardContent>
             </Card>
           ))}
        </div>

        <Separator />

        {/* Modules Grid */}
        <div className="space-y-4">
            <h2 className="text-xl font-semibold text-slate-900">Enabled Modules</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {modules.map((module) => (
                    <Card key={module.id} className={`flex flex-col h-full transition-all ${module.status === 'disabled' ? 'opacity-60 bg-slate-50' : 'hover:border-blue-300 hover:shadow-md'}`}>
                        <CardHeader className="pb-3">
                            <div className="flex justify-between items-start">
                                <div className={`p-3 rounded-lg ${module.status === 'disabled' ? 'bg-slate-200 text-slate-500' : 'bg-blue-50 text-blue-600'}`}>
                                    <module.icon className="h-6 w-6" />
                                </div>
                                {module.status === 'enabled' ? (
                                    <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200 flex gap-1 items-center">
                                        <CheckCircle2 className="h-3 w-3" /> Active
                                    </Badge>
                                ) : (
                                    <Badge variant="outline" className="bg-slate-100 text-slate-500 border-slate-200 flex gap-1 items-center">
                                        <XCircle className="h-3 w-3" /> Disabled
                                    </Badge>
                                )}
                            </div>
                            <CardTitle className="mt-4 text-lg">{module.name}</CardTitle>
                            <CardDescription className="h-10">{module.description}</CardDescription>
                        </CardHeader>
                        <CardFooter className="mt-auto pt-4">
                            {module.status === 'enabled' ? (
                                <Link to={module.link} className="w-full">
                                    <Button className="w-full group">
                                        Open Module <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                                    </Button>
                                </Link>
                            ) : (
                                <Button variant="outline" disabled className="w-full">
                                    Not Available
                                </Button>
                            )}
                        </CardFooter>
                    </Card>
                ))}
            </div>
        </div>
      </main>
    </div>
  );
};

export default AppDashboard;
