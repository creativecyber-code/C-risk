
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { FileQuestion } from 'lucide-react';

const NotFound = () => {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-slate-50 p-4 text-center">
      <div className="bg-white p-4 rounded-full shadow-sm mb-6">
        <FileQuestion className="h-12 w-12 text-slate-400" />
      </div>
      <h1 className="text-4xl font-bold text-slate-900 mb-2">Page not found</h1>
      <p className="text-slate-600 mb-8 max-w-md">
        Sorry, we couldn't find the page you're looking for. It might have been moved or deleted.
      </p>
      <Link to="/">
        <Button>Return Home</Button>
      </Link>
    </div>
  );
};

export default NotFound;
