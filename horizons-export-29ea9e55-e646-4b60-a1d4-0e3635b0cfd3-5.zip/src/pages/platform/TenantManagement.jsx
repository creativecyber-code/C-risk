
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { invitationService } from '@/services/invitationService';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import { 
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { 
  Building2, MoreHorizontal, Plus, Loader2, Pencil, RefreshCcw,
  UserPlus, Users, Clock, Copy, XCircle, Check
} from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function TenantManagement() {
  const { user } = useAuth();
  const [tenants, setTenants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();

  // Modal States
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isMembersSheetOpen, setIsMembersSheetOpen] = useState(false);
  
  const [currentTenant, setCurrentTenant] = useState(null);
  const [tenantMembers, setTenantMembers] = useState([]);
  const [tenantInvites, setTenantInvites] = useState([]); 
  const [loadingMembers, setLoadingMembers] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Invite Success State
  const [lastInvite, setLastInvite] = useState(null);

  // Form States
  const [formData, setFormData] = useState({
    name: '', slug: '', status: 'active', license_tier: 'standard'
  });

  // New Member Form
  const [newMemberEmail, setNewMemberEmail] = useState('');
  // Default to 'admin' for platform-initiated invites usually, but let them choose
  const [newMemberRole, setNewMemberRole] = useState('admin'); 

  const fetchTenants = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('organizations')
        .select('*, tenant_members(count)')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formattedData = data.map(org => ({
        ...org,
        memberCount: org.tenant_members ? org.tenant_members[0]?.count || 0 : 0
      }));

      setTenants(formattedData);
    } catch (error) {
      toast({ variant: "destructive", title: "Error fetching tenants", description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const fetchTenantData = async (tenantId) => {
    try {
      setLoadingMembers(true);
      const { data: members, error: membersError } = await supabase
        .from('tenant_members')
        .select('*')
        .eq('tenant_id', tenantId);
      if (membersError) throw membersError;
      
      const invites = await invitationService.getTenantInvites(tenantId);
      
      setTenantMembers(members);
      setTenantInvites(invites);
    } catch (error) {
      console.error("Error fetching data:", error);
      toast({ variant: "destructive", title: "Could not load data", description: error.message });
    } finally {
      setLoadingMembers(false);
    }
  };

  useEffect(() => {
    fetchTenants();
  }, []);

  const handleCreateSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    const finalSlug = formData.slug || formData.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    
    try {
      const payload = {
        name: formData.name, slug: finalSlug, status: formData.status, license_tier: formData.license_tier,
        created_at: new Date().toISOString(), updated_at: new Date().toISOString()
      };
      const { data, error } = await supabase.from('organizations').insert([payload]).select().single();
      if (error) throw error;
      toast({ title: "Tenant created", description: `${data.name} is ready.` });
      setTenants(prev => [{ ...data, memberCount: 0 }, ...prev]);
      setIsCreateOpen(false);
    } catch (error) {
      toast({ variant: "destructive", title: "Error creating tenant", description: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInviteMember = async () => {
    if (!newMemberEmail || !currentTenant) return;
    setIsSubmitting(true);
    setLastInvite(null); // Clear previous success state

    try {
      // Determine link path based on role. 
      // If invited as Admin from Platform Console, we use the Tenant Admin Invite flow
      const linkPath = newMemberRole === 'admin' ? '/tenant-invite' : '/invite';

      console.log(`Creating invite for ${newMemberEmail} with role ${newMemberRole} at path ${linkPath}`);

      const result = await invitationService.createInvite({
        email: newMemberEmail,
        role: newMemberRole,
        tenantId: currentTenant.id,
        linkPath: linkPath
      });
      
      // Construct the full link if the result provides a path
      let fullLink = result.inviteLink;
      if (fullLink && !fullLink.startsWith('http')) {
         fullLink = `${window.location.origin}${fullLink}`;
      }

      setLastInvite({
         email: newMemberEmail,
         role: newMemberRole,
         link: fullLink,
         token: result.token
      });
      
      toast({
        title: "Invitation Generated",
        description: `Invite created successfully.`,
        className: "bg-green-50 border-green-200"
      });
      
      setNewMemberEmail('');
      fetchTenantData(currentTenant.id);
    } catch (error) {
      console.error("Invite generation failed:", error);
      toast({ variant: "destructive", title: "Failed to create invite", description: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleResendInvite = async (inviteId) => {
    try {
      const result = await invitationService.resendInvite(inviteId);
      
      // We also show the new link for resends if possible, but for now just toast is okay for resend action
      // OR we could update lastInvite to show the new link:
      let fullLink = result.inviteLink;
      if (fullLink && !fullLink.startsWith('http')) {
         fullLink = `${window.location.origin}${fullLink}`;
      }
      setLastInvite({
          email: result.email || 'User',
          role: result.role,
          link: fullLink,
          token: result.token
      });

      toast({ title: "Invitation Renewed", description: "Old invite revoked, new one created." });
      fetchTenantData(currentTenant.id);
    } catch(e) {
      toast({ variant: "destructive", title: "Failed to resend", description: e.message });
    }
  };

  const handleRevokeInvite = async (inviteId) => {
      try {
          await invitationService.revokeInvite(inviteId);
          toast({ title: "Invitation Revoked" });
          fetchTenantData(currentTenant.id);
      } catch(e) {
          toast({ variant: "destructive", title: "Failed to revoke", description: e.message });
      }
  };

  const openMembersSheet = (tenant) => {
    setCurrentTenant(tenant);
    setTenantMembers([]); 
    setTenantInvites([]);
    setLastInvite(null); // Reset invite state
    fetchTenantData(tenant.id);
    setIsMembersSheetOpen(true);
  };

  const openCreateModal = () => { setIsCreateOpen(true); setFormData({name: '', slug: '', status: 'active', license_tier: 'standard'}); };
  const openEditModal = (tenant) => { setCurrentTenant(tenant); setFormData({name: tenant.name, slug: tenant.slug, status: tenant.status, license_tier: tenant.license_tier}); setIsEditOpen(true); };
  
  const filteredTenants = tenants.filter(t => t.name?.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex justify-between">
        <h2 className="text-2xl font-bold flex gap-2"><Building2 /> Tenant Management</h2>
        <Button onClick={openCreateModal}><Plus className="mr-2 h-4 w-4" /> Add Tenant</Button>
      </div>

      <Card>
        <CardHeader className="pb-3"><Input placeholder="Search tenants..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} /></CardHeader>
        <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Status</TableHead><TableHead>Members</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
              <TableBody>
                {filteredTenants.map((tenant) => (
                  <TableRow key={tenant.id}>
                    <TableCell>{tenant.name}</TableCell>
                    <TableCell><Badge variant="outline">{tenant.status}</Badge></TableCell>
                    <TableCell>
                         <Button variant="ghost" size="sm" onClick={() => openMembersSheet(tenant)} className="text-blue-600 hover:text-blue-800">
                           {tenant.memberCount} Users
                         </Button>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => openMembersSheet(tenant)}><Users className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => openEditModal(tenant)}><Pencil className="h-4 w-4" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
        </CardContent>
      </Card>

      {/* --- MEMBERS SHEET --- */}
      <Sheet open={isMembersSheetOpen} onOpenChange={setIsMembersSheetOpen}>
        <SheetContent className="sm:max-w-xl w-full overflow-y-auto">
          <SheetHeader className="mb-6">
            <SheetTitle>Manage {currentTenant?.name}</SheetTitle>
            <SheetDescription>Manage tenant admins and users.</SheetDescription>
          </SheetHeader>
          
          <div className="mb-6">
             {lastInvite ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 space-y-4 animate-in fade-in slide-in-from-top-2">
                   <div className="flex items-center gap-2 text-green-800 font-semibold">
                      <Check className="h-5 w-5 text-green-600" />
                      Invitation Ready
                   </div>
                   <div className="space-y-2">
                      <label className="text-xs uppercase text-green-700 font-bold tracking-wider">Shareable Link</label>
                      <div className="flex gap-2">
                         <Input value={lastInvite.link} readOnly className="bg-white font-mono text-xs text-slate-600 h-9" />
                         <Button variant="outline" size="sm" className="bg-white hover:bg-green-50 text-green-700 border-green-200" onClick={() => {
                            navigator.clipboard.writeText(lastInvite.link);
                            toast({ title: "Copied to clipboard" });
                         }}>
                            <Copy className="h-4 w-4" />
                         </Button>
                      </div>
                      <p className="text-xs text-green-700 mt-1">
                         Share this link with <strong>{lastInvite.email}</strong> to activate their {lastInvite.role} account.
                      </p>
                   </div>
                   <Button size="sm" variant="outline" className="w-full border-green-300 text-green-800 hover:bg-green-100 hover:text-green-900" onClick={() => setLastInvite(null)}>
                      <Plus className="w-4 h-4 mr-2" /> Invite Another User
                   </Button>
                </div>
             ) : (
                <div className="space-y-4 p-4 bg-slate-50 rounded-lg border">
                    <h4 className="text-sm font-medium flex gap-2"><UserPlus className="h-4 w-4" /> Invite User</h4>
                    <div className="flex flex-col gap-3">
                       <div className="flex gap-2">
                           <Input 
                                placeholder="email@company.com" 
                                value={newMemberEmail} 
                                onChange={(e) => setNewMemberEmail(e.target.value)} 
                                className="flex-1"
                           />
                           <Select value={newMemberRole} onValueChange={setNewMemberRole}>
                               <SelectTrigger className="w-[110px]">
                                   <SelectValue />
                               </SelectTrigger>
                               <SelectContent>
                                   <SelectItem value="admin">Admin</SelectItem>
                                   <SelectItem value="editor">Editor</SelectItem>
                                   <SelectItem value="viewer">Viewer</SelectItem>
                               </SelectContent>
                           </Select>
                       </div>
                       <Button onClick={handleInviteMember} disabled={isSubmitting || !newMemberEmail} className="w-full">
                         {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                         {isSubmitting ? 'Generating Invite...' : 'Create Invite'}
                       </Button>
                       <p className="text-xs text-slate-500">
                          Inviting as <strong>Admin</strong> will generate a <strong>Tenant Admin Invite</strong> link.
                       </p>
                    </div>
                </div>
             )}
          </div>

          <Tabs defaultValue="members" className="w-full">
            <TabsList className="w-full">
              <TabsTrigger value="members" className="flex-1">Members</TabsTrigger>
              <TabsTrigger value="invites" className="flex-1">Invites ({tenantInvites.filter(i => i.status === 'pending').length})</TabsTrigger>
            </TabsList>

            <TabsContent value="members" className="mt-4 space-y-2">
               {loadingMembers ? <Loader2 className="animate-spin mx-auto" /> : 
                 tenantMembers.length === 0 ? <p className="text-sm text-slate-500 text-center py-4">No active members.</p> :
                 tenantMembers.map(m => (
                   <div key={m.id} className="flex justify-between items-center p-3 border rounded-md bg-white">
                     <div className="flex items-center gap-3">
                       <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-500">
                          {m.email.substring(0,2).toUpperCase()}
                       </div>
                       <div>
                         <div className="font-medium text-sm">{m.email}</div>
                         <div className="text-xs text-slate-500 capitalize">{m.role_key}</div>
                       </div>
                     </div>
                   </div>
                 ))
               }
            </TabsContent>

            <TabsContent value="invites" className="mt-4 space-y-3">
               {loadingMembers ? <Loader2 className="animate-spin mx-auto" /> : 
                 tenantInvites.length === 0 ? <p className="text-sm text-slate-500 text-center py-4">No invitation history.</p> :
                 tenantInvites.map(inv => (
                   <div key={inv.id} className="p-3 border rounded-md bg-white space-y-2">
                     <div className="flex justify-between items-start">
                        <div>
                           <div className="font-medium text-sm">{inv.email}</div>
                           <div className="text-xs text-slate-500">Role: <span className="capitalize">{inv.role}</span></div>
                        </div>
                        <Badge variant={inv.status === 'pending' ? 'secondary' : 'outline'}>{inv.status}</Badge>
                     </div>
                     
                     <div className="flex items-center justify-between pt-2 border-t mt-2">
                        <div className="text-[10px] text-slate-400 flex items-center gap-1">
                            <Clock className="w-3 h-3"/> {inv.status === 'pending' ? `Expires ${new Date(inv.expires_at).toLocaleDateString()}` : `Created ${new Date(inv.created_at).toLocaleDateString()}`}
                        </div>
                        <div className="flex gap-1">
                           {inv.status === 'pending' && (
                               <>
                                 <Button variant="ghost" size="icon" className="h-6 w-6" title="Copy Link" onClick={() => {
                                     const path = inv.role === 'admin' ? '/tenant-invite' : '/invite';
                                     navigator.clipboard.writeText(`${window.location.origin}${path}?code=${inv.token}`);
                                     toast({ title: "Copied", description: "Link copied to clipboard." });
                                 }}>
                                    <Copy className="h-3 w-3" />
                                 </Button>
                                 <Button variant="ghost" size="icon" className="h-6 w-6 text-red-500 hover:text-red-700 hover:bg-red-50" title="Revoke" onClick={() => handleRevokeInvite(inv.id)}>
                                    <XCircle className="h-3 w-3" />
                                 </Button>
                               </>
                           )}
                           {inv.status !== 'accepted' && inv.status !== 'pending' && (
                               <Button variant="ghost" size="icon" className="h-6 w-6" title="Resend" onClick={() => handleResendInvite(inv.id)}>
                                  <RefreshCcw className="h-3 w-3" />
                               </Button>
                           )}
                        </div>
                     </div>
                   </div>
                 ))
               }
            </TabsContent>
          </Tabs>

        </SheetContent>
      </Sheet>

      {/* --- DIALOGS --- */}
      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
         <DialogContent><DialogHeader><DialogTitle>New Tenant</DialogTitle></DialogHeader>
         <form onSubmit={handleCreateSubmit} className="space-y-4">
            <Input placeholder="Name" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} required />
            <Button type="submit" disabled={isSubmitting}>Create</Button>
         </form>
         </DialogContent>
      </Dialog>
    </div>
  );
}
