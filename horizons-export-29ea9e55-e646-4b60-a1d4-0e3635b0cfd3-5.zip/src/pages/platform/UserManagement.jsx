
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { adminService } from '@/services/adminService';
import { inviteService } from '@/services/inviteService';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator,
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Users, 
  MoreHorizontal, 
  Plus, 
  Search, 
  Loader2, 
  Pencil, 
  Trash2, 
  Shield, 
  RefreshCcw, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  Copy,
  Ticket,
  KeyRound,
  Activity
} from 'lucide-react';
import { format } from 'date-fns';

export default function UserManagement() {
  const { user: currentUser, userRole } = useAuth();
  const { toast } = useToast();
  
  // Permissions
  const isViewer = userRole === 'viewer';
  const isSuperAdmin = userRole === 'super_admin';
  const canManage = userRole === 'admin' || isSuperAdmin;

  const [users, setUsers] = useState([]);
  const [invites, setInvites] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('active'); // 'active', 'inactive', 'invites'

  // Modal States
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditRoleOpen, setIsEditRoleOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isComplianceOpen, setIsComplianceOpen] = useState(false);
  
  // Invite Deletion States
  const [isDeleteInviteOpen, setIsDeleteInviteOpen] = useState(false);
  const [selectedInvite, setSelectedInvite] = useState(null);

  const [selectedUser, setSelectedUser] = useState(null);
  const [complianceData, setComplianceData] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [newInviteCode, setNewInviteCode] = useState(null);
  const [newRole, setNewRole] = useState('viewer');

  // Form Data for Invites
  const [inviteForm, setInviteForm] = useState({
    email: '',
    role: 'viewer'
  });

  const fetchUsers = async () => {
    try {
      if (users.length === 0) setLoading(true);
      console.log('[UserManagement] 1. Initiating fetch for platform staff...');
      const data = await adminService.getPlatformStaff();
      
      console.log('[UserManagement] 2. Raw Staff Data Received:', data);
      
      if (Array.isArray(data)) {
        // Validation check
        const sample = data[0];
        if (sample) {
          console.log('[UserManagement] 3. Data Structure Verification (Sample User):', {
            id: sample.id,
            email: sample.email,
            role: sample.role,
            last_sign_in_at: sample.last_sign_in_at,
            status: sample.status,
            full_name: sample.full_name
          });
          
          if (!sample.id || !sample.email || !sample.role) {
             console.warn('[UserManagement] WARNING: Critical fields missing in staff data');
          }
        } else {
          console.log('[UserManagement] Staff array is empty.');
        }
      } else {
        console.error('[UserManagement] ERROR: Expected array but got:', typeof data);
      }

      setUsers(data || []);
    } catch (error) {
      console.error("[UserManagement] CRITICAL ERROR fetching users:", error);
      toast({
        variant: "destructive",
        title: "Error fetching users",
        description: error.message || "Check console for details"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchInvites = async () => {
    try {
      console.log('[UserManagement] Fetching invites...');
      const data = await inviteService.getInvites();
      console.log('[UserManagement] Raw Invites Data:', data);
      setInvites(data || []);
    } catch (error) {
      console.error("[UserManagement] Failed to fetch invites:", error);
    }
  };

  useEffect(() => {
    fetchUsers();
    fetchInvites();

    const staffSub = supabase.channel('platform_staff_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'platform_staff' }, (payload) => {
        console.log('[UserManagement] Realtime update on staff:', payload);
        fetchUsers();
      })
      .subscribe();

    const inviteSub = supabase.channel('platform_invites_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'platform_invites' }, (payload) => {
         console.log('[UserManagement] Realtime update on invites:', payload);
         fetchInvites();
      })
      .subscribe();

    return () => {
      staffSub.unsubscribe();
      inviteSub.unsubscribe();
    };
  }, []);

  // --- ACTIONS ---

  const openCreateModal = () => {
    setInviteForm({ email: '', role: 'viewer' });
    setNewInviteCode(null);
    setIsCreateOpen(true);
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard" });
  };

  const handleCreateInvite = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setNewInviteCode(null);

    try {
      const result = await inviteService.createInvite(inviteForm.email, inviteForm.role);
      if (result.success) {
        setNewInviteCode({ code: result.code, ...inviteForm });
        toast({ title: "Invite Generated" });
        fetchInvites();
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      toast({ variant: "destructive", title: "Failed", description: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteInvite = async () => {
    if (!selectedInvite) return;
    setIsSubmitting(true);
    try {
      await inviteService.deleteInvite(selectedInvite.id);
      toast({ title: "Invite Deleted" });
      setIsDeleteInviteOpen(false);
      fetchInvites();
    } catch (error) {
      toast({ variant: "destructive", title: "Delete Failed", description: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChangeRole = async () => {
    if (!selectedUser || !newRole) return;
    setIsSubmitting(true);
    try {
      await adminService.changeUserRole(selectedUser.id, newRole);
      toast({ title: "Role Updated", description: `User is now ${newRole}` });
      setIsEditRoleOpen(false);
      fetchUsers();
    } catch (error) {
      toast({ variant: "destructive", title: "Update Failed", description: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteUser = async () => {
    if (!selectedUser) return;
    setIsSubmitting(true);
    try {
      await adminService.deletePlatformUser(selectedUser.id);
      toast({ title: "User Removed", description: "Access has been revoked." });
      setIsDeleteOpen(false);
      fetchUsers();
    } catch (error) {
      toast({ variant: "destructive", title: "Delete Failed", description: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleForceReset = async (userId) => {
    try {
      await adminService.forcePasswordReset(userId);
      toast({ title: "Reset Flagged", description: "User will be prompted to reset password on next login." });
    } catch (error) {
      toast({ variant: "destructive", title: "Failed", description: error.message });
    }
  };

  const handleCheckCompliance = async (user) => {
    console.log('[UserManagement] Checking compliance for:', user);
    setSelectedUser(user);
    setComplianceData(null);
    setIsComplianceOpen(true);
    try {
      const data = await adminService.getComplianceStatus(user.user_id);
      console.log('[UserManagement] Compliance Data Received:', data);
      setComplianceData(data);
    } catch (error) {
      console.error('[UserManagement] Compliance Error:', error);
      toast({ variant: "destructive", title: "Error", description: "Could not fetch compliance data" });
    }
  };

  // --- FILTERING LOGIC ---

  // 1. "Active Staff" = Users in platform_staff who HAVE logged in (last_sign_in_at is present)
  // 2. "Inactive/Invited Staff" = Users in platform_staff who have NEVER logged in (last_sign_in_at is null) OR explicitly status='invited'
  // 3. "Pending Invites" = Records in platform_invites table

  const activeStaff = users.filter(u => u.last_sign_in_at && u.status !== 'invited');
  const inactiveStaff = users.filter(u => !u.last_sign_in_at || u.status === 'invited');
  
  // Debug log filtering
  useEffect(() => {
    if(!loading) {
       console.log(`[UserManagement] 4. Filtering Stats: Active=${activeStaff.length}, Inactive=${inactiveStaff.length}, Invites=${invites.length}`);
       console.log('[UserManagement] Active Staff List:', activeStaff.map(u => u.email));
       console.log('[UserManagement] Inactive Staff List:', inactiveStaff.map(u => u.email));
    }
  }, [users, invites, loading]);

  const filteredList = (activeTab === 'active' ? activeStaff : activeTab === 'inactive' ? inactiveStaff : [])
    .filter(u => {
      const search = searchTerm.toLowerCase();
      return (
        (u.email?.toLowerCase().includes(search) || u.full_name?.toLowerCase().includes(search)) &&
        (roleFilter === 'all' || u.role === roleFilter)
      );
    });

  const filteredInvites = invites.filter(i => 
    i.email.toLowerCase().includes(searchTerm.toLowerCase()) || 
    i.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getRoleBadge = (role) => {
    const styles = {
      super_admin: "bg-purple-500/10 text-purple-400 border-purple-500/20",
      admin: "bg-blue-500/10 text-blue-400 border-blue-500/20",
      viewer: "bg-slate-700 text-slate-300 border-slate-600"
    };
    return (
      <Badge className={`hover:opacity-80 ${styles[role] || styles.viewer}`}>
        {role?.replace('_', ' ').toUpperCase()}
      </Badge>
    );
  };

  return (
    <div className="space-y-6 p-6 animate-in fade-in duration-500 max-w-[1600px] mx-auto">
      
      {/* HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-100 flex items-center gap-2">
            <Users className="h-8 w-8 text-blue-500" />
            User Management
          </h2>
          <p className="text-slate-400 mt-1">Manage staff access, roles, and compliance.</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" onClick={() => { fetchUsers(); fetchInvites(); }} disabled={loading}>
            <RefreshCcw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} /> Refresh
          </Button>
          {!isViewer && (
            <Button onClick={openCreateModal} className="bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="mr-2 h-4 w-4" /> Invite User
            </Button>
          )}
        </div>
      </div>

      {/* TABS */}
      <div className="flex gap-4 border-b border-slate-800 pb-2 overflow-x-auto">
        {[
          { id: 'active', label: 'Active Staff', count: activeStaff.length, icon: CheckCircle2 },
          { id: 'inactive', label: 'Pending / Inactive', count: inactiveStaff.length, icon: Clock },
          { id: 'invites', label: 'Invite Codes', count: invites.filter(i => i.status === 'pending').length, icon: Ticket }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`
              flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-t-lg transition-colors whitespace-nowrap
              ${activeTab === tab.id ? 'bg-slate-800 text-white border-b-2 border-blue-500' : 'text-slate-400 hover:text-white hover:bg-slate-800/50'}
            `}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
            <Badge variant="secondary" className="ml-1 bg-slate-700 text-xs">{tab.count}</Badge>
          </button>
        ))}
      </div>

      {/* MAIN CONTENT CARD */}
      <Card className="bg-slate-900 border-slate-800 shadow-xl rounded-tl-none">
        <CardHeader className="pb-4">
          <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
            <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-slate-500" />
                <Input 
                  placeholder="Search email or name..." 
                  className="pl-8 bg-slate-950 border-slate-700 text-slate-200" 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              {activeTab !== 'invites' && (
                <Select value={roleFilter} onValueChange={setRoleFilter}>
                  <SelectTrigger className="w-full sm:w-[150px] bg-slate-950 border-slate-700 text-slate-200">
                    <SelectValue placeholder="Filter Role" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-900 border-slate-800 text-slate-200">
                    <SelectItem value="all">All Roles</SelectItem>
                    <SelectItem value="super_admin">Super Admin</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="viewer">Viewer</SelectItem>
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>
        </CardHeader>

        <CardContent>
          {activeTab === 'invites' ? (
            // --- INVITES TABLE ---
            <Table>
              <TableHeader className="bg-slate-950">
                <TableRow className="border-slate-800 hover:bg-slate-900">
                  <TableHead className="text-slate-400">Email</TableHead>
                  <TableHead className="text-slate-400">Code</TableHead>
                  <TableHead className="text-slate-400">Role</TableHead>
                  <TableHead className="text-slate-400">Created</TableHead>
                  <TableHead className="text-slate-400">Status</TableHead>
                  {!isViewer && <TableHead className="text-right text-slate-400">Actions</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInvites.map((inv) => (
                  <TableRow key={inv.id} className="border-slate-800 hover:bg-slate-800/50">
                    <TableCell className="text-slate-200">{inv.email}</TableCell>
                    <TableCell><code className="bg-slate-950 px-2 py-1 rounded text-blue-400 text-xs">{inv.code}</code></TableCell>
                    <TableCell>{getRoleBadge(inv.role)}</TableCell>
                    <TableCell className="text-slate-500 text-xs">{format(new Date(inv.created_at), 'MMM d, yyyy')}</TableCell>
                    <TableCell>
                      <Badge variant={inv.status === 'pending' ? 'outline' : 'secondary'} className={inv.status === 'pending' ? 'text-yellow-500 border-yellow-500/30' : ''}>
                        {inv.status}
                      </Badge>
                    </TableCell>
                    {!isViewer && (
                      <TableCell className="text-right">
                         <div className="flex justify-end gap-2">
                            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => copyToClipboard(inv.code)}>
                              <Copy className="h-4 w-4 text-slate-400" />
                            </Button>
                            {inv.status === 'pending' && (
                              <Button size="icon" variant="ghost" className="h-8 w-8 hover:bg-red-900/20" onClick={() => { setSelectedInvite(inv); setIsDeleteInviteOpen(true); }}>
                                <Trash2 className="h-4 w-4 text-red-400" />
                              </Button>
                            )}
                         </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
                 {filteredInvites.length === 0 && <TableRow><TableCell colSpan={6} className="text-center py-8 text-slate-500">No invites found</TableCell></TableRow>}
              </TableBody>
            </Table>
          ) : (
            // --- USERS TABLE (Active & Inactive) ---
            <Table>
              <TableHeader className="bg-slate-950">
                <TableRow className="border-slate-800 hover:bg-slate-900">
                  <TableHead className="text-slate-400">User</TableHead>
                  <TableHead className="text-slate-400">Role</TableHead>
                  <TableHead className="text-slate-400">Compliance</TableHead>
                  <TableHead className="text-slate-400">Last Seen</TableHead>
                  <TableHead className="text-right text-slate-400">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredList.map((u) => (
                  <TableRow key={u.id} className="border-slate-800 hover:bg-slate-800/50">
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="font-medium text-slate-200">{u.full_name || '—'}</span>
                        <span className="text-xs text-slate-500">{u.email}</span>
                      </div>
                    </TableCell>
                    <TableCell>{getRoleBadge(u.role)}</TableCell>
                    <TableCell>
                       {/* Quick visual check based on last login */}
                       {u.last_sign_in_at ? (
                          <div className="flex items-center gap-1.5">
                             <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]"></div>
                             <span className="text-xs text-green-500">Good</span>
                          </div>
                       ) : (
                          <div className="flex items-center gap-1.5">
                             <div className="w-2 h-2 rounded-full bg-slate-500"></div>
                             <span className="text-xs text-slate-500">Never Logged In</span>
                          </div>
                       )}
                    </TableCell>
                    <TableCell className="text-slate-400 text-sm">
                      {u.last_sign_in_at ? format(new Date(u.last_sign_in_at), 'MMM d, h:mm a') : '—'}
                    </TableCell>
                    <TableCell className="text-right">
                       {!isViewer && (
                         <DropdownMenu>
                           <DropdownMenuTrigger asChild>
                             <Button variant="ghost" className="h-8 w-8 p-0 hover:bg-slate-800">
                               <MoreHorizontal className="h-4 w-4 text-slate-400" />
                             </Button>
                           </DropdownMenuTrigger>
                           <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800 text-slate-200">
                             <DropdownMenuLabel className="text-xs text-slate-500 uppercase tracking-wider">User Actions</DropdownMenuLabel>
                             
                             <DropdownMenuItem onClick={() => handleCheckCompliance(u)}>
                               <Activity className="mr-2 h-4 w-4 text-blue-400" /> Check Status
                             </DropdownMenuItem>
                             
                             {isSuperAdmin && (
                               <DropdownMenuItem onClick={() => { setSelectedUser(u); setNewRole(u.role); setIsEditRoleOpen(true); }}>
                                 <Pencil className="mr-2 h-4 w-4" /> Change Role
                               </DropdownMenuItem>
                             )}
                             
                             {canManage && (
                               <DropdownMenuItem onClick={() => handleForceReset(u.user_id)}>
                                 <KeyRound className="mr-2 h-4 w-4" /> Reset Password
                               </DropdownMenuItem>
                             )}

                             <DropdownMenuSeparator className="bg-slate-800" />
                             
                             {isSuperAdmin && (
                               <DropdownMenuItem 
                                 className="text-red-400 hover:text-red-300 focus:text-red-300"
                                 onClick={() => { setSelectedUser(u); setIsDeleteOpen(true); }}
                               >
                                 <Trash2 className="mr-2 h-4 w-4" /> Delete User
                               </DropdownMenuItem>
                             )}
                           </DropdownMenuContent>
                         </DropdownMenu>
                       )}
                    </TableCell>
                  </TableRow>
                ))}
                {filteredList.length === 0 && <TableRow><TableCell colSpan={5} className="text-center py-8 text-slate-500">No active users found.</TableCell></TableRow>}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* --- MODALS --- */}

      {/* 1. Create Invite Modal */}
      <Dialog open={isCreateOpen} onOpenChange={(v) => { setIsCreateOpen(v); if(!v) setNewInviteCode(null); }}>
         <DialogContent className="bg-slate-900 border-slate-800 text-slate-200">
            <DialogHeader>
              <DialogTitle>Invite New User</DialogTitle>
              <DialogDescription>Generate a secure code for signup.</DialogDescription>
            </DialogHeader>
            {!newInviteCode ? (
               <form onSubmit={handleCreateInvite} className="space-y-4 py-2">
                 <div className="space-y-2">
                   <Label>Email</Label>
                   <Input 
                      required type="email" 
                      value={inviteForm.email} 
                      onChange={e => setInviteForm({...inviteForm, email: e.target.value})}
                      className="bg-slate-950 border-slate-700" 
                   />
                 </div>
                 <div className="space-y-2">
                   <Label>Role</Label>
                   <Select value={inviteForm.role} onValueChange={v => setInviteForm({...inviteForm, role: v})}>
                     <SelectTrigger className="bg-slate-950 border-slate-700"><SelectValue /></SelectTrigger>
                     <SelectContent className="bg-slate-900 border-slate-800 text-slate-200">
                        <SelectItem value="viewer">Viewer</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="super_admin">Super Admin</SelectItem>
                     </SelectContent>
                   </Select>
                 </div>
                 <Button type="submit" disabled={isSubmitting} className="w-full mt-4">
                   {isSubmitting ? <Loader2 className="animate-spin mr-2 h-4 w-4" /> : 'Generate Invite'}
                 </Button>
               </form>
            ) : (
               <div className="space-y-4 py-4 text-center">
                  <div className="bg-green-900/20 text-green-400 p-4 rounded-lg border border-green-900/50">
                     <CheckCircle2 className="w-8 h-8 mx-auto mb-2" />
                     <p className="font-medium">Invite Ready!</p>
                  </div>
                  <div className="bg-slate-950 p-4 rounded border border-slate-800 font-mono text-xl select-all">
                     {newInviteCode.code}
                  </div>
                  <Button onClick={() => setIsCreateOpen(false)} className="w-full">Done</Button>
               </div>
            )}
         </DialogContent>
      </Dialog>

      {/* 2. Compliance Status Modal */}
      <Dialog open={isComplianceOpen} onOpenChange={setIsComplianceOpen}>
         <DialogContent className="bg-slate-900 border-slate-800 text-slate-200">
            <DialogHeader>
               <DialogTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-blue-500" /> Security Status
               </DialogTitle>
            </DialogHeader>
            {!complianceData ? (
               <div className="py-8 flex justify-center"><Loader2 className="animate-spin h-8 w-8 text-blue-500" /></div>
            ) : (
               <div className="space-y-6 py-4">
                  <div className="flex justify-between items-center p-4 bg-slate-950 rounded-lg border border-slate-800">
                     <div>
                        <p className="text-sm text-slate-500 uppercase font-bold tracking-wider">Compliance Score</p>
                        <p className={`text-3xl font-bold ${complianceData.compliance_score > 80 ? 'text-green-500' : 'text-yellow-500'}`}>
                           {complianceData.compliance_score}%
                        </p>
                     </div>
                     {complianceData.compliance_score > 80 
                        ? <CheckCircle2 className="h-10 w-10 text-green-500/50" />
                        : <AlertCircle className="h-10 w-10 text-yellow-500/50" />
                     }
                  </div>

                  <div className="space-y-3">
                     <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                        <span className="text-slate-400">MFA Enabled</span>
                        {complianceData.mfa_enabled 
                           ? <Badge className="bg-green-500/10 text-green-500">Yes</Badge> 
                           : <Badge variant="destructive">No</Badge>
                        }
                     </div>
                     <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                        <span className="text-slate-400">Days Since Login</span>
                        <span className="font-mono text-slate-200">
                           {complianceData.days_since_login === -1 ? 'Never' : `${complianceData.days_since_login} days`}
                        </span>
                     </div>
                  </div>

                  {complianceData.issues?.length > 0 && (
                     <div className="bg-red-500/10 border border-red-500/20 rounded p-3">
                        <p className="text-red-400 text-xs font-bold uppercase mb-2">Issues Found</p>
                        <ul className="list-disc pl-4 space-y-1">
                           {complianceData.issues.map((issue, idx) => (
                              <li key={idx} className="text-sm text-red-300">{issue}</li>
                           ))}
                        </ul>
                     </div>
                  )}
               </div>
            )}
         </DialogContent>
      </Dialog>

      {/* 3. Edit Role Modal */}
      <Dialog open={isEditRoleOpen} onOpenChange={setIsEditRoleOpen}>
         <DialogContent className="bg-slate-900 border-slate-800 text-slate-200">
            <DialogHeader><DialogTitle>Change User Role</DialogTitle></DialogHeader>
            <div className="py-4">
               <Label className="mb-2 block">New Role</Label>
               <Select value={newRole} onValueChange={setNewRole}>
                  <SelectTrigger className="bg-slate-950 border-slate-700"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-slate-900 border-slate-800 text-slate-200">
                     <SelectItem value="viewer">Viewer</SelectItem>
                     <SelectItem value="admin">Admin</SelectItem>
                     <SelectItem value="super_admin">Super Admin</SelectItem>
                  </SelectContent>
               </Select>
            </div>
            <DialogFooter>
               <Button variant="ghost" onClick={() => setIsEditRoleOpen(false)}>Cancel</Button>
               <Button onClick={handleChangeRole} disabled={isSubmitting}>
                  {isSubmitting ? <Loader2 className="animate-spin h-4 w-4" /> : 'Update Role'}
               </Button>
            </DialogFooter>
         </DialogContent>
      </Dialog>

      {/* 4. Delete Confirmation */}
      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
         <AlertDialogContent className="bg-slate-900 border-slate-800 text-slate-200">
            <AlertDialogHeader>
               <AlertDialogTitle>Delete User Permanently?</AlertDialogTitle>
               <AlertDialogDescription>
                  This will revoke all access for <span className="text-white font-medium">{selectedUser?.email}</span>.
               </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
               <AlertDialogCancel className="bg-transparent border-slate-700 text-slate-300 hover:bg-slate-800">Cancel</AlertDialogCancel>
               <AlertDialogAction onClick={handleDeleteUser} className="bg-red-600 hover:bg-red-700 text-white border-none">
                  {isSubmitting ? <Loader2 className="animate-spin h-4 w-4" /> : 'Delete User'}
               </AlertDialogAction>
            </AlertDialogFooter>
         </AlertDialogContent>
      </AlertDialog>

      {/* 5. Delete Invite Confirmation */}
      <AlertDialog open={isDeleteInviteOpen} onOpenChange={setIsDeleteInviteOpen}>
         <AlertDialogContent className="bg-slate-900 border-slate-800 text-slate-200">
            <AlertDialogHeader>
               <AlertDialogTitle>Revoke Invite?</AlertDialogTitle>
               <AlertDialogDescription>
                  This will invalidate the invite code for <span className="text-white font-medium">{selectedInvite?.email}</span>.
               </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
               <AlertDialogCancel className="bg-transparent border-slate-700 text-slate-300 hover:bg-slate-800">Cancel</AlertDialogCancel>
               <AlertDialogAction onClick={handleDeleteInvite} className="bg-red-600 hover:bg-red-700 text-white border-none">
                  {isSubmitting ? <Loader2 className="animate-spin h-4 w-4" /> : 'Revoke Invite'}
               </AlertDialogAction>
            </AlertDialogFooter>
         </AlertDialogContent>
      </AlertDialog>

    </div>
  );
}
