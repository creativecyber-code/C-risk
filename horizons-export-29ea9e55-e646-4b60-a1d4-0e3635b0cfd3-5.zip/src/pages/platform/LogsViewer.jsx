
import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { loggingService } from '@/services/loggingService';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  FileText, 
  Search, 
  Download, 
  RefreshCcw, 
  Filter, 
  AlertTriangle, 
  Info, 
  XCircle, 
  Bug,
  ChevronLeft,
  ChevronRight,
  Eye,
  Activity
} from 'lucide-react';
import { format } from 'date-fns';

export default function LogsViewer() {
  const { toast } = useToast();
  
  // -- State --
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ total: 0, info: 0, warning: 0, error: 0 });
  const [page, setPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const pageSize = 15;

  // Filters
  const [levelFilter, setLevelFilter] = useState('all');
  const [dateRange, setDateRange] = useState('today');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Custom Date Range
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');

  // Selected Log for Details Modal
  const [selectedLog, setSelectedLog] = useState(null);

  // Sorting
  const [sortConfig, setSortConfig] = useState({ column: 'timestamp', ascending: false });

  // -- Actions --

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    try {
      const filters = {
        level: levelFilter,
        dateRange,
        search: searchTerm,
        startDate: customStart,
        endDate: customEnd
      };
      
      const { data, count } = await loggingService.getLogs({
        page,
        pageSize,
        filters,
        sort: sortConfig
      });
      
      setLogs(data || []);
      setTotalCount(count || 0);

    } catch (error) {
      console.error('Fetch logs error:', error);
      toast({
        variant: "destructive",
        title: "Error fetching logs",
        description: error.message
      });
    } finally {
      setLoading(false);
    }
  }, [page, levelFilter, dateRange, searchTerm, customStart, customEnd, sortConfig, toast]);

  const fetchStats = useCallback(async () => {
    try {
      const s = await loggingService.getStats();
      setStats(s);
    } catch (e) {
      console.error("Failed to fetch stats", e);
    }
  }, []);

  // -- Effects --

  useEffect(() => {
    fetchLogs();
    fetchStats();

    // Realtime subscription
    const channel = supabase
      .channel('public:system_logs')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'system_logs' }, (payload) => {
        // Optimistically add new log if it matches current sort/filter
        // For simplicity, we just trigger a refetch or show a toast notification
        // Adding to top of list if sort is desc timestamp
        if (sortConfig.column === 'timestamp' && !sortConfig.ascending && page === 1) {
           // We could prepend, but filters might exclude it.
           // Safer to just re-fetch or indicate update availability.
           // Let's silently re-fetch for "Live" feel
           fetchLogs();
           fetchStats();
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchLogs, fetchStats, sortConfig, page]);

  // -- Handlers --

  const handleExport = async () => {
    try {
      toast({ title: "Exporting...", description: "Preparing your CSV download." });
      const csvContent = await loggingService.exportLogs({
        level: levelFilter,
        dateRange,
        search: searchTerm
      });

      if (!csvContent) {
        toast({ title: "No data", description: "There are no logs to export." });
        return;
      }

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `system_logs_${format(new Date(), 'yyyy-MM-dd_HH-mm')}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({ title: "Export Complete", description: "Your logs have been downloaded." });
    } catch (error) {
      toast({ variant: "destructive", title: "Export Failed", description: error.message });
    }
  };

  const handleSort = (column) => {
    setSortConfig(current => ({
      column,
      ascending: current.column === column ? !current.ascending : true
    }));
  };

  // -- Render Helpers --

  const getLevelBadge = (level) => {
    switch (level?.toLowerCase()) {
      case 'error': return <Badge variant="destructive" className="bg-red-500/10 text-red-500 hover:bg-red-500/20 border-red-500/20"><XCircle className="w-3 h-3 mr-1" /> Error</Badge>;
      case 'warning': return <Badge variant="secondary" className="bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20 border-yellow-500/20"><AlertTriangle className="w-3 h-3 mr-1" /> Warning</Badge>;
      case 'info': return <Badge variant="secondary" className="bg-blue-500/10 text-blue-500 hover:bg-blue-500/20 border-blue-500/20"><Info className="w-3 h-3 mr-1" /> Info</Badge>;
      case 'debug': return <Badge variant="outline" className="text-slate-400 border-slate-700"><Bug className="w-3 h-3 mr-1" /> Debug</Badge>;
      default: return <Badge variant="outline">{level}</Badge>;
    }
  };

  const getStatusColor = (status) => {
    return status === 'success' ? 'text-green-500' : status === 'failure' ? 'text-red-500' : 'text-slate-400';
  };

  const totalPages = Math.ceil(totalCount / pageSize);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-100 flex items-center gap-2">
            <Activity className="h-8 w-8 text-blue-500" />
            System Logs
          </h2>
          <p className="text-slate-400 mt-1">Monitor system activity, errors, and audit trails.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={fetchLogs} className="border-slate-700 text-slate-300 hover:bg-slate-800">
            <RefreshCcw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button onClick={handleExport} className="bg-slate-800 text-slate-200 border border-slate-700 hover:bg-slate-700">
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-slate-900 border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">Total Events</CardTitle>
            <FileText className="h-4 w-4 text-slate-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stats.total}</div>
          </CardContent>
        </Card>
        <Card className="bg-slate-900 border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">Errors</CardTitle>
            <XCircle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-400">{stats.error}</div>
          </CardContent>
        </Card>
        <Card className="bg-slate-900 border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">Warnings</CardTitle>
            <AlertTriangle className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-400">{stats.warning}</div>
          </CardContent>
        </Card>
        <Card className="bg-slate-900 border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">Info</CardTitle>
            <Info className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-400">{stats.info}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="bg-slate-900 border-slate-800 p-4">
        <div className="flex flex-col md:flex-row gap-4 flex-wrap">
          
          <div className="flex-1 min-w-[200px] relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500" />
            <Input 
              placeholder="Search by Action, User, or Keyword..." 
              className="pl-9 bg-slate-950 border-slate-700 text-slate-200 focus:ring-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <Select value={levelFilter} onValueChange={setLevelFilter}>
            <SelectTrigger className="w-[150px] bg-slate-950 border-slate-700 text-slate-200">
              <SelectValue placeholder="Log Level" />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-slate-800 text-slate-200">
              <SelectItem value="all">All Levels</SelectItem>
              <SelectItem value="info">Info</SelectItem>
              <SelectItem value="warning">Warning</SelectItem>
              <SelectItem value="error">Error</SelectItem>
              <SelectItem value="debug">Debug</SelectItem>
            </SelectContent>
          </Select>

          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-[150px] bg-slate-950 border-slate-700 text-slate-200">
              <SelectValue placeholder="Date Range" />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-slate-800 text-slate-200">
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="7d">Last 7 Days</SelectItem>
              <SelectItem value="30d">Last 30 Days</SelectItem>
              <SelectItem value="custom">Custom Range</SelectItem>
            </SelectContent>
          </Select>

          {dateRange === 'custom' && (
             <div className="flex items-center gap-2">
                <Input 
                  type="date" 
                  className="bg-slate-950 border-slate-700 text-slate-200 w-[140px]" 
                  value={customStart}
                  onChange={(e) => setCustomStart(e.target.value)}
                />
                <span className="text-slate-500">-</span>
                <Input 
                  type="date" 
                  className="bg-slate-950 border-slate-700 text-slate-200 w-[140px]" 
                  value={customEnd}
                  onChange={(e) => setCustomEnd(e.target.value)}
                />
             </div>
          )}

          <Button 
            variant="secondary" 
            onClick={fetchLogs}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Filter className="h-4 w-4 mr-2" /> Apply
          </Button>

        </div>
      </Card>

      {/* Logs Table */}
      <Card className="bg-slate-900 border-slate-800 overflow-hidden">
        <div className="rounded-md border border-slate-800">
          <Table>
            <TableHeader className="bg-slate-950">
              <TableRow className="border-slate-800 hover:bg-slate-900">
                <TableHead onClick={() => handleSort('timestamp')} className="cursor-pointer text-slate-400 hover:text-white transition-colors">
                  Timestamp {sortConfig.column === 'timestamp' && (sortConfig.ascending ? '↑' : '↓')}
                </TableHead>
                <TableHead onClick={() => handleSort('level')} className="cursor-pointer text-slate-400 hover:text-white transition-colors">
                  Level {sortConfig.column === 'level' && (sortConfig.ascending ? '↑' : '↓')}
                </TableHead>
                <TableHead className="text-slate-400">User / IP</TableHead>
                <TableHead onClick={() => handleSort('action')} className="cursor-pointer text-slate-400 hover:text-white transition-colors">
                  Action {sortConfig.column === 'action' && (sortConfig.ascending ? '↑' : '↓')}
                </TableHead>
                <TableHead className="text-slate-400">Resource</TableHead>
                <TableHead className="text-slate-400">Status</TableHead>
                <TableHead className="text-right text-slate-400">Details</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={7} className="h-32 text-center text-slate-500">
                    <div className="flex items-center justify-center gap-2">
                       <RefreshCcw className="h-5 w-5 animate-spin" />
                       Loading logs...
                    </div>
                  </TableCell>
                </TableRow>
              ) : logs.length === 0 ? (
                <TableRow>
                   <TableCell colSpan={7} className="h-32 text-center text-slate-500">
                    No logs found matching your criteria.
                   </TableCell>
                </TableRow>
              ) : (
                logs.map((log) => (
                  <TableRow key={log.id} className="border-slate-800 hover:bg-slate-800/50">
                    <TableCell className="text-slate-300 font-mono text-xs whitespace-nowrap">
                      {format(new Date(log.timestamp), 'MMM d, HH:mm:ss')}
                    </TableCell>
                    <TableCell>
                      {getLevelBadge(log.level)}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="text-sm text-slate-200">{log.user_email || 'System'}</span>
                        <span className="text-xs text-slate-600 font-mono">{log.ip_address}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-slate-300 font-medium">
                      {log.action}
                    </TableCell>
                    <TableCell className="text-slate-400 text-sm">
                      {log.resource || '-'}
                    </TableCell>
                    <TableCell className={`text-xs uppercase font-bold ${getStatusColor(log.status)}`}>
                      {log.status}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => setSelectedLog(log)}
                        className="h-8 w-8 p-0 text-slate-400 hover:text-white hover:bg-slate-700"
                      >
                        <Eye className="h-4 w-4" />
                        <span className="sr-only">View Details</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        <div className="p-4 flex items-center justify-between border-t border-slate-800">
           <div className="text-sm text-slate-500">
             Showing {logs.length} of {totalCount} logs
           </div>
           <div className="flex items-center gap-2">
             <Button 
               variant="outline" 
               size="sm" 
               onClick={() => setPage(p => Math.max(1, p - 1))}
               disabled={page === 1 || loading}
               className="border-slate-700 text-slate-300 hover:bg-slate-800 disabled:opacity-50"
             >
               <ChevronLeft className="h-4 w-4" />
             </Button>
             <span className="text-sm text-slate-400">Page {page} of {totalPages || 1}</span>
             <Button 
               variant="outline" 
               size="sm" 
               onClick={() => setPage(p => Math.min(totalPages, p + 1))}
               disabled={page >= totalPages || loading}
               className="border-slate-700 text-slate-300 hover:bg-slate-800 disabled:opacity-50"
             >
               <ChevronRight className="h-4 w-4" />
             </Button>
           </div>
        </div>
      </Card>

      {/* Detail Modal */}
      <Dialog open={!!selectedLog} onOpenChange={(open) => !open && setSelectedLog(null)}>
        <DialogContent className="bg-slate-950 border-slate-800 text-slate-200 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              {getLevelBadge(selectedLog?.level)}
              <span className="font-mono text-slate-300">{selectedLog?.action}</span>
            </DialogTitle>
            <DialogDescription className="text-slate-500">
              Log ID: {selectedLog?.id}
            </DialogDescription>
          </DialogHeader>
          
          {selectedLog && (
            <div className="space-y-6 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500">Timestamp</h4>
                  <p className="text-sm text-slate-300">{format(new Date(selectedLog.timestamp), 'yyyy-MM-dd HH:mm:ss.SSS')}</p>
                </div>
                 <div className="space-y-1">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500">IP Address</h4>
                  <p className="text-sm text-slate-300 font-mono">{selectedLog.ip_address}</p>
                </div>
                 <div className="space-y-1">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500">User</h4>
                  <p className="text-sm text-slate-300">{selectedLog.user_email || 'N/A'}</p>
                </div>
                 <div className="space-y-1">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500">Resource</h4>
                  <p className="text-sm text-slate-300">{selectedLog.resource || 'N/A'}</p>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500">JSON Details</h4>
                <div className="bg-slate-900 p-4 rounded-md border border-slate-800 overflow-x-auto">
                  <pre className="text-xs font-mono text-blue-300">
                    {JSON.stringify(selectedLog.details, null, 2)}
                  </pre>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
             <Button onClick={() => setSelectedLog(null)} className="bg-slate-800 hover:bg-slate-700 text-white">Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
}
