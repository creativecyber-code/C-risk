
import React, { useState } from 'react';
import { Routes, Route, Link, useNavigate, useLocation, Navigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Settings, 
  LogOut, 
  ShieldAlert, 
  Activity, 
  Building2,
  FileCode,
  Globe,
  Database,
  Menu
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext'; // Fixed import to match App.jsx Provider
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger, 
  SheetHeader, 
  SheetTitle,
  SheetDescription 
} from "@/components/ui/sheet";
import Logo from '@/components/Logo';

// Ensure these components exist or handle default exports properly
import TenantManagement from './TenantManagement';
import UserManagement from './UserManagement';
import LogsViewer from './LogsViewer';
import RegulatoryLibraryManager from '@/components/platform/RegulatoryLibraryManager';
import RegulatoryImportWizard from '@/components/platform/RegulatoryImportWizard';
import ContentPushEngine from './ContentPushEngine';

const PlatformDashboardHome = () => (
  <div className="p-4 md:p-8 space-y-6">
    <h1 className="text-2xl md:text-3xl font-bold text-brand-900">Platform Overview</h1>
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-brand-100">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-brand-900">Total Tenants</h3>
          <Building2 className="h-5 w-5 text-brand-500" />
        </div>
        <p className="text-3xl font-bold text-brand-700">24</p>
        <p className="text-sm text-brand-600/70 mt-1">+2 this week</p>
      </div>
      <div className="bg-white p-6 rounded-xl shadow-sm border border-brand-100">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-brand-900">Active Users</h3>
          <Users className="h-5 w-5 text-brand-500" />
        </div>
        <p className="text-3xl font-bold text-brand-700">1,204</p>
        <p className="text-sm text-brand-600/70 mt-1">98% active rate</p>
      </div>
      <div className="bg-white p-6 rounded-xl shadow-sm border border-brand-100">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-brand-900">System Health</h3>
          <Activity className="h-5 w-5 text-green-500" />
        </div>
        <p className="text-3xl font-bold text-green-600">99.99%</p>
        <p className="text-sm text-green-700/70 mt-1">All systems operational</p>
      </div>
    </div>
  </div>
);

const PlatformConsole = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  const navItems = [
    { label: 'Overview', path: '/platform-console', icon: LayoutDashboard },
    { label: 'Tenant Management', path: '/platform-console/tenants', icon: Building2 },
    { label: 'Platform Users', path: '/platform-console/users', icon: Users },
    { label: 'Regulatory Library', path: '/platform-console/regulatory-library', icon: Database },
    { label: 'Import Wizard', path: '/platform-console/import-wizard', icon: FileCode },
    { label: 'Content Push', path: '/platform-console/content-push', icon: Globe },
    { label: 'System Logs', path: '/platform-console/logs', icon: Activity },
  ];

  return (
    <div className="min-h-[100dvh] bg-slate-50 flex flex-col md:flex-row font-sans overflow-x-hidden">
      
      {/* Mobile Header - Sticky */}
      <div className="md:hidden bg-brand-900 text-white p-4 flex items-center justify-between sticky top-0 z-50 shadow-md">
        <div className="flex items-center gap-2">
          <Logo imgClassName="h-8 w-auto brightness-0 invert" />
        </div>
        
        <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="text-white hover:bg-brand-800 -mr-2">
              <Menu className="h-6 w-6" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          {/* Note: Side="left" is handled by sheet variants. Custom class handles styling. */}
          <SheetContent side="left" className="w-[85%] max-w-[300px] bg-brand-950 border-r border-brand-900 p-0 text-white flex flex-col focus:outline-none">
             {/* Accessibility: Title is required by Radix UI Dialog */}
             <SheetHeader className="sr-only">
               <SheetTitle>Mobile Navigation</SheetTitle>
               <SheetDescription>Access platform administration routes</SheetDescription>
             </SheetHeader>

             <div className="p-6 border-b border-brand-900 flex-none">
               <Logo imgClassName="h-8 w-auto brightness-0 invert" />
               <p className="text-xs text-brand-400 mt-2 uppercase tracking-wider font-semibold">Platform Console</p>
             </div>
             
             <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={`flex items-center gap-3 px-3 py-3 rounded-lg text-sm font-medium transition-colors ${
                    location.pathname === item.path 
                      ? 'bg-brand-800 text-white' 
                      : 'text-brand-300 hover:bg-brand-900 hover:text-white'
                  }`}
                >
                  <item.icon className="h-5 w-5 flex-shrink-0" />
                  <span className="truncate">{item.label}</span>
                </Link>
              ))}
            </nav>
            
            <div className="p-4 border-t border-brand-900 flex-none bg-brand-950">
               <div className="mb-4 px-2">
                 <div className="flex items-center gap-3 mb-3">
                   <Avatar className="h-8 w-8 border border-brand-700">
                      <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${user?.email}`} />
                      <AvatarFallback className="bg-brand-800 text-brand-200">AD</AvatarFallback>
                   </Avatar>
                   <div className="overflow-hidden">
                      <p className="text-sm font-medium text-white truncate">Platform Admin</p>
                      <p className="text-xs text-brand-400 truncate">{user?.email}</p>
                   </div>
                 </div>
               </div>
              <Button 
                variant="ghost" 
                className="w-full justify-start text-red-400 hover:text-red-300 hover:bg-red-950/30"
                onClick={handleSignOut}
              >
                <LogOut className="h-5 w-5 mr-3 flex-shrink-0" />
                Sign Out
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-brand-950 border-r border-brand-900 text-white fixed h-full z-10">
        <div className="p-6 border-b border-brand-900">
          <Logo imgClassName="h-10 w-auto brightness-0 invert" />
          <div className="mt-4 flex items-center gap-2 px-2 py-1 bg-brand-900/50 rounded border border-brand-800/50">
            <ShieldAlert className="h-3 w-3 text-brand-400" />
            <span className="text-[10px] font-bold text-brand-300 uppercase tracking-wider">Admin Console</span>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                location.pathname === item.path 
                  ? 'bg-brand-800 text-white shadow-lg shadow-black/10' 
                  : 'text-brand-300 hover:bg-brand-900 hover:text-white'
              }`}
            >
              <item.icon className="h-5 w-5 flex-shrink-0" />
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-brand-900 bg-brand-950">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-3 w-full p-2 rounded-lg hover:bg-brand-900 transition-colors text-left outline-none focus:ring-2 focus:ring-brand-500">
                <Avatar className="h-9 w-9 border-2 border-brand-700">
                  <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${user?.email}`} />
                  <AvatarFallback className="bg-brand-800 text-brand-200">AD</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">Platform Admin</p>
                  <p className="text-xs text-brand-400 truncate">{user?.email}</p>
                </div>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 bg-brand-900 border-brand-800 text-brand-100">
              <DropdownMenuLabel className="text-brand-400">My Account</DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-brand-800" />
              <DropdownMenuItem className="focus:bg-brand-800 focus:text-white cursor-pointer">
                <Settings className="mr-2 h-4 w-4" /> Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-brand-800" />
              <DropdownMenuItem 
                className="text-red-400 focus:bg-red-950/30 focus:text-red-300 cursor-pointer"
                onClick={handleSignOut}
              >
                <LogOut className="mr-2 h-4 w-4" /> Log out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 md:ml-64 min-h-[100dvh] bg-slate-50/50 w-full">
        {/* Use overflow-x-auto wrapper for content that might be too wide on mobile */}
        <div className="w-full">
          <Routes>
            <Route path="/" element={<PlatformDashboardHome />} />
            
            <Route path="/tenants" element={
              <div className="p-4 md:p-8 overflow-x-auto"><TenantManagement /></div>
            } />
            
            <Route path="/users" element={
              <div className="p-4 md:p-8 overflow-x-auto"><UserManagement /></div>
            } />
            
            <Route path="/logs" element={
              <div className="p-4 md:p-8 overflow-x-auto"><LogsViewer /></div>
            } />
            
            <Route path="/regulatory-library" element={
              <div className="p-4 md:p-8 overflow-x-auto"><RegulatoryLibraryManager /></div>
            } />
            
            <Route path="/import-wizard" element={
              <div className="p-4 md:p-8 overflow-x-auto"><RegulatoryImportWizard /></div>
            } />
            
            <Route path="/content-push" element={
              <div className="p-4 md:p-8"><ContentPushEngine /></div>
            } />
            
            <Route path="*" element={<Navigate to="/platform-console" replace />} />
          </Routes>
        </div>
      </main>
    </div>
  );
};

export default PlatformConsole;
