
import React, { useState, useEffect } from 'react';
import { 
  Rocket, History, BookOpen, CheckCircle2, AlertCircle, 
  ArrowRight, Users, Eye, Globe 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/components/ui/use-toast';
import RegulatoryLibraryManager from '@/components/platform/RegulatoryLibraryManager';
import { contentPushService } from '@/services/contentPushService';

// --- Sub-component: Deployment Wizard ---
const DeploymentWizard = () => {
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [regulations, setRegulations] = useState([]);
  const [tenants, setTenants] = useState([]);
  
  // Selection State
  const [selectedRegId, setSelectedRegId] = useState('');
  const [targetType, setTargetType] = useState('SPECIFIC');
  const [selectedTenantIds, setSelectedTenantIds] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [regs, tnts] = await Promise.all([
      contentPushService.getRegulations(),
      contentPushService.getActiveTenants()
    ]);
    setRegulations(regs || []);
    setTenants(tnts || []);
  };

  const selectedRegulation = regulations.find(r => r.id === selectedRegId);

  const handleDeploy = async () => {
    setLoading(true);
    try {
      const finalTenantIds = targetType === 'ALL' 
        ? tenants.map(t => t.id) 
        : selectedTenantIds;

      if (finalTenantIds.length === 0) {
        throw new Error("No target tenants selected");
      }

      await contentPushService.createDeployment(selectedRegId, targetType, finalTenantIds);
      
      toast({
        title: "Deployment Successful",
        description: `Content pushed to ${finalTenantIds.length} tenants.`,
        className: "bg-green-50 border-green-200 text-green-900"
      });
      setStep(1);
      setSelectedRegId('');
      setSelectedTenantIds([]);
    } catch (e) {
      toast({ 
        title: "Deployment Failed", 
        description: e.message, 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleTenant = (id) => {
    setSelectedTenantIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-4">
      {/* Progress Steps */}
      <div className="flex justify-between items-center px-12">
        <div className={`flex flex-col items-center gap-2 ${step >= 1 ? 'text-blue-600' : 'text-slate-400'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${step >= 1 ? 'border-blue-600 bg-blue-50' : 'border-slate-300'}`}>1</div>
          <span className="text-xs font-semibold">Select Content</span>
        </div>
        <div className="flex-1 h-0.5 bg-slate-200 mx-4"></div>
        <div className={`flex flex-col items-center gap-2 ${step >= 2 ? 'text-blue-600' : 'text-slate-400'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${step >= 2 ? 'border-blue-600 bg-blue-50' : 'border-slate-300'}`}>2</div>
          <span className="text-xs font-semibold">Target Audience</span>
        </div>
        <div className="flex-1 h-0.5 bg-slate-200 mx-4"></div>
        <div className={`flex flex-col items-center gap-2 ${step >= 3 ? 'text-blue-600' : 'text-slate-400'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${step >= 3 ? 'border-blue-600 bg-blue-50' : 'border-slate-300'}`}>3</div>
          <span className="text-xs font-semibold">Preview & Deploy</span>
        </div>
      </div>

      <Card className="min-h-[400px]">
        {step === 1 && (
          <CardContent className="pt-6 space-y-6">
            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Select Regulation to Deploy</h3>
              <p className="text-slate-500 text-sm">Choose from the master library.</p>
            </div>
            <div className="grid gap-3">
              {regulations.map(reg => (
                <div 
                  key={reg.id} 
                  className={`p-4 border rounded-lg cursor-pointer transition-all ${selectedRegId === reg.id ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' : 'hover:border-slate-300'}`}
                  onClick={() => setSelectedRegId(reg.id)}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-semibold text-slate-900">{reg.regulation_name}</h4>
                      <p className="text-sm text-slate-500">{reg.description}</p>
                    </div>
                    <Badge variant="outline">{reg.category?.name}</Badge>
                  </div>
                  <div className="mt-2 flex gap-4 text-xs text-slate-600">
                    <span>{reg.control_items?.length || 0} Controls</span>
                    <span>Created: {new Date(reg.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
              ))}
              {regulations.length === 0 && <p className="text-center py-8 text-slate-400">Library is empty.</p>}
            </div>
          </CardContent>
        )}

        {step === 2 && (
          <CardContent className="pt-6 space-y-6">
            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Select Targets</h3>
              <p className="text-slate-500 text-sm">Who should receive this update?</p>
            </div>
            
            <div className="flex gap-4 p-4 bg-slate-50 rounded-lg">
              <div className="flex items-center space-x-2">
                <input 
                  type="radio" 
                  id="target-specific" 
                  checked={targetType === 'SPECIFIC'} 
                  onChange={() => setTargetType('SPECIFIC')}
                  className="w-4 h-4 text-blue-600"
                />
                <label htmlFor="target-specific" className="text-sm font-medium">Specific Tenants</label>
              </div>
              <div className="flex items-center space-x-2">
                <input 
                  type="radio" 
                  id="target-all" 
                  checked={targetType === 'ALL'} 
                  onChange={() => setTargetType('ALL')}
                  className="w-4 h-4 text-blue-600"
                />
                <label htmlFor="target-all" className="text-sm font-medium">All Active Tenants</label>
              </div>
            </div>

            {targetType === 'SPECIFIC' && (
              <ScrollArea className="h-60 border rounded-md p-4">
                <div className="space-y-2">
                  {tenants.map(tenant => (
                    <div key={tenant.id} className="flex items-center space-x-3 p-2 hover:bg-slate-50 rounded">
                      <Checkbox 
                        checked={selectedTenantIds.includes(tenant.id)}
                        onCheckedChange={() => toggleTenant(tenant.id)}
                      />
                      <div className="flex-1">
                        <div className="text-sm font-medium">{tenant.name}</div>
                        <div className="text-xs text-slate-400">{tenant.slug}</div>
                      </div>
                      <Badge className={tenant.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}>
                        {tenant.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        )}

        {step === 3 && selectedRegulation && (
          <CardContent className="pt-6 space-y-6">
            <div className="text-center space-y-2">
              <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto text-blue-600">
                <Rocket className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-900">Ready to Deploy?</h3>
              <p className="text-slate-500">Review details before pushing to production.</p>
            </div>

            <div className="bg-slate-50 p-6 rounded-lg border space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-slate-500 block mb-1">Regulation</span>
                  <span className="font-semibold block">{selectedRegulation.regulation_name}</span>
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">Controls</span>
                  <span className="font-semibold block">{selectedRegulation.control_items?.length} items</span>
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">Target Audience</span>
                  <span className="font-semibold block">
                    {targetType === 'ALL' ? 'All Active Tenants' : `${selectedTenantIds.length} Specific Tenant(s)`}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">Risk Category</span>
                  <Badge variant="outline">{selectedRegulation.category?.name}</Badge>
                </div>
              </div>

              <div className="border-t pt-4">
                 <h4 className="text-xs font-bold text-slate-500 uppercase mb-2">Content Preview</h4>
                 <div className="max-h-40 overflow-y-auto space-y-2 text-sm">
                    {selectedRegulation.control_items?.slice(0, 5).map((c, i) => (
                      <div key={i} className="flex gap-2">
                        <span className="font-mono text-slate-600">{c.code}</span>
                        <span className="truncate">{c.name}</span>
                      </div>
                    ))}
                    {(selectedRegulation.control_items?.length || 0) > 5 && (
                      <div className="text-xs text-slate-400 italic">...and {selectedRegulation.control_items.length - 5} more</div>
                    )}
                 </div>
              </div>
            </div>
          </CardContent>
        )}

        <CardFooter className="flex justify-between border-t p-6 bg-slate-50/50">
          <Button 
            variant="outline" 
            onClick={() => setStep(s => Math.max(1, s - 1))}
            disabled={step === 1 || loading}
          >
            Back
          </Button>
          
          {step < 3 ? (
            <Button 
              onClick={() => setStep(s => s + 1)} 
              disabled={step === 1 && !selectedRegId}
            >
              Next <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button 
              className="bg-green-600 hover:bg-green-700" 
              onClick={handleDeploy}
              disabled={loading}
            >
              {loading ? 'Deploying...' : 'Confirm & Push'}
              {!loading && <Rocket className="w-4 h-4 ml-2" />}
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
};

// --- Sub-component: History ---
const DeploymentHistory = () => {
  const [history, setHistory] = useState([]);
  
  useEffect(() => {
    contentPushService.getDeploymentHistory().then(setHistory);
  }, []);

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-slate-900">Recent Deployments</h3>
      <div className="border rounded-md bg-white">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-slate-500 border-b">
            <tr>
              <th className="p-4">Regulation</th>
              <th className="p-4">Target</th>
              <th className="p-4">Status</th>
              <th className="p-4">Deployed At</th>
            </tr>
          </thead>
          <tbody>
            {history.map(item => (
              <tr key={item.id} className="border-b last:border-0 hover:bg-slate-50">
                <td className="p-4 font-medium">{item.regulation?.regulation_name || 'Unknown'}</td>
                <td className="p-4">
                  {item.target_type === 'ALL' ? (
                    <Badge variant="secondary"><Globe className="w-3 h-3 mr-1" /> Global</Badge>
                  ) : (
                    <Badge variant="outline"><Users className="w-3 h-3 mr-1" /> {item.target_tenant_ids?.length || 0} Tenants</Badge>
                  )}
                </td>
                <td className="p-4">
                  <Badge className={item.status === 'COMPLETED' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}>
                    {item.status}
                  </Badge>
                </td>
                <td className="p-4 text-slate-500">
                  {new Date(item.created_at).toLocaleString()}
                </td>
              </tr>
            ))}
            {history.length === 0 && (
              <tr><td colSpan={4} className="p-8 text-center text-slate-400">No history found</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// --- Main Page Component ---
const ContentPushEngine = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white">Content Push Engine</h1>
          <p className="text-slate-400 mt-2">Manage regulatory master libraries and distribute updates to tenants.</p>
        </div>
      </div>

      <Tabs defaultValue="library" className="space-y-6">
        <TabsList className="bg-slate-900 border border-slate-800 p-1">
          <TabsTrigger value="library" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            <BookOpen className="w-4 h-4 mr-2" /> Master Library
          </TabsTrigger>
          <TabsTrigger value="deploy" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            <Rocket className="w-4 h-4 mr-2" /> Push Deployment
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            <History className="w-4 h-4 mr-2" /> History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="library" className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <RegulatoryLibraryManager />
        </TabsContent>

        <TabsContent value="deploy" className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <DeploymentWizard />
        </TabsContent>

        <TabsContent value="history" className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <DeploymentHistory />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ContentPushEngine;
