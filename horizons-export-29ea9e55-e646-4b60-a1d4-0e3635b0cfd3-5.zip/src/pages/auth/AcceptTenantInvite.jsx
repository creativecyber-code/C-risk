
import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { invitationService } from '@/services/invitationService';
import { supabase } from '@/lib/customSupabaseClient';
import { Loader2, CheckCircle2, XCircle, Building2, ArrowRight } from 'lucide-react';

const AcceptTenantInvite = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token') || searchParams.get('code');
  const navigate = useNavigate();
  const { toast } = useToast();

  const [inviteData, setInviteData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Form State
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (!token) {
      setError("No invitation token provided.");
      setLoading(false);
      return;
    }
    validateToken();
  }, [token]);

  const validateToken = async () => {
    try {
      const data = await invitationService.validateToken(token);
      setInviteData(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      toast({ title: "Passwords do not match", variant: "destructive" });
      return;
    }
    if (password.length < 8) {
        toast({ title: "Password too weak", description: "Must be at least 8 characters.", variant: "destructive" });
        return;
    }

    setSubmitting(true);
    try {
      // 1. Accept Invite (Creates user, links to tenant, assigns role)
      await invitationService.acceptInvite({
        token,
        password,
        fullName
      });
      
      setSuccess(true);
      
      // 2. Auto-login immediately
      const { error: loginError } = await supabase.auth.signInWithPassword({
        email: inviteData.email,
        password: password
      });

      if (!loginError) {
        toast({ title: "Welcome Administrator", description: "Setting up your tenant environment..." });
        
        // 3. Redirect to MFA Setup
        // Passing 'fromLogin' ensures MFA setup knows this is a fresh flow
        setTimeout(() => {
             navigate('/mfa-setup', { 
               state: { 
                 fromLogin: true,
                 // Explicitly set final destination to dashboard
                 from: { pathname: '/app-dashboard' }
               } 
             });
        }, 1500);
      } else {
        toast({ title: "Account Created", description: "Please log in manually." });
        setTimeout(() => navigate('/login'), 2000);
      }

    } catch (err) {
      console.error("Acceptance Error:", err);
      toast({ title: "Setup Failed", description: err.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900 p-4">
        <Card className="w-full max-w-md border-red-900 bg-slate-950 text-slate-100">
          <CardHeader className="text-center">
            <div className="mx-auto bg-red-900/20 p-3 rounded-full w-fit mb-4">
              <XCircle className="h-8 w-8 text-red-500" />
            </div>
            <CardTitle className="text-red-500">Invalid Link</CardTitle>
            <CardDescription className="text-slate-400">{error}</CardDescription>
          </CardHeader>
          <CardFooter className="justify-center">
            <Link to="/login">
              <Button variant="outline" className="border-slate-700 text-slate-300 hover:bg-slate-800">Return to Login</Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900 p-4">
        <Card className="w-full max-w-md border-green-900 bg-slate-950 shadow-lg shadow-green-900/10">
          <CardHeader className="text-center">
            <div className="mx-auto bg-green-900/20 p-3 rounded-full w-fit mb-4">
              <CheckCircle2 className="h-8 w-8 text-green-500" />
            </div>
            <CardTitle className="text-green-500">Organization Activated</CardTitle>
            <CardDescription className="text-slate-400">
              Admin account created for <strong>{inviteData?.organizations?.name}</strong>.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center pb-8 flex-col items-center gap-4">
             <Loader2 className="h-6 w-6 animate-spin text-green-500" />
             <p className="text-xs text-slate-500">Redirecting to Security Setup...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-900 p-4 text-slate-50">
      <Helmet>
        <title>Setup Tenant Admin | C-RISK</title>
      </Helmet>
      
      <div className="mb-8 text-center">
        <div className="flex items-center justify-center gap-2 mb-2 text-blue-500">
           <Building2 className="h-8 w-8" />
           <span className="text-2xl font-bold tracking-tight">C-RISK Enterprise</span>
        </div>
      </div>

      <Card className="w-full max-w-md shadow-2xl border-slate-800 bg-slate-950">
        <CardHeader>
          <CardTitle className="text-white">Activate Admin Account</CardTitle>
          <CardDescription className="text-slate-400">
            Setup administrator access for <strong>{inviteData?.organizations?.name}</strong>.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6 p-3 rounded bg-blue-950/30 border border-blue-900/50">
             <p className="text-sm text-blue-300">
               <strong>Note:</strong> As a tenant administrator, you will have full access to manage users, settings, and compliance data for this organization.
             </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fullname" className="text-slate-200">Full Name</Label>
              <Input 
                id="fullname" 
                placeholder="Admin Name" 
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
                className="bg-slate-900 border-slate-700 text-white placeholder:text-slate-600 focus:border-blue-500"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-slate-200">Set Password</Label>
              <Input 
                id="password" 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="bg-slate-900 border-slate-700 text-white focus:border-blue-500"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm" className="text-slate-200">Confirm Password</Label>
              <Input 
                id="confirm" 
                type="password" 
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                className="bg-slate-900 border-slate-700 text-white focus:border-blue-500"
              />
            </div>
            
            <Button type="submit" className="w-full mt-4 bg-blue-600 hover:bg-blue-500 text-white font-medium" disabled={submitting}>
              {submitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ArrowRight className="mr-2 h-4 w-4" />}
              Create Admin Account
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default AcceptTenantInvite;
