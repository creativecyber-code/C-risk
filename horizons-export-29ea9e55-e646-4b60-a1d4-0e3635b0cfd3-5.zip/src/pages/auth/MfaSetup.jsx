
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardContent, CardFooter, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Shield, Copy, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

const MfaSetup = () => {
  const [factorId, setFactorId] = useState(null);
  const [qrCode, setQrCode] = useState(''); // The totp uri
  const [secret, setSecret] = useState('');
  const [verifyCode, setVerifyCode] = useState('');
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [verifying, setVerifying] = useState(false);
  
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    if (!user) {
        navigate('/login');
        return;
    }
    initMfa();
  }, [user]);

  const initMfa = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase.auth.mfa.enroll({
        factorType: 'totp',
      });

      if (error) throw error;

      setFactorId(data.id);
      setQrCode(data.totp.uri);
      setSecret(data.totp.secret);
    } catch (err) {
      console.error(err);
      setError("Failed to initialize MFA setup.");
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setVerifying(true);
    setError(null);
    try {
      const { data, error } = await supabase.auth.mfa.challengeAndVerify({
        factorId,
        code: verifyCode,
      });

      if (error) throw error;

      // --- REDIRECT LOGIC ---
      // Success! Check where to go.
      const userId = user.id;

       // Check if tenant
       const { data: tenantMember } = await supabase
         .from('tenant_members')
         .select('tenant_id')
         .eq('user_id', userId)
         .maybeSingle();

       if (tenantMember) {
          navigate('/dashboard/overview');
          return;
       }

       // Check if platform
       const { data: platformStaff } = await supabase
         .from('platform_staff')
         .select('role')
         .eq('user_id', userId)
         .maybeSingle();

       if (platformStaff) {
          navigate('/platform-console');
          return;
       }

       navigate('/app-dashboard');

    } catch (err) {
      setError(err.message || "Invalid code. Please try again.");
    } finally {
      setVerifying(false);
    }
  };

  if (loading) {
    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50">
            <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <Card className="w-full max-w-lg shadow-lg">
        <CardHeader>
          <div className="flex items-center gap-3 mb-2">
             <div className="bg-blue-100 p-2 rounded-lg">
                 <Shield className="h-6 w-6 text-blue-600" />
             </div>
             <div>
                 <CardTitle>Secure Your Account</CardTitle>
                 <CardDescription>Set up Two-Factor Authentication (2FA)</CardDescription>
             </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          
          {error && (
             <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
             </Alert>
          )}

          <div className="space-y-4">
             <div className="bg-slate-50 p-4 rounded-lg border border-slate-100 flex flex-col items-center">
                 <div className="bg-white p-2 rounded shadow-sm mb-4">
                    {qrCode && <QRCodeSVG value={qrCode} size={180} />}
                 </div>
                 <p className="text-sm text-slate-500 text-center mb-2">
                    Scan this QR code with your authenticator app (Google Authenticator, Authy, etc.)
                 </p>
             </div>

             <div className="space-y-2">
                 <p className="text-xs font-medium text-slate-500 uppercase">Or enter code manually</p>
                 <div className="flex items-center gap-2">
                    <code className="flex-1 bg-slate-100 p-2 rounded text-sm font-mono text-slate-700 break-all">
                        {secret}
                    </code>
                    <Button variant="outline" size="icon" onClick={() => navigator.clipboard.writeText(secret)}>
                        <Copy className="h-4 w-4" />
                    </Button>
                 </div>
             </div>
          </div>

          <div className="space-y-3 pt-4 border-t">
              <p className="text-sm font-medium">Verify Setup</p>
              <div className="flex gap-2">
                  <Input 
                     placeholder="Enter 6-digit code" 
                     value={verifyCode}
                     onChange={(e) => setVerifyCode(e.target.value)}
                     className="tracking-widest"
                     maxLength={6}
                  />
                  <Button onClick={handleVerify} disabled={verifying || verifyCode.length !== 6}>
                     {verifying ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Activate'}
                  </Button>
              </div>
          </div>

        </CardContent>
      </Card>
    </div>
  );
};

export default MfaSetup;
