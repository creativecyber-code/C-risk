
import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Lock, Loader2, AlertCircle } from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import { useToast } from '@/components/ui/use-toast';
import LogoHeader from '@/components/LogoHeader';
import { COMPANY_NAME } from '@/lib/constants';

const GatewayLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [authStage, setAuthStage] = useState('credentials'); // credentials | mfa_check
  const [errorMsg, setErrorMsg] = useState('');
  
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg('');
    setAuthStage('credentials');

    try {
      // 1. Attempt Credential Login
      const { data, error } = await signIn(email, password);
      
      if (error) {
        throw error;
      }

      setAuthStage('mfa_check');

      // 2. Check MFA Status immediately
      const { data: factors, error: mfaError } = await supabase.auth.mfa.listFactors();
      
      if (mfaError) {
        console.error("MFA Check Error:", mfaError);
        navigate(location.state?.from?.pathname || '/dashboard');
        return;
      }

      const hasVerifiedMfa = factors?.totp?.some(f => f.status === 'verified');

      if (hasVerifiedMfa) {
        toast({
            title: "MFA Required",
            description: "Please verify your identity.",
        });
        navigate('/mfa-verify', { 
            state: { 
                from: location.state?.from || { pathname: '/dashboard' }
            } 
        });
      } else {
        toast({
            title: "Security Check",
            description: "We recommend setting up 2FA for your account.",
        });
        navigate('/mfa-setup', { 
            state: { 
                fromLogin: true,
                from: location.state?.from || { pathname: '/dashboard' }
            } 
        });
      }

    } catch (err) {
      console.error("Login Error:", err);
      setErrorMsg(err.message || "Authentication failed. Please check your credentials.");
      setIsLoading(false);
      setAuthStage('credentials');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <Helmet>
        <title>Login | {COMPANY_NAME}</title>
      </Helmet>

      {/* Main Logo Placement */}
      <div className="mb-8">
        <LogoHeader size="xl" showText={true} />
      </div>

      <Card className="w-full max-w-md shadow-lg border-t-4 border-t-blue-600">
        <CardHeader className="space-y-1 text-center">
          <CardTitle className="text-xl font-bold text-slate-900">Secure Gateway</CardTitle>
          <CardDescription>
            Enter your credentials to access the platform
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          
          {errorMsg && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{errorMsg}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleLogin}>
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="name@organization.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isLoading}
                  required
                  autoComplete="email"
                />
              </div>
              <div className="grid gap-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <Link
                    to="/forgot-password"
                    className="text-sm font-medium text-blue-600 hover:text-blue-500 hover:underline"
                  >
                    Forgot password?
                  </Link>
                </div>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={isLoading}
                  required
                  autoComplete="current-password"
                />
              </div>
              
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={isLoading}>
                {isLoading ? (
                    <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        {authStage === 'mfa_check' ? 'Checking Security...' : 'Authenticating...'}
                    </>
                ) : (
                    <>
                        <Lock className="mr-2 h-4 w-4" /> Sign In
                    </>
                )}
              </Button>
            </div>
          </form>

          <div className="relative my-2">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-slate-200" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-2 text-slate-500">
                Secure Environment
              </span>
            </div>
          </div>
          
          <div className="text-center text-xs text-slate-400">
             By signing in, you agree to our Terms of Service and Privacy Policy.
          </div>

        </CardContent>
        <CardFooter className="bg-slate-50 border-t p-4 flex justify-center">
          <div className="text-sm text-slate-600">
            Don't have an account?{' '}
            <Link to="/signup" className="font-semibold text-blue-600 hover:text-blue-500 hover:underline">
              Request Access
            </Link>
          </div>
        </CardFooter>
      </Card>
      
      <div className="mt-8 text-center text-sm text-slate-400">
        &copy; {new Date().getFullYear()} {COMPANY_NAME}. All rights reserved.
      </div>
    </div>
  );
};

export default GatewayLogin;
