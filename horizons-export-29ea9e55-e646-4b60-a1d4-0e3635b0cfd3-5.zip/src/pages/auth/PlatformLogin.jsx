
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { ShieldAlert, Lock, AlertTriangle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const PlatformLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { signIn } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Platform-specific login logic would typically verify role here
    // For now we use the unified auth context
    const { error } = await signIn(email, password);
    
    if (!error) {
      navigate('/dashboard/platform');
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-500 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-600 rounded-full blur-[120px]" />
      </div>

      <div className="w-full max-w-md space-y-8 relative z-10">
        <div className="text-center space-y-2">
          <div className="mx-auto h-16 w-16 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-center shadow-2xl">
            <ShieldAlert className="h-8 w-8 text-red-500" />
          </div>
          <h1 className="text-3xl font-bold tracking-tighter text-white">Fleet Command</h1>
          <p className="text-slate-400">Restricted Access • Platform Administrators Only</p>
        </div>

        <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-sm shadow-2xl">
          <CardHeader>
            <CardTitle className="text-slate-100">Secure Login</CardTitle>
            <CardDescription className="text-slate-500">Authenticate with your master credentials.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-300">Admin Email</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="admin@platform.internal"
                    className="pl-9 bg-slate-950 border-slate-800 text-slate-100 focus:ring-red-500 focus:border-red-500"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-300">Master Password</Label>
                <Input 
                  id="password" 
                  type="password" 
                  className="bg-slate-950 border-slate-800 text-slate-100 focus:ring-red-500 focus:border-red-500"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              
              <Alert className="bg-amber-950/20 border-amber-900/50">
                <AlertTriangle className="h-4 w-4 text-amber-500" />
                <AlertTitle className="text-amber-500 text-xs font-bold uppercase">Legal Notice</AlertTitle>
                <AlertDescription className="text-amber-600/80 text-[10px] leading-tight mt-1">
                  Unauthorized access is prohibited. All activities are monitored and logged. 
                  By logging in, you agree to the Platform Administrative Policy.
                </AlertDescription>
              </Alert>

              <Button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white" disabled={isLoading}>
                {isLoading ? 'Verifying Credentials...' : 'Authenticate'}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="justify-center border-t border-slate-800 pt-4">
            <p className="text-xs text-slate-600">IP: {window.location.hostname} • SSL Secured</p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default PlatformLogin;
