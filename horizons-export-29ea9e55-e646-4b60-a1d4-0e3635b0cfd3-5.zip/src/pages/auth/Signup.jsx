
import React, { useState, useEffect } from 'react';
import { useNavigate, Link, useSearchParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Lock, Mail, ArrowRight, Loader2, AlertCircle, Eye, EyeOff, CheckCircle2, ShieldCheck, UserPlus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import Logo from '@/components/Logo';

const Signup = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { signUp } = useAuth();
  const { toast } = useToast();
  
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState(null);
  const [isValidatingInvite, setIsValidatingInvite] = useState(false);
  const [inviteData, setInviteData] = useState(null);

  const inviteCode = searchParams.get('code');

  const { register, handleSubmit, setValue, formState: { errors } } = useForm({
    defaultValues: { email: '', password: '', confirmPassword: '' }
  });

  // 1. Validate Invite Code on Mount (if present)
  useEffect(() => {
    const validateInvite = async () => {
      if (!inviteCode) return;

      try {
        setIsValidatingInvite(true);
        // Call RPC to check code validity
        const { data, error } = await supabase.rpc('validate_invite_code', { p_code: inviteCode });

        if (error) throw error;

        if (data && data.valid) {
          setInviteData(data);
          setValue('email', data.email); // Auto-fill email
          toast({
            title: "Invite Verified",
            description: `Welcome! You are accepting an invite for ${data.email}.`,
          });
        } else {
          setAuthError(data?.error || "Invalid or expired invite code.");
        }
      } catch (err) {
        console.error("Invite validation error:", err);
        setAuthError("Failed to validate invite code.");
      } finally {
        setIsValidatingInvite(false);
      }
    };

    validateInvite();
  }, [inviteCode, setValue, toast]);

  const handleSignup = async (data) => {
    if (data.password !== data.confirmPassword) {
      setAuthError("Passwords do not match.");
      return;
    }

    setIsLoading(true);
    setAuthError(null);

    try {
      // 2. Prepare Signup Options
      const options = {
        data: {
          full_name: data.fullName || '', // Optional field if added later
          // CRITICAL: Pass invite code in metadata so trigger can find it
          invite_code: inviteCode || null,
          // Optional: Pass role hint, though DB trigger is source of truth
          role: inviteData?.role || 'viewer' 
        }
      };

      // 3. Call Supabase SignUp
      const { data: authData, error } = await signUp(data.email, data.password, options);

      if (error) throw error;

      if (authData?.user) {
        toast({
          title: "Account Created",
          description: "Redirecting to your dashboard...",
        });

        // 4. Smart Redirect
        // If invite was for platform, go to console. Else dashboard.
        setTimeout(() => {
          if (inviteData || (authData.user.user_metadata?.role && ['super_admin', 'admin', 'viewer'].includes(authData.user.user_metadata.role))) {
            navigate('/platform-console');
          } else {
            navigate('/app-dashboard');
          }
        }, 1500);
      }

    } catch (err) {
      console.error('Signup error:', err);
      setAuthError(err.message || "Could not create account.");
      setIsLoading(false);
    }
  };

  if (isValidatingInvite) {
     return (
       <div className="min-h-screen bg-brand-50 flex items-center justify-center">
          <div className="flex flex-col items-center gap-4 animate-pulse">
             <Loader2 className="h-10 w-10 text-brand-600 animate-spin" />
             <p className="text-brand-700 font-medium">Verifying Invitation...</p>
          </div>
       </div>
     );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-blue-100/50 rounded-full blur-[80px]" />
        <div className="absolute bottom-[-10%] left-[-5%] w-[500px] h-[500px] bg-indigo-100/50 rounded-full blur-[80px]" />
      </div>

      <div className="w-full max-w-md z-10 space-y-8 animate-in fade-in zoom-in-95 duration-500">
        
        {/* Header */}
        <div className="flex flex-col items-center text-center space-y-2">
          <Logo className="scale-100 mb-2" />
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            {inviteData ? 'Accept Invitation' : 'Create an Account'}
          </h1>
          <p className="text-slate-500 text-sm max-w-xs">
            {inviteData 
              ? `Set up your secure access for ${inviteData.email}` 
              : 'Join C-RISK to manage compliance and risk effectively.'}
          </p>
        </div>

        {/* Signup Card */}
        <div className="bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden">
          {inviteData && (
             <div className="bg-blue-50/80 border-b border-blue-100 px-6 py-3 flex items-center justify-center gap-2">
                <UserPlus className="h-4 w-4 text-blue-600" />
                <span className="text-xs font-semibold text-blue-700">
                   Joining as <span className="uppercase">{inviteData.role?.replace('_', ' ')}</span>
                </span>
             </div>
          )}

          <div className="p-8 pt-6">
            <form onSubmit={handleSubmit(handleSignup)} className="space-y-4">
              
              {authError && (
                <Alert variant="destructive" className="bg-red-50 border-red-200 text-red-800">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="ml-2 text-xs font-medium">
                    {authError}
                  </AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <Input 
                    id="email" 
                    type="email" 
                    {...register("email", {
                      required: "Email is required",
                      pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                        message: "Invalid email address"
                      }
                    })} 
                    // Lock email if it came from a valid invite
                    disabled={!!inviteData}
                    className={`pl-10 h-10 ${inviteData ? 'bg-slate-100 text-slate-500 border-slate-200' : 'bg-white'}`}
                    placeholder="name@company.com" 
                  />
                  {inviteData && <CheckCircle2 className="absolute right-3 top-3 h-4 w-4 text-green-500" />}
                </div>
                {errors.email && <p className="text-xs text-red-500 font-medium ml-1">{errors.email.message}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <Input 
                    id="password" 
                    type={showPassword ? "text" : "password"} 
                    {...register("password", { 
                      required: "Password is required",
                      minLength: { value: 8, message: "Password must be at least 8 characters" }
                    })} 
                    placeholder="Create a strong password" 
                    className="pl-10 pr-10 h-10" 
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-3 text-slate-400 hover:text-slate-600">
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {errors.password && <p className="text-xs text-red-500 font-medium ml-1">{errors.password.message}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <Input 
                    id="confirmPassword" 
                    type={showPassword ? "text" : "password"} 
                    {...register("confirmPassword", { required: "Please confirm your password" })} 
                    placeholder="Repeat password" 
                    className="pl-10 h-10" 
                  />
                </div>
              </div>

              <Button type="submit" className="w-full h-11 bg-brand-600 hover:bg-brand-700 text-white mt-2" disabled={isLoading || (inviteCode && !inviteData)}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating Account...
                  </>
                ) : (
                  <>
                    Sign Up <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-slate-500">
                Already have an account?{' '}
                <Link to="/login" className="font-semibold text-brand-600 hover:text-brand-700 hover:underline">
                  Sign In
                </Link>
              </p>
            </div>
          </div>
          
           {/* Security Footer */}
           <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 flex items-center justify-center gap-2">
              <ShieldCheck className="h-3 w-3 text-slate-400" />
              <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wide">
                 Enterprise Grade Security
              </p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
