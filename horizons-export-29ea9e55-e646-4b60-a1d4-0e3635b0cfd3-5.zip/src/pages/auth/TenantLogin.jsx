
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Building2, ArrowRight, Lock, AlertCircle, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { supabase } from '@/lib/customSupabaseClient';
import Logo from '@/components/Logo';

const GatewayLogin = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  // Form handling for Tenant Domain
  const { register, handleSubmit, formState: { errors } } = useForm();

  const handleTenantLookup = async (data) => {
    setIsLoading(true);
    setError(null);
    const domain = data.domain.toLowerCase().trim();

    try {
      // Simulate API call delay for UX
      await new Promise(resolve => setTimeout(resolve, 600));

      if (domain.length < 3) {
        throw new Error("Invalid organization domain.");
      }

      // In a real scenario, we would check if the tenant exists here:
      /*
      const { data: org, error: orgError } = await supabase
        .from('organizations')
        .select('slug')
        .eq('slug', domain)
        .single();
      
      if (orgError || !org) throw new Error("Organization not found.");
      */
      
      // Store the tenant context
      localStorage.setItem('c-risk-tenant-domain', domain);
      
      // Redirect to the dashboard (simulating successful tenant entry)
      navigate('/dashboard/overview'); 

    } catch (err) {
      setError(err.message || "Unable to locate organization.");
    } finally {
      setIsLoading(false);
    }
  };

  const handlePlatformLogin = () => {
    navigate('/login/platform');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 z-0 opacity-5 pointer-events-none">
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-900 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-indigo-900 rounded-full blur-3xl translate-x-1/2 translate-y-1/2"></div>
      </div>

      <div className="w-full max-w-5xl z-10 flex flex-col items-center gap-8">
        
        {/* Branding Area */}
        <div className="flex flex-col items-center space-y-2 mb-4">
          <Logo className="scale-125" />
          <p className="text-slate-500 font-medium tracking-wide text-sm uppercase mt-2">
            Enterprise Risk Intelligence Gateway
          </p>
        </div>

        {/* Main Gateway Card Container */}
        <div className="w-full grid grid-cols-1 md:grid-cols-2 shadow-2xl rounded-2xl overflow-hidden bg-white min-h-[500px]">
          
          {/* LEFT: Tenant Login */}
          <div className="p-8 md:p-12 flex flex-col justify-center bg-white relative">
            <div className="max-w-md mx-auto w-full space-y-8">
              <div className="space-y-2">
                <div className="h-12 w-12 bg-blue-50 rounded-lg flex items-center justify-center mb-4">
                  <Building2 className="h-6 w-6 text-blue-600" />
                </div>
                <h2 className="text-3xl font-bold text-slate-900">Tenant Login</h2>
                <p className="text-slate-500">
                  Access your organization's secure workspace.
                </p>
              </div>

              {error && (
                <Alert variant="destructive" className="animate-in fade-in slide-in-from-top-2">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit(handleTenantLookup)} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="domain" className="text-slate-700">Organization Domain</Label>
                  <div className="relative">
                    <Input 
                      id="domain"
                      {...register("domain", { required: "Domain is required" })}
                      placeholder="company-name"
                      className="pl-4 pr-24 h-12 bg-slate-50 border-slate-200 focus:border-blue-500 focus:ring-blue-500 transition-all text-lg"
                    />
                    <div className="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none text-slate-400 font-medium">
                      .c-risk.io
                    </div>
                  </div>
                  {errors.domain && (
                    <p className="text-sm text-red-500 mt-1">{errors.domain.message}</p>
                  )}
                  <p className="text-xs text-slate-400">
                    Enter your dedicated workspace slug.
                  </p>
                </div>

                <Button 
                  type="submit" 
                  className="w-full h-12 text-base bg-blue-600 hover:bg-blue-700 transition-all shadow-lg shadow-blue-200"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <span className="flex items-center gap-2">
                      <span className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/>
                      Locating Tenant...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      Go to Organization <ArrowRight className="h-4 w-4" />
                    </span>
                  )}
                </Button>
              </form>

              <div className="pt-6 border-t border-slate-100">
                <p className="text-xs text-slate-400 text-center">
                  Need help finding your domain? Contact your system administrator.
                </p>
              </div>
            </div>
          </div>

          {/* RIGHT: System Administration */}
          <div className="p-8 md:p-12 flex flex-col justify-center bg-[#1a2a4a] text-white relative overflow-hidden">
            {/* Abstract geometric patterns */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-500/10 rounded-full blur-2xl translate-y-1/2 -translate-x-1/2 pointer-events-none"></div>

            <div className="max-w-md mx-auto w-full space-y-8 relative z-10">
              <div className="space-y-2">
                <div className="h-12 w-12 bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="h-6 w-6 text-blue-200" />
                </div>
                <h2 className="text-3xl font-bold text-white">System Administration</h2>
                <p className="text-blue-200/80">
                  Restricted access for C-RISK platform staff and operators.
                </p>
              </div>

              <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6 space-y-4">
                <div className="flex items-start gap-3">
                  <Lock className="h-5 w-5 text-blue-300 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-white">Secure Environment</h4>
                    <p className="text-sm text-blue-200/70 mt-1">
                      Multi-factor authentication is required for all administrative sessions.
                    </p>
                  </div>
                </div>
              </div>

              <Button 
                onClick={handlePlatformLogin}
                variant="outline" 
                className="w-full h-12 text-base border-white/20 bg-transparent text-white hover:bg-white hover:text-[#1a2a4a] transition-all"
              >
                Staff Secure Login
              </Button>

              <div className="pt-6 border-t border-white/10 text-center">
                 <p className="text-xs text-blue-200/50">
                   v2.4.0-stable (Build 8921)
                 </p>
              </div>
            </div>
          </div>
        </div>

        {/* Legal Disclaimer */}
        <div className="w-full max-w-4xl text-center px-4">
          <p className="text-xs text-slate-400 font-mono border-t border-slate-200 pt-6 mt-2">
            NOTICE: This system is for the use of authorized users only. Individuals using this computer system without authority, 
            or in excess of their authority, are subject to having all of their activities on this system monitored and recorded by system personnel.
            <br/><br/>
            <span className="text-red-900/40 font-bold uppercase">Unlawful access is a criminal offense.</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default GatewayLogin;
