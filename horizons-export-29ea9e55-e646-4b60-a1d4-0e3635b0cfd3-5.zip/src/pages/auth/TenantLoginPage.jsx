
import React, { useState, useEffect } from 'react';
import { useSearchParams, Link, useNavigate } from 'react-router-dom';
import { 
  ShieldCheck, 
  Lock, 
  ArrowLeft,
  CheckCircle2, 
  AlertCircle,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { getSubdomain } from '@/lib/subdomainHelper';

// Helper to generate deterministic security image based on email (simulating stored user preference)
const getSecurityVisuals = (email) => {
  if (!email) return null;
  const hash = email.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const images = [
    "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=150&q=80", // Nature
    "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?auto=format&fit=crop&w=150&q=80", // Field
    "https://images.unsplash.com/photo-1501854140884-07504b81ad09?auto=format&fit=crop&w=150&q=80", // Abstract
    "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=150&q=80"  // Forest
  ];
  const phrases = ["Blue Horizon", "Golden Field", "Mountain Peak", "Forest Mist"];
  
  const index = hash % images.length;
  return { image: images[index], phrase: phrases[index] };
};

const TenantLoginPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { signIn, checkRole } = useAuth(); // Assuming checkRole is exposed or we might need to manually check
  const { toast } = useToast();
  
  // State
  // Retrieve slug from subdomain first, fallback to query param for dev/testing
  const tenantSlug = getSubdomain() || searchParams.get('slug') || 'demo-bank';
  
  const [tenantName, setTenantName] = useState('Loading...');
  const [tenantId, setTenantId] = useState(null);
  const [isLoadingOrg, setIsLoadingOrg] = useState(true);
  
  // Auth Flow State
  const [authMethod, setAuthMethod] = useState('sso'); // 'sso' | 'email-entry' | 'password-entry'
  const [email, setEmail] = useState(searchParams.get('prefill') || '');
  const [password, setPassword] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [authError, setAuthError] = useState('');
  const [clientIP, setClientIP] = useState('Loading...');
  
  // Security Visuals
  const [securityContext, setSecurityContext] = useState(null);

  // Initialize Page
  useEffect(() => {
    const fetchOrgDetails = async () => {
      try {
        setIsLoadingOrg(true);
        // Fetch organization details by slug
        const { data, error } = await supabase
          .from('organizations')
          .select('id, name')
          .eq('slug', tenantSlug)
          .maybeSingle();

        if (error) throw error;

        if (data) {
          setTenantName(data.name);
          setTenantId(data.id);
        } else {
          // Fallback if slug not found (or handle 404)
          setTenantName(tenantSlug.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '));
        }

        // Simulate IP fetch (real implementation would use an API or edge function)
        setClientIP("192.168.1.142"); 

      } catch (err) {
        console.error("Org fetch error:", err);
      } finally {
        setIsLoadingOrg(false);
      }
    };

    fetchOrgDetails();
  }, [tenantSlug]);

  // Handle Email Entry (Step 1 of Email Flow)
  const handleEmailSubmit = (e) => {
    e.preventDefault();
    setAuthError('');
    
    if (!email || !email.includes('@')) {
      setAuthError('Please enter a valid work email address.');
      return;
    }

    setIsAuthenticating(true);
    
    // Simulate checking if user exists to prevent enumeration, 
    // but we calculate deterministic visuals to show regardless (security best practice)
    setTimeout(() => {
      setSecurityContext(getSecurityVisuals(email));
      setAuthMethod('password-entry');
      setIsAuthenticating(false);
    }, 600);
  };

  // Handle Password Login (Step 2 of Email Flow)
  const handlePasswordLogin = async (e) => {
    e.preventDefault();
    setIsAuthenticating(true);
    setAuthError('');

    try {
      const { data, error } = await signIn(email, password);
      
      if (error) throw error;
      
      toast({
        title: "Authentication Successful",
        description: "Redirecting to your secure dashboard...",
        variant: "default",
      });

      // --- NEW REDIRECT LOGIC START ---
      // Check if user is a tenant member
      const user = data.user || data.session?.user;
      if (user) {
        // Quick check for tenant membership
        const { data: tenantMember } = await supabase
          .from('tenant_members')
          .select('tenant_id')
          .eq('user_id', user.id)
          .maybeSingle();

        if (tenantMember) {
           navigate('/dashboard/overview');
           return;
        }

        // Check if platform staff
        const { data: platformStaff } = await supabase
          .from('platform_staff')
          .select('role')
          .eq('user_id', user.id)
          .maybeSingle();

        if (platformStaff) {
           navigate('/platform-console');
           return;
        }
        
        // Default fallback
        navigate('/app-dashboard');
      } else {
        // Fallback if no user object immediately available (should not happen on success)
        navigate('/dashboard/overview'); 
      }
      // --- NEW REDIRECT LOGIC END ---
      
    } catch (err) {
      console.error(err);
      setAuthError(err.message || "Invalid credentials provided.");
    } finally {
      setIsAuthenticating(false);
    }
  };

  // Handle SSO Login
  const handleSSOLogin = async () => {
    setIsAuthenticating(true);
    try {
      // Real implementation:
      // await supabase.auth.signInWithOAuth({ provider: 'azure', options: { scopes: 'email' } });
      
      // Simulation:
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast({
        title: "SSO Redirect",
        description: "Redirecting to Azure AD Identity Provider...",
      });
    } catch (err) {
      setAuthError("SSO Service unavailable. Please try again.");
    } finally {
      setIsAuthenticating(false);
    }
  };

  const handleBack = () => {
    if (authMethod === 'password-entry') {
      setAuthMethod('email-entry');
      setPassword('');
      setAuthError('');
    } else if (authMethod === 'email-entry') {
      setAuthMethod('sso');
      setAuthError('');
    }
  };

  if (isLoadingOrg) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="h-8 w-8 animate-spin text-slate-400" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
      
      <main className="flex-1 flex flex-col items-center justify-center p-4 sm:p-8">
        <div className="w-full max-w-md space-y-8">
          
          {/* Header Branding */}
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="h-20 w-20 bg-white rounded-2xl shadow-lg flex items-center justify-center border border-slate-100 mb-2">
              <span className="text-3xl font-bold text-blue-900 tracking-tighter">
                {tenantName.charAt(0)}
              </span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">{tenantName}</h1>
              <p className="text-slate-500 flex items-center justify-center gap-1.5 mt-2 text-sm">
                <span className="h-2 w-2 rounded-full bg-green-500"></span>
                Secure Workspace
              </p>
            </div>
          </div>

          <Card className="border-0 shadow-xl shadow-slate-200/60 overflow-hidden">
            {/* Security Banner Top */}
            <div className="bg-blue-600/5 border-b border-blue-100 p-3 flex items-center justify-center gap-2 text-[11px] font-medium text-blue-700">
              <Lock className="h-3 w-3" />
              <span>Session Encrypted (TLS 1.3)</span>
              <span className="text-blue-300">|</span>
              <span>IP: {clientIP}</span>
            </div>

            <CardContent className="p-8 space-y-6">
              
              {/* --- VIEW: SSO (Default) --- */}
              {authMethod === 'sso' && (
                <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                   <div className="text-center space-y-1">
                     <h3 className="text-lg font-semibold">Sign in</h3>
                     <p className="text-sm text-slate-500">Select an authentication method to continue</p>
                   </div>

                   <Button 
                    onClick={handleSSOLogin}
                    className="w-full h-14 text-base bg-[#0078D4] hover:bg-[#006cbd] text-white flex items-center justify-center gap-3 shadow-lg shadow-blue-900/10 transition-all hover:-translate-y-0.5"
                    disabled={isAuthenticating}
                   >
                     <div className="bg-white/20 p-1 rounded">
                       <svg className="h-5 w-5 fill-current" viewBox="0 0 23 23">
                         <path d="M0 0h11v11H0zM12 0h11v11H12zM0 12h11v11H0zM12 12h11v11H12z"/>
                       </svg>
                     </div>
                     Log in with SSO (Azure AD)
                   </Button>

                   <div className="relative py-2">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t border-slate-200" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-white px-2 text-slate-400 font-medium">Or continue with</span>
                    </div>
                  </div>

                  <Button 
                    variant="outline" 
                    onClick={() => setAuthMethod('email-entry')}
                    className="w-full h-12 border-slate-200 text-slate-700 hover:bg-slate-50 hover:text-slate-900 hover:border-slate-300"
                  >
                    Email and Password
                  </Button>
                </div>
              )}

              {/* --- VIEW: Email Entry --- */}
              {authMethod === 'email-entry' && (
                <form onSubmit={handleEmailSubmit} className="space-y-6 animate-in slide-in-from-right-8 duration-300">
                  <div className="space-y-1">
                    <Button 
                      type="button" 
                      variant="ghost" 
                      className="pl-0 h-auto text-slate-500 hover:text-slate-900 mb-2" 
                      onClick={handleBack}
                    >
                      <ArrowLeft className="mr-2 h-4 w-4" /> Back
                    </Button>
                    <h3 className="text-lg font-semibold">Enter your email</h3>
                  </div>

                  {authError && (
                    <Alert variant="destructive" className="py-2 text-sm bg-red-50 text-red-900 border-red-100">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{authError}</AlertDescription>
                    </Alert>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-slate-700">Work Email</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      placeholder="name@company.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="h-12 text-lg"
                      autoFocus
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full h-12 bg-slate-900 hover:bg-slate-800" disabled={isAuthenticating}>
                    {isAuthenticating ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Next'}
                  </Button>
                </form>
              )}

              {/* --- VIEW: Password Entry (With Site-to-User Auth) --- */}
              {authMethod === 'password-entry' && (
                <form onSubmit={handlePasswordLogin} className="space-y-6 animate-in slide-in-from-right-8 duration-300">
                   <div className="space-y-1">
                    <Button 
                      type="button" 
                      variant="ghost" 
                      className="pl-0 h-auto text-slate-500 hover:text-slate-900 mb-2" 
                      onClick={handleBack}
                    >
                      <ArrowLeft className="mr-2 h-4 w-4" /> Not {email}?
                    </Button>
                  </div>

                  {/* Site-to-User Authentication Verification */}
                  <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 flex items-center gap-4 animate-in zoom-in-95 duration-300">
                    <img 
                      src={securityContext?.image} 
                      alt="Security verification" 
                      className="h-16 w-16 rounded-md object-cover border border-blue-200 shadow-sm"
                    />
                    <div className="flex-1 space-y-0.5">
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-blue-800 uppercase tracking-wide">
                        <ShieldCheck className="h-3 w-3" />
                        Security Image
                      </div>
                      <p className="text-sm font-medium text-slate-900">"{securityContext?.phrase}"</p>
                      <p className="text-[10px] text-slate-500 leading-tight mt-1">
                        Verify this is your chosen image before entering password.
                      </p>
                    </div>
                    <CheckCircle2 className="h-5 w-5 text-green-600 self-start mt-1" />
                  </div>

                  {authError && (
                    <Alert variant="destructive" className="py-2 text-sm bg-red-50 text-red-900 border-red-100">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{authError}</AlertDescription>
                    </Alert>
                  )}

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="password">Password</Label>
                      <Link to="#" className="text-xs text-blue-600 hover:underline">Forgot password?</Link>
                    </div>
                    <Input 
                      id="password" 
                      type="password" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="h-12 text-lg"
                      autoFocus
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full h-12 bg-slate-900 hover:bg-slate-800" disabled={isAuthenticating}>
                     {isAuthenticating ? (
                       <div className="flex items-center gap-2">
                         <Loader2 className="h-5 w-5 animate-spin" /> Verifying...
                       </div>
                     ) : 'Sign In'}
                  </Button>
                </form>
              )}

            </CardContent>
            
            <CardFooter className="bg-slate-50/50 border-t border-slate-100 p-6 flex flex-col gap-4 items-center text-center">
              <div className="flex items-center justify-center gap-2 text-slate-400">
                <span className="text-xs">C-RISK Platform v2.4.0</span>
              </div>
            </CardFooter>
          </Card>

          <div className="text-center">
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              Protected by reCAPTCHA and subject to the C-RISK 
              <Link to="#" className="underline hover:text-slate-600 mx-1">Privacy Policy</Link> 
              and 
              <Link to="#" className="underline hover:text-slate-600 mx-1">Terms of Service</Link>.
            </p>
          </div>

        </div>
      </main>

      <footer className="bg-white border-t border-slate-200 py-6 px-4 md:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-500 font-medium">
          <div className="flex items-center gap-4">
             <span className="flex items-center gap-2">
               Powered by 
               <span className="font-bold text-slate-700">C-RISK Intelligence</span>
             </span>
          </div>
          <div className="flex gap-6">
            <Link to="#" className="hover:text-blue-600 transition-colors">Privacy Policy</Link>
            <Link to="#" className="hover:text-blue-600 transition-colors">Compliance Statement</Link>
            <span className="text-slate-300">|</span>
            <span className="hover:text-slate-700">Support: +91-800-CRISK-HELP</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default TenantLoginPage;
