
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import MFAVerification from '@/components/auth/MFAVerification';

const MfaVerify = () => {
  const navigate = useNavigate();
  const { user, isPlatformStaff, userRole } = useAuth();

  useEffect(() => {
    // If not logged in at all (no AAL1), go to login
    if (!user) {
        navigate('/login', { replace: true });
    }
  }, [user, navigate]);

  const handleSuccess = () => {
    // Determine destination based on user role/type
    if (isPlatformStaff) {
       navigate('/platform-console', { replace: true });
    } else if (userRole) {
       navigate('/dashboard', { replace: true });
    } else {
       navigate('/app-dashboard', { replace: true });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4">
      <MFAVerification onSuccess={handleSuccess} />
    </div>
  );
};

export default MfaVerify;
