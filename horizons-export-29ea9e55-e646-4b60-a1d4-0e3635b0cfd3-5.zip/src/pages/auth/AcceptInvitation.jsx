
import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/components/ui/use-toast';
import { invitationService } from '@/services/invitationService';
import { supabase } from '@/lib/customSupabaseClient';
import { Loader2, CheckCircle2, XCircle, ShieldCheck, ArrowRight } from 'lucide-react';

const AcceptInvitation = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token') || searchParams.get('code');
  const navigate = useNavigate();
  const { toast } = useToast();

  const [inviteData, setInviteData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Form State
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (!token) {
      setError("No invitation token provided.");
      setLoading(false);
      return;
    }
    validateToken();
  }, [token]);

  const validateToken = async () => {
    try {
      const data = await invitationService.validateToken(token);
      setInviteData(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      toast({ title: "Passwords do not match", variant: "destructive" });
      return;
    }
    if (password.length < 8) {
        toast({ title: "Password too weak", description: "Must be at least 8 characters.", variant: "destructive" });
        return;
    }

    setSubmitting(true);
    try {
      // 1. Accept Invitation (Backend creates user)
      await invitationService.acceptInvite({
        token,
        password,
        fullName
      });
      
      setSuccess(true);
      
      // 2. Auto-login attempt
      const { error: loginError } = await supabase.auth.signInWithPassword({
        email: inviteData.email,
        password: password
      });

      if (!loginError) {
        toast({ title: "Login Successful", description: "Redirecting to security setup..." });
        // 3. Redirect to MFA Setup (Critical step for security)
        setTimeout(() => {
             navigate('/mfa-setup', { state: { fromLogin: true } });
        }, 1500);
      } else {
        // Fallback if auto-login fails
        toast({ title: "Account Created", description: "Please log in to continue." });
        setTimeout(() => navigate('/login'), 2000);
      }

    } catch (err) {
      toast({ title: "Acceptance Failed", description: err.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <Card className="w-full max-w-md border-red-200 shadow-lg">
          <CardHeader className="text-center">
            <div className="mx-auto bg-red-100 p-3 rounded-full w-fit mb-4">
              <XCircle className="h-8 w-8 text-red-600" />
            </div>
            <CardTitle className="text-red-700">Invalid Invitation</CardTitle>
            <CardDescription>{error}</CardDescription>
          </CardHeader>
          <CardFooter className="justify-center">
            <Link to="/login">
              <Button variant="outline">Return to Login</Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <Card className="w-full max-w-md border-green-200 shadow-lg">
          <CardHeader className="text-center">
            <div className="mx-auto bg-green-100 p-3 rounded-full w-fit mb-4">
              <CheckCircle2 className="h-8 w-8 text-green-600" />
            </div>
            <CardTitle className="text-green-800">Welcome Aboard!</CardTitle>
            <CardDescription>
              Your account has been created successfully. Redirecting you to security setup...
            </CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
             <Loader2 className="h-5 w-5 animate-spin text-green-600" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 p-4">
      <Helmet>
        <title>Accept Invitation | C-RISK</title>
      </Helmet>
      
      <div className="mb-8 text-center">
        <div className="flex items-center justify-center gap-2 mb-2 text-blue-700">
           <ShieldCheck className="h-8 w-8" />
           <span className="text-2xl font-bold">C-RISK Platform</span>
        </div>
      </div>

      <Card className="w-full max-w-md shadow-xl border-t-4 border-t-blue-600">
        <CardHeader>
          <CardTitle>Join {inviteData?.organizations?.name}</CardTitle>
          <CardDescription>
            You have been invited to join as <strong>{inviteData?.role}</strong>. 
            Please set up your account to continue.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert className="mb-6 bg-blue-50 border-blue-100">
            <AlertTitle className="text-blue-800 text-xs font-semibold uppercase">Email Verified</AlertTitle>
            <AlertDescription className="text-blue-700 text-sm">
              We've verified <strong>{inviteData?.email}</strong> via this invitation link.
            </AlertDescription>
          </Alert>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fullname">Full Name</Label>
              <Input 
                id="fullname" 
                placeholder="Jane Doe" 
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Create Password</Label>
              <Input 
                id="password" 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm">Confirm Password</Label>
              <Input 
                id="confirm" 
                type="password" 
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>
            
            <Button type="submit" className="w-full mt-4 bg-blue-600 hover:bg-blue-700" disabled={submitting}>
              {submitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ArrowRight className="mr-2 h-4 w-4" />}
              Create Account & Join
            </Button>
          </form>
        </CardContent>
        <CardFooter className="justify-center border-t bg-slate-50 py-4">
          <p className="text-xs text-slate-500">
            By joining, you agree to our Terms of Service and Privacy Policy.
          </p>
        </CardFooter>
      </Card>
    </div>
  );
};

export default AcceptInvitation;
