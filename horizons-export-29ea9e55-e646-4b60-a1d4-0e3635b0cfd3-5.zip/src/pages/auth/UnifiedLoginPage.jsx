
// <type="write" filePath="src/pages/auth/UnifiedLoginPage.jsx">
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Button } from '@/components/ui/button';
import Logo from '@/components/Logo';
import { ArrowRight, Building2, Lock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useEffect } from 'react';

// This file is now deprecated and will be removed.
// GatewayLogin is now directly mapped to /login route.
const UnifiedLoginPage = () => {
  const navigate = useNavigate();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading && user) {
      // Redirect authenticated users based on their realm
      if (user.user_metadata?.realm === 'platform') {
        navigate('/platform-console');
      } else if (user.user_metadata?.realm === 'tenant') {
        navigate('/app-dashboard');
      }
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="flex flex-col items-center gap-4">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-blue-600 border-t-transparent" />
          <p className="text-sm text-blue-600 font-medium tracking-wider">Loading authentication...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
      <Helmet>
        <title>Login - C-RISK</title>
        <meta name="description" content="Choose your login portal: Client Access for tenants or Staff Login for platform administrators." />
      </Helmet>
      <div className="w-full max-w-4xl bg-white shadow-xl rounded-lg p-8 md:p-12 text-center space-y-8 border border-slate-200 animate-in fade-in zoom-in-95 duration-500">
        <Logo className="mb-6 justify-center" />
        <h1 className="text-4xl font-bold text-slate-900 mb-4">Welcome to C-RISK</h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Please select your access portal.
        </p>

        <div className="grid md:grid-cols-2 gap-8 pt-8">
          {/* Client Access */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 space-y-4 flex flex-col items-center text-center shadow-md hover:shadow-lg transition-shadow">
            <Building2 className="h-12 w-12 text-blue-600 mb-3" />
            <h2 className="text-2xl font-semibold text-blue-800">Client Access</h2>
            <p className="text-blue-700">For banking partners, enterprises, and tenant users.</p>
            <Button 
              onClick={() => { /* This functionality is now handled by GatewayLogin */ }} 
              variant="outline" 
              className="mt-4 bg-blue-600 hover:bg-blue-700 text-white w-full"
              disabled
            >
              Go to Tenant Login <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <p className="text-sm text-blue-500 mt-2">Will be handled by the dedicated Gateway.</p>
          </div>

          {/* Platform Access */}
          <div className="bg-slate-100 border border-slate-300 rounded-lg p-6 space-y-4 flex flex-col items-center text-center shadow-md hover:shadow-lg transition-shadow">
            <Lock className="h-12 w-12 text-slate-700 mb-3" />
            <h2 className="text-2xl font-semibold text-slate-800">Platform Admin</h2>
            <p className="text-slate-700">Restricted access for C-RISK administrators.</p>
            <Button 
              onClick={() => { /* This functionality is now handled by GatewayLogin */ }} 
              variant="outline" 
              className="mt-4 bg-slate-700 hover:bg-slate-800 text-white w-full"
              disabled
            >
              Go to Staff Login <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
             <p className="text-sm text-slate-500 mt-2">Will be handled by the dedicated Gateway.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UnifiedLoginPage;
