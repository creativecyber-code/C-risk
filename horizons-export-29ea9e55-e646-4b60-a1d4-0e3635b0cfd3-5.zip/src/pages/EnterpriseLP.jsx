
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { 
  Shield, 
  Lock, 
  ChevronRight, 
  Server, 
  FileText, 
  CheckCircle, 
  Database, 
  Building2, 
  Globe, 
  Activity,
  AlertTriangle,
  ArrowRight,
  GitBranch,
  Layers,
  Scale,
  BrainCircuit,
  FileCheck
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';

// Brand Assets
const LOGO_URL = "https://static.wixstatic.com/media/186906_ca518eeffc474be0b217c71f521c0a21~mv2.png";
const BG_PATTERN = "https://www.transparenttextures.com/patterns/cubes.png";

// Reusable Animation Wrapper
const FadeIn = ({ children, delay = 0, className, id }) => (
  <motion.div
    id={id}
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-50px" }}
    transition={{ duration: 0.7, delay, ease: "easeOut" }}
    className={className}
  >
    {children}
  </motion.div>
);

const DilemmaCard = ({ title, icon: Icon, problem, solution }) => (
  <div className="grid md:grid-cols-2 border border-slate-200 rounded-sm overflow-hidden shadow-sm hover:shadow-md transition-all group bg-white">
    {/* Current State - Problem */}
    <div className="p-8 bg-slate-50 border-b md:border-b-0 md:border-r border-slate-200 relative">
      <div className="absolute top-4 right-4 bg-red-100 text-red-600 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">
        Current State
      </div>
      <div className="flex items-start gap-4 mb-4">
        <div className="p-2 bg-slate-200 rounded text-slate-500">
          <AlertTriangle className="w-5 h-5" />
        </div>
        <h3 className="text-lg font-semibold text-slate-700">{title}</h3>
      </div>
      <p className="text-slate-600 leading-relaxed text-sm">
        {problem}
      </p>
    </div>

    {/* C-RISK State - Solution */}
    <div className="p-8 bg-white relative group-hover:bg-blue-50/10 transition-colors">
      <div className="absolute top-4 right-4 bg-blue-100 text-blue-700 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">
        C-RISK State
      </div>
      <div className="flex items-start gap-4 mb-4">
        <div className="p-2 bg-blue-600 rounded text-white shadow-lg shadow-blue-900/20">
          <Icon className="w-5 h-5" />
        </div>
        <h3 className="text-lg font-semibold text-slate-900">Automated Control</h3>
      </div>
      <p className="text-slate-700 leading-relaxed text-sm">
        {solution}
      </p>
    </div>
  </div>
);

const FeatureHighlight = ({ title, description, items, imageRight = false }) => (
  <div className={cn("flex flex-col lg:flex-row items-center gap-12 lg:gap-20 py-16", imageRight && "lg:flex-row-reverse")}>
    <div className="flex-1 space-y-6">
      <div className="inline-flex items-center px-3 py-1 rounded bg-blue-50 text-blue-700 text-xs font-bold uppercase tracking-widest border border-blue-100">
        Capability
      </div>
      <h3 className="text-3xl font-semibold text-slate-900 leading-tight">
        {title}
      </h3>
      <p className="text-lg text-slate-600 leading-relaxed">
        {description}
      </p>
      <ul className="space-y-4 pt-4">
        {items.map((item, i) => (
          <li key={i} className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <span className="text-slate-700">{item}</span>
          </li>
        ))}
      </ul>
    </div>
    <div className="flex-1 w-full bg-slate-100 rounded-sm border border-slate-200 aspect-video flex items-center justify-center relative overflow-hidden shadow-inner group">
       <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
       <div className="relative z-10 p-8 w-full max-w-sm">
          {/* Abstract UI representation */}
          <div className="bg-white rounded-md shadow-xl border border-slate-200 overflow-hidden transform group-hover:-translate-y-1 transition-transform duration-500">
             <div className="h-8 bg-slate-50 border-b border-slate-100 flex items-center px-3 gap-2">
                <div className="w-2 h-2 rounded-full bg-slate-300"></div>
                <div className="w-2 h-2 rounded-full bg-slate-300"></div>
             </div>
             <div className="p-6 space-y-3">
                <div className="h-2 w-1/3 bg-slate-200 rounded"></div>
                <div className="h-2 w-3/4 bg-slate-100 rounded"></div>
                <div className="h-20 w-full bg-blue-50/50 rounded border border-blue-100 mt-4 flex items-center justify-center">
                   <Activity className="text-blue-200 w-8 h-8" />
                </div>
             </div>
          </div>
       </div>
    </div>
  </div>
);

const ModuleCard = ({ number, title, description, features, icon: Icon }) => (
  <Card className="border-slate-200 shadow-sm hover:shadow-lg transition-all duration-300 group overflow-hidden">
    <div className="h-2 w-full bg-slate-900 group-hover:bg-blue-600 transition-colors"></div>
    <CardContent className="p-8">
      <div className="flex justify-between items-start mb-6">
        <div className="p-3 bg-slate-50 rounded-sm text-slate-900 group-hover:bg-blue-50 group-hover:text-blue-700 transition-colors">
          <Icon className="w-8 h-8" />
        </div>
        <span className="text-4xl font-light text-slate-200 group-hover:text-slate-300 transition-colors">
          {number}
        </span>
      </div>
      <h3 className="text-xl font-bold text-slate-900 mb-3">{title}</h3>
      <p className="text-slate-600 mb-8 leading-relaxed h-20">
        {description}
      </p>
      <div className="space-y-3 pt-6 border-t border-slate-100">
        {features.map((feat, idx) => (
          <div key={idx} className="flex items-center gap-2 text-sm text-slate-700">
            <div className="w-1.5 h-1.5 bg-blue-600 rounded-full"></div>
            {feat}
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

const EnterpriseLP = () => {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    organization: '',
    designation: ''
  });

  const scrollToContact = () => {
    document.getElementById('enquiry-form')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleEnquiry = (e) => {
    e.preventDefault();
    if (!formState.email.includes('@') || !formState.name) {
      toast({
        variant: "destructive",
        title: "Invalid Details",
        description: "Please provide valid business contact information."
      });
      return;
    }
    toast({
      title: "Request Received",
      description: "Our compliance team will review your credentials and contact you shortly.",
      className: "bg-slate-900 text-white border-slate-800"
    });
    setFormState({ name: '', email: '', organization: '', designation: '' });
  };

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900 selection:bg-blue-100 selection:text-blue-900">
      <Helmet>
        <title>C-RISK | Risk Intelligence for Regulated Banking</title>
        <meta name="description" content="The definitive risk intelligence platform for RBI, SEBI, and DPDP compliance. Invitation-only access for regulated entities." />
      </Helmet>

      {/* --- Navigation --- */}
      <nav className="fixed w-full z-50 bg-white/95 backdrop-blur-md border-b border-slate-100 transition-all duration-300">
        <div className="container mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
             <Link to="/" className="flex items-center gap-3 group">
                <div className="h-10 w-auto overflow-hidden">
                   <img src={LOGO_URL} alt="CreativeCyber" className="h-full object-contain" />
                </div>
                <div className="h-6 w-px bg-slate-300 mx-1"></div>
                <span className="font-semibold text-lg tracking-tight text-slate-900 group-hover:text-blue-700 transition-colors">
                  C-RISK
                </span>
             </Link>
          </div>
          
          <div className="flex items-center gap-8">
            <div className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
              <button onClick={() => document.getElementById('capabilities').scrollIntoView({ behavior: 'smooth' })} className="hover:text-slate-900 transition-colors">Capabilities</button>
              <button onClick={() => document.getElementById('modules').scrollIntoView({ behavior: 'smooth' })} className="hover:text-slate-900 transition-colors">Modules</button>
              <Link to="/login" className="hover:text-slate-900 transition-colors">Client Portal</Link>
            </div>
            <Button onClick={scrollToContact} className="bg-slate-900 text-white hover:bg-blue-700 hover:shadow-lg transition-all rounded-sm px-6 py-5 font-medium tracking-wide">
              Request Invitation
            </Button>
          </div>
        </div>
      </nav>

      <main className="pt-20">
        
        {/* --- 1. Hero Section --- */}
        <section className="relative py-32 lg:py-48 overflow-hidden bg-slate-50">
          <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: `url(${BG_PATTERN})` }}></div>
          <div className="container mx-auto px-6 relative z-10">
            <FadeIn className="max-w-4xl mx-auto text-center">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-slate-200 shadow-sm mb-8">
                <Shield className="w-4 h-4 text-blue-600" />
                <span className="text-xs font-bold tracking-widest text-slate-600 uppercase">Bank-Grade Assurance</span>
              </div>
              
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-slate-900 mb-8 leading-[1.1]">
                The Risk Intelligence Standard <br />
                <span className="text-slate-400">for Regulated Banking</span>
              </h1>
              
              <p className="text-xl text-slate-600 mb-12 max-w-2xl mx-auto leading-relaxed font-light">
                Engineered exclusively for entities governed by <span className="font-medium text-slate-900">RBI Master Directions</span>, <span className="font-medium text-slate-900">SEBI</span>, and the <span className="font-medium text-slate-900">DPDP Act 2023</span>. Automate governance with precision.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button onClick={scrollToContact} className="h-14 px-8 text-lg bg-blue-700 hover:bg-blue-800 text-white rounded-sm shadow-xl shadow-blue-900/10 min-w-[200px]">
                  Request Invitation
                </Button>
                <div className="flex items-center gap-2 text-sm text-slate-500 px-6 py-4 bg-white/50 rounded-sm border border-slate-200/50 backdrop-blur-sm">
                   <Lock className="w-4 h-4" /> Invitation Only Access
                </div>
              </div>
            </FadeIn>
          </div>
        </section>

        {/* --- 2. The BFSI CISO's Dilemma --- */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-6">
            <FadeIn className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold text-slate-900 mb-4">The BFSI CISO's Dilemma</h2>
              <p className="text-lg text-slate-600">
                In an era of rapid digital transformation, maintaining regulatory alignment is no longer a human-scale problem.
              </p>
            </FadeIn>

            <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
              <FadeIn delay={0.1}>
                <DilemmaCard 
                  title="Shadow IT & Drift"
                  icon={GitBranch}
                  problem="Business units launch applications faster than security can govern. Risk assessments become outdated the moment code is deployed, creating invisible exposure."
                  solution="Continuous monitoring of asset inventory with real-time drift detection. Security posture is recalculated automatically with every deployment."
                />
              </FadeIn>
              
              <FadeIn delay={0.2}>
                <DilemmaCard 
                  title="Compliance Lag"
                  icon={Scale}
                  problem="New circulars from RBI/SEBI take months to translate into technical controls. By the time policies are updated, the regulatory landscape has shifted again."
                  solution="Live regulatory mapping engine. New mandates are instantly parsed into actionable technical controls and pushed to relevant asset owners."
                />
              </FadeIn>
            </div>
          </div>
        </section>

        {/* --- 3. Smart-Intake Capability --- */}
        <section id="capabilities" className="py-24 bg-slate-50 border-y border-slate-200">
          <div className="container mx-auto px-6">
            <div className="text-center mb-12">
               <h2 className="text-3xl font-bold text-slate-900">Intelligent Governance Core</h2>
               <p className="text-slate-500 mt-2">Built-in intelligence that understands banking context.</p>
            </div>

            <FadeIn>
              <FeatureHighlight 
                title="Smart-Intake & Classification"
                description="Move beyond static spreadsheets. Our intake engine intelligently maps business context to regulatory obligations in real-time, classifying data sensitivity before a single line of code is written."
                items={[
                  "Auto-detection of SPII, Financial Data, and KYC artifacts.",
                  "Instant DPDP applicability scoring based on data residency inputs.",
                  "Context-aware criticality assessment for RTO/RPO definition."
                ]}
              />
            </FadeIn>
          </div>
        </section>

        {/* --- 4. The Modules --- */}
        <section id="modules" className="py-32 bg-white">
          <div className="container mx-auto px-6">
            <FadeIn className="max-w-3xl mx-auto text-center mb-20">
              <h2 className="text-3xl font-bold text-slate-900 mb-6">Modular Precision</h2>
              <p className="text-lg text-slate-600">
                Deploy distinct capabilities tailored to your organization's maturity. Start with initiation, scale to full architectural governance.
              </p>
            </FadeIn>

            <div className="grid md:grid-cols-2 gap-10 max-w-5xl mx-auto">
              <FadeIn delay={0.1}>
                <ModuleCard 
                  number="01"
                  icon={FileCheck}
                  title="Business Initiation & Gating"
                  description="Formalize the 'Idea-to-Project' phase. Enforce mandatory security gatechecks before resources are allocated."
                  features={[
                    " Standardized Risk Scoring (High/Med/Low)",
                    " Automated Stakeholder Approvals",
                    " Budgetary Compliance Pre-checks"
                  ]}
                />
              </FadeIn>

              <FadeIn delay={0.2}>
                <ModuleCard 
                  number="02"
                  icon={BrainCircuit}
                  title="Architecture & Design"
                  description="AI-Assisted STRIDE analysis that generates threat models directly from your high-level design documents."
                  features={[
                    " Automated Threat Modeling",
                    " Control Library Integration (NIST/ISO)",
                    " Secure Design Pattern Recommendations"
                  ]}
                />
              </FadeIn>
            </div>
          </div>
        </section>

        {/* --- 5. Enquiry Form --- */}
        <section id="enquiry-form" className="py-32 bg-slate-900 text-white relative">
           <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-10"></div>
           <div className="container mx-auto px-6 relative z-10">
             <div className="grid lg:grid-cols-2 gap-16 items-center max-w-6xl mx-auto">
               
               <FadeIn className="space-y-8">
                 <h2 className="text-4xl font-bold leading-tight">
                   Secure Your Invitation to <br />
                   <span className="text-blue-400">The Future of Risk</span>
                 </h2>
                 <p className="text-slate-400 text-lg leading-relaxed">
                   C-RISK is currently available specifically for financial institutions and regulated entities. We manually vet every request to ensure network integrity.
                 </p>
                 <div className="space-y-4">
                    <div className="flex items-center gap-4 text-slate-300">
                       <Building2 className="w-6 h-6 text-blue-500" />
                       <span>Enterprise-Only SaaS Platform</span>
                    </div>
                    <div className="flex items-center gap-4 text-slate-300">
                       <Globe className="w-6 h-6 text-blue-500" />
                       <span>Data Residency: Mumbai, India (AWS ap-south-1)</span>
                    </div>
                    <div className="flex items-center gap-4 text-slate-300">
                       <Shield className="w-6 h-6 text-blue-500" />
                       <span>SOC2 Type II & ISO 27001 Certified</span>
                    </div>
                 </div>
               </FadeIn>

               <FadeIn delay={0.2}>
                 <form onSubmit={handleEnquiry} className="bg-white rounded-sm p-8 md:p-10 shadow-2xl text-slate-900">
                    <h3 className="text-2xl font-bold mb-6 text-slate-900">Request Access</h3>
                    
                    <div className="space-y-5">
                       <div className="space-y-2">
                          <Label htmlFor="name" className="text-slate-700 font-semibold">Full Name</Label>
                          <Input 
                            id="name" 
                            placeholder="e.g. Aditi Sharma" 
                            className="h-12 bg-slate-50 border-slate-200 focus:border-blue-500"
                            value={formState.name}
                            onChange={(e) => setFormState({...formState, name: e.target.value})}
                          />
                       </div>

                       <div className="space-y-2">
                          <Label htmlFor="email" className="text-slate-700 font-semibold">Corporate Email</Label>
                          <Input 
                            id="email" 
                            type="email" 
                            placeholder="name@bank.com" 
                            className="h-12 bg-slate-50 border-slate-200 focus:border-blue-500"
                            value={formState.email}
                            onChange={(e) => setFormState({...formState, email: e.target.value})}
                          />
                          <p className="text-xs text-slate-500">Public email domains (gmail, yahoo) are automatically rejected.</p>
                       </div>

                       <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                             <Label htmlFor="org" className="text-slate-700 font-semibold">Organization</Label>
                             <Input 
                                id="org" 
                                placeholder="Bank / Entity Name" 
                                className="h-12 bg-slate-50 border-slate-200 focus:border-blue-500"
                                value={formState.organization}
                                onChange={(e) => setFormState({...formState, organization: e.target.value})}
                              />
                          </div>
                          <div className="space-y-2">
                             <Label htmlFor="role" className="text-slate-700 font-semibold">Designation</Label>
                             <Input 
                                id="role" 
                                placeholder="e.g. CISO, CRO" 
                                className="h-12 bg-slate-50 border-slate-200 focus:border-blue-500"
                                value={formState.designation}
                                onChange={(e) => setFormState({...formState, designation: e.target.value})}
                              />
                          </div>
                       </div>
                       
                       <Button type="submit" className="w-full h-14 mt-4 text-lg font-bold bg-slate-900 hover:bg-blue-800 text-white rounded-sm transition-colors">
                          Submit Request <ArrowRight className="ml-2 w-5 h-5" />
                       </Button>
                    </div>
                 </form>
               </FadeIn>
             </div>
           </div>
        </section>

      </main>

      {/* --- Footer --- */}
      <footer className="bg-slate-50 border-t border-slate-200 py-12 text-sm text-slate-500">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-3">
             <div className="h-6 w-auto overflow-hidden grayscale opacity-50">
                <img src={LOGO_URL} alt="CreativeCyber" className="h-full object-contain" />
             </div>
             <span>© {new Date().getFullYear()} CreativeCyber. All rights reserved.</span>
          </div>
          
          <div className="flex gap-8">
            <a href="#" className="hover:text-slate-900 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-slate-900 transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-slate-900 transition-colors">Security</a>
            <a href="#" className="hover:text-slate-900 transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default EnterpriseLP;
