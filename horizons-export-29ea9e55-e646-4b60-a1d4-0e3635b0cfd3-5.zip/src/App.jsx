import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { AuthProvider } from '@/contexts/AuthContext';
import AppErrorBoundary from '@/components/AppErrorBoundary';
import { Toaster } from '@/components/ui/toaster';
import ConnectionStatus from '@/components/ui/ConnectionStatus';
import { MobilePreviewSimulator } from '@/components/ui/MobilePreviewSimulator';

// Layout & Core
import ProtectedRoute from '@/components/ProtectedRoute';
import PlatformRoute from '@/components/PlatformRoute';

// Lazy Load Pages
const PlatformConsole = lazy(() => import('@/pages/platform/PlatformConsole'));
const AppDashboard = lazy(() => import('@/pages/tenant/AppDashboard'));
const EnterpriseLP = lazy(() => import('@/pages/EnterpriseLP'));
const Diagnostics = lazy(() => import('@/pages/Diagnostics'));
const GatewayLogin = lazy(() => import('@/pages/auth/GatewayLogin'));
const AcceptInvitation = lazy(() => import('@/pages/auth/AcceptInvitation'));
const AcceptTenantInvite = lazy(() => import('@/pages/auth/AcceptTenantInvite'));
const AcceptTenantUserInvite = lazy(() => import('@/pages/auth/AcceptTenantUserInvite'));
const Signup = lazy(() => import('@/pages/auth/Signup'));

// CyberWorkbench & Dashboard Pages
const CyberWorkbench = lazy(() => import('@/pages/tenant/CyberWorkbench'));
const CyberOverviewPage = lazy(() => import('@/pages/dashboard/CyberOverviewPage'));

// Detailed Pages
const BusinessInitiationPage = lazy(() => import('@/pages/dashboard/BusinessInitiationPage'));
const BusinessInitiationDetail = lazy(() => import('@/pages/dashboard/BusinessInitiationDetail'));

const ArchitectureReview = lazy(() => import('@/pages/dashboard/ArchitectureReview'));
const ArchitectureReviewDetail = lazy(() => import('@/pages/tenant/ArchitectureReviewDetail')); 
const AuditWorkspace = lazy(() => import('@/pages/tenant/AuditWorkspacePage'));
const ControlDetailPage = lazy(() => import('@/pages/tenant/ControlDetailPage'));
const TenantSettingsPage = lazy(() => import('@/pages/tenant/TenantSettingsPage'));

// MFA Pages
const MfaSetup = lazy(() => import('@/pages/auth/MfaSetup'));
const MfaVerify = lazy(() => import('@/pages/auth/MfaVerify'));

// Profile & Team
const ProfilePage = lazy(() => import('@/pages/dashboard/ProfilePage'));
const TeamManagement = lazy(() => import('@/pages/tenant/TeamManagement'));

// Fallback Loader
const PageLoader = () => (
  <div className="flex items-center justify-center h-screen w-full bg-slate-50">
    <div className="flex flex-col items-center gap-4">
      <div className="h-12 w-12 animate-spin rounded-full border-4 border-blue-600 border-t-transparent" />
      <p className="text-sm text-blue-600 font-medium tracking-wider">LOADING SECURE CONTEXT...</p>
    </div>
  </div>
);

function App() {
  return (
    <HelmetProvider>
      <AppErrorBoundary>
        <AuthProvider>
          <BrowserRouter>
            <Suspense fallback={<PageLoader />}>
              <Routes>
                
                {/* --- Public Routes --- */}
                <Route path="/" element={<EnterpriseLP />} />
                <Route path="/login" element={<GatewayLogin />} /> 
                <Route path="/signup" element={<Signup />} />
                <Route path="/diagnostics" element={<Diagnostics />} />
                <Route path="/accept-invitation" element={<AcceptInvitation />} />
                <Route path="/invite" element={<AcceptInvitation />} />
                <Route path="/tenant-invite" element={<AcceptTenantInvite />} />
                <Route path="/tenant-user-invite" element={<AcceptTenantUserInvite />} />

                {/* --- MFA Routes (Protected) --- */}
                <Route 
                  path="/mfa-setup" 
                  element={
                    <ProtectedRoute>
                      <MfaSetup />
                    </ProtectedRoute>
                  } 
                />
                
                {/* --- MFA Verification (Public/Auth Guarded) --- */}
                <Route path="/mfa-verify" element={<MfaVerify />} />

                {/* --- Platform Admin Routes --- */}
                <Route 
                  path="/platform-console/*" 
                  element={
                    <PlatformRoute>
                      <PlatformConsole />
                    </PlatformRoute>
                  } 
                />

                {/* --- CyberWorkbench (Tenant Main Dashboard) --- */}
                <Route 
                  path="/dashboard" 
                  element={
                    <ProtectedRoute allowedRole="tenant">
                      <CyberWorkbench />
                    </ProtectedRoute>
                  }
                >
                    <Route index element={<Navigate to="overview" replace />} />
                    <Route path="overview" element={<CyberOverviewPage />} />
                    
                    {/* Business Initiation Routes */}
                    <Route path="initiation" element={<BusinessInitiationPage />} />
                    <Route path="initiation/:id" element={<BusinessInitiationDetail />} />

                    {/* Architecture Review Routes */}
                    <Route path="architecture-review" element={<ArchitectureReview />} />
                    <Route path="architecture-review/:id" element={<ArchitectureReviewDetail />} />

                    {/* Audit & Control Routes */}
                    <Route path="audit-workspace" element={<AuditWorkspace />} />
                    <Route path="control/:id" element={<ControlDetailPage />} />
                    
                    {/* Settings Routes */}
                    <Route path="tenant-settings" element={<TenantSettingsPage />} />
                </Route>

                {/* --- Legacy Tenant User Routes --- */}
                <Route 
                  path="/app-dashboard" 
                  element={
                    <ProtectedRoute allowedRole="tenant">
                      <AppDashboard />
                    </ProtectedRoute>
                  } 
                />
                <Route 
                  path="/app-dashboard/overview" 
                  element={
                    <ProtectedRoute allowedRole="tenant">
                      <AppDashboard />
                    </ProtectedRoute>
                  } 
                />

                {/* Profile & Team (Shared/Accessible) */}
                 <Route 
                  path="/app-dashboard/profile" 
                  element={
                    <ProtectedRoute allowedRole="tenant">
                      <ProfilePage />
                    </ProtectedRoute>
                  } 
                />
                <Route 
                  path="/app-dashboard/team" 
                  element={
                    <ProtectedRoute allowedRole="tenant">
                      <TeamManagement />
                    </ProtectedRoute>
                  } 
                />
                
                {/* --- Redirects & Catch-alls --- */}
                <Route path="*" element={<Navigate to="/login" replace />} />

              </Routes>
            </Suspense>
            
            <ConnectionStatus />
            <MobilePreviewSimulator />
            <Toaster />
          </BrowserRouter>
        </AuthProvider>
      </AppErrorBoundary>
    </HelmetProvider>
  );
}

export default App;