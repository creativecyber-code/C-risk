
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App';
import '@/index.css';
import { registerSW } from './pwaRegistration';

// Register Service Worker for PWA
try {
  registerSW();
} catch (e) {
  console.error('Service Worker registration failed:', e);
}

const rootElement = document.getElementById('root');

if (rootElement) {
  ReactDOM.createRoot(rootElement).render(
    <App />
  );
}
