
import { supabase } from '@/lib/customSupabaseClient';

export const complianceService = {
  async getOrgId() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;
    
    // Use maybeSingle to avoid PGRST116 if profile is not yet created
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('org_id')
      .eq('id', user.id)
      .maybeSingle();
      
    return profile?.org_id;
  },

  // --- Internal Controls ---
  async getInternalControls(orgId) {
    if (!orgId) return [];
    
    const { data, error } = await supabase
      .from('internal_controls')
      .select(`
        *,
        owner:user_profiles!owner_id(full_name, email),
        mappings:internal_control_mappings(*),
        risks:internal_control_risks(
            id, 
            threat_assessment:threat_assessments(id, title, risk_score)
        )
      `)
      .eq('org_id', orgId)
      .order('code', { ascending: true });

    if (error) throw error;
    return data;
  },

  async createInternalControl(controlData) {
    const { data, error } = await supabase
      .from('internal_controls')
      .insert(controlData)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async updateInternalControl(id, updates) {
    const { data, error } = await supabase
      .from('internal_controls')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteInternalControl(id) {
    const { error } = await supabase
      .from('internal_controls')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  // --- Mappings ---
  async addFrameworkMapping(controlId, framework, frameworkControlId) {
    const { error } = await supabase
      .from('internal_control_mappings')
      .insert({
        internal_control_id: controlId,
        framework,
        framework_control_id: frameworkControlId
      });
    
    if (error) throw error;
  },

  async removeFrameworkMapping(mappingId) {
    const { error } = await supabase
      .from('internal_control_mappings')
      .delete()
      .eq('id', mappingId);
    
    if (error) throw error;
  },

  // --- Risks ---
  async getAvailableRisks(orgId) {
    if (!orgId) return [];
    
    const { data, error } = await supabase
      .from('threat_assessments')
      .select('id, title, risk_score, status')
      .neq('status', 'Closed'); 
      
    if (error) throw error;
    return data;
  },

  async linkRisk(controlId, assessmentId) {
    const { error } = await supabase
      .from('internal_control_risks')
      .insert({
        internal_control_id: controlId,
        threat_assessment_id: assessmentId
      });
    
    if (error) throw error;
  },

  async unlinkRisk(linkId) {
    const { error } = await supabase
      .from('internal_control_risks')
      .delete()
      .eq('id', linkId);
    
    if (error) throw error;
  },

  // --- Audits & Testing ---
  async getControlHistory(controlId) {
    const { data, error } = await supabase
      .from('control_audits')
      .select(`
        *,
        auditor:user_profiles!auditor_id(full_name)
      `)
      .eq('internal_control_id', controlId)
      .order('audit_date', { ascending: false });

    if (error) throw error;
    return data;
  },

  async logControlAudit(auditData) {
    const { data: { user } } = await supabase.auth.getUser();
    
    const { error: auditError } = await supabase
      .from('control_audits')
      .insert({
        ...auditData,
        auditor_id: user.id
      });
    
    if (auditError) throw auditError;

    let newStatus = 'Effective';
    if (auditData.result === 'Fail') newStatus = 'Ineffective';
    if (auditData.result === 'Partial') newStatus = 'Partially Effective';

    await this.updateInternalControl(auditData.internal_control_id, {
        status: newStatus,
        last_tested_at: auditData.audit_date
    });
  },

  // --- Evidence ---
  async getEvidence(controlId) {
    const { data, error } = await supabase
      .from('compliance_evidence')
      .select(`
        *,
        uploader:user_profiles!created_by(full_name)
      `)
      .eq('control_id', controlId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  async uploadEvidence(file, metadata) {
    const { data: { user } } = await supabase.auth.getUser();
    const orgId = await this.getOrgId();

    const fileExt = file.name.split('.').pop();
    const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
    const filePath = `${orgId}/${metadata.control_id}/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('evidence') 
      .upload(filePath, file);

    if (uploadError) {
        console.error("Upload failed", uploadError);
        throw new Error("Failed to upload file to storage");
    }

    const { data: { publicUrl } } = supabase.storage
      .from('evidence')
      .getPublicUrl(filePath);

    const { error: dbError } = await supabase
      .from('compliance_evidence')
      .insert({
        org_id: orgId,
        control_id: metadata.control_id,
        framework: 'INTERNAL',
        title: metadata.title,
        description: metadata.description,
        type: metadata.type,
        evidence_url: publicUrl,
        created_by: user.id
      });

    if (dbError) throw dbError;
  },
  
  async deleteEvidence(id) {
      const { error } = await supabase
          .from('compliance_evidence')
          .delete()
          .eq('id', id);
      if (error) throw error;
  },

  async getUsers(orgId) {
      if (!orgId) return [];
      const { data, error } = await supabase
          .from('user_profiles')
          .select('id, full_name, email')
          .eq('org_id', orgId);
      
      if (error) throw error;
      return data;
  }
};
