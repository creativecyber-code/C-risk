
import { supabase } from '@/lib/customSupabaseClient';

export const testMonitoringService = {
  // 1. Fetch History
  async getTestHistory(orgId) {
    const { data, error } = await supabase
      .from('test_runs')
      .select('*')
      .eq('org_id', orgId)
      .order('started_at', { ascending: false })
      .limit(50);

    if (error) throw error;
    return data;
  },

  // 2. Get Single Run Details
  async getTestRunDetails(runId) {
    const { data: run, error: runError } = await supabase
      .from('test_runs')
      .select('*')
      .eq('id', runId)
      .single();
    
    if (runError) throw runError;

    const { data: suites, error: suiteError } = await supabase
      .from('test_suite_results')
      .select(`
        *,
        cases:test_case_results(*)
      `)
      .eq('run_id', runId);

    if (suiteError) throw suiteError;

    return { ...run, suites };
  },

  // 3. Simulate Test Execution (Frontend Demo)
  // Since we can't run Node.js tests in browser, this simulates the database entries
  // that a real CI runner would produce.
  async startSimulation(orgId, userId) {
    // Create Run
    const { data: run, error } = await supabase
      .from('test_runs')
      .insert({
        org_id: orgId,
        status: 'running',
        triggered_by: userId,
        environment: 'staging',
        total_tests: 0,
        ci_pipeline_id: `CI-${Math.floor(Math.random() * 10000)}`
      })
      .select()
      .single();

    if (error) throw error;

    // Start async simulation (fire and forget for UI, but in reality we'd await in a worker)
    this.runSimulationLoop(run.id, orgId);
    
    return run.id;
  },

  async runSimulationLoop(runId, orgId) {
    const suites = [
      { name: 'AuthService Tests', count: 5, failProb: 0.1 },
      { name: 'BusinessInitiation Workflow', count: 8, failProb: 0.2 },
      { name: 'RLS Security Policies', count: 12, failProb: 0.05 },
      { name: 'Risk Calculation Engine', count: 6, failProb: 0.15 },
      { name: 'UI Component Library', count: 10, failProb: 0.0 }
    ];

    let totalPassed = 0;
    let totalFailed = 0;
    let totalSkipped = 0;

    for (const suite of suites) {
      // Simulate Suite Delay
      await new Promise(r => setTimeout(r, 800));

      // Create Suite
      const { data: suiteData } = await supabase
        .from('test_suite_results')
        .insert({
          run_id: runId,
          suite_name: suite.name,
          status: 'running'
        })
        .select()
        .single();

      // Run Cases
      let suiteDuration = 0;
      let suiteStatus = 'passed';

      for (let i = 0; i < suite.count; i++) {
        await new Promise(r => setTimeout(r, 200)); // Case delay
        const duration = Math.floor(Math.random() * 150) + 20;
        suiteDuration += duration;

        const isFail = Math.random() < suite.failProb;
        const status = isFail ? 'failed' : 'passed';
        
        if (isFail) {
          suiteStatus = 'failed';
          totalFailed++;
        } else {
          totalPassed++;
        }

        await supabase.from('test_case_results').insert({
          suite_result_id: suiteData.id,
          test_name: `${suite.name} - Case ${i + 1}: Verify behavior`,
          status,
          duration_ms: duration,
          error_message: isFail ? 'AssertionError: expected true to be false' : null,
          stack_trace: isFail ? 'Error: Failed at step 3\n  at checkCondition (test.js:45)\n  at runTest (testRunner.js:12)' : null
        });

        // Update Run Totals Realtime
        await supabase.from('test_runs').update({
          total_tests: totalPassed + totalFailed + totalSkipped,
          passed_tests: totalPassed,
          failed_tests: totalFailed
        }).eq('id', runId);
      }

      // Complete Suite
      await supabase.from('test_suite_results').update({
        status: suiteStatus,
        duration_ms: suiteDuration
      }).eq('id', suiteData.id);
    }

    // Complete Run
    const coverage = {
      statements: 85 + Math.floor(Math.random() * 10),
      branches: 70 + Math.floor(Math.random() * 15),
      functions: 90 + Math.floor(Math.random() * 5),
      lines: 88 + Math.floor(Math.random() * 8)
    };

    await supabase.from('test_runs').update({
      status: totalFailed > 0 ? 'failed' : 'passed',
      completed_at: new Date().toISOString(),
      coverage_summary: coverage,
      duration_ms: (Date.now() - new Date(Date.now() - 5000).getTime()) // rough estimate
    }).eq('id', runId);
  }
};
