
import { supabase } from '@/lib/customSupabaseClient';
import { emailService } from '@/services/emailService';

export const invitationService = {
  /**
   * Generates an invite link and record.
   * @param {Object} params
   * @param {string} params.email
   * @param {string} params.role
   * @param {string} params.tenantId
   * @param {string} [params.linkPath] - Optional custom path for the invite link
   */
  async createInvite({ email, role, tenantId, linkPath }) {
    // Invoke Edge Function to generate token and record
    const { data, error } = await supabase.functions.invoke('invite-user', {
      body: { email, role, tenantId, linkPath }
    });

    if (error) {
      console.error('Create Invite Error:', error);
      throw new Error("Failed to create invitation. Please try again.");
    }
    
    if (!data.success) {
      throw new Error(data.error || "Failed to generate invite.");
    }

    return data; // contains { inviteLink, token, ... }
  },

  /**
   * Validates the token on the acceptance page.
   */
  async validateToken(token) {
    if (!token) throw new Error("Missing invitation token.");

    const { data, error } = await supabase
      .from('tenant_invitations')
      .select('*, organizations(name)')
      .eq('token', token)
      .maybeSingle();

    if (error) throw error;
    if (!data) throw new Error("Invalid invitation code.");
    
    if (data.status !== 'pending') {
      throw new Error(`This invitation has already been ${data.status}.`);
    }

    if (new Date(data.expires_at) < new Date()) {
      throw new Error("This invitation has expired.");
    }

    return data;
  },

  /**
   * Completes the invitation process: creates user, links to tenant.
   * Used for new users signing up via invite link.
   */
  async acceptInvite({ token, password, fullName }) {
    const { data, error } = await supabase.functions.invoke('accept-invite', {
      body: { token, password, fullName }
    });

    if (error) throw new Error("Network error connecting to acceptance service.");
    if (!data.success) throw new Error(data.error);

    return data;
  },

  /**
   * Gets all invitations for a tenant (for management UI).
   */
  async getTenantInvites(tenantId) {
    const { data, error } = await supabase
      .from('tenant_invitations')
      .select('*')
      .eq('tenant_id', tenantId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  /**
   * Gets active members for a tenant.
   */
  async getTenantMembers(tenantId) {
    const { data, error } = await supabase
        .from('tenant_members')
        .select('*')
        .eq('tenant_id', tenantId);
        
    if (error) throw error;
    return data;
  },

  /**
   * Revokes an invite.
   */
  async revokeInvite(inviteId) {
      const { error } = await supabase
        .from('tenant_invitations')
        .update({ status: 'revoked' })
        .eq('id', inviteId);
        
      if (error) throw error;
      return true;
  },

  /**
   * Resends an invite (invalidates old, creates new).
   */
  async resendInvite(oldInviteId) {
    // 1. Get old invite details
    const { data: oldInvite, error: fetchError } = await supabase
      .from('tenant_invitations')
      .select('*, organizations(name)')
      .eq('id', oldInviteId)
      .single();
      
    if (fetchError || !oldInvite) throw new Error("Invite not found");

    // 2. Mark old as revoked
    await supabase.from('tenant_invitations').update({ status: 'revoked' }).eq('id', oldInviteId);

    // 3. Create new invite using existing service
    // We reuse createInvite logic which handles token generation and email sending via Edge Function
    // If you don't use Edge Function for this part, we can call emailService directly, but consistency is key.
    
    // For now, let's trigger the createInvite flow again.
    const result = await this.createInvite({
      email: oldInvite.email,
      role: oldInvite.role,
      tenantId: oldInvite.tenant_id,
      linkPath: oldInvite.role === 'admin' || oldInvite.role === 'tenant_admin' ? '/tenant-invite' : '/invite'
    });

    return result;
  },

  /**
   * Gets pending invites for the currently logged-in user.
   * Uses RPC get_my_pending_invites.
   */
  async getMyPendingInvites() {
    const { data, error } = await supabase.rpc('get_my_pending_invites');
    if (error) throw error;
    return data || [];
  },

  /**
   * Accepts an invite for the currently logged-in user.
   * Uses RPC accept_my_invite.
   */
  async acceptInviteForUser(inviteId) {
    const { data, error } = await supabase.rpc('accept_my_invite', { p_invite_id: inviteId });
    
    if (error) throw error;
    if (!data.success) throw new Error(data.error || 'Failed to accept invitation');
    
    return data;
  }
};
