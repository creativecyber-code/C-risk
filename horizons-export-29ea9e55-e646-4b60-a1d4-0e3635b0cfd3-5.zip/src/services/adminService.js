
import { supabase } from '@/lib/customSupabaseClient';

/**
 * Service for Platform Administration tasks.
 * Uses RPC calls to manage platform staff securely.
 */
export const adminService = {
  
  /**
   * Fetches all platform staff members with detailed auth info.
   */
  async getPlatformStaff() {
    const { data, error } = await supabase.rpc('get_platform_staff_details');
    if (error) {
      console.error('[adminService] Error fetching staff:', error);
      throw error;
    }
    return data;
  },

  /**
   * Creates a new platform user.
   */
  async createPlatformUser(userData) {
    const { data, error } = await supabase.rpc('manage_platform_user', {
      operation: 'create',
      payload: {
        email: userData.email,
        role: userData.role,
        fullName: userData.fullName
      }
    });

    if (error) throw new Error(error.message);
    if (!data.success) throw new Error(data.error || 'Failed to create user');
    return data;
  },

  /**
   * Deletes a platform user (revokes access) using the new specific RPC if available, 
   * or falls back to generic manage_platform_user.
   */
  async deletePlatformUser(staffId) {
    // We prefer the specific RPC if it matches requirements
    const { data, error } = await supabase.rpc('delete_staff_member', { p_staff_id: staffId });
    
    if (error) throw error;
    if (!data.success) throw new Error(data.error || 'Failed to delete user');
    return data;
  },

  /**
   * Changes a user's role
   */
  async changeUserRole(staffId, newRole) {
    const { data, error } = await supabase.rpc('change_staff_role', { 
        p_staff_id: staffId, 
        p_new_role: newRole 
    });

    if (error) throw error;
    if (!data.success) throw new Error(data.error || 'Failed to change role');
    return data;
  },

  /**
   * Forces a password reset flag
   */
  async forcePasswordReset(userId) {
     const { data, error } = await supabase.rpc('force_password_reset', { p_user_id: userId });
     if (error) throw error;
     if (!data.success) throw new Error(data.error || 'Failed to flag for reset');
     return data;
  },

  /**
   * Gets compliance details for a user
   */
  async getComplianceStatus(userId) {
    const { data, error } = await supabase.rpc('get_compliance_status', { p_user_id: userId });
    if (error) throw error;
    if (!data.success) throw new Error(data.error || 'Failed to get status');
    return data;
  },

  /**
   * Fetches all organizations/tenants.
   */
  async getAllOrganizations() {
    const { data, error } = await supabase
      .from('organizations')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  }
};
