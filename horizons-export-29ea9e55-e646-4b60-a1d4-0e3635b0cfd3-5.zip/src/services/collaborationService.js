
import { supabase } from '@/lib/customSupabaseClient';
import { notificationService } from './notificationService';

export const collaborationService = {
  // --- Comments ---
  async getComments(assessmentId) {
    const { data, error } = await supabase
      .from('comments')
      .select('*, user_profiles(full_name, avatar_url)')
      .eq('assessment_id', assessmentId)
      .order('created_at', { ascending: true });
    
    if (error) throw error;
    
    // Transform flat list to tree
    const map = {};
    const roots = [];
    
    data.forEach(c => {
      map[c.id] = { ...c, replies: [] };
    });
    
    data.forEach(c => {
      if (c.parent_id && map[c.parent_id]) {
        map[c.parent_id].replies.push(map[c.id]);
      } else {
        roots.push(map[c.id]);
      }
    });
    
    return roots;
  },

  async addComment(assessmentId, content, parentId = null) {
    const { data: { user } } = await supabase.auth.getUser();
    
    const { data, error } = await supabase
      .from('comments')
      .insert({
        assessment_id: assessmentId,
        user_id: user.id,
        content,
        parent_id: parentId
      })
      .select('*, user_profiles(full_name, avatar_url)')
      .single();

    if (error) throw error;

    // Check for Mentions
    this.handleMentions(content, assessmentId, user.id);
    
    // Notify thread participants if reply
    if (parentId) {
      // Fetch parent author
      const { data: parent } = await supabase.from('comments').select('user_id').eq('id', parentId).single();
      if (parent && parent.user_id !== user.id) {
         notificationService.notify({
           type: 'TEAM',
           title: 'New Reply',
           message: 'Someone replied to your comment on a threat.',
           severity: 'Info',
           userId: parent.user_id // Note: need to update notify to support direct userId targeting if implemented
         });
      }
    }

    return data;
  },

  async handleMentions(content, assessmentId, senderId) {
    // Simple regex for @Name. In prod, use IDs.
    // This is a simulation since we don't have easy lookup of names to IDs in text without a rich editor
    if (content.includes('@')) {
       // Logic to find users and notify them
       console.log("Mentions detected in", content);
    }
  },

  // --- Assignments ---
  async assignThreat(assessmentId, userId) {
    const { data, error } = await supabase
      .from('threat_assessments')
      .update({ 
        assigned_to: userId,
        assignment_status: 'Open',
        updated_at: new Date().toISOString()
      })
      .eq('id', assessmentId)
      .select('*, assigned_to_user:user_profiles!threat_assessments_assigned_to_fkey(*)')
      .single();

    if (error) throw error;

    // Notify Assignee
    if (userId) {
       await notificationService.notify({
         type: 'TEAM',
         title: 'Threat Assigned',
         message: `You have been assigned to threat: ${data.title}`,
         severity: 'Medium'
       });
    }

    return data;
  },

  async updateAssignmentStatus(assessmentId, status) {
    const { data, error } = await supabase
      .from('threat_assessments')
      .update({ assignment_status: status })
      .eq('id', assessmentId)
      .select()
      .single();
      
    if (error) throw error;
    return data;
  },

  // --- Approvals ---
  async requestApproval(assessmentId, type, justification) {
    const { data: { user } } = await supabase.auth.getUser();
    
    const { data, error } = await supabase
      .from('threat_approvals')
      .insert({
        assessment_id: assessmentId,
        requested_by: user.id,
        type,
        status: 'Pending',
        justification
      })
      .select();

    if (error) throw error;

    // Notify Admins (Simulation)
    await notificationService.notify({
       type: 'COMPLIANCE',
       title: 'Approval Requested',
       message: `${user.email} requested approval for ${type}`,
       severity: 'Medium'
    });

    return data[0];
  },

  async reviewApproval(approvalId, status, comments) {
    const { data: { user } } = await supabase.auth.getUser();
    
    const { data, error } = await supabase
      .from('threat_approvals')
      .update({
        status,
        reviewer_comments: comments,
        reviewed_by: user.id,
        reviewed_at: new Date().toISOString()
      })
      .eq('id', approvalId)
      .select()
      .single();

    if (error) throw error;

    // Update Threat Status if approved
    if (status === 'Approved') {
        // Fetch approval to get assessment_id
        // Update assessment status to 'Accepted' or 'Mitigated' based on type
    }
    
    return data;
  },

  async getPendingApprovals() {
     const { data, error } = await supabase
       .from('threat_approvals')
       .select(`
         *,
         threat_assessments (title, risk_score),
         requester:user_profiles!threat_approvals_requested_by_fkey(full_name, email)
       `)
       .eq('status', 'Pending')
       .order('created_at', { ascending: false });

     if (error) throw error;
     return data;
  },

  // --- Activity ---
  async getRecentActivity(limit = 10) {
     // Ideally query a union of comments, logs, and approvals
     // For now, let's fetch latest comments as a proxy for activity
     const { data, error } = await supabase
       .from('comments')
       .select('*, user_profiles(full_name)')
       .order('created_at', { ascending: false })
       .limit(limit);
       
     if (error) return [];
     return data.map(c => ({
       id: c.id,
       type: 'COMMENT',
       user: c.user_profiles?.full_name || 'Unknown',
       text: `commented: "${c.content.substring(0, 50)}..."`,
       timestamp: c.created_at
     }));
  }
};
