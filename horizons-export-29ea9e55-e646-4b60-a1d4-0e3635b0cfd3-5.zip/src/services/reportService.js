
import { supabase } from '@/lib/customSupabaseClient';

export const reportService = {
  /**
   * Fetch all report templates for the organization
   */
  async getTemplates() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("Not authenticated");
    
    // Get user's org safely
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('org_id')
      .eq('id', user.id)
      .maybeSingle();
      
    if (!profile?.org_id) return [];

    const { data, error } = await supabase
      .from('report_templates')
      .select('*')
      .eq('org_id', profile.org_id)
      .order('created_at', { ascending: false });
      
    if (error) throw error;
    return data;
  },

  /**
   * Create a new report template
   */
  async createTemplate(name, description, config) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('org_id')
      .eq('id', user.id)
      .maybeSingle();

    if (!profile?.org_id) throw new Error("Organization context missing");

    const { data, error } = await supabase
      .from('report_templates')
      .insert({
        org_id: profile.org_id,
        created_by: user.id,
        name,
        description,
        config
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Get scheduled reports
   */
  async getScheduledReports() {
    const { data: { user } } = await supabase.auth.getUser();
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('org_id')
      .eq('id', user.id)
      .maybeSingle();

    if (!profile?.org_id) return [];

    const { data, error } = await supabase
      .from('scheduled_reports')
      .select(`
        *,
        template:report_templates(name)
      `)
      .eq('org_id', profile.org_id);

    if (error) throw error;
    return data;
  },

  /**
   * Schedule a report
   */
  async scheduleReport(templateId, frequency, recipients) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('org_id')
      .eq('id', user.id)
      .maybeSingle();

    if (!profile?.org_id) throw new Error("Organization context missing");

    const { data, error } = await supabase
      .from('scheduled_reports')
      .insert({
        org_id: profile.org_id,
        template_id: templateId,
        frequency,
        recipients,
        created_by: user.id
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }
};
