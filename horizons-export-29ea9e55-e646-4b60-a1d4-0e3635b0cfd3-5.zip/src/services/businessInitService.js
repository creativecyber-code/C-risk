import { supabase } from '@/lib/customSupabaseClient';

export const businessInitService = {
  
  async getScenarioLibrary(orgId) {
    if (!orgId) return [];
    
    // Fetch system scenarios (org_id is null) AND tenant scenarios
    const { data, error } = await supabase
      .from('scenario_library')
      .select('*')
      .or(`org_id.eq.${orgId},org_id.is.null`)
      .order('name');

    if (error) {
      console.error("Error fetching scenario library:", error);
      throw error;
    }
    return data;
  },

  async listInitiations(orgId) {
    const { data, error } = await supabase
      .from('business_initiations')
      .select('*')
      .eq('org_id', orgId)
      .order('updated_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  async createInitiation(payload) {
    const { data, error } = await supabase
      .from('business_initiations')
      .insert(payload)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async getInitiationById(id) {
    const { data, error } = await supabase
      .from('business_initiations')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  async updateInitiation(id, updates) {
    const { data, error } = await supabase
      .from('business_initiations')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteInitiation(id) {
    const { error } = await supabase
      .from('business_initiations')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
    return true;
  }
};