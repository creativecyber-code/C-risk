
import { supabase } from '@/lib/customSupabaseClient';

export const riskService = {
  // Fetch existing assessments for a model
  async getAssessments(modelId) {
    const { data, error } = await supabase
      .from('threat_assessments')
      .select('*')
      .eq('model_id', modelId);
    
    if (error) throw error;
    return data;
  },

  // Fetch all assessments for the organization (for All Models view)
  async getAllOrgAssessments() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    // Get user's org safely
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('org_id')
      .eq('id', user.id)
      .maybeSingle();

    if (!profile?.org_id) return [];

    // Join with threat_models to filter by org_id indirectly
    const { data, error } = await supabase
      .from('threat_assessments')
      .select(`
        *,
        model:threat_models!inner(id, org_id, name)
      `)
      .eq('threat_models.org_id', profile.org_id);

    if (error) throw error;
    
    return data.map(item => ({
      ...item,
      model_name: item.model.name 
    }));
  },

  // Save or Update an assessment
  async saveAssessment(assessment) {
    // Check if exists
    const { data: existing } = await supabase
      .from('threat_assessments')
      .select('id')
      .eq('model_id', assessment.model_id)
      .eq('threat_source_id', assessment.threat_source_id)
      .maybeSingle();

    if (existing) {
      const { data, error } = await supabase
        .from('threat_assessments')
        .update({
          ...assessment,
          updated_at: new Date().toISOString()
        })
        .eq('id', existing.id)
        .select()
        .single();
      if (error) throw error;
      return data;
    } else {
      const { data, error } = await supabase
        .from('threat_assessments')
        .insert(assessment)
        .select()
        .single();
      if (error) throw error;
      return data;
    }
  },

  // Batch update assessments
  async syncThreats(modelId, calculatedThreats) {
    const existing = await this.getAssessments(modelId);
    
    // Find threats that don't have assessments yet
    const newThreats = calculatedThreats.filter(ct => 
      !existing.find(e => e.threat_source_id === ct.id)
    );

    if (newThreats.length === 0) return existing;

    // Create default assessments for new threats
    const defaults = newThreats.map(t => ({
      model_id: modelId,
      threat_source_id: t.id,
      title: t.risks[0]?.title || 'Detected Threat',
      category: t.risks[0]?.category || 'General',
      impact_score: 5.0,
      likelihood_score: 5.0,
      risk_score: 5.0,
      status: 'Open'
    }));

    const { data, error } = await supabase
      .from('threat_assessments')
      .insert(defaults)
      .select();

    if (error) throw error;
    return [...existing, ...data];
  }
};
