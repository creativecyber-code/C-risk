
import { supabase } from '@/lib/customSupabaseClient';

export const threatModelService = {
  // Ensure user has an organization (Simple onboarding)
  async ensureUserSetup() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    // 1. Check for existing profile
    // Use maybeSingle() to avoid error if no row is found
    const { data: profile, error: fetchError } = await supabase
      .from('user_profiles')
      .select('org_id, email')
      .eq('id', user.id)
      .maybeSingle();

    if (fetchError) {
      console.error('Error fetching user profile:', fetchError);
      // We continue to try creating if it's just missing, unless it's a critical error
    }

    if (profile) {
      // Backfill email if it's missing (migration support)
      if (!profile.email && user.email) {
        await supabase
          .from('user_profiles')
          .update({ email: user.email })
          .eq('id', user.id);
      }
      return profile.org_id;
    }

    // 2. Create default org if profile doesn't exist
    const { data: org, error: orgError } = await supabase
      .from('organizations')
      .insert({ name: 'My Organization' })
      .select()
      .single();

    if (orgError) {
      console.error('Error creating organization:', orgError);
      throw orgError;
    }

    // 3. Create profile linked to org
    // Handle race conditions where profile might be created by another request
    const { error: profileError } = await supabase
      .from('user_profiles')
      .insert({
        id: user.id,
        org_id: org.id,
        role: 'Admin',
        full_name: user.email?.split('@')[0] || 'User',
        email: user.email,
        avatar_url: `https://ui-avatars.com/api/?name=${user.email}`
      });

    if (profileError) {
      // Check for unique constraint violation (code 23505)
      // This happens if another request created the profile between step 1 and 3
      if (profileError.code === '23505') {
        console.log('Profile created concurrently, fetching existing profile...');
        const { data: existingProfile, error: retryError } = await supabase
          .from('user_profiles')
          .select('org_id')
          .eq('id', user.id)
          .single();
          
        if (retryError) throw retryError;
        return existingProfile.org_id;
      }

      console.error('Error creating profile:', profileError);
      throw profileError;
    }

    return org.id;
  },

  // Main method to fetch models for the current user's organization
  async getModels() {
    try {
      const orgId = await this.ensureUserSetup();
      
      if (!orgId) {
        throw new Error('Could not determine organization ID for user');
      }

      const { data, error } = await supabase
        .from('threat_models')
        .select('*')
        .eq('org_id', orgId)
        .order('updated_at', { ascending: false });

      if (error) {
        console.error('Supabase error fetching models:', error);
        throw error;
      }
      return data || [];
    } catch (error) {
      console.error('Error in threatModelService.getModels:', error);
      throw error;
    }
  },

  // Alias for backward compatibility or alternative naming preference
  async listModels() {
    return this.getModels();
  },

  async createModel(name, description = '') {
    const orgId = await this.ensureUserSetup();
    const { data: { user } } = await supabase.auth.getUser();
    
    const { data, error } = await supabase
      .from('threat_models')
      .insert({
        org_id: orgId,
        created_by: user.id,
        name,
        description,
        is_public: false
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteModel(modelId) {
    const { error } = await supabase
      .from('threat_models')
      .delete()
      .eq('id', modelId);
    if (error) throw error;
  },

  async loadModel(modelId) {
    // Load model metadata
    const { data: model, error: modelError } = await supabase
      .from('threat_models')
      .select('*')
      .eq('id', modelId)
      .single();
    
    if (modelError) throw modelError;

    // Load elements
    const { data: elements, error: elError } = await supabase
      .from('threat_elements')
      .select('*')
      .eq('model_id', modelId);
    
    if (elError) throw elError;

    // Load flows
    const { data: flows, error: flowError } = await supabase
      .from('data_flows')
      .select('*')
      .eq('model_id', modelId);

    if (flowError) throw flowError;

    // Load boundaries (treat as elements in frontend, but stored separately)
    const { data: boundaries, error: boundError } = await supabase
      .from('trust_boundaries')
      .select('*')
      .eq('model_id', modelId);

    if (boundError) throw boundError;

    return {
      model,
      elements: [
        ...(elements || []).map(e => ({ ...e, id: e.id })), 
        ...(boundaries || []).map(b => ({ ...b, id: b.id, type: 'boundary' }))
      ],
      connections: (flows || []).map(f => ({ 
        id: f.id, 
        from: f.from_element_id, 
        to: f.to_element_id,
        label: f.label 
      }))
    };
  },

  async saveModel(modelId, { elements, connections }) {
    // Update timestamp
    await supabase
      .from('threat_models')
      .update({ updated_at: new Date().toISOString() })
      .eq('id', modelId);

    // Full replacement strategy for simplicity and consistency
    // 1. Clear existing items
    await supabase.from('data_flows').delete().eq('model_id', modelId);
    await supabase.from('threat_elements').delete().eq('model_id', modelId);
    await supabase.from('trust_boundaries').delete().eq('model_id', modelId);

    // 2. Separate elements and boundaries
    const standardElements = elements.filter(e => e.type !== 'boundary');
    const boundaries = elements.filter(e => e.type === 'boundary');

    // 3. Insert new items
    if (standardElements.length > 0) {
      const { error } = await supabase.from('threat_elements').insert(
        standardElements.map(e => ({
          id: e.id,
          model_id: modelId,
          type: e.type,
          x: e.x,
          y: e.y,
          label: e.label,
          metadata: e.data || {}
        }))
      );
      if (error) console.error("Error saving elements", error);
    }

    if (boundaries.length > 0) {
      const { error } = await supabase.from('trust_boundaries').insert(
        boundaries.map(b => ({
          id: b.id,
          model_id: modelId,
          x: b.x,
          y: b.y,
          label: b.label
        }))
      );
      if (error) console.error("Error saving boundaries", error);
    }

    if (connections.length > 0) {
      const { error } = await supabase.from('data_flows').insert(
        connections.map(c => ({
          id: c.id,
          model_id: modelId,
          from_element_id: c.from,
          to_element_id: c.to,
          label: c.label || ''
        }))
      );
      if (error) console.error("Error saving flows", error);
    }

    return true;
  }
};
