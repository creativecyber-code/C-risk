
import { supabase } from '@/lib/customSupabaseClient';

/**
 * Service to handle all email communications via Supabase Edge Functions.
 * Includes validation, history logging, and retry logic.
 */
export const emailService = {
  
  // Default sender configuration
  DEFAULT_SENDER: {
    name: 'Security Team',
    email: 'noreply@creativecyber.in'
  },

  /**
   * Validates an email address format.
   * @param {string} email 
   * @returns {boolean}
   */
  isValidEmail(email) {
    const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return re.test(String(email).toLowerCase());
  },

  /**
   * Helper to log email attempts to the database for audit trails.
   * @private
   */
  async _logEmail({ orgId, recipient, subject, templateType, status, errorMessage = null, metadata = {} }) {
    try {
      const { error } = await supabase.from('email_logs').insert({
        org_id: orgId,
        recipient,
        subject,
        template_type: templateType,
        status, // Values: 'sent', 'failed', 'pending', 'queued'
        error_message: errorMessage,
        metadata,
        created_at: new Date().toISOString()
      });

      if (error) {
        console.error('[EmailService] Database insert failed:', error);
      }
    } catch (err) {
      console.error('[EmailService] Failed to log email history:', err);
    }
  },

  /**
   * Internal method to invoke edge function with retry logic.
   * @private
   */
  async _sendWithRetry(payload, attempt = 1, maxAttempts = 2) {
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: payload
      });

      if (error) throw error;
      if (data && !data.success) throw new Error(data.error || 'Unknown edge function error');

      return { success: true, data };
    } catch (err) {
      console.warn(`[EmailService] Attempt ${attempt} failed:`, err.message);
      
      if (attempt < maxAttempts) {
        // Wait 1 second before retrying
        await new Promise(resolve => setTimeout(resolve, 1000));
        return this._sendWithRetry(payload, attempt + 1, maxAttempts);
      }
      
      return { success: false, error: err };
    }
  },

  /**
   * Sends an invitation email to a new user.
   * @param {string} email - Recipient email
   * @param {string} role - Role assigned
   * @param {string} orgName - Organization name
   * @param {string} token - Invitation token
   * @param {string} orgId - Optional org ID for logging
   */
  async sendInvitation(email, role, orgName, token, orgId = null) {
    if (!this.isValidEmail(email)) {
      return { success: false, error: new Error('Invalid email address') };
    }

    const subject = `Invitation to join ${orgName} on CreativeCyber`;
    const payload = {
      to: email,
      subject,
      template: 'invitation',
      data: {
        role,
        orgName,
        inviteLink: `${window.location.origin}/signup?token=${token}&email=${encodeURIComponent(email)}`,
        token
      }
    };

    const result = await this._sendWithRetry(payload);

    await this._logEmail({
      orgId,
      recipient: email,
      subject,
      templateType: 'invitation',
      status: result.success ? 'sent' : 'failed',
      errorMessage: result.error?.message,
      metadata: { role, orgName }
    });

    return result;
  },

  /**
   * Sends a generic notification email.
   * @param {string} email 
   * @param {string} title 
   * @param {string} message 
   * @param {string} link - Optional CTA link
   */
  async sendNotificationEmail(email, title, message, link = null) {
    if (!this.isValidEmail(email)) return { success: false };

    const payload = {
      to: email,
      subject: title,
      template: 'notification',
      data: { title, message, link }
    };

    const result = await this._sendWithRetry(payload);

    // Log failures for debugging
    if (!result.success) {
      await this._logEmail({
        recipient: email,
        subject: title,
        templateType: 'notification',
        status: 'failed',
        errorMessage: result.error?.message
      });
    }

    return result;
  },

  /**
   * Sends a high-priority alert.
   * @param {string} email 
   * @param {string} title 
   * @param {string} message 
   * @param {string} severity 
   * @param {string} link 
   */
  async sendAlert(email, title, message, severity, link) {
    const payload = {
      to: email,
      subject: `[${severity}] ${title}`,
      template: 'alert',
      data: { title, message, severity, link }
    };

    const result = await this._sendWithRetry(payload);
    
    await this._logEmail({
      recipient: email,
      subject: title,
      templateType: 'alert',
      status: result.success ? 'sent' : 'failed',
      errorMessage: result.error?.message,
      metadata: { severity }
    });

    return result;
  },

  /**
   * Sends a test email to verify configuration.
   * @param {string} email 
   * @param {string} orgId 
   */
  async sendTestEmail(email, orgId = null) {
    if (!this.isValidEmail(email)) throw new Error('Invalid email address');

    const subject = 'Test Email from CreativeCyber';
    const payload = {
      to: email,
      subject,
      template: 'generic',
      data: { 
        message: 'This is a test email to verify your SMTP configuration is working correctly.' 
      }
    };

    const result = await this._sendWithRetry(payload);

    await this._logEmail({
      orgId,
      recipient: email,
      subject,
      templateType: 'test',
      status: result.success ? 'sent' : 'failed',
      errorMessage: result.error?.message
    });

    if (!result.success) throw new Error(result.error?.message || 'Failed to send test email');
    return result;
  },

  /**
   * Fetches email history for an organization.
   * @param {string} orgId 
   */
  async getEmailHistory(orgId) {
    if (!orgId) return [];
    
    const { data, error } = await supabase
      .from('email_logs')
      .select('*')
      .eq('org_id', orgId)
      .order('created_at', { ascending: false })
      .limit(50);

    if (error) throw error;
    return data;
  },

  /**
   * Used for testing connection from the UI (Legacy alias)
   */
  async testConnection(email = 'test@example.com') {
    try {
      await this.sendTestEmail(email);
      return { success: true };
    } catch (error) {
      return { success: false, error };
    }
  }
};
