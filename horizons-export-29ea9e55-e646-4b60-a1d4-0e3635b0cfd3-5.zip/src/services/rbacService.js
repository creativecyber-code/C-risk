
import { ROLE_PERMISSIONS, PLATFORM_ROLES, TENANT_ROLES, PERMISSIONS } from '@/lib/rbac_constants';

/**
 * Service to handle Role-Based Access Control (RBAC) logic.
 * Provides methods to check permissions and role capabilities.
 */

// Debug flag - can be toggled or controlled by env vars in real app
const DEBUG_RBAC = true;

const log = (message, data) => {
  if (DEBUG_RBAC) {
    console.log(`🛡️ [RBAC]: ${message}`, data || '');
  }
};

/**
 * Checks if a given role has a specific permission.
 * @param {string} role - The user's role (e.g., 'Platform Admin', 'Tenant Admin')
 * @param {string} permission - The permission identifier (e.g., 'platform:tenants:manage')
 * @returns {boolean}
 */
export const hasPermission = (role, permission) => {
  if (!role || !permission) {
    log('Missing role or permission for check', { role, permission });
    return false;
  }

  // Normalize role name just in case (though constants should be used)
  // We don't normalize permission strings as they are exact keys usually.
  
  const rolePermissions = ROLE_PERMISSIONS[role];
  
  if (!rolePermissions) {
    log(`No permissions defined for role: ${role}`);
    return false;
  }

  // Platform Admin Superuser Check
  // Often useful to have a failsafe where Platform Admin has *everything*
  if (role === PLATFORM_ROLES.PLATFORM_ADMIN) {
    log(`Granted SUPERUSER access to ${permission} for ${role}`);
    return true;
  }

  const hasAccess = rolePermissions.includes(permission);
  
  log(`Permission Check: ${role} -> ${permission}? ${hasAccess ? '✅' : '❌'}`);
  return hasAccess;
};

/**
 * Checks if a role is a Platform-level role.
 * @param {string} role 
 * @returns {boolean}
 */
export const isPlatformRole = (role) => {
  return Object.values(PLATFORM_ROLES).includes(role);
};

/**
 * Checks if a role is a Tenant-level role.
 * @param {string} role 
 * @returns {boolean}
 */
export const isTenantRole = (role) => {
  return Object.values(TENANT_ROLES).includes(role);
};

/**
 * Get all permissions assigned to a role
 * @param {string} role 
 * @returns {Array} List of permission strings
 */
export const getRolePermissions = (role) => {
  return ROLE_PERMISSIONS[role] || [];
};

/**
 * Validates if the user can perform a specific action on a resource type.
 * This is a placeholder for more complex ABAC (Attribute Based Access Control) logic.
 * @param {Object} user 
 * @param {string} permission 
 * @param {Object} resource 
 */
export const can = (user, permission, resource = null) => {
    if (!user || !user.role) return false;
    
    // 1. Basic Role Check
    const roleHasPermission = hasPermission(user.role, permission);
    if (!roleHasPermission) return false;

    // 2. Resource Ownership Check (if resource is provided)
    // Example: Users can only edit their own profile unless they are admins
    if (resource) {
        // Implement specific resource logic here if needed
        // For now, we assume if you have the permission, you can act on the resource
        // unless explicitly implemented otherwise.
    }

    return true;
};

export default {
  hasPermission,
  isPlatformRole,
  isTenantRole,
  getRolePermissions,
  can,
  PERMISSIONS // Re-export for convenience
};
