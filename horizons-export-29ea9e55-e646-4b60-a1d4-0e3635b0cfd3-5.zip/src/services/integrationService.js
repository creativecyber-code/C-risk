
import { supabase } from '@/lib/customSupabaseClient';
import { INTEGRATION_TOOLS } from '@/data/integrationTools';

export const integrationService = {
  async getOrgId() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("User not authenticated");
    
    // Use maybeSingle to avoid PGRST116
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('org_id')
      .eq('id', user.id)
      .maybeSingle();
      
    if (!profile?.org_id) {
      // Return null or throw specific error, but don't crash with PGRST116
      console.warn("Organization not found for user");
      return null;
    }
    return profile.org_id;
  },

  async getMyIntegrations() {
    const orgId = await this.getOrgId();
    if (!orgId) return [];
    
    const { data, error } = await supabase
      .from('integrations')
      .select('*')
      .eq('org_id', orgId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    return data.map(integration => {
      const toolInfo = INTEGRATION_TOOLS.find(t => t.id === integration.provider_key);
      return {
        ...integration,
        toolInfo: toolInfo || { 
          name: 'Unknown Tool', 
          logo: '', 
          description: 'This tool is no longer supported.' 
        }
      };
    });
  },

  async connectIntegration(providerKey, credentials, config) {
    const orgId = await this.getOrgId();
    if (!orgId) throw new Error("Organization context missing");

    const tool = INTEGRATION_TOOLS.find(t => t.id === providerKey);

    if (!tool) throw new Error("Invalid provider");

    await new Promise(resolve => setTimeout(resolve, 1500));

    if (Object.values(credentials).some(v => !v)) {
      throw new Error("Invalid credentials provided. Please check your inputs.");
    }

    const { data, error } = await supabase
      .from('integrations')
      .insert({
        org_id: orgId,
        provider_key: providerKey,
        name: tool.name, 
        credentials, 
        config,
        status: 'active',
        last_sync_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) throw error;

    await this.logEvent(data.id, orgId, 'success', `Connected to ${tool.name}`);
    return data;
  },

  async deleteIntegration(id) {
    const { error } = await supabase.from('integrations').delete().eq('id', id);
    if (error) throw error;
  },

  async getLogs(integrationId = null) {
    const orgId = await this.getOrgId();
    if (!orgId) return [];

    let query = supabase
      .from('integration_logs')
      .select('*, integrations(name, provider_key)')
      .eq('org_id', orgId)
      .order('created_at', { ascending: false })
      .limit(100);

    if (integrationId) {
      query = query.eq('integration_id', integrationId);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  async pushThreatToExternal(integrationId, threat) {
    const { data: integration } = await supabase
      .from('integrations')
      .select('*')
      .eq('id', integrationId)
      .single();

    if (!integration) throw new Error("Integration not found");

    const provider = integration.provider_key;
    let externalId = '';
    let url = '';

    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000)); 

    const prefix = provider.toUpperCase().substring(0, 3);
    const randId = Math.floor(Math.random() * 10000);

    switch (provider) {
      case 'jira':
        externalId = `PROJ-${randId}`;
        url = `https://${integration.config?.domain || 'jira.com'}/browse/${externalId}`;
        break;
      case 'azure-devops': 
      case 'azure':
        externalId = `${randId}`;
        url = `https://dev.azure.com/org/project/_workitems/edit/${externalId}`;
        break;
      case 'github':
        externalId = `#${randId}`;
        url = `https://github.com/org/repo/issues/${randId}`;
        break;
      default:
        externalId = `${prefix}-${randId}`;
        url = `#`;
    }

    await this.logEvent(integrationId, integration.org_id, 'success', `Pushed threat "${threat.title}" to ${integration.name}`, {
      external_id: externalId,
      threat_id: threat.id
    });

    return { externalId, url };
  },

  async logEvent(integrationId, orgId, status, message, details = {}) {
    await supabase
      .from('integration_logs')
      .insert({
        integration_id: integrationId,
        org_id: orgId,
        status,
        message,
        details
      });
  },
  
  async bulkSync(integrationId, threats) {
    const results = [];
    for (const threat of threats) {
        try {
            const res = await this.pushThreatToExternal(integrationId, threat);
            results.push({ id: threat.id, status: 'success', ...res });
        } catch (e) {
            results.push({ id: threat.id, status: 'error', error: e.message });
        }
    }
    return results;
  },

  async syncNow(integrationId) {
    await new Promise(resolve => setTimeout(resolve, 2000));
    const orgId = await this.getOrgId();
    if (orgId) {
      await this.logEvent(integrationId, orgId, 'success', 'Manual sync completed successfully.');
    }
    return { message: 'Sync completed successfully.' };
  },
  
  async disconnectIntegration(id) {
      return this.deleteIntegration(id);
  }
};
