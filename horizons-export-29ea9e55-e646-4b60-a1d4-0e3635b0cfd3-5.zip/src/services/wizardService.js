
import { supabase } from '@/lib/customSupabaseClient';
import { templateService } from './templateService';
import { threatModelService } from './threatModelService';

export const wizardService = {
  /**
   * Save wizard progress (Draft)
   */
  async saveDraft(userId, data) {
    // In a real app, this would save to a drafts table
    localStorage.setItem(`wizard_draft_${userId}`, JSON.stringify(data));
  },

  /**
   * Load wizard progress
   */
  async loadDraft(userId) {
    const data = localStorage.getItem(`wizard_draft_${userId}`);
    return data ? JSON.parse(data) : null;
  },

  /**
   * Clear draft
   */
  async clearDraft(userId) {
    localStorage.removeItem(`wizard_draft_${userId}`);
  },

  /**
   * Finalize wizard and create model
   */
  async createModelFromWizard(data) {
    const { name, description, templateId, customization, teamMembers } = data;

    // 1. Create base model from template
    const modelId = await templateService.useTemplate(templateId, name);
    
    // 2. Apply description update if changed
    if (description) {
      await supabase
        .from('threat_models')
        .update({ description })
        .eq('id', modelId);
    }

    // 3. Apply customizations (e.g., adding extra components defined in wizard)
    if (customization && customization.addedComponents?.length > 0) {
      const currentModel = await threatModelService.loadModel(modelId);
      const newElements = [...currentModel.elements, ...customization.addedComponents];
      await threatModelService.saveModel(modelId, { 
        elements: newElements, 
        connections: currentModel.connections 
      });
    }

    // 4. Invite team members
    // (Mock implementation)
    if (teamMembers?.length > 0) {
      console.log(`Inviting ${teamMembers.length} members to model ${modelId}`);
    }

    // 5. Update analytics
    this.incrementUsage(templateId);

    return modelId;
  },

  async incrementUsage(templateId) {
    // Check if record exists
    const { data } = await supabase
      .from('template_analytics')
      .select('id, usage_count')
      .eq('template_id', templateId)
      .single();

    if (data) {
      await supabase
        .from('template_analytics')
        .update({ 
          usage_count: data.usage_count + 1,
          last_used_at: new Date().toISOString()
        })
        .eq('id', data.id);
    } else {
      await supabase.from('template_analytics').insert({
        template_id: templateId,
        usage_count: 1,
        last_used_at: new Date().toISOString()
      });
    }
  }
};
