
import { supabase } from '@/lib/customSupabaseClient';

export const roleService = {
  /**
   * Fetches all defined tenant roles from the database.
   * @returns {Promise<Array>} Array of role objects
   */
  async getTenantRoles() {
    const { data, error } = await supabase
      .from('tenant_role_definitions')
      .select('*')
      .order('display_name', { ascending: true });
    
    if (error) {
      console.error('Error fetching tenant roles:', error);
      throw error;
    }
    
    return data || [];
  },

  /**
   * Fetches a specific role definition by its key.
   * @param {string} roleKey 
   * @returns {Promise<Object|null>} Role object
   */
  async getRoleByKey(roleKey) {
    if (!roleKey) return null;
    
    const { data, error } = await supabase
      .from('tenant_role_definitions')
      .select('*')
      .eq('role_key', roleKey)
      .single();
      
    if (error) {
      console.error(`Error fetching role ${roleKey}:`, error);
      return null;
    }
    
    return data;
  },

  /**
   * Helper to format a role for display.
   * @param {Object} roleDef 
   * @returns {string}
   */
  formatRoleName(roleDef) {
    if (!roleDef) return 'Unknown Role';
    return roleDef.display_name;
  }
};
