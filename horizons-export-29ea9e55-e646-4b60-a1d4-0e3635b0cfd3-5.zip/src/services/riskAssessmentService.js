
import { supabase } from '@/lib/customSupabaseClient';

// Service to handle risk assessment data persistence and retrieval
export const riskAssessmentService = {
  
  // Save generated threats to the database
  async saveThreats(threats, modelName = 'Architecture Review') {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    // Get Org ID
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('org_id')
      .eq('id', user.id)
      .single();
      
    if (!profile?.org_id) return null;

    // 1. Create or find a threat model container for this session
    // In a real app, this might be selected by the user. For now, we auto-create/find one.
    let { data: model } = await supabase
      .from('threat_models')
      .select('id')
      .eq('name', modelName)
      .eq('org_id', profile.org_id)
      .maybeSingle();

    if (!model) {
      const { data: newModel, error: modelError } = await supabase
        .from('threat_models')
        .insert({
          org_id: profile.org_id,
          name: modelName,
          description: 'Automated STRIDE Analysis',
          created_by: user.id
        })
        .select()
        .single();
      
      if (modelError) {
        console.error('Error creating threat model:', modelError);
        return null;
      }
      model = newModel;
    }

    // 2. Insert threats as threat_assessments
    const assessments = threats.map(t => ({
      model_id: model.id,
      threat_source_id: 'STRIDE-ENGINE',
      title: `${t.category} on ${t.element}`,
      category: t.category,
      // Map simplified risk levels to numeric scores for dashboard
      impact_score: t.riskLevel === 'Critical' ? 10 : t.riskLevel === 'High' ? 8 : t.riskLevel === 'Medium' ? 5 : 2,
      likelihood_score: 5, // Default medium likelihood
      risk_score: t.riskLevel === 'Critical' ? 10 : t.riskLevel === 'High' ? 8 : t.riskLevel === 'Medium' ? 5 : 2,
      status: 'Open', // Default status
      justification: t.threat,
      mitigation_plan: t.control,
      assigned_to: user.id, // Assign to creator by default
      external_refs: {
        component_type: t.elementType,
        regulatory_impact: t.impact
      }
    }));

    const { error: insertError } = await supabase
      .from('threat_assessments')
      .insert(assessments);

    if (insertError) {
      console.error('Error saving threats:', insertError);
      return false;
    }

    return true;
  },

  // Fetch all open threats for the organization
  async getOpenThreats() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('org_id')
      .eq('id', user.id)
      .single();
      
    if (!profile?.org_id) return [];

    // Fetch threats linked to models in this org
    const { data, error } = await supabase
      .from('threat_assessments')
      .select(`
        *,
        model:threat_models!inner(name, org_id)
      `)
      .eq('model.org_id', profile.org_id)
      .neq('status', 'Resolved') // Fetch everything not resolved
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching threats:', error);
      return [];
    }

    return data;
  },

  // Update threat status
  async updateThreatStatus(id, status) {
    const { error } = await supabase
      .from('threat_assessments')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', id);

    if (error) {
      console.error('Error updating threat status:', error);
      return false;
    }
    return true;
  }
};
