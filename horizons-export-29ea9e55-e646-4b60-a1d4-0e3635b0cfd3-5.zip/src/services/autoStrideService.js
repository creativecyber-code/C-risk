
import { BANKING_THREAT_LIBRARY } from '@/data/bankingThreatLibrary';

export const autoStrideService = {
  /**
   * Analyze the graph for threats based on STRIDE and Banking rules
   * @param {Array} nodes React Flow nodes
   * @param {Array} edges React Flow edges
   */
  analyze(nodes, edges) {
    const threats = [];
    const trustBoundaries = nodes.filter(n => n.type === 'trustBoundary');

    edges.forEach(edge => {
      const source = nodes.find(n => n.id === edge.source);
      const target = nodes.find(n => n.id === edge.target);

      if (!source || !target) return;

      // 1. STRIDE: Spoofing (Crossing Boundary)
      const crossesBoundary = this.checkBoundaryCrossing(edge, nodes, trustBoundaries);
      
      if (crossesBoundary) {
        threats.push({
            id: `stride-spoof-${edge.id}`,
            title: `Spoofing: Trust Boundary Violation`,
            description: `Data flows from ${source.data.label} to ${target.data.label} crossing a Trust Boundary. Ensure authentication is enforced.`,
            category: 'Spoofing',
            severity: 'High',
            suggestedControls: ['Mutual TLS (mTLS)', 'Strong Authentication (OIDC)']
        });

        // 2. Tampering (Data in Transit)
        threats.push({
            id: `stride-tamp-${edge.id}`,
            title: `Tampering: Data in Transit`,
            description: `Data traveling over the network between ${source.data.label} and ${target.data.label} is susceptible to interception/modification.`,
            category: 'Tampering',
            severity: 'Medium',
            suggestedControls: ['TLS 1.3', 'Message Signing (HMAC)']
        });
      }

      // 3. Information Disclosure (Storage)
      if (target.type === 'store') {
          threats.push({
              id: `stride-info-${target.id}`,
              title: `Information Disclosure: ${target.data.label}`,
              description: `Sensitive data stored in ${target.data.label} needs encryption at rest.`,
              category: 'Information Disclosure',
              severity: 'Critical',
              suggestedControls: ['Database Encryption (TDE)', 'Field-Level Encryption']
          });
      }

      // 4. Banking Specific Checks
      if (source.data.label.toLowerCase().includes('mobile') || source.data.label.toLowerCase().includes('client')) {
          threats.push({
              id: `bank-client-${source.id}`,
              title: `Unrusted Client: ${source.data.label}`,
              description: BANKING_THREAT_LIBRARY.digitalBanking.threats[1].description, // MitM
              category: 'Network Security',
              severity: 'High',
              suggestedControls: ['Certificate Pinning', 'App Integrity Checks']
          });
      }
    });

    return threats;
  },

  checkBoundaryCrossing(edge, nodes, boundaries) {
    // Simplified logic: Check if edge connects two nodes that are visually separated by a boundary node
    // In a real geometry engine, we'd check intersection. 
    // Here, we check if one is inside a group/parent boundary and other is outside.
    
    // For this implementation, we assume if an edge exists between an 'interactor' (usually external) 
    // and a 'process' (internal), it effectively crosses a boundary.
    const source = nodes.find(n => n.id === edge.source);
    const target = nodes.find(n => n.id === edge.target);

    if (source.type === 'interactor' && target.type === 'process') return true;
    if (source.type === 'interactor' && target.type === 'store') return true;
    
    // Explicit boundary crossing logic would go here if using parent/child nodes
    return false;
  }
};
