
import { supabase } from '@/lib/customSupabaseClient';

export const regulatoryImportService = {
  
  async createImportLog(filename, fileType, totalRecords) {
    const { data: { user } } = await supabase.auth.getUser();
    
    const { data, error } = await supabase
      .from('regulatory_imports')
      .insert({
        filename,
        file_type: fileType,
        status: 'processing',
        total_records: totalRecords,
        imported_by: user.id
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async completeImport(importId, count, errors = null) {
    await supabase
      .from('regulatory_imports')
      .update({
        status: errors ? 'completed_with_errors' : 'completed',
        imported_count: count,
        error_log: errors ? JSON.stringify(errors) : null
      })
      .eq('id', importId);
  },

  async failImport(importId, error) {
    await supabase
      .from('regulatory_imports')
      .update({
        status: 'failed',
        error_log: error.message
      })
      .eq('id', importId);
  },

  async getImportHistory() {
    // Explicitly use the constraint name to resolve the relationship
    const { data, error } = await supabase
      .from('regulatory_imports')
      .select(`
        *,
        importer:platform_staff!regulatory_imports_imported_by_fkey(email)
      `)
      .order('created_at', { ascending: false });
      
    if (error) throw error;
    return data;
  },

  /**
   * Process a single import record:
   * 1. Find or Create Category
   * 2. Create Regulation
   * 3. (Implicit) Controls are part of regulation JSONB
   */
  async processRecord(record) {
    // 1. Handle Category
    let categoryId = null;
    
    // Check if category exists
    const { data: existingCat } = await supabase
      .from('master_risk_categories')
      .select('id')
      .ilike('name', record.category_name)
      .single();

    if (existingCat) {
      categoryId = existingCat.id;
    } else {
      // Create new category
      const { data: newCat, error: catError } = await supabase
        .from('master_risk_categories')
        .insert({
          name: record.category_name,
          severity: record.severity || 'Medium',
          description: `Imported category for ${record.regulation_name}`
        })
        .select()
        .single();
      
      if (catError) throw catError;
      categoryId = newCat.id;
    }

    // 2. Create Regulation
    const { data: { user } } = await supabase.auth.getUser();
    
    // Construct control items structure
    // If input has explicit control array (PDF import), use it.
    // If flattened CSV row, create single control item array.
    let controlItems = record.control_items || [];
    
    if (controlItems.length === 0 && (record.control_name || record.control_code)) {
      controlItems.push({
        id: Date.now(), // simple ID generation
        code: record.control_code || 'GEN-01',
        name: record.control_name || 'General Control',
        description: record.control_description || ''
      });
    }

    const { error: regError } = await supabase
      .from('regulatory_library')
      .insert({
        category_id: categoryId,
        regulation_name: record.regulation_name,
        description: record.description,
        control_items: controlItems,
        created_by: user.id
      });

    if (regError) throw regError;
    return true;
  }
};
