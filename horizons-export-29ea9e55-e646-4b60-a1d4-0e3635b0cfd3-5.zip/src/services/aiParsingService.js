
import { supabase } from '@/lib/customSupabaseClient';
import * as XLSX from 'xlsx';

// Mock AI parsing delay and response for demo purposes
// In a real implementation, this would call OpenAI/Claude API via Edge Function
const MOCK_AI_RESPONSE_DELAY = 2000; 

export const aiParsingService = {
  
  /**
   * Main entry point to parse a file based on its type
   */
  async parseFile(file) {
    const fileType = file.name.split('.').pop().toLowerCase();
    
    if (['csv', 'xlsx', 'xls'].includes(fileType)) {
      return this.parseSpreadsheet(file);
    } else if (fileType === 'pdf') {
      return this.parsePDF(file);
    } else {
      throw new Error('Unsupported file type. Please use CSV, Excel, or PDF.');
    }
  },

  /**
   * Parses Spreadsheet files (CSV/Excel) using XLSX
   */
  async parseSpreadsheet(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const data = e.target.result;
          const workbook = XLSX.read(data, { type: 'binary' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }); // Array of arrays

          if (jsonData.length < 2) {
            throw new Error('File appears to be empty or missing headers.');
          }

          const headers = jsonData[0];
          const rows = jsonData.slice(1);

          resolve({
            type: 'spreadsheet',
            headers,
            rows: rows.map(row => {
              // Map array back to object using headers safely
              const obj = {};
              headers.forEach((header, index) => {
                obj[header] = row[index];
              });
              return obj;
            })
          });
        } catch (error) {
          reject(new Error('Failed to parse spreadsheet file.'));
        }
      };
      
      reader.onerror = () => reject(new Error('File read error.'));
      reader.readAsBinaryString(file);
    });
  },

  /**
   * Simulates AI PDF extraction
   */
  async parsePDF(file) {
    // In production: Send file to backend -> Textract/OCR -> LLM
    // Here: We simulate the extraction of a regulatory document
    
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          type: 'pdf_extracted',
          detectedStructure: 'regulatory_document',
          confidence: 0.89,
          extractedData: [
            {
              regulation_name: "AI Risk Management Framework 1.0",
              category_name: "Artificial Intelligence",
              severity: "High",
              description: "Governs the development and deployment of generative AI models.",
              control_items: [
                { code: "AI.1", name: "Model Explainability", description: "Ensure model outputs can be interpreted." },
                { code: "AI.2", name: "Training Data Privacy", description: "Sanitize PII from training sets." }
              ]
            },
            {
              regulation_name: "Cloud Security Standard v2",
              category_name: "Technology",
              severity: "Critical",
              description: "Baseline security controls for cloud infrastructure.",
              control_items: [
                { code: "CS.1", name: "Encryption at Rest", description: "AES-256 requirement for all storage buckets." },
                { code: "CS.2", name: "Key Management", description: "Rotation of access keys every 90 days." }
              ]
            }
          ]
        });
      }, MOCK_AI_RESPONSE_DELAY);
    });
  },

  /**
   * Heuristic to auto-map CSV columns to system fields
   */
  suggestMapping(headers) {
    const systemFields = {
      category_name: ['category', 'risk category', 'domain', 'group'],
      regulation_name: ['regulation', 'title', 'name', 'standard'],
      description: ['description', 'desc', 'summary', 'detail'],
      severity: ['severity', 'level', 'criticality', 'impact'],
      control_code: ['control code', 'id', 'ref', 'reference'],
      control_name: ['control name', 'control title', 'control'],
      control_description: ['control description', 'requirement', 'mandate']
    };

    const mapping = {};

    headers.forEach(header => {
      const lowerHeader = header.toLowerCase();
      
      for (const [field, keywords] of Object.entries(systemFields)) {
        if (!mapping[field] && keywords.some(k => lowerHeader.includes(k))) {
          mapping[field] = header;
        }
      }
    });

    return mapping;
  }
};
