
import { supabase } from '@/lib/customSupabaseClient';
import { SEED_PATTERNS, SEED_KB_ARTICLES } from '@/data/initialThreatLibrary';

export const threatLibraryService = {
  /**
   * Get patterns with optional filtering
   */
  async getPatterns({ search = '', category = 'All', industry = 'All', severity = 'All' } = {}) {
    try {
      let query = supabase
        .from('threat_patterns')
        .select('*')
        .order('usage_count', { ascending: false });

      if (category !== 'All') query = query.eq('stride_category', category);
      if (severity !== 'All') query = query.eq('severity', severity);
      if (industry !== 'All') query = query.contains('industry', [industry]);
      if (search) query = query.ilike('title', `%${search}%`);

      const { data, error } = await query;

      // Fallback to seed data if DB is empty (for demo purposes)
      if (!data || data.length === 0) {
        let results = [...SEED_PATTERNS];
        if (category !== 'All') results = results.filter(p => p.stride_category === category);
        if (severity !== 'All') results = results.filter(p => p.severity === severity);
        if (industry !== 'All') results = results.filter(p => p.industry.includes(industry));
        if (search) results = results.filter(p => p.title.toLowerCase().includes(search.toLowerCase()));
        return results;
      }

      if (error) throw error;
      return data;
    } catch (err) {
      console.error('Error fetching patterns:', err);
      return SEED_PATTERNS; // Fail safe
    }
  },

  /**
   * Get single pattern details
   */
  async getPatternDetails(id) {
    // Check seed first for demo IDs
    const seed = SEED_PATTERNS.find(p => p.id === id);
    if (seed) return seed;

    const { data, error } = await supabase
      .from('threat_patterns')
      .select('*, threat_reviews(*)')
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Create a new custom pattern
   */
  async createPattern(patternData) {
    const user = await supabase.auth.getUser();
    if (!user.data.user) throw new Error("Not authenticated");
    
    // Get org_id (simplified)
    const { data: profile } = await supabase.from('user_profiles').select('org_id').single();
    
    const { data, error } = await supabase
      .from('threat_patterns')
      .insert({
        ...patternData,
        org_id: profile?.org_id,
        created_by: user.data.user.id,
        usage_count: 0,
        is_public: false
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Import pattern into a threat model
   */
  async importPatternToModel(modelId, pattern) {
    // This creates a threat_assessment record based on the pattern
    const { data, error } = await supabase
      .from('threat_assessments')
      .insert({
        model_id: modelId,
        title: pattern.title,
        threat_source_id: 'LIBRARY_IMPORT',
        category: pattern.stride_category,
        risk_score: pattern.severity === 'Critical' ? 95 : pattern.severity === 'High' ? 75 : 50,
        status: 'Open',
        justification: pattern.description,
        mitigation_plan: pattern.mitigation_strategies,
        impact_score: pattern.impact === 'High' ? 9 : 5,
        likelihood_score: pattern.likelihood === 'High' ? 9 : 5,
      })
      .select()
      .single();
      
    if (error) throw error;
    
    // Increment usage count
    await supabase.rpc('increment_pattern_usage', { row_id: pattern.id });
    
    return data;
  },

  /**
   * Get Knowledge Base Articles
   */
  async getKnowledgeBase() {
    const { data, error } = await supabase
      .from('knowledge_base_articles')
      .select('*')
      .order('views', { ascending: false });

    if (!data || data.length === 0) return SEED_KB_ARTICLES;
    
    if (error) throw error;
    return data;
  }
};
