
import { supabase } from '@/lib/customSupabaseClient';

export const auditService = {
  /**
   * Log an immutable action to the audit trail.
   * Designed to be fault-tolerant: will not crash the app if logging fails.
   * 
   * @param {string} action - The action name (e.g., 'LOGIN', 'UPDATE_THREAT')
   * @param {string} targetResource - The resource being acted upon
   * @param {object} details - Additional JSON details
   */
  async logAction(action, targetResource, details = {}) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      // If no user, we can't log to app_audit_logs securely as it requires user_id usually.
      // However, for system events or anonymous actions, we might handle differently.
      // For now, return early if no user to respect RLS policies.
      if (!user) return;

      // Try to fetch org_id, but don't block if it fails or doesn't exist yet
      let orgId = null;
      try {
        const { data: profile } = await supabase
          .from('user_profiles')
          .select('org_id')
          .eq('id', user.id)
          .maybeSingle();
        
        if (profile) orgId = profile.org_id;
      } catch (err) {
        // Ignore profile fetch errors for audit logging to ensure logging doesn't become a blocker
        console.warn("Audit log warning: Could not fetch profile for context", err);
      }

      // Construct payload strictly matching schema types
      const payload = {
        user_id: user.id,
        org_id: orgId, // Can be null if nullable in DB, otherwise might trigger error if RLS expects it
        action: String(action), 
        target_resource: String(targetResource || 'system'),
        details: typeof details === 'object' ? details : { raw: details },
        ip_address: '0.0.0.0', // Placeholder, real IP usually requires Edge Function context
        user_agent: typeof navigator !== 'undefined' ? navigator.userAgent : 'server',
        status: 'SUCCESS',
        created_at: new Date().toISOString() // Ensure timestamp is present
      };

      const { error } = await supabase
        .from('app_audit_logs')
        .insert(payload);

      if (error) {
        // Log to console but don't throw, so we don't break the user flow
        console.error("Audit Log Insert Error:", error.message, error.details);
      }
    } catch (e) {
      console.error("Audit Service Critical Failure:", e);
    }
  }
};
