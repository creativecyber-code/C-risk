
import { supabase } from '@/lib/customSupabaseClient';

export const notificationService = {
  async getNotifications(userId, limit = 10) {
    if (!userId) return [];
    
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data;
  },

  async getUnreadCount(userId) {
    if (!userId) return 0;

    const { count, error } = await supabase
      .from('notifications')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId)
      .eq('is_read', false);

    if (error) {
      console.warn("Error fetching unread count:", error);
      return 0;
    }
    return count;
  },

  async markAsRead(notificationId) {
    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', notificationId);

    if (error) throw error;
  },

  async markAllAsRead(userId) {
    if (!userId) return;

    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('user_id', userId);

    if (error) throw error;
  },

  async getEmailConfig(orgId) {
    if (!orgId) return null;

    const { data, error } = await supabase
      .from('organizations')
      .select('settings')
      .eq('id', orgId)
      .single();

    if (error) {
      console.warn("Failed to fetch email config:", error);
      return null;
    }

    return data?.settings?.email_config || {
      smtp_host: '',
      smtp_port: '465',
      smtp_user: '',
      smtp_pass: '',
      sender_email: '',
      sender_name: '',
      use_custom_smtp: false
    };
  },

  async updateEmailConnection(orgId, config) {
    if (!orgId) throw new Error("Organization ID is required");

    // Fetch current settings first to merge
    const { data: currentOrg, error: fetchError } = await supabase
      .from('organizations')
      .select('settings')
      .eq('id', orgId)
      .single();

    if (fetchError) throw fetchError;

    const newSettings = {
      ...currentOrg.settings,
      email_config: config
    };

    const { error: updateError } = await supabase
      .from('organizations')
      .update({ settings: newSettings })
      .eq('id', orgId);

    if (updateError) throw updateError;
    return true;
  },

  async testSmtpConnection(config) {
    // Simulate a connection test since we can't actually connect to SMTP from client-side JS
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (config.smtp_host && config.smtp_user) {
          resolve({ success: true, message: "Connection successful" });
        } else {
          reject(new Error("Invalid SMTP configuration"));
        }
      }, 1500);
    });
  }
};
