
import { supabase } from '@/lib/customSupabaseClient';

export const tenantService = {
  /**
   * Fetch current tenant settings including logo
   */
  async getTenantSettings(tenantId) {
    if (!tenantId) throw new Error("Tenant ID is required");

    const { data, error } = await supabase
      .from('organizations')
      .select('*')
      .eq('id', tenantId)
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Get the current user's role within the tenant
   */
  async getCurrentMemberRole(tenantId, userId) {
    if (!tenantId || !userId) return null;

    const { data, error } = await supabase
      .from('tenant_members')
      .select('role_key')
      .eq('tenant_id', tenantId)
      .eq('user_id', userId)
      .single();

    if (error) {
      console.error("Error fetching member role:", error);
      return null;
    }
    return data?.role_key;
  },

  /**
   * Upload a new logo for the tenant
   */
  async uploadTenantLogo(tenantId, file) {
    if (!tenantId || !file) throw new Error("Missing tenant ID or file");

    const fileExt = file.name.split('.').pop();
    const filePath = `${tenantId}/logo.${fileExt}`;
    const bucket = 'tenant-logos';

    // 1. Upload to Storage
    const { error: uploadError } = await supabase.storage
      .from(bucket)
      .upload(filePath, file, {
        upsert: true,
        cacheControl: '3600'
      });

    if (uploadError) throw uploadError;

    // 2. Get Public URL
    const { data: { publicUrl } } = supabase.storage
      .from(bucket)
      .getPublicUrl(filePath);

    // 3. Update Organization Record with timestamp to force refresh if URL is same
    const versionedUrl = `${publicUrl}?t=${new Date().getTime()}`;

    const { error: dbError } = await supabase
      .from('organizations')
      .update({ logo_url: versionedUrl })
      .eq('id', tenantId);

    if (dbError) throw dbError;

    return versionedUrl;
  },

  /**
   * Delete the current tenant logo
   */
  async deleteTenantLogo(tenantId) {
    if (!tenantId) throw new Error("Tenant ID is required");

    // We can't easily know the exact file extension to delete from storage without listing, 
    // but typically we can try to update the DB first to clear the reference.
    // For a cleaner cleanup, we would list files in the folder `tenantId/` and delete them.
    
    // 1. List files in tenant folder to find the logo
    const { data: files } = await supabase.storage
      .from('tenant-logos')
      .list(tenantId);

    if (files && files.length > 0) {
      const pathsToDelete = files.map(f => `${tenantId}/${f.name}`);
      const { error: deleteError } = await supabase.storage
        .from('tenant-logos')
        .remove(pathsToDelete);
        
      if (deleteError) console.warn("Failed to delete file from storage", deleteError);
    }

    // 2. Clear URL in DB
    const { error: dbError } = await supabase
      .from('organizations')
      .update({ logo_url: null })
      .eq('id', tenantId);

    if (dbError) throw dbError;
    
    return true;
  }
};
