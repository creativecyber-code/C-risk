
import { supabase } from '@/lib/customSupabaseClient';

// Browser-native Web Crypto API wrapper
export const encryptionService = {
  
  // Generate a random AES-GCM key
  async generateKey() {
    return await window.crypto.subtle.generateKey(
      {
        name: "AES-GCM",
        length: 256
      },
      true,
      ["encrypt", "decrypt"]
    );
  },

  // Export key to string for storage (simulated secure storage)
  async exportKey(key) {
    const exported = await window.crypto.subtle.exportKey("jwk", key);
    return JSON.stringify(exported);
  },

  // Import key from string
  async importKey(keyString) {
    const jwk = JSON.parse(keyString);
    return await window.crypto.subtle.importKey(
      "jwk",
      jwk,
      { name: "AES-GCM" },
      true,
      ["encrypt", "decrypt"]
    );
  },

  // Encrypt data
  async encrypt(text, key) {
    const encoded = new TextEncoder().encode(text);
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    
    const encrypted = await window.crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv: iv
      },
      key,
      encoded
    );

    // Combine IV and ciphertext for storage
    const encryptedArray = new Uint8Array(encrypted);
    const combined = new Uint8Array(iv.length + encryptedArray.length);
    combined.set(iv);
    combined.set(encryptedArray, iv.length);

    // Return as base64 string
    return btoa(String.fromCharCode(...combined));
  },

  // Decrypt data
  async decrypt(encryptedString, key) {
    try {
      const combined = new Uint8Array(
        atob(encryptedString).split('').map(c => c.charCodeAt(0))
      );
      
      const iv = combined.slice(0, 12);
      const data = combined.slice(12);

      const decrypted = await window.crypto.subtle.decrypt(
        {
          name: "AES-GCM",
          iv: iv
        },
        key,
        data
      );

      return new TextDecoder().decode(decrypted);
    } catch (e) {
      console.error("Decryption failed", e);
      throw new Error("Decryption failed or invalid key");
    }
  },

  // Mask sensitive data for display
  maskData(text, visibleChars = 4) {
    if (!text) return '';
    if (text.length <= visibleChars) return '*'.repeat(text.length);
    return text.substring(0, visibleChars) + '*'.repeat(text.length - visibleChars);
  },

  // Database interactions
  async getLatestKey() {
    // In a real app, this would fetch from a secure vault or use KMS
    // Here we fetch the latest active key from our table
    const { data, error } = await supabase
      .from('security_keys')
      .select('*')
      .eq('status', 'active')
      .order('version', { ascending: false })
      .limit(1)
      .single();
    
    if (error || !data) {
      // Create initial key if none exists
      return this.rotateKey();
    }
    
    return this.importKey(data.key_material);
  },

  async rotateKey() {
    const newKey = await this.generateKey();
    const keyString = await this.exportKey(newKey);
    
    // Get current max version
    const { data: current } = await supabase
      .from('security_keys')
      .select('version')
      .order('version', { ascending: false })
      .limit(1);
      
    const nextVersion = (current?.[0]?.version || 0) + 1;

    // Archive old keys (optional logic)
    await supabase
      .from('security_keys')
      .update({ status: 'archived' })
      .eq('status', 'active');

    // Store new key
    const { data, error } = await supabase
      .from('security_keys')
      .insert({
        version: nextVersion,
        key_material: keyString,
        status: 'active',
        algorithm: 'AES-GCM'
      })
      .select()
      .single();

    if (error) throw error;
    return newKey;
  }
};
