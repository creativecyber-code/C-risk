
import { supabase } from '@/lib/customSupabaseClient';

export const contentPushService = {
  // --- Risk Categories ---
  async getRiskCategories() {
    const { data, error } = await supabase
      .from('master_risk_categories')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  async createRiskCategory(category) {
    const { data, error } = await supabase
      .from('master_risk_categories')
      .insert(category)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async deleteRiskCategory(id) {
    const { error } = await supabase
      .from('master_risk_categories')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },

  // --- Regulatory Library ---
  async getRegulations() {
    const { data, error } = await supabase
      .from('regulatory_library')
      .select(`
        *,
        category:master_risk_categories(name, severity)
      `)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  async createRegulation(regulation) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase
      .from('regulatory_library')
      .insert({ ...regulation, created_by: user.id })
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async deleteRegulation(id) {
    const { error } = await supabase
      .from('regulatory_library')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },

  // --- Tenants ---
  async getActiveTenants() {
    const { data, error } = await supabase
      .from('organizations')
      .select('id, name, slug, status')
      .eq('status', 'active'); // Assuming 'active' is the status for live tenants
    if (error) throw error;
    return data;
  },

  // --- Deployments ---
  async createDeployment(regulationId, targetType, targetTenantIds) {
    const { data: { user } } = await supabase.auth.getUser();
    
    // 1. Create Deployment Record
    const { data: deployment, error: depError } = await supabase
      .from('content_deployments')
      .insert({
        regulation_id: regulationId,
        target_type: targetType,
        target_tenant_ids: targetTenantIds,
        deployed_by: user.id,
        status: 'PROCESSING'
      })
      .select()
      .single();

    if (depError) throw depError;

    // 2. Create Subscriptions for each tenant
    const subscriptions = targetTenantIds.map(tenantId => ({
      tenant_id: tenantId,
      regulation_id: regulationId,
      deployment_id: deployment.id,
      status: 'DEPLOYED'
    }));

    const { error: subError } = await supabase
      .from('tenant_regulatory_subscriptions')
      .insert(subscriptions);

    if (subError) {
      // Mark deployment as failed if partial insert fails
      await supabase.from('content_deployments').update({ status: 'FAILED' }).eq('id', deployment.id);
      throw subError;
    }

    // 3. Mark complete
    await supabase.from('content_deployments').update({ status: 'COMPLETED' }).eq('id', deployment.id);

    return deployment;
  },

  async getDeploymentHistory() {
    // Explicitly use the constraint name to resolve the relationship
    const { data, error } = await supabase
      .from('content_deployments')
      .select(`
        *,
        regulation:regulatory_library(regulation_name),
        deployer:platform_staff!content_deployments_deployed_by_fkey(email) 
      `)
      .order('created_at', { ascending: false });
      
    if (error) throw error;
    return data;
  }
};
