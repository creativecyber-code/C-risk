
// Simple mock service using LocalStorage to replace Supabase/Database calls
const STORAGE_KEYS = {
  APPLICATIONS: 'c_risk_simple_apps',
  RISKS: 'c_risk_simple_risks',
  TESTS: 'c_risk_simple_tests'
};

export const mockDataService = {
  // Initialize simple data if empty
  init() {
    if (!localStorage.getItem(STORAGE_KEYS.APPLICATIONS)) {
      localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify([
        { id: '1', name: 'Payment Gateway Alpha', owner: 'Alice Smith', status: 'Active', created_at: new Date().toISOString() },
        { id: '2', name: 'User Auth Service', owner: 'Bob Jones', status: 'Draft', created_at: new Date().toISOString() }
      ]));
    }
    if (!localStorage.getItem(STORAGE_KEYS.RISKS)) {
      localStorage.setItem(STORAGE_KEYS.RISKS, JSON.stringify([
        { appId: '1', confidentiality: 5, integrity: 4, availability: 5, score: 25, level: 'Critical' }
      ]));
    }
  },

  getApplications() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.APPLICATIONS) || '[]');
    } catch (e) {
      return [];
    }
  },

  addApplication(app) {
    const apps = this.getApplications();
    const newApp = { ...app, id: Date.now().toString(), created_at: new Date().toISOString() };
    apps.push(newApp);
    localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
    return newApp;
  },

  saveRiskAssessment(assessment) {
    const risks = JSON.parse(localStorage.getItem(STORAGE_KEYS.RISKS) || '[]');
    // Remove existing for this app
    const filtered = risks.filter(r => r.appId !== assessment.appId);
    filtered.push(assessment);
    localStorage.setItem(STORAGE_KEYS.RISKS, JSON.stringify(filtered));
    return assessment;
  },

  getRiskForApp(appId) {
    const risks = JSON.parse(localStorage.getItem(STORAGE_KEYS.RISKS) || '[]');
    return risks.find(r => r.appId === appId) || null;
  },

  exportData() {
    return {
      applications: this.getApplications(),
      risks: JSON.parse(localStorage.getItem(STORAGE_KEYS.RISKS) || '[]')
    };
  }
};
