
import * as XLSX from 'xlsx';

export const excelParserService = {
  /**
   * Reads a file (Excel or CSV) and returns the parsed data.
   * @param {File} file - The file object from input.
   * @returns {Promise<{sheets: string[], data: Record<string, any[]>}>}
   */
  async parseFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = (e) => {
        try {
          const data = e.target.result;
          const workbook = XLSX.read(data, { type: 'array' });
          
          const sheets = workbook.SheetNames;
          const parsedData = {};

          sheets.forEach(sheetName => {
            const worksheet = workbook.Sheets[sheetName];
            // Convert to JSON, treating first row as headers
            parsedData[sheetName] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
          });

          resolve({ sheets, data: parsedData });
        } catch (error) {
          reject(new Error("Failed to parse file. Please ensure it is a valid Excel or CSV file."));
        }
      };

      reader.onerror = () => reject(new Error("Failed to read file"));
      reader.readAsArrayBuffer(file);
    });
  },

  /**
   * Generates a template Excel file for users to download.
   */
  downloadTemplate() {
    const headers = [
      'Reference Number', 
      'Obligation Text', 
      'Control Statement', 
      'Control Type', 
      'Category', 
      'Risk Objective', 
      'Evidence Required'
    ];
    
    const sampleRow = [
      'Para 2.1', 
      'Entities must ensure data is encrypted.', 
      'Implement AES-256 encryption for data at rest.', 
      'Preventive', 
      'Technology', 
      'Prevent data leakage.', 
      'Encryption logs; Config screenshots'
    ];

    const ws = XLSX.utils.aoa_to_sheet([headers, sampleRow]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Compliance Template");
    
    XLSX.writeFile(wb, "RegParser_Import_Template.xlsx");
  },

  /**
   * Validates if the mapping has required fields.
   * @param {Object} mapping - The mapping object { systemField: fileColumnIndex }
   * @returns {Object} { isValid: boolean, missing: string[] }
   */
  validateMapping(mapping) {
    const required = ['section_ref', 'requirement_text', 'suggested_control_name'];
    const missing = required.filter(field => mapping[field] === undefined || mapping[field] === null || mapping[field] === '');
    
    return {
      isValid: missing.length === 0,
      missing
    };
  }
};
