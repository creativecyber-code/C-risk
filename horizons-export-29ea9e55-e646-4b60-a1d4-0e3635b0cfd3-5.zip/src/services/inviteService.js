
import { supabase } from '@/lib/customSupabaseClient';

export const inviteService = {
  /**
   * Creates a new platform invite using RPC.
   */
  async createInvite(email, role) {
    const { data, error } = await supabase.rpc('create_platform_invite', {
      p_email: email,
      p_role: role
    });

    if (error) {
      console.error('Create invite error:', error);
      return { success: false, error: error.message };
    }

    return data; // { success: true, code: '...', invite_id: '...' }
  },

  /**
   * Deletes a platform invite using RPC.
   */
  async deleteInvite(inviteId) {
    const { data, error } = await supabase.rpc('delete_platform_invite', {
      p_invite_id: inviteId
    });

    if (error) {
      console.error('Delete invite error:', error);
      throw new Error(error.message);
    }

    if (!data.success) {
      throw new Error(data.error || 'Failed to delete invite');
    }

    return data;
  },

  /**
   * Fetches all platform invites directly from the table (admin only via RLS).
   */
  async getInvites() {
    const { data, error } = await supabase
      .from('platform_invites')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  }
};
