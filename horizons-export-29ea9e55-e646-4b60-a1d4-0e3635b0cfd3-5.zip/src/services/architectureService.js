import { supabase } from '@/lib/customSupabaseClient';

export const architectureService = {
  /**
   * List all architecture reviews for a tenant
   */
  async listReviews(orgId) {
    if (!orgId) throw new Error("Organization ID is required");

    const { data, error } = await supabase
      .from('architecture_reviews')
      .select(`
        *,
        business_initiations (title, application_type)
      `)
      .eq('org_id', orgId)
      .order('updated_at', { ascending: false });

    if (error) {
      console.error("Error listing architecture reviews:", error);
      throw error;
    }
    return data;
  },

  /**
   * Get a single architecture review by ID
   */
  async getReview(reviewId) {
    const { data, error } = await supabase
      .from('architecture_reviews')
      .select(`
        *,
        business_initiations (*),
        stride_threats (*),
        architecture_review_controls (*)
      `)
      .eq('id', reviewId)
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Create a new architecture review
   */
  async createReview(payload) {
    const { data, error } = await supabase
      .from('architecture_reviews')
      .insert(payload)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Update an existing architecture review
   */
  async updateReview(id, updates) {
    const { data, error } = await supabase
      .from('architecture_reviews')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Delete an architecture review
   */
  async deleteReview(id) {
    const { error } = await supabase
      .from('architecture_reviews')
      .delete()
      .eq('id', id);

    if (error) throw error;
    return true;
  },

  /**
   * Get threats for a specific review
   */
  async getThreats(reviewId) {
    const { data, error } = await supabase
      .from('stride_threats')
      .select('*')
      .eq('architecture_review_id', reviewId);

    if (error) throw error;
    return data;
  }
};