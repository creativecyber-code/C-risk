
import { supabase } from '@/lib/customSupabaseClient';

export const loggingService = {
  /**
   * Fetch logs with filtering, sorting, and pagination
   */
  async getLogs({ page = 1, pageSize = 20, filters = {}, sort = { column: 'timestamp', ascending: false } }) {
    let query = supabase
      .from('system_logs')
      .select('*', { count: 'exact' });

    // Apply Filters
    if (filters.level && filters.level !== 'all') {
      query = query.eq('level', filters.level);
    }

    if (filters.search) {
      // Search in action, user_email, or cast details to text
      // Note: searching JSONB as text is limited in simple queries, 
      // primarily searching core text columns here for performance and simplicity
      query = query.or(`action.ilike.%${filters.search}%,user_email.ilike.%${filters.search}%`);
    }

    if (filters.dateRange) {
      const now = new Date();
      let startDate;

      switch (filters.dateRange) {
        case 'today':
          startDate = new Date(now.setHours(0, 0, 0, 0));
          break;
        case '7d':
          startDate = new Date(now.setDate(now.getDate() - 7));
          break;
        case '30d':
          startDate = new Date(now.setDate(now.getDate() - 30));
          break;
        case 'custom':
          if (filters.startDate) startDate = new Date(filters.startDate);
          break;
        default:
          break;
      }

      if (startDate) {
        query = query.gte('timestamp', startDate.toISOString());
      }
      
      if (filters.dateRange === 'custom' && filters.endDate) {
        const endDate = new Date(filters.endDate);
        endDate.setHours(23, 59, 59, 999);
        query = query.lte('timestamp', endDate.toISOString());
      }
    }

    // Pagination
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    // Sorting
    query = query.order(sort.column, { ascending: sort.ascending }).range(from, to);

    const { data, error, count } = await query;
    
    if (error) throw error;
    return { data, count };
  },

  /**
   * Get aggregated statistics for the dashboard
   */
  async getStats() {
    // We can run separate count queries or use a consolidated approach.
    // Supabase doesn't support complex aggregation in one simple SDK call easily without RPC.
    // We'll run parallel count queries for efficiency.
    
    const levels = ['info', 'warning', 'error'];
    
    // Total count
    const totalPromise = supabase.from('system_logs').select('*', { count: 'exact', head: true });
    
    // Level counts
    const levelPromises = levels.map(level => 
      supabase.from('system_logs').select('*', { count: 'exact', head: true }).eq('level', level)
    );

    const [totalRes, infoRes, warnRes, errorRes] = await Promise.all([
      totalPromise, 
      levelPromises[0], // info
      levelPromises[1], // warning
      levelPromises[2]  // error
    ]);

    if (totalRes.error) throw totalRes.error;

    return {
      total: totalRes.count || 0,
      info: infoRes.count || 0,
      warning: warnRes.count || 0,
      error: errorRes.count || 0
    };
  },

  /**
   * Helper to download logs as CSV
   */
  async exportLogs(filters = {}) {
    // Fetch ALL logs matching filters (ignoring pagination)
    let query = supabase.from('system_logs').select('*');

    if (filters.level && filters.level !== 'all') query = query.eq('level', filters.level);
    if (filters.search) query = query.or(`action.ilike.%${filters.search}%,user_email.ilike.%${filters.search}%`);
    // ... replicate date logic if strictly needed for export, omitting for brevity in this helper
    
    const { data, error } = await query.order('timestamp', { ascending: false }).limit(1000); // Limit to 1000 for safety
    
    if (error) throw error;

    // Convert to CSV
    if (!data || !data.length) return null;

    const headers = Object.keys(data[0]).join(',');
    const rows = data.map(row => 
      Object.values(row).map(value => {
        if (typeof value === 'object') return `"${JSON.stringify(value).replace(/"/g, '""')}"`;
        return `"${String(value).replace(/"/g, '""')}"`;
      }).join(',')
    );

    return [headers, ...rows].join('\n');
  }
};
