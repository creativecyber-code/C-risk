
import { supabase } from '@/lib/customSupabaseClient';
import { auditService } from '@/services/auditService';
import { emailService } from '@/services/emailService';

const BILLING_MANAGER_EMAIL = 'billing@creativecyber.com';

export const billingService = {
  // In a real application, this would fetch from Stripe/payment provider via Supabase functions
  async getSubscriptionDetails() {
    // Mock data for demonstration
    // Simulating fetching current state - let's assume it's stored or default to monthly
    return {
      plan: {
        id: 'pro-monthly',
        name: 'Enterprise Plan',
        price: 50000,
        currency: 'INR',
        interval: 'month', // 'month' or 'year'
        features: [
          'Unlimited Threat Models',
          'Advanced DFD Components', 
          'Full Threat Library Access',
          'Team Collaboration (Up to 10)',
          'Priority Email & Phone Support',
          'Custom Compliance Reporting'
        ]
      },
      status: 'active',
      startDate: '2025-01-15T10:00:00Z',
      nextBillingDate: '2026-02-15T10:00:00Z',
      billingPeriod: 'Monthly'
    };
  },

  async getBillingHistory() {
    // Mock invoices with INR amounts and billing periods
    return [
      { id: 'inv_1234567890', date: '2025-12-15', amount: 50000, status: 'Paid', items: ['Enterprise Plan - Monthly'], billingPeriod: 'Monthly' },
      { id: 'inv_0987654321', date: '2025-11-15', amount: 50000, status: 'Paid', items: ['Enterprise Plan - Monthly'], billingPeriod: 'Monthly' },
      { id: 'inv_1122334455', date: '2025-10-15', amount: 50000, status: 'Paid', items: ['Enterprise Plan - Monthly'], billingPeriod: 'Monthly' },
      { id: 'inv_yearly_old', date: '2024-10-15', amount: 500000, status: 'Paid', items: ['Enterprise Plan - Yearly'], billingPeriod: 'Yearly' },
      { id: 'inv_5544332211', date: '2025-09-15', amount: 50000, status: 'Paid', items: ['Enterprise Plan - Monthly'], billingPeriod: 'Monthly' }
    ];
  },

  async downloadInvoice(invoiceId, format = 'pdf') {
    return new Promise((resolve) => setTimeout(resolve, 1500));
  },

  /**
   * Switches the plan between Monthly and Yearly
   */
  async switchPlan(currentInterval) {
    // Simulate network request
    await new Promise(resolve => setTimeout(resolve, 2000));

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("User not authenticated");

    const newInterval = currentInterval === 'month' ? 'year' : 'month';
    const oldPrice = currentInterval === 'month' ? 50000 : 500000;
    const newPrice = newInterval === 'month' ? 50000 : 500000;
    const orgId = user.user_metadata?.org_id || 'org_unknown';

    // 1. Log to Audit Service
    try {
      await auditService.logAction(
        'SWITCH_PLAN',
        'Billing',
        {
          userId: user.id,
          userEmail: user.email,
          oldPlan: `Enterprise - ${currentInterval}ly`,
          newPlan: `Enterprise - ${newInterval}ly`,
          amountChange: newPrice - oldPrice,
          status: 'success'
        },
        'success'
      );
    } catch (e) {
      console.warn("Audit logging failed, but proceeding with plan switch", e);
    }

    // 2. Send Notifications
    const emailSubject = `Subscription Updated: Switched to ${newInterval === 'year' ? 'Annual' : 'Monthly'} Plan`;
    const emailBody = `
      Your subscription plan has been successfully updated.
      
      New Plan: Enterprise ${newInterval === 'year' ? 'Annual' : 'Monthly'}
      Amount: ₹${newPrice.toLocaleString('en-IN')}
      Effective Date: Immediate
      
      Thank you for your continued business.
    `;

    try {
      // To Customer
      await emailService.sendEmail(
        user.email, 
        emailSubject, 
        'billing_notification', 
        { message: emailBody }
      );

      // To Billing Manager
      await emailService.sendEmail(
        BILLING_MANAGER_EMAIL, 
        `[ADMIN] Billing Update - ${orgId}`, 
        'admin_alert', 
        { 
          user: user.email, 
          action: 'Plan Switch', 
          details: `Switched from ${currentInterval} to ${newInterval}.` 
        }
      );
    } catch (e) {
      console.warn("Email notification failed", e);
    }

    return { success: true, newInterval };
  },

  /**
   * Cancels the current subscription
   */
  async cancelPlan(reason) {
    await new Promise(resolve => setTimeout(resolve, 2000));

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("User not authenticated");
    const orgId = user.user_metadata?.org_id || 'org_unknown';

    // 1. Log to Audit
    try {
      await auditService.logAction(
        'CANCEL_PLAN',
        'Billing',
        {
          userId: user.id,
          userEmail: user.email,
          reason: reason,
          status: 'cancelled'
        },
        'warning'
      );
    } catch (e) {
      console.warn("Audit logging failed", e);
    }

    // 2. Notifications
    const subject = "Subscription Cancellation Confirmation";
    const body = `
      Your subscription has been cancelled as requested.
      
      Reason: ${reason}
      Effective Date: End of current billing cycle.
      
      We are sorry to see you go. If this was a mistake, please contact support immediately.
    `;

    try {
      // To Customer
      await emailService.sendEmail(user.email, subject, 'cancellation', { message: body });

      // To Billing Manager
      await emailService.sendEmail(
        BILLING_MANAGER_EMAIL, 
        `[ADMIN] Cancellation Alert - ${orgId}`, 
        'admin_alert', 
        { 
          user: user.email, 
          reason, 
          action: 'Cancellation' 
        }
      );
    } catch (e) {
      console.warn("Email notification failed", e);
    }

    return { success: true };
  }
};
