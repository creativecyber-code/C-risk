
import { supabase } from '@/lib/customSupabaseClient';
import { threatModelService } from './threatModelService';

// Heuristic rules to simulate AI analysis
const RULES = [
  {
    id: 'rule-encryption-rest',
    condition: (elements, connections, meta) => elements.some(e => e.type === 'store'),
    generator: () => ({
      title: 'Missing Encryption at Rest',
      category: 'Information Disclosure',
      description: 'Data stores detected without explicit encryption controls defined. Sensitive data may be readable if physical media is compromised.',
      risk: 'High',
      confidence: 92,
      reasoning: 'Analysis of "Data Store" components indicates potential storage of persistent data without associated encryption attributes.',
      mitigation: 'Implement AES-256 encryption for all data volumes and database columns containing PII.',
      compliance: ['GDPR Art. 32', 'PCI-DSS 3.4']
    })
  },
  {
    id: 'rule-auth-boundary',
    condition: (elements, connections, meta) => connections.some(c => {
      const from = elements.find(e => e.id === c.from);
      const to = elements.find(e => e.id === c.to);
      return from?.type === 'interactor' && to?.type === 'process';
    }),
    generator: () => ({
      title: 'Weak Authentication at Trust Boundary',
      category: 'Spoofing',
      description: 'External entity interacts directly with internal process without visible authentication gateway.',
      risk: 'Critical',
      confidence: 88,
      reasoning: 'Traffic flow analysis detected crossing from "Interactor" (External) to "Process" (Internal) without an intermediate "Auth Service" component.',
      mitigation: 'Implement OAuth2.0 / OIDC flow. Ensure all external calls pass through an API Gateway with strict authentication policies.',
      compliance: ['NIST 800-63', 'OWASP ASVS']
    })
  },
  {
    id: 'rule-fin-logging',
    condition: (elements, connections, meta) => meta.industry === 'Finance' || meta.industry === 'Banking',
    generator: () => ({
      title: 'Insufficient Transaction Logging',
      category: 'Repudiation',
      description: 'Financial system model detected, but comprehensive audit logging mechanisms appear undefined for high-value flows.',
      risk: 'High',
      confidence: 95,
      reasoning: 'Context-aware analysis: Model tagged as "Finance/Banking". Regulatory requirements (SOX/Basel III) mandate non-repudiation logs which are not explicitly modeled.',
      mitigation: 'Implement immutable audit trails for all state-changing transactions. Sync logs to a WORM (Write Once Read Many) storage.',
      compliance: ['SOX Section 404', 'Basel III']
    })
  },
  {
    id: 'rule-dos-api',
    condition: (elements, connections, meta) => elements.some(e => e.label.toLowerCase().includes('api')),
    generator: () => ({
      title: 'API Rate Limiting Missing',
      category: 'Denial of Service',
      description: 'API endpoints detected without visible rate-limiting or throttling controls, increasing vulnerability to DoS attacks.',
      risk: 'Medium',
      confidence: 78,
      reasoning: 'Component label analysis found "API" keywords. Standard architectural patterns require traffic shaping which is absent in current metadata.',
      mitigation: 'Configure rate limiting (token bucket algorithm) at the load balancer or API Gateway level.',
      compliance: ['OWASP API Security Top 10']
    })
  },
  {
    id: 'rule-sql-injection',
    condition: (elements, connections, meta) => elements.some(e => e.type === 'store' && (e.label.toLowerCase().includes('sql') || e.label.toLowerCase().includes('db'))),
    generator: () => ({
      title: 'Potential SQL Injection Vulnerability',
      category: 'Tampering',
      description: 'Interaction with SQL-based data store suggests risk of injection if input sanitization is not perfect.',
      risk: 'Critical',
      confidence: 85,
      reasoning: 'Technology detection: SQL database keywords found. Data flows entering this store must be validated.',
      mitigation: 'Use parameterized queries (Prepared Statements) exclusively. Implement strict input validation on all upstream data flows.',
      compliance: ['OWASP Top 10 A03:2021']
    })
  }
];

export const aiThreatService = {
  /**
   * Run the "AI" analysis engine on a specific model
   */
  async generateSuggestions(modelId) {
    // 1. Fetch full model context
    const fullModel = await threatModelService.loadModel(modelId);
    const { model, elements, connections } = fullModel;
    
    // 2. Fetch previous user actions to "learn" (filter out rejected ones)
    const { data: history } = await supabase
      .from('ai_suggestion_actions')
      .select('suggestion_signature, action')
      .eq('model_id', modelId);

    const rejectedSignatures = new Set(
      history?.filter(h => h.action === 'rejected').map(h => h.suggestion_signature)
    );

    // 3. Run heuristic engine
    const suggestions = [];
    
    RULES.forEach(rule => {
      if (rule.condition(elements, connections, model)) {
        const suggestion = {
          ...rule.generator(),
          id: `sug-${Math.random().toString(36).substr(2, 9)}`,
          signature: rule.id // In real app, hash content
        };

        // Filter if previously rejected
        if (!rejectedSignatures.has(suggestion.signature)) {
           suggestions.push(suggestion);
        }
      }
    });

    // 4. Calculate Gap Analysis
    const gapAnalysis = this.calculateGaps(suggestions, model);

    return {
      suggestions,
      gapAnalysis,
      meta: {
        analyzedAt: new Date().toISOString(),
        engineVersion: 'v2.4.0-neural',
        confidenceScore: 0.89
      }
    };
  },

  calculateGaps(suggestions, model) {
    const categories = ['Spoofing', 'Tampering', 'Repudiation', 'Information Disclosure', 'Denial of Service', 'Elevation of Privilege'];
    const covered = new Set(suggestions.map(s => s.category));
    
    return {
      missingCategories: categories.filter(c => !covered.has(c)),
      coverageScore: Math.round((covered.size / categories.length) * 100),
      riskProfile: {
        critical: suggestions.filter(s => s.risk === 'Critical').length,
        high: suggestions.filter(s => s.risk === 'High').length,
        medium: suggestions.filter(s => s.risk === 'Medium').length,
        low: suggestions.filter(s => s.risk === 'Low').length
      }
    };
  },

  /**
   * Log user feedback to improve future suggestions
   */
  async logFeedback(modelId, suggestionSignature, action, reason = null) {
    const { data: { user } } = await supabase.auth.getUser();
    
    await supabase.from('ai_suggestion_actions').insert({
      model_id: modelId,
      suggestion_signature: suggestionSignature,
      action,
      reason,
      user_id: user.id
    });
  },

  /**
   * Import accepted suggestions as real threats into the model
   */
  async importThreats(modelId, suggestions) {
    // In a real app, this would insert into a 'threats' table
    // Since our current threat model stores threats dynamically or in JSON, 
    // we'll mock this by assuming we'd add them to a 'threat_assessments' table or similar.
    
    // For now, we'll return success to simulate the UI action
    return true;
  }
};
