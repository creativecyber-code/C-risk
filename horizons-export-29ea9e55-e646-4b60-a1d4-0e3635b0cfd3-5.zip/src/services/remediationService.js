
import { supabase } from '@/lib/customSupabaseClient';

export const remediationService = {
  // Fetch all threats across all models
  async getAllThreats() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    // 1. Get User's Org safely
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('org_id')
      .eq('id', user.id)
      .maybeSingle();
      
    if (!profile?.org_id) return [];

    // 2. Fetch Threats linked to Models in that Org
    const { data, error } = await supabase
      .from('threat_assessments')
      .select(`
        *,
        threat_model:threat_models!inner(id, name, org_id),
        assignee:user_profiles(full_name, email),
        mitigation_plan:mitigation_plans!threat_assessments_mitigation_plan_id_fkey(*)
      `)
      .eq('threat_model.org_id', profile.org_id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching all threats:', error);
      throw error;
    }

    return data.map(t => ({
      ...t,
      model_name: t.threat_model?.name || 'Unknown Model',
      assigned_to_name: t.assignee?.full_name,
      assigned_to_email: t.assignee?.email,
      mitigation_status: t.mitigation_plan?.status || 'Not Started'
    }));
  },

  async updateThreatStatus(threatId, status) {
    const updates = { 
      status, 
      updated_at: new Date().toISOString() 
    };
    
    const { data, error } = await supabase
      .from('threat_assessments')
      .update(updates)
      .eq('id', threatId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async saveThreatExternalRef(threatId, toolKey, externalId, url = null) {
    const { data: threat, error: fetchError } = await supabase
      .from('threat_assessments')
      .select('external_refs')
      .eq('id', threatId)
      .single();
    
    if (fetchError) throw fetchError;

    const currentRefs = threat.external_refs || {};
    
    const updatedRefs = {
      ...currentRefs,
      [toolKey]: { id: externalId, url, synced_at: new Date().toISOString() }
    };

    const { data, error } = await supabase
      .from('threat_assessments')
      .update({ external_refs: updatedRefs })
      .eq('id', threatId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async getMitigationPlans(filters = {}) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('org_id')
      .eq('id', user.id)
      .maybeSingle();
      
    if (!profile?.org_id) return [];

    let query = supabase
      .from('mitigation_plans')
      .select(`
        *,
        threat_assessment:threat_assessments!mitigation_plans_threat_assessment_id_fkey(title, risk_score),
        owner:user_profiles!mitigation_plans_owner_id_fkey(full_name, avatar_url),
        blockers:mitigation_blockers(count)
      `)
      .eq('org_id', profile.org_id);

    if (filters.status) query = query.eq('status', filters.status);
    
    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  async getMitigation(id) {
    const { data, error } = await supabase
      .from('mitigation_plans')
      .select(`
        *,
        threat_assessment:threat_assessments!mitigation_plans_threat_assessment_id_fkey(title, risk_score, id),
        owner:user_profiles!mitigation_plans_owner_id_fkey(full_name, avatar_url, id),
        blockers:mitigation_blockers(*)
      `)
      .eq('id', id)
      .single();
    
    if (error) throw error;
    return data;
  },

  async createMitigationPlan(planData) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('org_id')
      .eq('id', user.id)
      .maybeSingle();

    if (!profile?.org_id) throw new Error("Organization context missing");

    const { data, error } = await supabase
      .from('mitigation_plans')
      .insert({ ...planData, org_id: profile.org_id })
      .select()
      .single();

    if (error) throw error;

    if (planData.threat_assessment_id) {
      await supabase
        .from('threat_assessments')
        .update({ mitigation_plan_id: data.id })
        .eq('id', planData.threat_assessment_id);
    }

    return data;
  },

  async updateMitigationPlan(id, updates) {
    const { data, error } = await supabase
      .from('mitigation_plans')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async addBlocker(mitigationId, description) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase
      .from('mitigation_blockers')
      .insert({
        mitigation_plan_id: mitigationId,
        description,
        reported_by: user.id
      })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async resolveBlocker(blockerId) {
    const { data, error } = await supabase
      .from('mitigation_blockers')
      .update({ status: 'Resolved', resolved_at: new Date().toISOString() })
      .eq('id', blockerId)
      .select()
      .single();
      
    if (error) throw error;
    return data;
  },

  async getMetrics() {
    const plans = await this.getMitigationPlans();
    
    const total = plans.length;
    const completed = plans.filter(p => p.status === 'Completed').length;
    const overdue = plans.filter(p => p.status === 'Overdue' || (p.target_date && new Date(p.target_date) < new Date() && p.status !== 'Completed')).length;
    const atRisk = plans.filter(p => p.blockers?.[0]?.count > 0).length;
    
    const velocity = completed > 0 ? (completed / 4).toFixed(1) : 0; 

    return { total, completed, overdue, atRisk, velocity, plans };
  }
};
