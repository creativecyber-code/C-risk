
import { supabase } from '@/lib/customSupabaseClient';

export const securityConfigService = {
  async getSettings(orgId) {
    if (!orgId) throw new Error("Organization ID is required");

    // Use maybeSingle() to avoid PGRST116 error when no settings exist yet
    const { data, error } = await supabase
      .from('security_settings')
      .select('*')
      .eq('org_id', orgId)
      .maybeSingle();

    if (error) {
      console.error('Error fetching security settings:', error);
      throw error;
    }

    // Return default structure if no settings exist yet
    return data || {
      org_id: orgId,
      sso_enabled: false,
      sso_provider: '',
      sso_config: {},
      mfa_enabled: false,
      mfa_methods: ['totp'],
      mfa_enforcement: 'optional'
    };
  },

  async saveSettings(orgId, settings) {
    if (!orgId) throw new Error("Organization ID is required");

    // Check if exists to determine insert or update (upsert)
    // Use maybeSingle() here as well to avoid errors if it doesn't exist
    const { data: existing, error: checkError } = await supabase
      .from('security_settings')
      .select('id')
      .eq('org_id', orgId)
      .maybeSingle();

    if (checkError) throw checkError;

    let result;
    const payload = {
      ...settings,
      org_id: orgId,
      updated_at: new Date().toISOString(),
      updated_by: (await supabase.auth.getUser()).data.user?.id
    };

    // Remove ID from payload to avoid primary key conflicts on insert if undefined
    delete payload.id; 

    if (existing) {
      result = await supabase
        .from('security_settings')
        .update(payload)
        .eq('org_id', orgId)
        .select()
        .single();
    } else {
      result = await supabase
        .from('security_settings')
        .insert(payload)
        .select()
        .single();
    }

    if (result.error) throw result.error;
    return result.data;
  },

  async testSSOConnection(provider, config) {
    // Simulate SSO connection test
    // In a real app, this might try to initiate an OAuth flow or ping a metadata URL
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (!config.client_id || !config.client_secret) {
          reject(new Error("Missing Client ID or Secret"));
          return;
        }
        if (provider === 'saml' && !config.metadata_url) {
          reject(new Error("Missing Metadata URL for SAML"));
          return;
        }
        resolve({ success: true, message: `Successfully connected to ${provider}` });
      }, 1500);
    });
  },

  async validateMFAMethods(methods) {
    // Simple validation logic
    if (!methods || methods.length === 0) {
      throw new Error("At least one MFA method must be selected.");
    }
    return true;
  }
};
