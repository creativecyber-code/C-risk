
import { supabase } from '@/lib/customSupabaseClient';

class ConnectivityService {
  constructor() {
    this.listeners = new Set();
    this.isOnline = navigator.onLine;
    this.serverStatus = 'unknown'; // 'healthy', 'degraded', 'unreachable'
    this.retryCount = 0;
    this.maxRetries = 5;
    
    // Initialize listeners
    window.addEventListener('online', this.handleOnline);
    window.addEventListener('offline', this.handleOffline);
    
    // Start health check loop
    this.checkHealth();
    setInterval(() => this.checkHealth(), 30000); // Check every 30s
  }

  subscribe(callback) {
    this.listeners.add(callback);
    // Initial callback
    callback({ online: this.isOnline, server: this.serverStatus });
    return () => this.listeners.delete(callback);
  }

  notify() {
    const status = { online: this.isOnline, server: this.serverStatus };
    this.listeners.forEach(cb => cb(status));
  }

  handleOnline = () => {
    this.isOnline = true;
    this.checkHealth(); // Immediate check on reconnection
    this.notify();
  };

  handleOffline = () => {
    this.isOnline = false;
    this.notify();
  };

  async checkHealth() {
    if (!this.isOnline) {
      this.serverStatus = 'unreachable';
      this.notify();
      return;
    }

    try {
      // Use Supabase simple query as health check since we don't have a dedicated backend endpoint
      const { error } = await supabase.from('organizations').select('count').limit(1).single();
      
      if (error) throw error;
      
      this.serverStatus = 'healthy';
      this.retryCount = 0;
    } catch (e) {
      console.warn('Health check failed:', e);
      this.serverStatus = 'degraded';
      
      // Exponential backoff for retry if critical
      if (this.retryCount < this.maxRetries) {
        const delay = Math.min(1000 * Math.pow(2, this.retryCount), 30000);
        this.retryCount++;
        setTimeout(() => this.checkHealth(), delay);
      }
    }
    
    this.notify();
  }

  // Helper for requests with timeout
  async fetchWithTimeout(resource, options = {}) {
    const { timeout = 8000 } = options;
    
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    
    try {
      const response = await fetch(resource, {
        ...options,
        signal: controller.signal
      });
      clearTimeout(id);
      return response;
    } catch (error) {
      clearTimeout(id);
      throw error;
    }
  }

  getStatus() {
    return { online: this.isOnline, server: this.serverStatus };
  }
}

export const connectivityService = new ConnectivityService();
