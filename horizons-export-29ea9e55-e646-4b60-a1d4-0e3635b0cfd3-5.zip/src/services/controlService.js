
import { supabase } from '@/lib/customSupabaseClient';

/**
 * Service for managing Internal Controls, Evidence, and Audits.
 */
export const controlService = {

  async getControlDetail(id, orgId) {
    if (!id || !orgId) throw new Error("Control ID and Org ID are required");

    const { data, error } = await supabase
      .from('internal_controls')
      .select(`
        *,
        owner:owner_id (
          id,
          email,
          raw_user_meta_data
        )
      `)
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (error) throw error;
    return data;
  },

  async getControlEvidence(controlId, orgId) {
    const { data, error } = await supabase
      .from('compliance_evidence')
      .select(`
        *,
        provider:provided_by (
            id,
            email,
            raw_user_meta_data
        )
      `)
      .eq('control_id', controlId)
      .eq('org_id', orgId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  async addEvidence(payload) {
    const { data, error } = await supabase
      .from('compliance_evidence')
      .insert({
        ...payload,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        status: 'submitted'
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteEvidence(evidenceId) {
    const { error } = await supabase
      .from('compliance_evidence')
      .delete()
      .eq('id', evidenceId);

    if (error) throw error;
  },

  async getControlAudits(controlId, orgId) {
    const { data, error } = await supabase
      .from('control_audits')
      .select(`
        *,
        auditor:audited_by (
            id,
            email,
            raw_user_meta_data
        )
      `)
      .eq('control_id', controlId)
      .eq('org_id', orgId)
      .order('audited_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  async addAuditResult(payload) {
    const { data, error } = await supabase
      .from('control_audits')
      .insert({
        ...payload,
        audited_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteAuditResult(auditId) {
    const { error } = await supabase
      .from('control_audits')
      .delete()
      .eq('id', auditId);

    if (error) throw error;
  }
};
