
import { supabase } from '@/lib/customSupabaseClient';

/**
 * Service to aggregate "Executive Decisions" from multiple modules:
 * 1. Security Gates (Architecture Review)
 * 2. Workflow Approvals (Business Initiation)
 */
export const decisionService = {

  // Fetch all pending decisions for the organization
  async getPendingDecisions() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('org_id')
      .eq('id', user.id)
      .single();
      
    if (!profile?.org_id) return [];
    const orgId = profile.org_id;

    // 1. Fetch Security Gates (Simulating pending architecture decisions)
    // In a real scenario, we'd join with business_applications to filter by org_id
    // For now, we assume RLS handles visibility or we check app ownership
    const { data: securityGates, error: gateError } = await supabase
      .from('security_gates')
      .select(`
        id,
        gate_type,
        status,
        created_at,
        application:business_applications(name, org_id)
      `)
      .in('status', ['PENDING', 'IN_PROGRESS', 'REVIEW_REQUIRED']) // Fetch actionable statuses
      .order('created_at', { ascending: false });

    // Filter purely by org in JS if join filtering is tricky with current policies
    const orgGates = (securityGates || []).filter(g => g.application?.org_id === orgId);

    // 2. Fetch Business Initiation Approvals
    const { data: workflowApprovals, error: workflowError } = await supabase
      .from('workflow_approvals')
      .select(`
        id,
        stage,
        status,
        created_at,
        sla_deadline,
        application:business_applications(name, org_id)
      `)
      .eq('status', 'PENDING')
      .order('created_at', { ascending: false });

    const orgWorkflows = (workflowApprovals || []).filter(w => w.application?.org_id === orgId);

    // 3. Normalize and Combine
    const gateItems = orgGates.map(g => ({
      id: g.id,
      source: 'Security Gate',
      title: `${mapGateType(g.gate_type)} Review`,
      description: `Security gate review for ${g.application?.name}`,
      status: g.status,
      severity: 'High', // Security gates are usually high priority
      date: g.created_at,
      actionRequired: 'Approve/Reject',
      rawType: 'gate'
    }));

    const workflowItems = orgWorkflows.map(w => ({
      id: w.id,
      source: 'Business Initiation',
      title: `${w.stage} Approval`,
      description: `Workflow stage approval for ${w.application?.name}`,
      status: w.status,
      severity: 'Medium',
      date: w.created_at,
      dueDate: w.sla_deadline,
      actionRequired: 'Sign-off',
      rawType: 'workflow'
    }));

    return [...gateItems, ...workflowItems].sort((a, b) => new Date(b.date) - new Date(a.date));
  },

  // Approve a decision item
  async approveDecision(item) {
    if (item.rawType === 'gate') {
      const { error } = await supabase
        .from('security_gates')
        .update({ status: 'APPROVED', updated_at: new Date().toISOString() })
        .eq('id', item.id);
      return !error;
    } else if (item.rawType === 'workflow') {
      const { data: { user } } = await supabase.auth.getUser();
      const { error } = await supabase
        .from('workflow_approvals')
        .update({ 
          status: 'APPROVED', 
          approved_by: user.id, 
          approved_at: new Date().toISOString() 
        })
        .eq('id', item.id);
      return !error;
    }
    return false;
  },

  // Reject a decision item
  async rejectDecision(item) {
    if (item.rawType === 'gate') {
      const { error } = await supabase
        .from('security_gates')
        .update({ status: 'REJECTED', updated_at: new Date().toISOString() })
        .eq('id', item.id);
      return !error;
    } else if (item.rawType === 'workflow') {
      const { data: { user } } = await supabase.auth.getUser();
      const { error } = await supabase
        .from('workflow_approvals')
        .update({ 
          status: 'REJECTED', 
          approved_by: user.id, 
          approved_at: new Date().toISOString() 
        })
        .eq('id', item.id);
      return !error;
    }
    return false;
  }
};

// Helper
function mapGateType(type) {
  const map = {
    'ARCHITECTURE': 'Architecture',
    'APPSEC': 'AppSec',
    'TPRM': 'Vendor Risk',
    'CONTRACT': 'Legal'
  };
  return map[type] || type;
}
