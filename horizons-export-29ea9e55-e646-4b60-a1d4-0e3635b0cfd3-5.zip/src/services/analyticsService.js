
import { supabase } from '@/lib/customSupabaseClient';
import { startOfMonth, format, subMonths, parseISO, getMonth, getYear } from 'date-fns';
import { getRiskLevel } from '@/utils/riskCalculations';

export const analyticsService = {
  async getAnalyticsData() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    // 1. Fetch all assessments to calculate aggregated metrics
    const { data: allRisks, error: risksError } = await supabase
      .from('threat_assessments')
      .select(`
        *,
        model:threat_models!inner(name, org_id)
      `);

    if (risksError) throw risksError;

    // 2. Fetch specific subsets
    const acceptedRisks = allRisks.filter(r => r.status === 'Accepted');
    
    // 3. Generate Report Data
    return this.generateReportData(acceptedRisks, allRisks);
  },

  generateReportData(acceptedRisks, allRisks) {
    const now = new Date();
    
    // --- FINANCIAL METRICS (FAIR) ---
    const totalALE = allRisks.reduce((sum, r) => sum + (r.ale || 0), 0);
    const topFinancialRisks = [...allRisks]
      .sort((a, b) => (b.ale || 0) - (a.ale || 0))
      .slice(0, 5)
      .map(r => ({
        name: r.title,
        value: r.ale || 0
      }));

    // --- DECISION POINTS ---
    const decisionPoints = acceptedRisks.map(risk => {
      const level = getRiskLevel(risk.risk_score);
      return {
        id: risk.id,
        title: risk.title,
        impact: level.label,
        owner: 'Risk Owner',
        deadline: new Date(risk.updated_at).toLocaleDateString(),
        justification: risk.justification,
        modelName: risk.model?.name,
        isReal: true,
        financialImpact: risk.ale // Add financial context to decision
      };
    });

    if (decisionPoints.length === 0) {
      decisionPoints.push(
         { id: 'demo-1', title: 'Pending: Vendor Security Exception', impact: 'High', deadline: '2025-10-20', owner: 'CISO', isReal: false }
      );
    }
    
    // --- MOCK / TREND DATA (Partial) ---
    const trendData = Array.from({ length: 6 }).map((_, i) => {
      const d = subMonths(now, 5 - i);
      // Simulate historical ALE (randomized slightly around current total for demo effect)
      const historicalALE = i === 5 ? totalALE : totalALE * (0.8 + Math.random() * 0.4);
      
      return {
        name: format(d, 'MMM'),
        threats: Math.floor(Math.random() * 20) + 10,
        riskScore: (Math.random() * 3 + 4).toFixed(1),
        projectedLoss: Math.floor(historicalALE)
      };
    });

    const riskOwnership = [
      { name: 'Engineering', value: 45, color: '#3b82f6' },
      { name: 'Product', value: 20, color: '#10b981' },
      { name: 'IT Ops', value: 25, color: '#f59e0b' },
      { name: 'Third Party', value: 10, color: '#64748b' }
    ];

    const investmentData = [
      { name: 'Q1', investment: 20000, riskReduction: 15 },
      { name: 'Q2', investment: 35000, riskReduction: 35 },
      { name: 'Q3', investment: 45000, riskReduction: 60 },
      { name: 'Q4 (Proj)', investment: 50000, riskReduction: 85 },
    ];

    const complianceData = [
      { name: 'GDPR', score: 92, status: 'Compliant', gap: 'None' },
      { name: 'PCI-DSS', score: 78, status: 'At Risk', gap: 'Encryption' },
      { name: 'HIPAA', score: 88, status: 'Compliant', gap: 'Logs' },
      { name: 'SOC2 Type II', score: 65, status: 'Non-Compliant', gap: 'Access Reviews' }
    ];

    const mitigationStats = [
      { name: 'Open', value: 12, color: '#ef4444' },
      { name: 'In Progress', value: 8, color: '#f59e0b' },
      { name: 'Completed', value: 24, color: '#10b981' },
      { name: 'Verified', value: 15, color: '#3b82f6' }
    ];

    return {
      summary: {
        financialExposure: totalALE, // Real Data
        riskScore: 7.2,
        activeThreats: allRisks.length,
        complianceScore: 81
      },
      businessImpact: {
        financial: `Total Annual Loss Expectancy (ALE) calculated at $${(totalALE/1000).toFixed(1)}k based on FAIR model.`,
        compliance: "GDPR fine risk elevated due to cookie consent implementation gap.",
        reputation: "Moderate risk of brand damage if API vulnerabilities are exploited.",
        operational: "Low risk of downtime; redundancy systems are functioning."
      },
      heatmapData: {
        categories: ['Financial', 'Privacy', 'Safety', 'Operational'],
        grid: [{ name: 'Critical', Financial: 1, Privacy: 0, Safety: 0, Operational: 0 }, { name: 'High', Financial: 2, Privacy: 1, Safety: 0, Operational: 1 }, { name: 'Medium', Financial: 3, Privacy: 2, Safety: 1, Operational: 0 }, { name: 'Low', Financial: 0, Privacy: 5, Safety: 0, Operational: 2 }]
      },
      topFinancialRisks, // New Field
      riskOwnership,
      investmentData,
      decisionPoints,
      threats: allRisks, // Return all risks for CSV export if needed
      trendData,
      complianceData,
      mitigationStats
    };
  }
};
