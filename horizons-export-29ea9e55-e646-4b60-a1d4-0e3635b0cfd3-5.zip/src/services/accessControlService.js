
import { supabase } from '@/lib/customSupabaseClient';

export const accessControlService = {
  // --- User Management ---
  
  /**
   * Fetches all users belonging to a specific organization.
   * @param {string} orgId - The UUID of the organization
   */
  async getOrgUsers(orgId) {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    
    if (!orgId) {
      console.warn('[AccessControl] getOrgUsers called with missing orgId');
      return [];
    }
    
    if (!uuidRegex.test(orgId)) {
      console.error(`[AccessControl] Invalid orgId format: ${orgId}`);
      throw new Error("Invalid Organization ID format");
    }

    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('org_id', orgId)
        .order('full_name', { ascending: true })
        .order('email', { ascending: true });
        
      if (error) {
        console.error('[AccessControl] Supabase error fetching users:', error);
        throw new Error(error.message);
      }
      
      return data || [];
    } catch (err) {
      console.error('[AccessControl] Service error:', err);
      throw err;
    }
  },

  /**
   * Fetches pending invitations for an organization.
   * @param {string} orgId 
   */
  async getOrgInvites(orgId) {
    if (!orgId) return [];
    
    try {
      const { data, error } = await supabase
        .from('organization_invites')
        .select('*')
        .eq('org_id', orgId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (err) {
      console.error('[AccessControl] Error fetching invites:', err);
      return [];
    }
  },

  async inviteUser({ email, role, orgId }) {
    if (!email || !orgId) throw new Error("Email and Org ID are required");

    // Check if invite already exists
    const { data: existing } = await supabase
      .from('organization_invites')
      .select('id')
      .eq('org_id', orgId)
      .eq('email', email)
      .maybeSingle();

    if (existing) {
      throw new Error("An invitation has already been sent to this email.");
    }

    const { data, error } = await supabase
      .from('organization_invites')
      .insert({
        email,
        role,
        org_id: orgId,
        token: Math.random().toString(36).substring(7),
        expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days
        created_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateUser(userId, updates, orgId) {
    if (!userId) throw new Error("User ID required for update");

    const { data, error } = await supabase
      .from('user_profiles')
      .update(updates)
      .eq('id', userId)
      .eq('org_id', orgId)
      .select();

    if (error) throw error;
    return data;
  },

  async removeUserFromOrg(userId) {
     const { error } = await supabase
       .from('user_profiles')
       .update({ org_id: null }) // Unlink user from org
       .eq('id', userId);
       
     if (error) throw error;
     return true;
  },
  
  async revokeInvite(inviteId) {
    const { error } = await supabase
      .from('organization_invites')
      .delete()
      .eq('id', inviteId);
      
    if (error) throw error;
    return true;
  },

  async bulkImportUsers(users, orgId) {
    let success = 0;
    let failed = 0;
    for (const user of users) {
      try {
        await this.inviteUser({ ...user, orgId });
        success++;
      } catch (e) {
        console.error("Bulk import failed for user:", user, e);
        failed++;
      }
    }
    return { success, failed };
  },

  // --- Organization Helpers ---
  
  async getOrgSettings(orgId) {
    if (!orgId) throw new Error("Organization ID is required");

    const { data, error } = await supabase
      .from('organizations')
      .select('*')
      .eq('id', orgId)
      .maybeSingle();

    if (error) throw error;
    return data;
  }
};
