
import { supabase } from '@/lib/customSupabaseClient';
import { threatModelService } from '@/services/threatModelService';

export const versionControlService = {
  /**
   * Creates a new version snapshot of the current model state
   */
  async createVersion(modelId, { tag, description, isAutoSave = false }) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("Not authenticated");

    // 1. Fetch current full state
    const fullState = await threatModelService.loadModel(modelId);
    
    // 2. Prepare snapshot payload
    const snapshot = {
      model: fullState.model,
      elements: fullState.elements,
      connections: fullState.connections,
      metadata: {
        elementCount: fullState.elements.length,
        connectionCount: fullState.connections.length,
        generatedAt: new Date().toISOString()
      }
    };

    // 3. Insert version
    const { data, error } = await supabase
      .from('threat_model_versions')
      .insert({
        model_id: modelId,
        version_tag: tag || `v${Date.now()}`,
        description: description || (isAutoSave ? 'Auto-generated version' : 'Manual snapshot'),
        snapshot_data: snapshot,
        created_by: user.id
      })
      .select()
      .single();

    if (error) {
      console.error('Error creating version:', error);
      throw error;
    }
    return data;
  },

  /**
   * Get version history for a model
   */
  async getVersions(modelId) {
    if (!modelId) return [];

    // Correctly query with expanded user profile data
    // Note: We use the FK 'created_by' which points to user_profiles
    // Removed 'email' as it does not exist in user_profiles table
    const { data, error } = await supabase
      .from('threat_model_versions')
      .select(`
        *,
        created_by_profile:created_by(full_name, avatar_url)
      `)
      .eq('model_id', modelId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching versions:', error);
      throw error;
    }
    return data;
  },

  /**
   * Restore a version (Overwrite live state or Branch)
   * if asNewModel is true, it creates a new model "branch"
   */
  async restoreVersion(versionId, asNewModel = false, newName = null) {
    // 1. Get snapshot
    const { data: version, error: vError } = await supabase
      .from('threat_model_versions')
      .select('*')
      .eq('id', versionId)
      .single();

    if (vError) throw vError;

    const snapshot = version.snapshot_data;

    if (asNewModel) {
      // Branching: Create new model from snapshot
      const newModel = await threatModelService.createModel(
        newName || `${snapshot.model.name} (Branch from ${version.version_tag})`,
        `Branched from version ${version.version_tag}. ${version.description}`
      );
      
      // Populate new model
      await threatModelService.saveModel(newModel.id, {
        elements: snapshot.elements,
        connections: snapshot.connections
      });
      
      return newModel;
    } else {
      // Rollback: Overwrite existing model
      await threatModelService.saveModel(version.model_id, {
        elements: snapshot.elements,
        connections: snapshot.connections
      });
      return { id: version.model_id };
    }
  },

  /**
   * Compare two versions to generate a diff
   */
  async compareVersions(versionIdA, versionIdB) {
    // Fetch both full version records
    const [vA, vB] = await Promise.all([
      this.fetchVersionData(versionIdA),
      this.fetchVersionData(versionIdB)
    ]);

    // Calculate diff using the snapshot data inside
    const diff = this.calculateDiff(vA.snapshot_data, vB.snapshot_data);

    // Return diff ALONG with the full version metadata (for display purposes)
    return {
      ...diff,
      versionA: vA, 
      versionB: vB
    };
  },

  async fetchVersionData(id) {
    const { data, error } = await supabase
      .from('threat_model_versions')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) throw error;
    return data;
  },

  calculateDiff(snapA, snapB) {
    // Ensure inputs are valid
    const elementsA = snapA?.elements || [];
    const elementsB = snapB?.elements || [];
    const connectionsA = snapA?.connections || [];
    const connectionsB = snapB?.connections || [];

    // 1. Elements Diff
    const addedElements = elementsB.filter(b => !elementsA.find(a => a.id === b.id));
    const removedElements = elementsA.filter(a => !elementsB.find(b => b.id === a.id));
    const modifiedElements = elementsB.filter(b => {
      const a = elementsA.find(prev => prev.id === b.id);
      if (!a) return false;
      return a.x !== b.x || a.y !== b.y || a.label !== b.label || a.type !== b.type;
    });

    // 2. Connections Diff
    const addedConnections = connectionsB.filter(b => !connectionsA.find(a => a.id === b.id));
    const removedConnections = connectionsA.filter(a => !connectionsB.find(b => b.id === a.id));

    // 3. Stats
    const stats = {
      elements: { added: addedElements.length, removed: removedElements.length, modified: modifiedElements.length },
      connections: { added: addedConnections.length, removed: removedConnections.length },
      riskScoreDelta: 0 
    };

    return {
      stats,
      changes: {
        elements: { added: addedElements, removed: removedElements, modified: modifiedElements },
        connections: { added: addedConnections, removed: removedConnections }
      }
    };
  }
};
