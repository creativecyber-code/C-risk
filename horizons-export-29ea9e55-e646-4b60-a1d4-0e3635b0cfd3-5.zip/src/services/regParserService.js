
import { supabase } from '@/lib/customSupabaseClient';
import { auditService } from './auditService';
import { complianceService } from './complianceService';

// Extended Mock data for RBI Integration
const MOCK_RBI_CIRCULARS = [
  {
    id: 'rbi-md-001',
    title: 'Master Direction on Digital Payment Security Controls',
    reference: 'RBI/2021-22/18',
    date: '2024-02-18',
    category: 'Payments',
    url: 'https://rbi.org.in/scripts/BS_ViewMasDirections.aspx?id=12032'
  },
  {
    id: 'rbi-md-002',
    title: 'Master Direction - Information Technology Framework for the NBFC Sector',
    reference: 'RBI/DNBS/2016-17/53',
    date: '2017-06-08',
    category: 'NBFC IT',
    url: 'https://rbi.org.in/scripts/NotificationUser.aspx?Id=10495'
  },
  {
    id: 'rbi-cir-003',
    title: 'Cyber Security Framework in Banks',
    reference: 'RBI/2016-17/109',
    date: '2016-06-02',
    category: 'Cyber Security',
    url: 'https://rbi.org.in/scripts/NotificationUser.aspx?Id=10435'
  }
];

export const regParserService = {
  // 1. Fetch from External Source (Mock)
  async fetchRecentRBICirculars() {
    await new Promise(resolve => setTimeout(resolve, 800));
    return MOCK_RBI_CIRCULARS;
  },

  // 2. Import/Upload Document
  async importDocument(fileOrMeta, type = 'UPLOAD') {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("User not authenticated");

    const orgId = await complianceService.getOrgId();
    if (!orgId) throw new Error("Organization ID not found");

    let title = 'Untitled Document';
    let fileUrl = null;
    let reference = 'MANUAL-UPLOAD';

    if (type === 'UPLOAD' || type === 'IMPORT') {
        const file = fileOrMeta;
        if (!file) throw new Error("No file provided for upload.");
        
        // VALIDATION: Ensure title exists, fallback to filename or default
        title = file.name || 'Untitled Document';
        
        // Sanitize filename for storage
        const safeName = title.replace(/[^a-z0-9.]/gi, '_').toLowerCase();
        const fileName = `${orgId}/reg-parser/${Date.now()}_${safeName}`;

        // Attempt upload but proceed even if storage not configured for demo
        try {
            const { error: uploadError } = await supabase.storage
                .from('compliance-docs')
                .upload(fileName, file);
                
            if (uploadError) {
                 console.warn("Storage upload failed (expected in demo without bucket setup):", uploadError);
            } else {
                 // If storage not configured, we just use a fake URL for the DB record
                 fileUrl = `https://storage.example.com/${fileName}`;
            }
        } catch (err) {
            console.warn("Storage upload exception:", err);
        }
    } else {
        // Handle RBI Web or other sources
        title = fileOrMeta?.title || 'Untitled Circular';
        reference = fileOrMeta?.reference || 'UNKNOWN-REF';
        fileUrl = fileOrMeta?.url || '#';
    }

    // VALIDATION: Final check before DB Insert to prevent NULL constraint violation
    if (!title || title.trim() === '') {
        title = 'Untitled Document';
    }

    const { data, error } = await supabase
        .from('compliance_documents')
        .insert({
            org_id: orgId,
            title: title,
            file_url: fileUrl,
            source: type,
            reference_number: reference,
            status: 'UPLOADED',
            uploaded_by: user.id
        })
        .select()
        .single();

    if (error) {
        console.error("DB Insert Error:", error);
        throw new Error(`Failed to create document record: ${error.message}`);
    }

    await auditService.logAction('REG_DOC_IMPORT', data.id, { title, type });
    return data;
  },

  // NEW: Process structured data from Excel/CSV
  async processStructuredImport(docId, mappedData) {
    if (!docId) throw new Error("Document ID is required for processing.");
    if (!mappedData || !Array.isArray(mappedData) || mappedData.length === 0) {
        throw new Error("No data provided for import.");
    }

    // 1. Update doc status
    await supabase
        .from('compliance_documents')
        .update({ status: 'PARSING' }) // Brief transition state
        .eq('id', docId);

    // 2. Transform mapped data to extracts
    // VALIDATION: Filter out rows that are missing CRITICAL fields to prevent SQL constraints errors
    const validRows = mappedData.filter(row => 
        row.section_ref && 
        row.requirement_text && 
        row.suggested_control_name
    );

    if (validRows.length === 0) {
        // Revert status
        await supabase.from('compliance_documents').update({ status: 'ERROR' }).eq('id', docId);
        throw new Error("Validation Failed: All rows are missing required fields (Reference, Obligation, or Control Statement).");
    }

    const extracts = validRows.map(row => ({
        document_id: docId,
        section_ref: row.section_ref, // Required
        original_obligation_text: row.requirement_text, // Required
        requirement_text: row.requirement_text, // Required
        suggested_control_name: row.suggested_control_name, // Required
        
        // Optional fields with defaults
        control_type: row.control_type || 'Preventive',
        suggested_category: row.suggested_category || 'General',
        risk_objective: row.risk_objective || 'Compliance',
        evidence_requirements: row.evidence_requirements ? (typeof row.evidence_requirements === 'string' ? row.evidence_requirements.split(',').map(s=>s.trim()) : [row.evidence_requirements]) : [],
        suggested_control_code: `IMP-${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
        confidence_score: 1.0, // High confidence since it's manual import
        tags: ['IMPORTED', 'MANUAL'],
        status: 'PENDING'
    }));

    // 3. Insert extracts
    // Supabase insert has limits, chunk it if large (mocking logic here)
    const { error } = await supabase
        .from('regulatory_extracts')
        .insert(extracts);

    if (error) {
        console.error("Extract Import Error:", error);
        throw new Error(`Failed to save extracted controls: ${error.message}`);
    }

    // 4. Finalize Doc Status
    await supabase
        .from('compliance_documents')
        .update({ status: 'PARSED', parsed_at: new Date().toISOString() })
        .eq('id', docId);

    return extracts.length;
  },

  async getDocuments() {
    const orgId = await complianceService.getOrgId();
    if (!orgId) return [];
    
    const { data, error } = await supabase
        .from('compliance_documents')
        .select('*')
        .eq('org_id', orgId)
        .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data;
  },

  // 3. Enhanced AI Parsing (Simulated)
  async parseDocument(docId) {
    // Update status
    await supabase
        .from('compliance_documents')
        .update({ status: 'PARSING' })
        .eq('id', docId);

    // Simulate AI Processing time for "Deep Parsing"
    await new Promise(resolve => setTimeout(resolve, 2500));

    // Get Doc details for context
    const { data: doc } = await supabase.from('compliance_documents').select('*').eq('id', docId).single();
    
    // Advanced Extraction Logic (Mocked)
    let extracts = [];
    const isPayments = doc.title && doc.title.toLowerCase().includes('payment');
    const isNBFC = doc.title && doc.title.toLowerCase().includes('nbfc');
    
    if (isPayments) {
        extracts = [
            { 
                section: 'Para 2.1', 
                raw_text: 'Regulated entities shall ensure that all digital payment transactions are authenticated using at least two factors of authentication (2FA).',
                obligation: 'Ensure 2FA for all digital payment transactions.',
                control_statement: 'Implement and enforce Two-Factor Authentication (2FA) for all digital payment initiation and validation flows.',
                type: 'Preventive',
                category: 'Technology',
                risk_objective: 'Mitigate risk of unauthorized transaction processing and account takeover.',
                evidence: ['Auth Logic Configuration', '2FA Provider Logs', 'Transaction Flow Diagram'],
                condition: 'Applicable to all digital payment transactions.',
                code: 'DP-AUTH-01' 
            },
            { 
                section: 'Para 3.4', 
                raw_text: 'Card data must be encrypted at rest using industry standard algorithms (e.g., AES-256) and keys must be rotated annually.',
                obligation: 'Encrypt card data at rest and rotate keys annually.',
                control_statement: 'Configure database level encryption for PAN/Track data using AES-256 and implement automated key rotation schedule.',
                type: 'Preventive',
                category: 'Technology',
                risk_objective: 'Prevent data leakage and compromise of sensitive cardholder data.',
                evidence: ['Encryption Configuration Screenshot', 'Key Rotation Logs', 'Data Classification Policy'],
                condition: 'If card data is stored.',
                code: 'DP-ENC-02' 
            }
        ];
    } else if (isNBFC) {
        extracts = [
            { 
                section: 'Section A.1', 
                raw_text: 'The Board shall approve an Information Security Policy.',
                obligation: 'Board approval of IS Policy.',
                control_statement: 'Obtain formal Board of Directors approval for the comprehensive Information Security Policy annually.',
                type: 'Preventive',
                category: 'Governance',
                risk_objective: 'Ensure executive oversight and strategic alignment of security posture.',
                evidence: ['Board Meeting Minutes', 'Signed IS Policy Document'],
                condition: 'Annual Requirement',
                code: 'NBFC-GOV-01' 
            }
        ];
    } else {
        extracts = [
            { 
                section: 'General', 
                raw_text: 'Entities must report cyber security incidents to RBI within 6 hours.',
                obligation: 'Report incidents within 6 hours.',
                control_statement: 'Establish an Incident Response procedure that mandates reporting of qualified cyber incidents to RBI CSITE within 6 hours of detection.',
                type: 'Corrective',
                category: 'Reporting & Disclosure',
                risk_objective: 'Ensure timely regulatory awareness and coordinated systemic response.',
                evidence: ['Incident Response Plan', 'Mock Drill Reports', 'Reporting Template'],
                condition: 'Upon detection of qualifying incident',
                code: 'GEN-REP-01' 
            }
        ];
    }

    // Save extracts
    const { error } = await supabase
        .from('regulatory_extracts')
        .insert(extracts.map(e => ({
            document_id: docId,
            section_ref: e.section,
            original_obligation_text: e.raw_text,
            requirement_text: e.obligation,
            suggested_control_name: e.control_statement,
            suggested_control_code: `${doc.reference_number || 'RBI'}-${e.code}`,
            suggested_category: e.category,
            control_type: e.type,
            risk_objective: e.risk_objective,
            evidence_requirements: e.evidence,
            conditionality: e.condition,
            confidence_score: 0.88 + (Math.random() * 0.1),
            tags: ['RBI', doc.reference_number || 'UNKNOWN', e.type, e.category],
            status: 'PENDING'
        })));

    if (error) throw error;

    await supabase
        .from('compliance_documents')
        .update({ status: 'PARSED', parsed_at: new Date().toISOString() })
        .eq('id', docId);

    return true;
  },

  async getExtracts(docId) {
    const { data, error } = await supabase
        .from('regulatory_extracts')
        .select('*')
        .eq('document_id', docId)
        .order('section_ref', { ascending: true });
    if (error) throw error;
    return data;
  },

  async approveExtract(extractId) {
    const orgId = await complianceService.getOrgId();
    const { data: { user } } = await supabase.auth.getUser();

    const { data: extract } = await supabase
        .from('regulatory_extracts')
        .select('*')
        .eq('id', extractId)
        .single();

    if (!extract) throw new Error("Extract not found");

    const richDescription = `
Original Mandate: ${extract.original_obligation_text || 'N/A'}
Risk Objective: ${extract.risk_objective || 'N/A'}
Type: ${extract.control_type || 'N/A'}
Evidence Required: ${Array.isArray(extract.evidence_requirements) ? extract.evidence_requirements.join(', ') : extract.evidence_requirements || 'N/A'}
    `.trim();

    const { data: control, error: controlError } = await supabase
        .from('internal_controls')
        .insert({
            org_id: orgId,
            code: extract.suggested_control_code,
            name: extract.suggested_control_name,
            description: richDescription,
            status: 'Draft',
            test_frequency: 'Annual',
            owner_id: user.id
        })
        .select()
        .single();

    if (controlError) throw controlError;

    await supabase
        .from('regulatory_extracts')
        .update({ status: 'APPROVED' })
        .eq('id', extractId);

    // Threat Mapping
    const keywords = extract.suggested_control_name.split(' ').filter(w => w.length > 4);
    let query = supabase.from('threat_assessments').select('id, title').neq('status', 'Closed');
    
    const { data: threats } = await query;
    const mappedThreats = threats.filter(t => 
        keywords.some(k => t.title.toLowerCase().includes(k.toLowerCase()))
    );

    if (mappedThreats.length > 0) {
        await supabase.from('internal_control_risks').insert(
            mappedThreats.map(t => ({
                internal_control_id: control.id,
                threat_assessment_id: t.id
            }))
        );
    }
    
    await auditService.logAction('CONTROL_GENERATED', control.id, { source_extract: extractId });

    return { control, mappedThreatsCount: mappedThreats.length };
  },

  async approveAllExtracts(docId) {
    const extracts = await this.getExtracts(docId);
    const pending = extracts.filter(e => e.status === 'PENDING');
    let count = 0;
    for (const extract of pending) {
        try {
            await this.approveExtract(extract.id);
            count++;
        } catch (e) {
            console.error("Failed to approve extract:", e);
        }
    }
    return count;
  }
};
