
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { businessInitService } from './businessInitService';
import { supabase } from '@/lib/customSupabaseClient';
import { appFactory } from '@/test/factories';

// Test Suites 3, 4, 5, 8, 11
describe('businessInitService', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('createApplication (Data Classification & Initial Scoping)', () => {
    it('should calculate "High" inherent risk if SPI is present (Requirement 3, 5)', async () => {
      const mockApp = appFactory({
        data_classification: { spi: true, pii: false, pci: false, financial: false }
      });
      
      const insertMock = vi.fn().mockReturnValue({
        select: vi.fn().mockReturnValue({
          single: vi.fn().mockResolvedValue({ data: { ...mockApp, inherent_risk_level: 'High' }, error: null })
        })
      });

      supabase.from.mockImplementation((table) => {
        if (table === 'business_applications') return { insert: insertMock };
        if (table === 'inherent_risk_assessments') return { insert: vi.fn() };
        return {};
      });

      const result = await businessInitService.createApplication(mockApp, 'org-123');
      
      expect(result.inherent_risk_level).toBe('High');
      expect(insertMock).toHaveBeenCalledWith(expect.objectContaining({
        inherent_risk_level: 'High'
      }));
    });

    it('should trigger Critical level for Core apps with High risk indicators (Requirement 5)', async () => {
      const mockApp = appFactory({
        type: 'Core',
        data_classification: { pci: true } // PCI triggers High, + Core = Critical
      });

      const insertMock = vi.fn().mockReturnValue({
        select: vi.fn().mockReturnValue({
          single: vi.fn().mockResolvedValue({ data: { ...mockApp, inherent_risk_level: 'Critical' }, error: null })
        })
      });

      supabase.from.mockImplementation((table) => {
        if (table === 'business_applications') return { insert: insertMock };
        if (table === 'inherent_risk_assessments') return { insert: vi.fn() };
        return {};
      });

      await businessInitService.createApplication(mockApp, 'org-123');
      
      expect(insertMock).toHaveBeenCalledWith(expect.objectContaining({
        inherent_risk_level: 'Critical'
      }));
    });
  });

  describe('updateAssessment (FAIR Model & Risk Scoring)', () => {
    it('should calculate FAIR ALE correctly based on impact factors (Requirement 6, 11)', async () => {
      const scores = {
        confidentiality_score: 4,
        integrity_score: 2,
        availability_score: 1,
        regulatory_impact: 4,
        operational_impact: 1,
        financial_impact: 3
      };

      // Base $50k * Conf(4) * Reg(4) * Fin(3) = 50,000 * 48 = 2,400,000
      // Logic from service: baseValue * (conf * reg * fin)
      const expectedALE = 50000 * 4 * 4 * 3;

      const updateMock = vi.fn().mockReturnValue({ eq: vi.fn().mockResolvedValue({ error: null }) });
      
      supabase.from.mockImplementation((table) => {
        if (table === 'inherent_risk_assessments') return { update: updateMock };
        if (table === 'business_applications') return { update: vi.fn().mockReturnValue({ eq: vi.fn() }) };
        return {};
      });

      await businessInitService.updateAssessment('app-123', scores);

      expect(updateMock).toHaveBeenCalledWith(expect.objectContaining({
        fair_ale_estimate: expectedALE
      }));
    });

    it('should auto-gate application status to "Under Review" if risk is Critical (Requirement 7)', async () => {
      const scores = {
        confidentiality_score: 5,
        integrity_score: 5,
        availability_score: 5,
        regulatory_impact: 5,
        operational_impact: 5,
        financial_impact: 5
      };
      // Weighted avg will be 5 -> Critical

      const appUpdateMock = vi.fn().mockReturnValue({ eq: vi.fn().mockResolvedValue({ error: null }) });
      
      supabase.from.mockImplementation((table) => {
        if (table === 'inherent_risk_assessments') return { update: vi.fn().mockReturnValue({ eq: vi.fn() }) };
        if (table === 'business_applications') return { update: appUpdateMock };
        return {};
      });

      await businessInitService.updateAssessment('app-123', scores);

      expect(appUpdateMock).toHaveBeenCalledWith(expect.objectContaining({
        inherent_risk_level: 'Critical',
        status: 'Under Review'
      }));
    });
  });

  describe('getRegulatoryMapping (Requirement 4, 10)', () => {
    it('should map DPDP regulations correctly', async () => {
      const mappings = await businessInitService.getRegulatoryMapping(['DPDP Act 2023']);
      expect(mappings).toContainEqual(expect.objectContaining({ code: 'DPDP-S3' }));
    });
    
    it('should map RBI regulations correctly', async () => {
      const mappings = await businessInitService.getRegulatoryMapping(['RBI Cyber Security Framework']);
      expect(mappings).toContainEqual(expect.objectContaining({ code: 'RBI-CS-12' }));
    });
  });
});
