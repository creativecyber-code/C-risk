
import { supabase } from '@/lib/customSupabaseClient';
import { SYSTEM_TEMPLATES } from '@/data/systemTemplates';
import { threatModelService } from './threatModelService';

export const templateService = {
  /**
   * Get all templates (System + Custom for the user's org)
   */
  async getTemplates() {
    // 1. Get system templates
    const systemTemplates = SYSTEM_TEMPLATES.map(t => ({
      ...t,
      source: 'SYSTEM',
      is_public: true
    }));

    // 2. Get custom templates from DB
    // We assume templates are stored in threat_models table with is_template = true
    const { data: { user } } = await supabase.auth.getUser();
    
    let customTemplates = [];
    
    if (user) {
      try {
        const orgId = await threatModelService.ensureUserSetup();

        const { data, error } = await supabase
          .from('threat_models')
          .select('*')
          .eq('org_id', orgId)
          .eq('is_template', true)
          .order('created_at', { ascending: false });

        if (error) {
          console.error('Error fetching custom templates:', error);
        } else {
          customTemplates = data || [];
        }
      } catch (err) {
        console.warn("Could not fetch custom templates (user might not be fully set up):", err);
      }
    }

    // Map custom templates to match system template structure roughly
    const formattedCustom = customTemplates.map(t => ({
      id: t.id,
      name: t.name,
      description: t.description || '',
      industry: t.industry || 'Other',
      complexity: t.complexity || 'Unknown',
      threatCount: 0, // Would need to calculate or store this
      previewImage: t.preview_image || 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=300&h=200',
      source: 'CUSTOM',
      is_public: t.is_public
    }));

    // 3. Fetch analytics for all templates to sort/display popularity
    // We do this in bulk or individually safely
    const allTemplates = [...systemTemplates, ...formattedCustom];
    
    // Optional: Enhance with usage stats if needed, but do it safely
    // For now, just return the combined list
    return allTemplates;
  },

  /**
   * Get full details for a specific template
   */
  async getTemplateDetails(templateId) {
    // Check system templates first
    const systemTpl = SYSTEM_TEMPLATES.find(t => t.id === templateId);
    if (systemTpl) return systemTpl;

    // Check custom templates
    try {
      // Re-use loadModel which fetches elements/flows
      const data = await threatModelService.loadModel(templateId);
      return {
        id: data.model.id,
        name: data.model.name,
        description: data.model.description,
        industry: data.model.industry,
        complexity: data.model.complexity,
        elements: data.elements,
        connections: data.connections,
        source: 'CUSTOM',
        useCases: [],
        hotspots: [],
        previewImage: data.model.preview_image
      };
    } catch (e) {
      console.error("Failed to load template details", e);
      throw new Error("Template not found");
    }
  },

  /**
   * Increment usage count for a template safely
   */
  async trackTemplateUsage(templateId) {
    try {
      // Check if record exists
      const { data: existing, error: fetchError } = await supabase
        .from('template_analytics')
        .select('id, usage_count')
        .eq('template_id', templateId)
        .maybeSingle(); // Use maybeSingle to avoid PGRST116

      if (fetchError) throw fetchError;

      if (existing) {
        // Update
        await supabase
          .from('template_analytics')
          .update({ 
            usage_count: (existing.usage_count || 0) + 1,
            last_used_at: new Date().toISOString()
          })
          .eq('id', existing.id);
      } else {
        // Insert new record
        await supabase
          .from('template_analytics')
          .insert({
            id: crypto.randomUUID(),
            template_id: templateId,
            usage_count: 1,
            last_used_at: new Date().toISOString()
          });
      }
    } catch (err) {
      console.warn("Failed to track template usage:", err);
      // Don't block the user flow for analytics errors
    }
  },

  /**
   * Create a new threat model based on a template
   */
  async useTemplate(templateId, newModelName) {
    const templateData = await this.getTemplateDetails(templateId);
    
    // Track usage asynchronously
    this.trackTemplateUsage(templateId);
    
    // 1. Create new empty model
    const newModel = await threatModelService.createModel(newModelName, templateData.description);
    
    // 2. Save template elements/connections to new model
    // We need to regenerate IDs to avoid conflicts if used multiple times (though UUIDs in DB handle this, 
    // system template IDs are simplified strings like 'el-1')
    
    const idMap = {};
    
    const newElements = (templateData.elements || []).map(el => {
      const newId = `${el.type}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      idMap[el.id] = newId;
      return { ...el, id: newId };
    });

    const newConnections = (templateData.connections || []).map(c => ({
      ...c,
      id: `conn-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      from: idMap[c.from] || c.from,
      to: idMap[c.to] || c.to
    }));

    await threatModelService.saveModel(newModel.id, {
      elements: newElements,
      connections: newConnections
    });

    return newModel.id;
  },

  /**
   * Save an existing model as a custom template
   */
  async saveAsTemplate(modelId, metadata) {
    const { error } = await supabase
      .from('threat_models')
      .update({
        is_template: true,
        industry: metadata.industry,
        complexity: metadata.complexity,
        preview_image: metadata.previewImage
      })
      .eq('id', modelId);
    
    if (error) throw error;
  }
};
