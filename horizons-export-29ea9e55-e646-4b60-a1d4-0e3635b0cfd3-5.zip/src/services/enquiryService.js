
import { supabase } from '@/lib/customSupabaseClient';

export const enquiryService = {
  async submitEnquiry(data) {
    const { error } = await supabase
      .from('enquiries')
      .insert([data]);

    if (error) throw error;
    return true;
  },

  async getAllEnquiries() {
    const { data, error } = await supabase
      .from('enquiries')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  async deleteEnquiry(id) {
    const { error } = await supabase
      .from('enquiries')
      .delete()
      .eq('id', id);

    if (error) throw error;
    return true;
  }
};
