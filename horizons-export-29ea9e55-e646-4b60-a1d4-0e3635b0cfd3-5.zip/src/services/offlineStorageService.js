
// Fallback data loading from localStorage (Requirement 15)

const STORAGE_PREFIX = 'cc_offline_';

export const offlineStorageService = {
  save(key, data) {
    try {
      localStorage.setItem(`${STORAGE_PREFIX}${key}`, JSON.stringify({
        timestamp: Date.now(),
        data
      }));
    } catch (e) {
      console.warn('Storage quota exceeded', e);
    }
  },

  load(key, maxAgeMs = 24 * 60 * 60 * 1000) { // Default 24h cache
    try {
      const item = localStorage.getItem(`${STORAGE_PREFIX}${key}`);
      if (!item) return null;

      const parsed = JSON.parse(item);
      if (Date.now() - parsed.timestamp > maxAgeMs) {
        localStorage.removeItem(`${STORAGE_PREFIX}${key}`);
        return null;
      }
      return parsed.data;
    } catch (e) {
      return null;
    }
  },

  clear() {
    Object.keys(localStorage).forEach(key => {
      if (key.startsWith(STORAGE_PREFIX)) {
        localStorage.removeItem(key);
      }
    });
  }
};
