
import { supabase } from '@/lib/customSupabaseClient';

/**
 * Service to handle Platform Administration tasks:
 * - System Health Checks
 * - Report Data Aggregation
 */
export const platformService = {
  
  /**
   * Performs real-time checks on system components
   */
  async getSystemHealth() {
    const start = performance.now();
    let dbStatus = 'unknown';
    let dbLatency = 0;
    let error = null;

    try {
      // 1. Database Connectivity & Latency
      const { data, error: dbErr } = await supabase.from('organizations').select('count', { count: 'exact', head: true });
      const end = performance.now();
      dbLatency = Math.round(end - start);
      
      if (dbErr) throw dbErr;
      dbStatus = 'healthy';

    } catch (err) {
      console.error('Health Check Failed:', err);
      dbStatus = 'degraded';
      error = err.message;
    }

    // 2. Error Rate (Last 24 Hours)
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    const { count: errorCount } = await supabase
      .from('system_logs')
      .select('*', { count: 'exact', head: true })
      .eq('level', 'error')
      .gte('timestamp', yesterday.toISOString());

    // 3. Storage Check (List Buckets)
    const { data: buckets, error: storageErr } = await supabase.storage.listBuckets();
    const storageStatus = storageErr ? 'degraded' : 'healthy';

    return {
      database: { status: dbStatus, latency: dbLatency, message: error },
      storage: { status: storageStatus, count: buckets?.length || 0 },
      // Simulating API status based on DB connection for now
      api: { status: dbStatus === 'healthy' ? 'healthy' : 'degraded', latency: Math.max(10, Math.round(dbLatency * 0.8)) }, 
      errors: { count: errorCount || 0, status: (errorCount || 0) > 50 ? 'warning' : 'healthy' },
      timestamp: new Date().toISOString()
    };
  },

  /**
   * Aggregates data for the Platform Status Report
   */
  async getReportData() {
    try {
      // Parallel fetch for efficiency
      const [
        { count: tenantCount },
        { count: userCount }, // This might be an approximation depending on RLS
        { count: logsCount },
        health
      ] = await Promise.all([
        supabase.from('organizations').select('*', { count: 'exact', head: true }),
        supabase.from('platform_staff').select('*', { count: 'exact', head: true }),
        supabase.from('system_logs').select('*', { count: 'exact', head: true }),
        this.getSystemHealth()
      ]);

      return {
        generatedAt: new Date(),
        metrics: {
          totalTenants: tenantCount || 0,
          totalStaff: userCount || 0,
          totalLogs: logsCount || 0,
        },
        health,
        status: 'generated'
      };
    } catch (error) {
      console.error('Report Generation Error:', error);
      throw new Error('Failed to aggregate platform data');
    }
  }
};
