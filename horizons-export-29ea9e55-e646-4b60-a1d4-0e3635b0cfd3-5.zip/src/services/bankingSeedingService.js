
import { supabase } from '@/lib/customSupabaseClient';
import { SYSTEM_TEMPLATES } from '@/data/systemTemplates';
import { threatModelService } from './threatModelService';

const BANKING_SAMPLE_DATA = [
  {
    templateId: 'tpl-bank-digital-001',
    name: "Mobile Banking App 2024",
    description: "Next-gen retail banking mobile application with integrated UPI, wallet, and investment features.",
    threats: [
      { title: "Insecure Data Storage in SQLite", category: "Storage", tef: 4, vuln: 0.8, loss: 800000, risk: 85, controls: ["Encrypted Database (SQLCipher)", "Keystore Integration"] },
      { title: "Weak SSL Pinning Implementation", category: "Network", tef: 3, vuln: 0.6, loss: 1200000, risk: 78, controls: ["Certificate Pinning", "Network Security Config"] },
      { title: "Reverse Engineering & Tampering", category: "Code", tef: 5, vuln: 0.9, loss: 500000, risk: 72, controls: ["Obfuscation (ProGuard/R8)", "Root Detection"] },
      { title: "Improper Session Handling", category: "Auth", tef: 3, vuln: 0.5, loss: 900000, risk: 88, controls: ["Short Session Timeout", "Secure Token Storage"] },
      { title: "Biometric Authentication Bypass", category: "Auth", tef: 2, vuln: 0.4, loss: 1500000, risk: 90, controls: ["Crypto-backed Biometrics", "Server-side Validation"] },
      { title: "API Key Leakage in Binary", category: "Config", tef: 5, vuln: 0.9, loss: 200000, risk: 65, controls: ["NDK Storage", "Runtime Retrieval"] },
      { title: "Keyboard Cache Data Leakage", category: "Privacy", tef: 4, vuln: 0.7, loss: 100000, risk: 45, controls: ["Disable Custom Keyboards", "InputType Sensitive"] },
      { title: "Screen Overlay Attacks (Cloaking)", category: "UI", tef: 3, vuln: 0.6, loss: 400000, risk: 60, controls: ["Filter Touches When Obscured"] },
      { title: "Intent Injection Vulnerabilities", category: "IPC", tef: 2, vuln: 0.5, loss: 300000, risk: 50, controls: ["Exported=False", "Permission Checks"] },
      { title: "Deep Link Phishing", category: "Navigation", tef: 4, vuln: 0.7, loss: 600000, risk: 75, controls: ["App Links / Universal Links", "Input Validation"] }
    ]
  },
  {
    templateId: 'tpl-bank-cbs-001',
    name: "Core Banking System Integration",
    description: "Legacy CBS modernization layer exposing core ledgers to digital channels via ESB.",
    threats: [
      { title: "Direct Database Access by Insider", category: "Insider", tef: 2, vuln: 0.4, loss: 5000000, risk: 95, controls: ["Database Activity Monitoring (DAM)", "PAM Solutions"] },
      { title: "Unencrypted Database Backups", category: "Storage", tef: 3, vuln: 0.8, loss: 2000000, risk: 82, controls: ["Backup Encryption", "Offsite Storage Security"] },
      { title: "Weak Auth for Internal APIs", category: "Auth", tef: 4, vuln: 0.7, loss: 1000000, risk: 78, controls: ["mTLS for Internal Calls", "Service Mesh Policies"] },
      { title: "Audit Log Tampering", category: "Audit", tef: 2, vuln: 0.5, loss: 3000000, risk: 85, controls: ["WORM Storage for Logs", "Blockchain Audit Trail"] },
      { title: "Batch Job Injection", category: "Integrity", tef: 1, vuln: 0.3, loss: 4000000, risk: 80, controls: ["File Integrity Monitoring", "Digital Signatures"] },
      { title: "Privilege Escalation in CBS", category: "AuthZ", tef: 2, vuln: 0.4, loss: 2500000, risk: 88, controls: ["RBAC Enforcement", "Periodic Access Reviews"] },
      { title: "Sensitive Data in App Logs", category: "Leakage", tef: 5, vuln: 0.9, loss: 500000, risk: 60, controls: ["Log Masking/Redaction", "Structured Logging"] },
      { title: "Unpatched Middleware (WebLogic)", category: "Patching", tef: 4, vuln: 0.8, loss: 3500000, risk: 92, controls: ["Automated Patch Management", "Virtual Patching (WAF)"] },
      { title: "Default Credentials on Servers", category: "Config", tef: 3, vuln: 0.9, loss: 1500000, risk: 70, controls: ["Configuration Hardening", "Credential Scanning"] },
      { title: "SQL Injection in Legacy Modules", category: "Code", tef: 4, vuln: 0.7, loss: 2000000, risk: 85, controls: ["Prepared Statements", "Legacy Code Audit"] }
    ]
  },
  {
    templateId: 'tpl-bank-api-001',
    name: "Open Banking API Platform",
    description: "PSD2-compliant API gateway for third-party providers (TPPs) and fintech partners.",
    threats: [
      { title: "Broken Object Level Auth (BOLA)", category: "API", tef: 5, vuln: 0.8, loss: 1000000, risk: 92, controls: ["Object Ownership Checks", "Randomized IDs"] },
      { title: "Excessive Data Exposure", category: "API", tef: 4, vuln: 0.7, loss: 500000, risk: 75, controls: ["Response Filtering", "Schema Validation"] },
      { title: "Lack of Rate Limiting (DDoS)", category: "Availability", tef: 5, vuln: 0.9, loss: 200000, risk: 65, controls: ["API Gateway Rate Limits", "Throttling per Client"] },
      { title: "JWT Token Weakness (None Alg)", category: "Auth", tef: 3, vuln: 0.6, loss: 800000, risk: 80, controls: ["Strong Signing Algorithms", "Key Rotation"] },
      { title: "Mass Assignment", category: "API", tef: 3, vuln: 0.5, loss: 600000, risk: 70, controls: ["Input DTOs", "Field Whitelisting"] },
      { title: "Injection (NoSQL/SQL)", category: "Code", tef: 4, vuln: 0.6, loss: 1500000, risk: 85, controls: ["Input Sanitization", "Parameterization"] },
      { title: "Improper Assets Management", category: "Ops", tef: 3, vuln: 0.7, loss: 300000, risk: 55, controls: ["API Inventory", "Deprecation Policy"] },
      { title: "Broken User Authentication", category: "Auth", tef: 2, vuln: 0.4, loss: 1200000, risk: 88, controls: ["OAuth 2.1 / OIDC", "MFA"] },
      { title: "Insufficient Logging", category: "Audit", tef: 4, vuln: 0.8, loss: 400000, risk: 50, controls: ["Centralized Logging", "Audit Trails"] },
      { title: "Security Misconfiguration (CORS)", category: "Config", tef: 5, vuln: 0.8, loss: 300000, risk: 60, controls: ["Strict CORS Policies", "Security Headers"] }
    ]
  },
  {
    templateId: 'tpl-bank-pay-001',
    name: "Payment Processing System",
    description: "High-speed switch for IMPS/NEFT/RTGS transactions handling millions of dollars daily.",
    threats: [
      { title: "Replay Attacks", category: "Network", tef: 3, vuln: 0.5, loss: 500000, risk: 75, controls: ["Nonce / Timestamps", "Unique Transaction IDs"] },
      { title: "Message Tampering (MitB)", category: "Integrity", tef: 2, vuln: 0.4, loss: 2000000, risk: 90, controls: ["Message Signing (HMAC)", "E2E Encryption"] },
      { title: "Double Spending", category: "Logic", tef: 2, vuln: 0.3, loss: 1000000, risk: 85, controls: ["Atomic Transactions", "Idempotency Keys"] },
      { title: "Rounding Error Exploits", category: "Logic", tef: 1, vuln: 0.2, loss: 200000, risk: 40, controls: ["High Precision Arithmetic", "Code Review"] },
      { title: "Race Conditions", category: "Concurrency", tef: 3, vuln: 0.5, loss: 800000, risk: 82, controls: ["Database Locking", "Transaction Isolation"] },
      { title: "HSM Misconfiguration", category: "Crypto", tef: 1, vuln: 0.2, loss: 5000000, risk: 95, controls: ["Dual Control", "Regular Audits"] },
      { title: "Weak Encryption Keys (DES)", category: "Crypto", tef: 2, vuln: 0.8, loss: 3000000, risk: 88, controls: ["AES-256 GCM", "Key Lifecycle Management"] },
      { title: "XXE in ISO 8583/XML", category: "Code", tef: 3, vuln: 0.6, loss: 1500000, risk: 80, controls: ["Disable External Entities", "XML Parser Hardening"] },
      { title: "Fraud Detection Bypass", category: "Logic", tef: 3, vuln: 0.5, loss: 1200000, risk: 85, controls: ["AI/ML Fraud Models", "Rule-based Engine"] },
      { title: "Settlement File Tampering", category: "Integrity", tef: 2, vuln: 0.4, loss: 2500000, risk: 92, controls: ["PGP Encryption", "SFTP with SSH Keys"] }
    ]
  },
  {
    templateId: 'tpl-bank-lms-001',
    name: "Customer Onboarding Platform",
    description: "Digital KYC and loan origination workflow handling sensitive PII and credit data.",
    threats: [
      { title: "Deepfake Identity Spoofing", category: "Fraud", tef: 4, vuln: 0.6, loss: 500000, risk: 85, controls: ["Liveness Detection", "Manual Verification"] },
      { title: "OCR Injection", category: "Input", tef: 2, vuln: 0.3, loss: 200000, risk: 50, controls: ["Input Sanitization", "Sandboxed Processing"] },
      { title: "Document Metadata Leakage", category: "Privacy", tef: 3, vuln: 0.7, loss: 100000, risk: 40, controls: ["Metadata Stripping", "Secure Viewers"] },
      { title: "Insecure S3 Buckets", category: "Cloud", tef: 4, vuln: 0.8, loss: 1500000, risk: 90, controls: ["Block Public Access", "Bucket Policies"] },
      { title: "PII Exposure in URLs", category: "Privacy", tef: 5, vuln: 0.9, loss: 800000, risk: 75, controls: ["POST Requests", "URL Rewriting"] },
      { title: "Cross-Site Scripting (Reflected)", category: "Web", tef: 5, vuln: 0.7, loss: 300000, risk: 65, controls: ["CSP", "Output Encoding"] },
      { title: "IDOR on Documents", category: "AuthZ", tef: 4, vuln: 0.6, loss: 1200000, risk: 88, controls: ["Indirect References", "Access Control Checks"] },
      { title: "Weak Password Policy", category: "Auth", tef: 3, vuln: 0.5, loss: 400000, risk: 60, controls: ["Complexity Requirements", "Breached Password Check"] },
      { title: "Session Fixation", category: "Auth", tef: 2, vuln: 0.4, loss: 600000, risk: 70, controls: ["Regenerate Session ID", "Secure Cookies"] },
      { title: "Malicious File Upload (RCE)", category: "Upload", tef: 3, vuln: 0.5, loss: 2000000, risk: 92, controls: ["File Type Validation", "Antivirus Scanning"] }
    ]
  },
  {
    templateId: 'tpl-bank-tpp-001',
    name: "FinTech Partner Integration",
    description: "Integration layer for co-branded cards and BNPL partners.",
    threats: [
      { title: "Insecure Webhooks", category: "API", tef: 4, vuln: 0.7, loss: 600000, risk: 80, controls: ["HMAC Signature Verification", "IP Whitelisting"] },
      { title: "Third-party Data Leakage", category: "Supply Chain", tef: 3, vuln: 0.6, loss: 1500000, risk: 85, controls: ["Data Minimization", "Vendor Risk Assessment"] },
      { title: "Supply Chain Compromise", category: "Supply Chain", tef: 2, vuln: 0.5, loss: 3000000, risk: 90, controls: ["SBOM Analysis", "Continuous Monitoring"] },
      { title: "Over-permissive OAuth Scopes", category: "AuthZ", tef: 4, vuln: 0.8, loss: 800000, risk: 75, controls: ["Least Privilege Scopes", "Consent Screens"] },
      { title: "Lack of Mutual TLS", category: "Network", tef: 3, vuln: 0.6, loss: 1000000, risk: 82, controls: ["Mandatory mTLS", "Cert Rotation"] },
      { title: "SSRF via Callbacks", category: "Network", tef: 3, vuln: 0.5, loss: 1200000, risk: 88, controls: ["Egress Filtering", "Input Validation"] },
      { title: "Shared Secret Exposure", category: "Config", tef: 4, vuln: 0.8, loss: 900000, risk: 78, controls: ["Secrets Management", "Rotation Policy"] },
      { title: "API Versioning Attacks", category: "API", tef: 2, vuln: 0.4, loss: 400000, risk: 60, controls: ["Deprecation Sunset", "Version Enforced"] },
      { title: "DoS via Partner API", category: "Availability", tef: 4, vuln: 0.7, loss: 300000, risk: 70, controls: ["Circuit Breakers", "Rate Limiting"] },
      { title: "Data Validation Failure", category: "Input", tef: 4, vuln: 0.6, loss: 500000, risk: 65, controls: ["Strict Schema Validation", "Sanitization"] }
    ]
  },
  {
    templateId: 'tpl-bank-ai-001',
    name: "Fraud Detection AI System",
    description: "ML pipeline for real-time transaction fraud scoring.",
    threats: [
      { title: "Model Inversion Attack", category: "Privacy", tef: 2, vuln: 0.5, loss: 1000000, risk: 85, controls: ["Differential Privacy", "Output Truncation"] },
      { title: "Model Poisoning", category: "Integrity", tef: 2, vuln: 0.4, loss: 2000000, risk: 90, controls: ["Training Data Sanitization", "Anomaly Detection"] },
      { title: "Adversarial Examples", category: "Evasion", tef: 3, vuln: 0.6, loss: 1500000, risk: 88, controls: ["Adversarial Training", "Ensemble Models"] },
      { title: "Model Extraction", category: "Theft", tef: 3, vuln: 0.5, loss: 800000, risk: 75, controls: ["Query Rate Limiting", "Watermarking"] },
      { title: "Membership Inference", category: "Privacy", tef: 2, vuln: 0.5, loss: 900000, risk: 80, controls: ["Regularization", "Privacy Audits"] },
      { title: "Bias Exploitation", category: "Ethics", tef: 3, vuln: 0.7, loss: 2000000, risk: 92, controls: ["Fairness Metrics", "Bias Testing"] },
      { title: "Lack of Explainability", category: "Compliance", tef: 5, vuln: 0.9, loss: 3000000, risk: 95, controls: ["SHAP/LIME", "Model Cards"] },
      { title: "Insecure ML Pipeline Access", category: "Auth", tef: 3, vuln: 0.6, loss: 1200000, risk: 82, controls: ["RBAC", "VPC Isolation"] },
      { title: "Pickle/Deserialization Attacks", category: "Code", tef: 2, vuln: 0.5, loss: 1500000, risk: 85, controls: ["Safe Formats (ONNX)", "Input Scanning"] },
      { title: "Training Data Leakage", category: "Leakage", tef: 4, vuln: 0.8, loss: 1000000, risk: 88, controls: ["DLP", "Access Controls"] }
    ]
  }
];

export const bankingSeedingService = {
  async seedBankingModels() {
    try {
      const orgId = await threatModelService.ensureUserSetup();
      const { data: { user } } = await supabase.auth.getUser();

      const results = { created: 0, errors: 0 };

      for (const modelData of BANKING_SAMPLE_DATA) {
        // 1. Get Template Details
        const template = SYSTEM_TEMPLATES.find(t => t.id === modelData.templateId);
        if (!template) {
          console.error(`Template ${modelData.templateId} not found`);
          continue;
        }

        // 2. Create Model
        const { data: model, error: modelError } = await supabase
          .from('threat_models')
          .insert({
            org_id: orgId,
            name: modelData.name,
            description: modelData.description,
            industry: 'Finance',
            complexity: 'Advanced',
            preview_image: template.previewImage,
            created_by: user.id
          })
          .select()
          .single();

        if (modelError) {
            console.error("Failed to create model", modelError);
            results.errors++;
            continue;
        }

        // 3. Create Elements & Flows (Copied logic from threatModelService.saveModel but customized for IDs)
        // We generate new IDs for everything to ensure uniqueness
        const idMap = {};
        
        const newElements = template.elements.map(el => {
            const newId = `${el.type}-${Math.random().toString(36).substr(2, 9)}`;
            idMap[el.id] = newId;
            return {
                id: newId,
                model_id: model.id,
                type: el.type,
                x: el.x,
                y: el.y,
                label: el.label,
                metadata: {}
            };
        });

        // Separate boundaries
        const threatElements = newElements.filter(e => e.type !== 'boundary');
        const boundaries = newElements.filter(e => e.type === 'boundary');

        if (threatElements.length) {
             await supabase.from('threat_elements').insert(threatElements);
        }
        if (boundaries.length) {
             await supabase.from('trust_boundaries').insert(boundaries.map(b => ({
                 id: b.id,
                 model_id: model.id,
                 x: b.x,
                 y: b.y,
                 label: b.label
             })));
        }

        const newFlows = template.connections.map(c => ({
            id: `flow-${Math.random().toString(36).substr(2, 9)}`,
            model_id: model.id,
            from_element_id: idMap[c.from] || c.from,
            to_element_id: idMap[c.to] || c.to,
            label: c.label || ''
        }));

        if (newFlows.length) {
            await supabase.from('data_flows').insert(newFlows);
        }

        // 4. Create Threats (Assessments) & Controls
        for (const threat of modelData.threats) {
             // Create Threat
             const { data: assessment, error: threatError } = await supabase
                .from('threat_assessments')
                .insert({
                    model_id: model.id,
                    title: threat.title,
                    category: threat.category,
                    threat_source_id: 'manual',
                    status: 'Open',
                    risk_score: threat.risk,
                    impact_score: threat.loss > 1000000 ? 5 : 3, // simplified mapping
                    likelihood_score: threat.tef,
                    tef: threat.tef,
                    vulnerability_percentage: threat.vuln * 100,
                    loss_magnitude: threat.loss,
                    justification: `Automated risk assessment based on ${template.name} architecture.`
                })
                .select()
                .single();
            
            if (threatError || !assessment) continue;

            // Create Controls and Link
            for (const controlName of threat.controls) {
                // Check if control exists or create new
                // For simplicity in this demo, we create new ones to ensure they appear
                const controlCode = `CTRL-${Math.floor(Math.random() * 10000)}`;
                
                const { data: control } = await supabase
                    .from('internal_controls')
                    .insert({
                        org_id: orgId,
                        code: controlCode,
                        name: controlName,
                        description: `Mitigation for ${threat.title}`,
                        status: 'Draft',
                        test_frequency: 'Annual',
                        owner_id: user.id
                    })
                    .select()
                    .single();

                if (control) {
                    await supabase
                        .from('internal_control_risks')
                        .insert({
                            internal_control_id: control.id,
                            threat_assessment_id: assessment.id
                        });
                }
            }
        }

        results.created++;
      }

      return results;
    } catch (e) {
      console.error("Seeding failed", e);
      throw e;
    }
  }
};
