
// Requirement 20: CI/CD Integration Script
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

console.log("Starting Test Suite Execution...");

// Execute Vitest and capture output
exec('npx vitest run --reporter=json --outputFile=test-results.json', (error, stdout, stderr) => {
    if (error) {
        console.error(`Exec error: ${error}`);
    }
    
    console.log("Tests Completed.");
    
    // Parse Results
    const resultsPath = path.resolve(__dirname, '../test-results.json');
    if (fs.existsSync(resultsPath)) {
        const results = JSON.parse(fs.readFileSync(resultsPath, 'utf8'));
        
        const summary = {
            total: results.numTotalTests,
            passed: results.numPassedTests,
            failed: results.numFailedTests,
            timestamp: new Date().toISOString()
        };
        
        console.log("--- TEST SUMMARY ---");
        console.table(summary);
        
        // Generate simple HTML report
        const html = `
            <html>
            <body>
                <h1>Test Execution Report</h1>
                <p>Date: ${summary.timestamp}</p>
                <div style="padding: 20px; background: ${summary.failed > 0 ? '#fee' : '#eef'};">
                    <h2>Status: ${summary.failed > 0 ? 'FAILED' : 'PASSED'}</h2>
                    <p>Total: ${summary.total}</p>
                    <p>Passed: ${summary.passed}</p>
                    <p>Failed: ${summary.failed}</p>
                </div>
            </body>
            </html>
        `;
        
        fs.writeFileSync(path.resolve(__dirname, '../test-report.html'), html);
        console.log("Report generated at test-report.html");
        
        if (summary.failed > 0) process.exit(1);
    } else {
        console.log("No JSON results found. Ensure vitest ran correctly.");
    }
});
